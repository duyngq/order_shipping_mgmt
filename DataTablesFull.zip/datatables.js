/*
 * This combined file was created by the DataTables downloader builder:
 *   https://datatables.net/download
 *
 * To rebuild or modify this file with the latest versions of the included
 * software please visit:
 *   https://datatables.net/download/#dt/dt-1.10.16/e-1.6.5/b-1.4.2/b-print-1.4.2/r-2.2.0
 *
 * Included libraries:
 *   DataTables 1.10.16, Editor 1.6.5, Buttons 1.4.2, Print view 1.4.2, Responsive 2.2.0
 */

/*! DataTables 1.10.16
 * ©2008-2017 SpryMedia Ltd - datatables.net/license
 */

/**
 * @summary     DataTables
 * @description Paginate, search and order HTML tables
 * @version     1.10.16
 * @file        jquery.dataTables.js
 * @author      SpryMedia Ltd
 * @contact     www.datatables.net
 * @copyright   Copyright 2008-2017 SpryMedia Ltd.
 *
 * This source file is free software, available under the following license:
 *   MIT license - http://datatables.net/license
 *
 * This source file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the license files for details.
 *
 * For details please refer to: http://www.datatables.net
 */

/*jslint evil: true, undef: true, browser: true */
/*globals $,require,jQuery,define,_selector_run,_selector_opts,_selector_first,_selector_row_indexes,_ext,_Api,_api_register,_api_registerPlural,_re_new_lines,_re_html,_re_formatted_numeric,_re_escape_regex,_empty,_intVal,_numToDecimal,_isNumber,_isHtml,_htmlNumeric,_pluck,_pluck_order,_range,_stripHtml,_unique,_fnBuildAjax,_fnAjaxUpdate,_fnAjaxParameters,_fnAjaxUpdateDraw,_fnAjaxDataSrc,_fnAddColumn,_fnColumnOptions,_fnAdjustColumnSizing,_fnVisibleToColumnIndex,_fnColumnIndexToVisible,_fnVisbleColumns,_fnGetColumns,_fnColumnTypes,_fnApplyColumnDefs,_fnHungarianMap,_fnCamelToHungarian,_fnLanguageCompat,_fnBrowserDetect,_fnAddData,_fnAddTr,_fnNodeToDataIndex,_fnNodeToColumnIndex,_fnGetCellData,_fnSetCellData,_fnSplitObjNotation,_fnGetObjectDataFn,_fnSetObjectDataFn,_fnGetDataMaster,_fnClearTable,_fnDeleteIndex,_fnInvalidate,_fnGetRowElements,_fnCreateTr,_fnBuildHead,_fnDrawHead,_fnDraw,_fnReDraw,_fnAddOptionsHtml,_fnDetectHeader,_fnGetUniqueThs,_fnFeatureHtmlFilter,_fnFilterComplete,_fnFilterCustom,_fnFilterColumn,_fnFilter,_fnFilterCreateSearch,_fnEscapeRegex,_fnFilterData,_fnFeatureHtmlInfo,_fnUpdateInfo,_fnInfoMacros,_fnInitialise,_fnInitComplete,_fnLengthChange,_fnFeatureHtmlLength,_fnFeatureHtmlPaginate,_fnPageChange,_fnFeatureHtmlProcessing,_fnProcessingDisplay,_fnFeatureHtmlTable,_fnScrollDraw,_fnApplyToChildren,_fnCalculateColumnWidths,_fnThrottle,_fnConvertToWidth,_fnGetWidestNode,_fnGetMaxLenString,_fnStringToCss,_fnSortFlatten,_fnSort,_fnSortAria,_fnSortListener,_fnSortAttachListener,_fnSortingClasses,_fnSortData,_fnSaveState,_fnLoadState,_fnSettingsFromNode,_fnLog,_fnMap,_fnBindAction,_fnCallbackReg,_fnCallbackFire,_fnLengthOverflow,_fnRenderer,_fnDataSource,_fnRowAttributes*/

(function( factory ) {
	"use strict";

	if ( typeof define === 'function' && define.amd ) {
		// AMD
		define( ['jquery'], function ( $ ) {
			return factory( $, window, document );
		} );
	}
	else if ( typeof exports === 'object' ) {
		// CommonJS
		module.exports = function (root, $) {
			if ( ! root ) {
				// CommonJS environments without a window global must pass a
				// root. This will give an error otherwise
				root = window;
			}

			if ( ! $ ) {
				$ = typeof window !== 'undefined' ? // jQuery's factory checks for a global window
					require('jquery') :
					require('jquery')( root );
			}

			return factory( $, root, root.document );
		};
	}
	else {
		// Browser
		factory( jQuery, window, document );
	}
}
(function( $, window, document, undefined ) {
	"use strict";

	/**
	 * DataTables is a plug-in for the jQuery Javascript library. It is a highly
	 * flexible tool, based upon the foundations of progressive enhancement,
	 * which will add advanced interaction controls to any HTML table. For a
	 * full list of features please refer to
	 * [DataTables.net](href="http://datatables.net).
	 *
	 * Note that the `DataTable` object is not a global variable but is aliased
	 * to `jQuery.fn.DataTable` and `jQuery.fn.dataTable` through which it may
	 * be  accessed.
	 *
	 *  @class
	 *  @param {object} [init={}] Configuration object for DataTables. Options
	 *    are defined by {@link DataTable.defaults}
	 *  @requires jQuery 1.7+
	 *
	 *  @example
	 *    // Basic initialisation
	 *    $(document).ready( function {
	 *      $('#example').dataTable();
	 *    } );
	 *
	 *  @example
	 *    // Initialisation with configuration options - in this case, disable
	 *    // pagination and sorting.
	 *    $(document).ready( function {
	 *      $('#example').dataTable( {
	 *        "paginate": false,
	 *        "sort": false
	 *      } );
	 *    } );
	 */
	var DataTable = function ( options )
	{
		/**
		 * Perform a jQuery selector action on the table's TR elements (from the tbody) and
		 * return the resulting jQuery object.
		 *  @param {string|node|jQuery} sSelector jQuery selector or node collection to act on
		 *  @param {object} [oOpts] Optional parameters for modifying the rows to be included
		 *  @param {string} [oOpts.filter=none] Select TR elements that meet the current filter
		 *    criterion ("applied") or all TR elements (i.e. no filter).
		 *  @param {string} [oOpts.order=current] Order of the TR elements in the processed array.
		 *    Can be either 'current', whereby the current sorting of the table is used, or
		 *    'original' whereby the original order the data was read into the table is used.
		 *  @param {string} [oOpts.page=all] Limit the selection to the currently displayed page
		 *    ("current") or not ("all"). If 'current' is given, then order is assumed to be
		 *    'current' and filter is 'applied', regardless of what they might be given as.
		 *  @returns {object} jQuery object, filtered by the given selector.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Highlight every second row
		 *      oTable.$('tr:odd').css('backgroundColor', 'blue');
		 *    } );
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Filter to rows with 'Webkit' in them, add a background colour and then
		 *      // remove the filter, thus highlighting the 'Webkit' rows only.
		 *      oTable.fnFilter('Webkit');
		 *      oTable.$('tr', {"search": "applied"}).css('backgroundColor', 'blue');
		 *      oTable.fnFilter('');
		 *    } );
		 */
		this.$ = function ( sSelector, oOpts )
		{
			return this.api(true).$( sSelector, oOpts );
		};
		
		
		/**
		 * Almost identical to $ in operation, but in this case returns the data for the matched
		 * rows - as such, the jQuery selector used should match TR row nodes or TD/TH cell nodes
		 * rather than any descendants, so the data can be obtained for the row/cell. If matching
		 * rows are found, the data returned is the original data array/object that was used to
		 * create the row (or a generated array if from a DOM source).
		 *
		 * This method is often useful in-combination with $ where both functions are given the
		 * same parameters and the array indexes will match identically.
		 *  @param {string|node|jQuery} sSelector jQuery selector or node collection to act on
		 *  @param {object} [oOpts] Optional parameters for modifying the rows to be included
		 *  @param {string} [oOpts.filter=none] Select elements that meet the current filter
		 *    criterion ("applied") or all elements (i.e. no filter).
		 *  @param {string} [oOpts.order=current] Order of the data in the processed array.
		 *    Can be either 'current', whereby the current sorting of the table is used, or
		 *    'original' whereby the original order the data was read into the table is used.
		 *  @param {string} [oOpts.page=all] Limit the selection to the currently displayed page
		 *    ("current") or not ("all"). If 'current' is given, then order is assumed to be
		 *    'current' and filter is 'applied', regardless of what they might be given as.
		 *  @returns {array} Data for the matched elements. If any elements, as a result of the
		 *    selector, were not TR, TD or TH elements in the DataTable, they will have a null
		 *    entry in the array.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Get the data from the first row in the table
		 *      var data = oTable._('tr:first');
		 *
		 *      // Do something useful with the data
		 *      alert( "First cell is: "+data[0] );
		 *    } );
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Filter to 'Webkit' and get all data for
		 *      oTable.fnFilter('Webkit');
		 *      var data = oTable._('tr', {"search": "applied"});
		 *
		 *      // Do something with the data
		 *      alert( data.length+" rows matched the search" );
		 *    } );
		 */
		this._ = function ( sSelector, oOpts )
		{
			return this.api(true).rows( sSelector, oOpts ).data();
		};
		
		
		/**
		 * Create a DataTables Api instance, with the currently selected tables for
		 * the Api's context.
		 * @param {boolean} [traditional=false] Set the API instance's context to be
		 *   only the table referred to by the `DataTable.ext.iApiIndex` option, as was
		 *   used in the API presented by DataTables 1.9- (i.e. the traditional mode),
		 *   or if all tables captured in the jQuery object should be used.
		 * @return {DataTables.Api}
		 */
		this.api = function ( traditional )
		{
			return traditional ?
				new _Api(
					_fnSettingsFromNode( this[ _ext.iApiIndex ] )
				) :
				new _Api( this );
		};
		
		
		/**
		 * Add a single new row or multiple rows of data to the table. Please note
		 * that this is suitable for client-side processing only - if you are using
		 * server-side processing (i.e. "bServerSide": true), then to add data, you
		 * must add it to the data source, i.e. the server-side, through an Ajax call.
		 *  @param {array|object} data The data to be added to the table. This can be:
		 *    <ul>
		 *      <li>1D array of data - add a single row with the data provided</li>
		 *      <li>2D array of arrays - add multiple rows in a single call</li>
		 *      <li>object - data object when using <i>mData</i></li>
		 *      <li>array of objects - multiple data objects when using <i>mData</i></li>
		 *    </ul>
		 *  @param {bool} [redraw=true] redraw the table or not
		 *  @returns {array} An array of integers, representing the list of indexes in
		 *    <i>aoData</i> ({@link DataTable.models.oSettings}) that have been added to
		 *    the table.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    // Global var for counter
		 *    var giCount = 2;
		 *
		 *    $(document).ready(function() {
		 *      $('#example').dataTable();
		 *    } );
		 *
		 *    function fnClickAddRow() {
		 *      $('#example').dataTable().fnAddData( [
		 *        giCount+".1",
		 *        giCount+".2",
		 *        giCount+".3",
		 *        giCount+".4" ]
		 *      );
		 *
		 *      giCount++;
		 *    }
		 */
		this.fnAddData = function( data, redraw )
		{
			var api = this.api( true );
		
			/* Check if we want to add multiple rows or not */
			var rows = $.isArray(data) && ( $.isArray(data[0]) || $.isPlainObject(data[0]) ) ?
				api.rows.add( data ) :
				api.row.add( data );
		
			if ( redraw === undefined || redraw ) {
				api.draw();
			}
		
			return rows.flatten().toArray();
		};
		
		
		/**
		 * This function will make DataTables recalculate the column sizes, based on the data
		 * contained in the table and the sizes applied to the columns (in the DOM, CSS or
		 * through the sWidth parameter). This can be useful when the width of the table's
		 * parent element changes (for example a window resize).
		 *  @param {boolean} [bRedraw=true] Redraw the table or not, you will typically want to
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable( {
		 *        "sScrollY": "200px",
		 *        "bPaginate": false
		 *      } );
		 *
		 *      $(window).on('resize', function () {
		 *        oTable.fnAdjustColumnSizing();
		 *      } );
		 *    } );
		 */
		this.fnAdjustColumnSizing = function ( bRedraw )
		{
			var api = this.api( true ).columns.adjust();
			var settings = api.settings()[0];
			var scroll = settings.oScroll;
		
			if ( bRedraw === undefined || bRedraw ) {
				api.draw( false );
			}
			else if ( scroll.sX !== "" || scroll.sY !== "" ) {
				/* If not redrawing, but scrolling, we want to apply the new column sizes anyway */
				_fnScrollDraw( settings );
			}
		};
		
		
		/**
		 * Quickly and simply clear a table
		 *  @param {bool} [bRedraw=true] redraw the table or not
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Immediately 'nuke' the current rows (perhaps waiting for an Ajax callback...)
		 *      oTable.fnClearTable();
		 *    } );
		 */
		this.fnClearTable = function( bRedraw )
		{
			var api = this.api( true ).clear();
		
			if ( bRedraw === undefined || bRedraw ) {
				api.draw();
			}
		};
		
		
		/**
		 * The exact opposite of 'opening' a row, this function will close any rows which
		 * are currently 'open'.
		 *  @param {node} nTr the table row to 'close'
		 *  @returns {int} 0 on success, or 1 if failed (can't find the row)
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable;
		 *
		 *      // 'open' an information row when a row is clicked on
		 *      $('#example tbody tr').click( function () {
		 *        if ( oTable.fnIsOpen(this) ) {
		 *          oTable.fnClose( this );
		 *        } else {
		 *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
		 *        }
		 *      } );
		 *
		 *      oTable = $('#example').dataTable();
		 *    } );
		 */
		this.fnClose = function( nTr )
		{
			this.api( true ).row( nTr ).child.hide();
		};
		
		
		/**
		 * Remove a row for the table
		 *  @param {mixed} target The index of the row from aoData to be deleted, or
		 *    the TR element you want to delete
		 *  @param {function|null} [callBack] Callback function
		 *  @param {bool} [redraw=true] Redraw the table or not
		 *  @returns {array} The row that was deleted
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Immediately remove the first row
		 *      oTable.fnDeleteRow( 0 );
		 *    } );
		 */
		this.fnDeleteRow = function( target, callback, redraw )
		{
			var api = this.api( true );
			var rows = api.rows( target );
			var settings = rows.settings()[0];
			var data = settings.aoData[ rows[0][0] ];
		
			rows.remove();
		
			if ( callback ) {
				callback.call( this, settings, data );
			}
		
			if ( redraw === undefined || redraw ) {
				api.draw();
			}
		
			return data;
		};
		
		
		/**
		 * Restore the table to it's original state in the DOM by removing all of DataTables
		 * enhancements, alterations to the DOM structure of the table and event listeners.
		 *  @param {boolean} [remove=false] Completely remove the table from the DOM
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      // This example is fairly pointless in reality, but shows how fnDestroy can be used
		 *      var oTable = $('#example').dataTable();
		 *      oTable.fnDestroy();
		 *    } );
		 */
		this.fnDestroy = function ( remove )
		{
			this.api( true ).destroy( remove );
		};
		
		
		/**
		 * Redraw the table
		 *  @param {bool} [complete=true] Re-filter and resort (if enabled) the table before the draw.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Re-draw the table - you wouldn't want to do it here, but it's an example :-)
		 *      oTable.fnDraw();
		 *    } );
		 */
		this.fnDraw = function( complete )
		{
			// Note that this isn't an exact match to the old call to _fnDraw - it takes
			// into account the new data, but can hold position.
			this.api( true ).draw( complete );
		};
		
		
		/**
		 * Filter the input based on data
		 *  @param {string} sInput String to filter the table on
		 *  @param {int|null} [iColumn] Column to limit filtering to
		 *  @param {bool} [bRegex=false] Treat as regular expression or not
		 *  @param {bool} [bSmart=true] Perform smart filtering or not
		 *  @param {bool} [bShowGlobal=true] Show the input global filter in it's input box(es)
		 *  @param {bool} [bCaseInsensitive=true] Do case-insensitive matching (true) or not (false)
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Sometime later - filter...
		 *      oTable.fnFilter( 'test string' );
		 *    } );
		 */
		this.fnFilter = function( sInput, iColumn, bRegex, bSmart, bShowGlobal, bCaseInsensitive )
		{
			var api = this.api( true );
		
			if ( iColumn === null || iColumn === undefined ) {
				api.search( sInput, bRegex, bSmart, bCaseInsensitive );
			}
			else {
				api.column( iColumn ).search( sInput, bRegex, bSmart, bCaseInsensitive );
			}
		
			api.draw();
		};
		
		
		/**
		 * Get the data for the whole table, an individual row or an individual cell based on the
		 * provided parameters.
		 *  @param {int|node} [src] A TR row node, TD/TH cell node or an integer. If given as
		 *    a TR node then the data source for the whole row will be returned. If given as a
		 *    TD/TH cell node then iCol will be automatically calculated and the data for the
		 *    cell returned. If given as an integer, then this is treated as the aoData internal
		 *    data index for the row (see fnGetPosition) and the data for that row used.
		 *  @param {int} [col] Optional column index that you want the data of.
		 *  @returns {array|object|string} If mRow is undefined, then the data for all rows is
		 *    returned. If mRow is defined, just data for that row, and is iCol is
		 *    defined, only data for the designated cell is returned.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    // Row data
		 *    $(document).ready(function() {
		 *      oTable = $('#example').dataTable();
		 *
		 *      oTable.$('tr').click( function () {
		 *        var data = oTable.fnGetData( this );
		 *        // ... do something with the array / object of data for the row
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Individual cell data
		 *    $(document).ready(function() {
		 *      oTable = $('#example').dataTable();
		 *
		 *      oTable.$('td').click( function () {
		 *        var sData = oTable.fnGetData( this );
		 *        alert( 'The cell clicked on had the value of '+sData );
		 *      } );
		 *    } );
		 */
		this.fnGetData = function( src, col )
		{
			var api = this.api( true );
		
			if ( src !== undefined ) {
				var type = src.nodeName ? src.nodeName.toLowerCase() : '';
		
				return col !== undefined || type == 'td' || type == 'th' ?
					api.cell( src, col ).data() :
					api.row( src ).data() || null;
			}
		
			return api.data().toArray();
		};
		
		
		/**
		 * Get an array of the TR nodes that are used in the table's body. Note that you will
		 * typically want to use the '$' API method in preference to this as it is more
		 * flexible.
		 *  @param {int} [iRow] Optional row index for the TR element you want
		 *  @returns {array|node} If iRow is undefined, returns an array of all TR elements
		 *    in the table's body, or iRow is defined, just the TR element requested.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Get the nodes from the table
		 *      var nNodes = oTable.fnGetNodes( );
		 *    } );
		 */
		this.fnGetNodes = function( iRow )
		{
			var api = this.api( true );
		
			return iRow !== undefined ?
				api.row( iRow ).node() :
				api.rows().nodes().flatten().toArray();
		};
		
		
		/**
		 * Get the array indexes of a particular cell from it's DOM element
		 * and column index including hidden columns
		 *  @param {node} node this can either be a TR, TD or TH in the table's body
		 *  @returns {int} If nNode is given as a TR, then a single index is returned, or
		 *    if given as a cell, an array of [row index, column index (visible),
		 *    column index (all)] is given.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      $('#example tbody td').click( function () {
		 *        // Get the position of the current data from the node
		 *        var aPos = oTable.fnGetPosition( this );
		 *
		 *        // Get the data array for this row
		 *        var aData = oTable.fnGetData( aPos[0] );
		 *
		 *        // Update the data array and return the value
		 *        aData[ aPos[1] ] = 'clicked';
		 *        this.innerHTML = 'clicked';
		 *      } );
		 *
		 *      // Init DataTables
		 *      oTable = $('#example').dataTable();
		 *    } );
		 */
		this.fnGetPosition = function( node )
		{
			var api = this.api( true );
			var nodeName = node.nodeName.toUpperCase();
		
			if ( nodeName == 'TR' ) {
				return api.row( node ).index();
			}
			else if ( nodeName == 'TD' || nodeName == 'TH' ) {
				var cell = api.cell( node ).index();
		
				return [
					cell.row,
					cell.columnVisible,
					cell.column
				];
			}
			return null;
		};
		
		
		/**
		 * Check to see if a row is 'open' or not.
		 *  @param {node} nTr the table row to check
		 *  @returns {boolean} true if the row is currently open, false otherwise
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable;
		 *
		 *      // 'open' an information row when a row is clicked on
		 *      $('#example tbody tr').click( function () {
		 *        if ( oTable.fnIsOpen(this) ) {
		 *          oTable.fnClose( this );
		 *        } else {
		 *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
		 *        }
		 *      } );
		 *
		 *      oTable = $('#example').dataTable();
		 *    } );
		 */
		this.fnIsOpen = function( nTr )
		{
			return this.api( true ).row( nTr ).child.isShown();
		};
		
		
		/**
		 * This function will place a new row directly after a row which is currently
		 * on display on the page, with the HTML contents that is passed into the
		 * function. This can be used, for example, to ask for confirmation that a
		 * particular record should be deleted.
		 *  @param {node} nTr The table row to 'open'
		 *  @param {string|node|jQuery} mHtml The HTML to put into the row
		 *  @param {string} sClass Class to give the new TD cell
		 *  @returns {node} The row opened. Note that if the table row passed in as the
		 *    first parameter, is not found in the table, this method will silently
		 *    return.
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable;
		 *
		 *      // 'open' an information row when a row is clicked on
		 *      $('#example tbody tr').click( function () {
		 *        if ( oTable.fnIsOpen(this) ) {
		 *          oTable.fnClose( this );
		 *        } else {
		 *          oTable.fnOpen( this, "Temporary row opened", "info_row" );
		 *        }
		 *      } );
		 *
		 *      oTable = $('#example').dataTable();
		 *    } );
		 */
		this.fnOpen = function( nTr, mHtml, sClass )
		{
			return this.api( true )
				.row( nTr )
				.child( mHtml, sClass )
				.show()
				.child()[0];
		};
		
		
		/**
		 * Change the pagination - provides the internal logic for pagination in a simple API
		 * function. With this function you can have a DataTables table go to the next,
		 * previous, first or last pages.
		 *  @param {string|int} mAction Paging action to take: "first", "previous", "next" or "last"
		 *    or page number to jump to (integer), note that page 0 is the first page.
		 *  @param {bool} [bRedraw=true] Redraw the table or not
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *      oTable.fnPageChange( 'next' );
		 *    } );
		 */
		this.fnPageChange = function ( mAction, bRedraw )
		{
			var api = this.api( true ).page( mAction );
		
			if ( bRedraw === undefined || bRedraw ) {
				api.draw(false);
			}
		};
		
		
		/**
		 * Show a particular column
		 *  @param {int} iCol The column whose display should be changed
		 *  @param {bool} bShow Show (true) or hide (false) the column
		 *  @param {bool} [bRedraw=true] Redraw the table or not
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Hide the second column after initialisation
		 *      oTable.fnSetColumnVis( 1, false );
		 *    } );
		 */
		this.fnSetColumnVis = function ( iCol, bShow, bRedraw )
		{
			var api = this.api( true ).column( iCol ).visible( bShow );
		
			if ( bRedraw === undefined || bRedraw ) {
				api.columns.adjust().draw();
			}
		};
		
		
		/**
		 * Get the settings for a particular table for external manipulation
		 *  @returns {object} DataTables settings object. See
		 *    {@link DataTable.models.oSettings}
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *      var oSettings = oTable.fnSettings();
		 *
		 *      // Show an example parameter from the settings
		 *      alert( oSettings._iDisplayStart );
		 *    } );
		 */
		this.fnSettings = function()
		{
			return _fnSettingsFromNode( this[_ext.iApiIndex] );
		};
		
		
		/**
		 * Sort the table by a particular column
		 *  @param {int} iCol the data index to sort on. Note that this will not match the
		 *    'display index' if you have hidden data entries
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Sort immediately with columns 0 and 1
		 *      oTable.fnSort( [ [0,'asc'], [1,'asc'] ] );
		 *    } );
		 */
		this.fnSort = function( aaSort )
		{
			this.api( true ).order( aaSort ).draw();
		};
		
		
		/**
		 * Attach a sort listener to an element for a given column
		 *  @param {node} nNode the element to attach the sort listener to
		 *  @param {int} iColumn the column that a click on this node will sort on
		 *  @param {function} [fnCallback] callback function when sort is run
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *
		 *      // Sort on column 1, when 'sorter' is clicked on
		 *      oTable.fnSortListener( document.getElementById('sorter'), 1 );
		 *    } );
		 */
		this.fnSortListener = function( nNode, iColumn, fnCallback )
		{
			this.api( true ).order.listener( nNode, iColumn, fnCallback );
		};
		
		
		/**
		 * Update a table cell or row - this method will accept either a single value to
		 * update the cell with, an array of values with one element for each column or
		 * an object in the same format as the original data source. The function is
		 * self-referencing in order to make the multi column updates easier.
		 *  @param {object|array|string} mData Data to update the cell/row with
		 *  @param {node|int} mRow TR element you want to update or the aoData index
		 *  @param {int} [iColumn] The column to update, give as null or undefined to
		 *    update a whole row.
		 *  @param {bool} [bRedraw=true] Redraw the table or not
		 *  @param {bool} [bAction=true] Perform pre-draw actions or not
		 *  @returns {int} 0 on success, 1 on error
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *      oTable.fnUpdate( 'Example update', 0, 0 ); // Single cell
		 *      oTable.fnUpdate( ['a', 'b', 'c', 'd', 'e'], $('tbody tr')[0] ); // Row
		 *    } );
		 */
		this.fnUpdate = function( mData, mRow, iColumn, bRedraw, bAction )
		{
			var api = this.api( true );
		
			if ( iColumn === undefined || iColumn === null ) {
				api.row( mRow ).data( mData );
			}
			else {
				api.cell( mRow, iColumn ).data( mData );
			}
		
			if ( bAction === undefined || bAction ) {
				api.columns.adjust();
			}
		
			if ( bRedraw === undefined || bRedraw ) {
				api.draw();
			}
			return 0;
		};
		
		
		/**
		 * Provide a common method for plug-ins to check the version of DataTables being used, in order
		 * to ensure compatibility.
		 *  @param {string} sVersion Version string to check for, in the format "X.Y.Z". Note that the
		 *    formats "X" and "X.Y" are also acceptable.
		 *  @returns {boolean} true if this version of DataTables is greater or equal to the required
		 *    version, or false if this version of DataTales is not suitable
		 *  @method
		 *  @dtopt API
		 *  @deprecated Since v1.10
		 *
		 *  @example
		 *    $(document).ready(function() {
		 *      var oTable = $('#example').dataTable();
		 *      alert( oTable.fnVersionCheck( '1.9.0' ) );
		 *    } );
		 */
		this.fnVersionCheck = _ext.fnVersionCheck;
		

		var _that = this;
		var emptyInit = options === undefined;
		var len = this.length;

		if ( emptyInit ) {
			options = {};
		}

		this.oApi = this.internal = _ext.internal;

		// Extend with old style plug-in API methods
		for ( var fn in DataTable.ext.internal ) {
			if ( fn ) {
				this[fn] = _fnExternApiFunc(fn);
			}
		}

		this.each(function() {
			// For each initialisation we want to give it a clean initialisation
			// object that can be bashed around
			var o = {};
			var oInit = len > 1 ? // optimisation for single table case
				_fnExtend( o, options, true ) :
				options;

			/*global oInit,_that,emptyInit*/
			var i=0, iLen, j, jLen, k, kLen;
			var sId = this.getAttribute( 'id' );
			var bInitHandedOff = false;
			var defaults = DataTable.defaults;
			var $this = $(this);
			
			
			/* Sanity check */
			if ( this.nodeName.toLowerCase() != 'table' )
			{
				_fnLog( null, 0, 'Non-table node initialisation ('+this.nodeName+')', 2 );
				return;
			}
			
			/* Backwards compatibility for the defaults */
			_fnCompatOpts( defaults );
			_fnCompatCols( defaults.column );
			
			/* Convert the camel-case defaults to Hungarian */
			_fnCamelToHungarian( defaults, defaults, true );
			_fnCamelToHungarian( defaults.column, defaults.column, true );
			
			/* Setting up the initialisation object */
			_fnCamelToHungarian( defaults, $.extend( oInit, $this.data() ) );
			
			
			
			/* Check to see if we are re-initialising a table */
			var allSettings = DataTable.settings;
			for ( i=0, iLen=allSettings.length ; i<iLen ; i++ )
			{
				var s = allSettings[i];
			
				/* Base check on table node */
				if ( s.nTable == this || s.nTHead.parentNode == this || (s.nTFoot && s.nTFoot.parentNode == this) )
				{
					var bRetrieve = oInit.bRetrieve !== undefined ? oInit.bRetrieve : defaults.bRetrieve;
					var bDestroy = oInit.bDestroy !== undefined ? oInit.bDestroy : defaults.bDestroy;
			
					if ( emptyInit || bRetrieve )
					{
						return s.oInstance;
					}
					else if ( bDestroy )
					{
						s.oInstance.fnDestroy();
						break;
					}
					else
					{
						_fnLog( s, 0, 'Cannot reinitialise DataTable', 3 );
						return;
					}
				}
			
				/* If the element we are initialising has the same ID as a table which was previously
				 * initialised, but the table nodes don't match (from before) then we destroy the old
				 * instance by simply deleting it. This is under the assumption that the table has been
				 * destroyed by other methods. Anyone using non-id selectors will need to do this manually
				 */
				if ( s.sTableId == this.id )
				{
					allSettings.splice( i, 1 );
					break;
				}
			}
			
			/* Ensure the table has an ID - required for accessibility */
			if ( sId === null || sId === "" )
			{
				sId = "DataTables_Table_"+(DataTable.ext._unique++);
				this.id = sId;
			}
			
			/* Create the settings object for this table and set some of the default parameters */
			var oSettings = $.extend( true, {}, DataTable.models.oSettings, {
				"sDestroyWidth": $this[0].style.width,
				"sInstance":     sId,
				"sTableId":      sId
			} );
			oSettings.nTable = this;
			oSettings.oApi   = _that.internal;
			oSettings.oInit  = oInit;
			
			allSettings.push( oSettings );
			
			// Need to add the instance after the instance after the settings object has been added
			// to the settings array, so we can self reference the table instance if more than one
			oSettings.oInstance = (_that.length===1) ? _that : $this.dataTable();
			
			// Backwards compatibility, before we apply all the defaults
			_fnCompatOpts( oInit );
			
			if ( oInit.oLanguage )
			{
				_fnLanguageCompat( oInit.oLanguage );
			}
			
			// If the length menu is given, but the init display length is not, use the length menu
			if ( oInit.aLengthMenu && ! oInit.iDisplayLength )
			{
				oInit.iDisplayLength = $.isArray( oInit.aLengthMenu[0] ) ?
					oInit.aLengthMenu[0][0] : oInit.aLengthMenu[0];
			}
			
			// Apply the defaults and init options to make a single init object will all
			// options defined from defaults and instance options.
			oInit = _fnExtend( $.extend( true, {}, defaults ), oInit );
			
			
			// Map the initialisation options onto the settings object
			_fnMap( oSettings.oFeatures, oInit, [
				"bPaginate",
				"bLengthChange",
				"bFilter",
				"bSort",
				"bSortMulti",
				"bInfo",
				"bProcessing",
				"bAutoWidth",
				"bSortClasses",
				"bServerSide",
				"bDeferRender"
			] );
			_fnMap( oSettings, oInit, [
				"asStripeClasses",
				"ajax",
				"fnServerData",
				"fnFormatNumber",
				"sServerMethod",
				"aaSorting",
				"aaSortingFixed",
				"aLengthMenu",
				"sPaginationType",
				"sAjaxSource",
				"sAjaxDataProp",
				"iStateDuration",
				"sDom",
				"bSortCellsTop",
				"iTabIndex",
				"fnStateLoadCallback",
				"fnStateSaveCallback",
				"renderer",
				"searchDelay",
				"rowId",
				[ "iCookieDuration", "iStateDuration" ], // backwards compat
				[ "oSearch", "oPreviousSearch" ],
				[ "aoSearchCols", "aoPreSearchCols" ],
				[ "iDisplayLength", "_iDisplayLength" ]
			] );
			_fnMap( oSettings.oScroll, oInit, [
				[ "sScrollX", "sX" ],
				[ "sScrollXInner", "sXInner" ],
				[ "sScrollY", "sY" ],
				[ "bScrollCollapse", "bCollapse" ]
			] );
			_fnMap( oSettings.oLanguage, oInit, "fnInfoCallback" );
			
			/* Callback functions which are array driven */
			_fnCallbackReg( oSettings, 'aoDrawCallback',       oInit.fnDrawCallback,      'user' );
			_fnCallbackReg( oSettings, 'aoServerParams',       oInit.fnServerParams,      'user' );
			_fnCallbackReg( oSettings, 'aoStateSaveParams',    oInit.fnStateSaveParams,   'user' );
			_fnCallbackReg( oSettings, 'aoStateLoadParams',    oInit.fnStateLoadParams,   'user' );
			_fnCallbackReg( oSettings, 'aoStateLoaded',        oInit.fnStateLoaded,       'user' );
			_fnCallbackReg( oSettings, 'aoRowCallback',        oInit.fnRowCallback,       'user' );
			_fnCallbackReg( oSettings, 'aoRowCreatedCallback', oInit.fnCreatedRow,        'user' );
			_fnCallbackReg( oSettings, 'aoHeaderCallback',     oInit.fnHeaderCallback,    'user' );
			_fnCallbackReg( oSettings, 'aoFooterCallback',     oInit.fnFooterCallback,    'user' );
			_fnCallbackReg( oSettings, 'aoInitComplete',       oInit.fnInitComplete,      'user' );
			_fnCallbackReg( oSettings, 'aoPreDrawCallback',    oInit.fnPreDrawCallback,   'user' );
			
			oSettings.rowIdFn = _fnGetObjectDataFn( oInit.rowId );
			
			/* Browser support detection */
			_fnBrowserDetect( oSettings );
			
			var oClasses = oSettings.oClasses;
			
			$.extend( oClasses, DataTable.ext.classes, oInit.oClasses );
			$this.addClass( oClasses.sTable );
			
			
			if ( oSettings.iInitDisplayStart === undefined )
			{
				/* Display start point, taking into account the save saving */
				oSettings.iInitDisplayStart = oInit.iDisplayStart;
				oSettings._iDisplayStart = oInit.iDisplayStart;
			}
			
			if ( oInit.iDeferLoading !== null )
			{
				oSettings.bDeferLoading = true;
				var tmp = $.isArray( oInit.iDeferLoading );
				oSettings._iRecordsDisplay = tmp ? oInit.iDeferLoading[0] : oInit.iDeferLoading;
				oSettings._iRecordsTotal = tmp ? oInit.iDeferLoading[1] : oInit.iDeferLoading;
			}
			
			/* Language definitions */
			var oLanguage = oSettings.oLanguage;
			$.extend( true, oLanguage, oInit.oLanguage );
			
			if ( oLanguage.sUrl )
			{
				/* Get the language definitions from a file - because this Ajax call makes the language
				 * get async to the remainder of this function we use bInitHandedOff to indicate that
				 * _fnInitialise will be fired by the returned Ajax handler, rather than the constructor
				 */
				$.ajax( {
					dataType: 'json',
					url: oLanguage.sUrl,
					success: function ( json ) {
						_fnLanguageCompat( json );
						_fnCamelToHungarian( defaults.oLanguage, json );
						$.extend( true, oLanguage, json );
						_fnInitialise( oSettings );
					},
					error: function () {
						// Error occurred loading language file, continue on as best we can
						_fnInitialise( oSettings );
					}
				} );
				bInitHandedOff = true;
			}
			
			/*
			 * Stripes
			 */
			if ( oInit.asStripeClasses === null )
			{
				oSettings.asStripeClasses =[
					oClasses.sStripeOdd,
					oClasses.sStripeEven
				];
			}
			
			/* Remove row stripe classes if they are already on the table row */
			var stripeClasses = oSettings.asStripeClasses;
			var rowOne = $this.children('tbody').find('tr').eq(0);
			if ( $.inArray( true, $.map( stripeClasses, function(el, i) {
				return rowOne.hasClass(el);
			} ) ) !== -1 ) {
				$('tbody tr', this).removeClass( stripeClasses.join(' ') );
				oSettings.asDestroyStripes = stripeClasses.slice();
			}
			
			/*
			 * Columns
			 * See if we should load columns automatically or use defined ones
			 */
			var anThs = [];
			var aoColumnsInit;
			var nThead = this.getElementsByTagName('thead');
			if ( nThead.length !== 0 )
			{
				_fnDetectHeader( oSettings.aoHeader, nThead[0] );
				anThs = _fnGetUniqueThs( oSettings );
			}
			
			/* If not given a column array, generate one with nulls */
			if ( oInit.aoColumns === null )
			{
				aoColumnsInit = [];
				for ( i=0, iLen=anThs.length ; i<iLen ; i++ )
				{
					aoColumnsInit.push( null );
				}
			}
			else
			{
				aoColumnsInit = oInit.aoColumns;
			}
			
			/* Add the columns */
			for ( i=0, iLen=aoColumnsInit.length ; i<iLen ; i++ )
			{
				_fnAddColumn( oSettings, anThs ? anThs[i] : null );
			}
			
			/* Apply the column definitions */
			_fnApplyColumnDefs( oSettings, oInit.aoColumnDefs, aoColumnsInit, function (iCol, oDef) {
				_fnColumnOptions( oSettings, iCol, oDef );
			} );
			
			/* HTML5 attribute detection - build an mData object automatically if the
			 * attributes are found
			 */
			if ( rowOne.length ) {
				var a = function ( cell, name ) {
					return cell.getAttribute( 'data-'+name ) !== null ? name : null;
				};
			
				$( rowOne[0] ).children('th, td').each( function (i, cell) {
					var col = oSettings.aoColumns[i];
			
					if ( col.mData === i ) {
						var sort = a( cell, 'sort' ) || a( cell, 'order' );
						var filter = a( cell, 'filter' ) || a( cell, 'search' );
			
						if ( sort !== null || filter !== null ) {
							col.mData = {
								_:      i+'.display',
								sort:   sort !== null   ? i+'.@data-'+sort   : undefined,
								type:   sort !== null   ? i+'.@data-'+sort   : undefined,
								filter: filter !== null ? i+'.@data-'+filter : undefined
							};
			
							_fnColumnOptions( oSettings, i );
						}
					}
				} );
			}
			
			var features = oSettings.oFeatures;
			var loadedInit = function () {
				/*
				 * Sorting
				 * @todo For modularisation (1.11) this needs to do into a sort start up handler
				 */
			
				// If aaSorting is not defined, then we use the first indicator in asSorting
				// in case that has been altered, so the default sort reflects that option
				if ( oInit.aaSorting === undefined ) {
					var sorting = oSettings.aaSorting;
					for ( i=0, iLen=sorting.length ; i<iLen ; i++ ) {
						sorting[i][1] = oSettings.aoColumns[ i ].asSorting[0];
					}
				}
			
				/* Do a first pass on the sorting classes (allows any size changes to be taken into
				 * account, and also will apply sorting disabled classes if disabled
				 */
				_fnSortingClasses( oSettings );
			
				if ( features.bSort ) {
					_fnCallbackReg( oSettings, 'aoDrawCallback', function () {
						if ( oSettings.bSorted ) {
							var aSort = _fnSortFlatten( oSettings );
							var sortedColumns = {};
			
							$.each( aSort, function (i, val) {
								sortedColumns[ val.src ] = val.dir;
							} );
			
							_fnCallbackFire( oSettings, null, 'order', [oSettings, aSort, sortedColumns] );
							_fnSortAria( oSettings );
						}
					} );
				}
			
				_fnCallbackReg( oSettings, 'aoDrawCallback', function () {
					if ( oSettings.bSorted || _fnDataSource( oSettings ) === 'ssp' || features.bDeferRender ) {
						_fnSortingClasses( oSettings );
					}
				}, 'sc' );
			
			
				/*
				 * Final init
				 * Cache the header, body and footer as required, creating them if needed
				 */
			
				// Work around for Webkit bug 83867 - store the caption-side before removing from doc
				var captions = $this.children('caption').each( function () {
					this._captionSide = $(this).css('caption-side');
				} );
			
				var thead = $this.children('thead');
				if ( thead.length === 0 ) {
					thead = $('<thead/>').appendTo($this);
				}
				oSettings.nTHead = thead[0];
			
				var tbody = $this.children('tbody');
				if ( tbody.length === 0 ) {
					tbody = $('<tbody/>').appendTo($this);
				}
				oSettings.nTBody = tbody[0];
			
				var tfoot = $this.children('tfoot');
				if ( tfoot.length === 0 && captions.length > 0 && (oSettings.oScroll.sX !== "" || oSettings.oScroll.sY !== "") ) {
					// If we are a scrolling table, and no footer has been given, then we need to create
					// a tfoot element for the caption element to be appended to
					tfoot = $('<tfoot/>').appendTo($this);
				}
			
				if ( tfoot.length === 0 || tfoot.children().length === 0 ) {
					$this.addClass( oClasses.sNoFooter );
				}
				else if ( tfoot.length > 0 ) {
					oSettings.nTFoot = tfoot[0];
					_fnDetectHeader( oSettings.aoFooter, oSettings.nTFoot );
				}
			
				/* Check if there is data passing into the constructor */
				if ( oInit.aaData ) {
					for ( i=0 ; i<oInit.aaData.length ; i++ ) {
						_fnAddData( oSettings, oInit.aaData[ i ] );
					}
				}
				else if ( oSettings.bDeferLoading || _fnDataSource( oSettings ) == 'dom' ) {
					/* Grab the data from the page - only do this when deferred loading or no Ajax
					 * source since there is no point in reading the DOM data if we are then going
					 * to replace it with Ajax data
					 */
					_fnAddTr( oSettings, $(oSettings.nTBody).children('tr') );
				}
			
				/* Copy the data index array */
				oSettings.aiDisplay = oSettings.aiDisplayMaster.slice();
			
				/* Initialisation complete - table can be drawn */
				oSettings.bInitialised = true;
			
				/* Check if we need to initialise the table (it might not have been handed off to the
				 * language processor)
				 */
				if ( bInitHandedOff === false ) {
					_fnInitialise( oSettings );
				}
			};
			
			/* Must be done after everything which can be overridden by the state saving! */
			if ( oInit.bStateSave )
			{
				features.bStateSave = true;
				_fnCallbackReg( oSettings, 'aoDrawCallback', _fnSaveState, 'state_save' );
				_fnLoadState( oSettings, oInit, loadedInit );
			}
			else {
				loadedInit();
			}
			
		} );
		_that = null;
		return this;
	};

	
	/*
	 * It is useful to have variables which are scoped locally so only the
	 * DataTables functions can access them and they don't leak into global space.
	 * At the same time these functions are often useful over multiple files in the
	 * core and API, so we list, or at least document, all variables which are used
	 * by DataTables as private variables here. This also ensures that there is no
	 * clashing of variable names and that they can easily referenced for reuse.
	 */
	
	
	// Defined else where
	//  _selector_run
	//  _selector_opts
	//  _selector_first
	//  _selector_row_indexes
	
	var _ext; // DataTable.ext
	var _Api; // DataTable.Api
	var _api_register; // DataTable.Api.register
	var _api_registerPlural; // DataTable.Api.registerPlural
	
	var _re_dic = {};
	var _re_new_lines = /[\r\n]/g;
	var _re_html = /<.*?>/g;
	
	// This is not strict ISO8601 - Date.parse() is quite lax, although
	// implementations differ between browsers.
	var _re_date = /^\d{2,4}[\.\/\-]\d{1,2}[\.\/\-]\d{1,2}([T ]{1}\d{1,2}[:\.]\d{2}([\.:]\d{2})?)?$/;
	
	// Escape regular expression special characters
	var _re_escape_regex = new RegExp( '(\\' + [ '/', '.', '*', '+', '?', '|', '(', ')', '[', ']', '{', '}', '\\', '$', '^', '-' ].join('|\\') + ')', 'g' );
	
	// http://en.wikipedia.org/wiki/Foreign_exchange_market
	// - \u20BD - Russian ruble.
	// - \u20a9 - South Korean Won
	// - \u20BA - Turkish Lira
	// - \u20B9 - Indian Rupee
	// - R - Brazil (R$) and South Africa
	// - fr - Swiss Franc
	// - kr - Swedish krona, Norwegian krone and Danish krone
	// - \u2009 is thin space and \u202F is narrow no-break space, both used in many
	//   standards as thousands separators.
	var _re_formatted_numeric = /[',$£€¥%\u2009\u202F\u20BD\u20a9\u20BArfk]/gi;
	
	
	var _empty = function ( d ) {
		return !d || d === true || d === '-' ? true : false;
	};
	
	
	var _intVal = function ( s ) {
		var integer = parseInt( s, 10 );
		return !isNaN(integer) && isFinite(s) ? integer : null;
	};
	
	// Convert from a formatted number with characters other than `.` as the
	// decimal place, to a Javascript number
	var _numToDecimal = function ( num, decimalPoint ) {
		// Cache created regular expressions for speed as this function is called often
		if ( ! _re_dic[ decimalPoint ] ) {
			_re_dic[ decimalPoint ] = new RegExp( _fnEscapeRegex( decimalPoint ), 'g' );
		}
		return typeof num === 'string' && decimalPoint !== '.' ?
			num.replace( /\./g, '' ).replace( _re_dic[ decimalPoint ], '.' ) :
			num;
	};
	
	
	var _isNumber = function ( d, decimalPoint, formatted ) {
		var strType = typeof d === 'string';
	
		// If empty return immediately so there must be a number if it is a
		// formatted string (this stops the string "k", or "kr", etc being detected
		// as a formatted number for currency
		if ( _empty( d ) ) {
			return true;
		}
	
		if ( decimalPoint && strType ) {
			d = _numToDecimal( d, decimalPoint );
		}
	
		if ( formatted && strType ) {
			d = d.replace( _re_formatted_numeric, '' );
		}
	
		return !isNaN( parseFloat(d) ) && isFinite( d );
	};
	
	
	// A string without HTML in it can be considered to be HTML still
	var _isHtml = function ( d ) {
		return _empty( d ) || typeof d === 'string';
	};
	
	
	var _htmlNumeric = function ( d, decimalPoint, formatted ) {
		if ( _empty( d ) ) {
			return true;
		}
	
		var html = _isHtml( d );
		return ! html ?
			null :
			_isNumber( _stripHtml( d ), decimalPoint, formatted ) ?
				true :
				null;
	};
	
	
	var _pluck = function ( a, prop, prop2 ) {
		var out = [];
		var i=0, ien=a.length;
	
		// Could have the test in the loop for slightly smaller code, but speed
		// is essential here
		if ( prop2 !== undefined ) {
			for ( ; i<ien ; i++ ) {
				if ( a[i] && a[i][ prop ] ) {
					out.push( a[i][ prop ][ prop2 ] );
				}
			}
		}
		else {
			for ( ; i<ien ; i++ ) {
				if ( a[i] ) {
					out.push( a[i][ prop ] );
				}
			}
		}
	
		return out;
	};
	
	
	// Basically the same as _pluck, but rather than looping over `a` we use `order`
	// as the indexes to pick from `a`
	var _pluck_order = function ( a, order, prop, prop2 )
	{
		var out = [];
		var i=0, ien=order.length;
	
		// Could have the test in the loop for slightly smaller code, but speed
		// is essential here
		if ( prop2 !== undefined ) {
			for ( ; i<ien ; i++ ) {
				if ( a[ order[i] ][ prop ] ) {
					out.push( a[ order[i] ][ prop ][ prop2 ] );
				}
			}
		}
		else {
			for ( ; i<ien ; i++ ) {
				out.push( a[ order[i] ][ prop ] );
			}
		}
	
		return out;
	};
	
	
	var _range = function ( len, start )
	{
		var out = [];
		var end;
	
		if ( start === undefined ) {
			start = 0;
			end = len;
		}
		else {
			end = start;
			start = len;
		}
	
		for ( var i=start ; i<end ; i++ ) {
			out.push( i );
		}
	
		return out;
	};
	
	
	var _removeEmpty = function ( a )
	{
		var out = [];
	
		for ( var i=0, ien=a.length ; i<ien ; i++ ) {
			if ( a[i] ) { // careful - will remove all falsy values!
				out.push( a[i] );
			}
		}
	
		return out;
	};
	
	
	var _stripHtml = function ( d ) {
		return d.replace( _re_html, '' );
	};
	
	
	/**
	 * Determine if all values in the array are unique. This means we can short
	 * cut the _unique method at the cost of a single loop. A sorted array is used
	 * to easily check the values.
	 *
	 * @param  {array} src Source array
	 * @return {boolean} true if all unique, false otherwise
	 * @ignore
	 */
	var _areAllUnique = function ( src ) {
		if ( src.length < 2 ) {
			return true;
		}
	
		var sorted = src.slice().sort();
		var last = sorted[0];
	
		for ( var i=1, ien=sorted.length ; i<ien ; i++ ) {
			if ( sorted[i] === last ) {
				return false;
			}
	
			last = sorted[i];
		}
	
		return true;
	};
	
	
	/**
	 * Find the unique elements in a source array.
	 *
	 * @param  {array} src Source array
	 * @return {array} Array of unique items
	 * @ignore
	 */
	var _unique = function ( src )
	{
		if ( _areAllUnique( src ) ) {
			return src.slice();
		}
	
		// A faster unique method is to use object keys to identify used values,
		// but this doesn't work with arrays or objects, which we must also
		// consider. See jsperf.com/compare-array-unique-versions/4 for more
		// information.
		var
			out = [],
			val,
			i, ien=src.length,
			j, k=0;
	
		again: for ( i=0 ; i<ien ; i++ ) {
			val = src[i];
	
			for ( j=0 ; j<k ; j++ ) {
				if ( out[j] === val ) {
					continue again;
				}
			}
	
			out.push( val );
			k++;
		}
	
		return out;
	};
	
	
	/**
	 * DataTables utility methods
	 * 
	 * This namespace provides helper methods that DataTables uses internally to
	 * create a DataTable, but which are not exclusively used only for DataTables.
	 * These methods can be used by extension authors to save the duplication of
	 * code.
	 *
	 *  @namespace
	 */
	DataTable.util = {
		/**
		 * Throttle the calls to a function. Arguments and context are maintained
		 * for the throttled function.
		 *
		 * @param {function} fn Function to be called
		 * @param {integer} freq Call frequency in mS
		 * @return {function} Wrapped function
		 */
		throttle: function ( fn, freq ) {
			var
				frequency = freq !== undefined ? freq : 200,
				last,
				timer;
	
			return function () {
				var
					that = this,
					now  = +new Date(),
					args = arguments;
	
				if ( last && now < last + frequency ) {
					clearTimeout( timer );
	
					timer = setTimeout( function () {
						last = undefined;
						fn.apply( that, args );
					}, frequency );
				}
				else {
					last = now;
					fn.apply( that, args );
				}
			};
		},
	
	
		/**
		 * Escape a string such that it can be used in a regular expression
		 *
		 *  @param {string} val string to escape
		 *  @returns {string} escaped string
		 */
		escapeRegex: function ( val ) {
			return val.replace( _re_escape_regex, '\\$1' );
		}
	};
	
	
	
	/**
	 * Create a mapping object that allows camel case parameters to be looked up
	 * for their Hungarian counterparts. The mapping is stored in a private
	 * parameter called `_hungarianMap` which can be accessed on the source object.
	 *  @param {object} o
	 *  @memberof DataTable#oApi
	 */
	function _fnHungarianMap ( o )
	{
		var
			hungarian = 'a aa ai ao as b fn i m o s ',
			match,
			newKey,
			map = {};
	
		$.each( o, function (key, val) {
			match = key.match(/^([^A-Z]+?)([A-Z])/);
	
			if ( match && hungarian.indexOf(match[1]+' ') !== -1 )
			{
				newKey = key.replace( match[0], match[2].toLowerCase() );
				map[ newKey ] = key;
	
				if ( match[1] === 'o' )
				{
					_fnHungarianMap( o[key] );
				}
			}
		} );
	
		o._hungarianMap = map;
	}
	
	
	/**
	 * Convert from camel case parameters to Hungarian, based on a Hungarian map
	 * created by _fnHungarianMap.
	 *  @param {object} src The model object which holds all parameters that can be
	 *    mapped.
	 *  @param {object} user The object to convert from camel case to Hungarian.
	 *  @param {boolean} force When set to `true`, properties which already have a
	 *    Hungarian value in the `user` object will be overwritten. Otherwise they
	 *    won't be.
	 *  @memberof DataTable#oApi
	 */
	function _fnCamelToHungarian ( src, user, force )
	{
		if ( ! src._hungarianMap ) {
			_fnHungarianMap( src );
		}
	
		var hungarianKey;
	
		$.each( user, function (key, val) {
			hungarianKey = src._hungarianMap[ key ];
	
			if ( hungarianKey !== undefined && (force || user[hungarianKey] === undefined) )
			{
				// For objects, we need to buzz down into the object to copy parameters
				if ( hungarianKey.charAt(0) === 'o' )
				{
					// Copy the camelCase options over to the hungarian
					if ( ! user[ hungarianKey ] ) {
						user[ hungarianKey ] = {};
					}
					$.extend( true, user[hungarianKey], user[key] );
	
					_fnCamelToHungarian( src[hungarianKey], user[hungarianKey], force );
				}
				else {
					user[hungarianKey] = user[ key ];
				}
			}
		} );
	}
	
	
	/**
	 * Language compatibility - when certain options are given, and others aren't, we
	 * need to duplicate the values over, in order to provide backwards compatibility
	 * with older language files.
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnLanguageCompat( lang )
	{
		var defaults = DataTable.defaults.oLanguage;
		var zeroRecords = lang.sZeroRecords;
	
		/* Backwards compatibility - if there is no sEmptyTable given, then use the same as
		 * sZeroRecords - assuming that is given.
		 */
		if ( ! lang.sEmptyTable && zeroRecords &&
			defaults.sEmptyTable === "No data available in table" )
		{
			_fnMap( lang, lang, 'sZeroRecords', 'sEmptyTable' );
		}
	
		/* Likewise with loading records */
		if ( ! lang.sLoadingRecords && zeroRecords &&
			defaults.sLoadingRecords === "Loading..." )
		{
			_fnMap( lang, lang, 'sZeroRecords', 'sLoadingRecords' );
		}
	
		// Old parameter name of the thousands separator mapped onto the new
		if ( lang.sInfoThousands ) {
			lang.sThousands = lang.sInfoThousands;
		}
	
		var decimal = lang.sDecimal;
		if ( decimal ) {
			_addNumericSort( decimal );
		}
	}
	
	
	/**
	 * Map one parameter onto another
	 *  @param {object} o Object to map
	 *  @param {*} knew The new parameter name
	 *  @param {*} old The old parameter name
	 */
	var _fnCompatMap = function ( o, knew, old ) {
		if ( o[ knew ] !== undefined ) {
			o[ old ] = o[ knew ];
		}
	};
	
	
	/**
	 * Provide backwards compatibility for the main DT options. Note that the new
	 * options are mapped onto the old parameters, so this is an external interface
	 * change only.
	 *  @param {object} init Object to map
	 */
	function _fnCompatOpts ( init )
	{
		_fnCompatMap( init, 'ordering',      'bSort' );
		_fnCompatMap( init, 'orderMulti',    'bSortMulti' );
		_fnCompatMap( init, 'orderClasses',  'bSortClasses' );
		_fnCompatMap( init, 'orderCellsTop', 'bSortCellsTop' );
		_fnCompatMap( init, 'order',         'aaSorting' );
		_fnCompatMap( init, 'orderFixed',    'aaSortingFixed' );
		_fnCompatMap( init, 'paging',        'bPaginate' );
		_fnCompatMap( init, 'pagingType',    'sPaginationType' );
		_fnCompatMap( init, 'pageLength',    'iDisplayLength' );
		_fnCompatMap( init, 'searching',     'bFilter' );
	
		// Boolean initialisation of x-scrolling
		if ( typeof init.sScrollX === 'boolean' ) {
			init.sScrollX = init.sScrollX ? '100%' : '';
		}
		if ( typeof init.scrollX === 'boolean' ) {
			init.scrollX = init.scrollX ? '100%' : '';
		}
	
		// Column search objects are in an array, so it needs to be converted
		// element by element
		var searchCols = init.aoSearchCols;
	
		if ( searchCols ) {
			for ( var i=0, ien=searchCols.length ; i<ien ; i++ ) {
				if ( searchCols[i] ) {
					_fnCamelToHungarian( DataTable.models.oSearch, searchCols[i] );
				}
			}
		}
	}
	
	
	/**
	 * Provide backwards compatibility for column options. Note that the new options
	 * are mapped onto the old parameters, so this is an external interface change
	 * only.
	 *  @param {object} init Object to map
	 */
	function _fnCompatCols ( init )
	{
		_fnCompatMap( init, 'orderable',     'bSortable' );
		_fnCompatMap( init, 'orderData',     'aDataSort' );
		_fnCompatMap( init, 'orderSequence', 'asSorting' );
		_fnCompatMap( init, 'orderDataType', 'sortDataType' );
	
		// orderData can be given as an integer
		var dataSort = init.aDataSort;
		if ( typeof dataSort === 'number' && ! $.isArray( dataSort ) ) {
			init.aDataSort = [ dataSort ];
		}
	}
	
	
	/**
	 * Browser feature detection for capabilities, quirks
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnBrowserDetect( settings )
	{
		// We don't need to do this every time DataTables is constructed, the values
		// calculated are specific to the browser and OS configuration which we
		// don't expect to change between initialisations
		if ( ! DataTable.__browser ) {
			var browser = {};
			DataTable.__browser = browser;
	
			// Scrolling feature / quirks detection
			var n = $('<div/>')
				.css( {
					position: 'fixed',
					top: 0,
					left: $(window).scrollLeft()*-1, // allow for scrolling
					height: 1,
					width: 1,
					overflow: 'hidden'
				} )
				.append(
					$('<div/>')
						.css( {
							position: 'absolute',
							top: 1,
							left: 1,
							width: 100,
							overflow: 'scroll'
						} )
						.append(
							$('<div/>')
								.css( {
									width: '100%',
									height: 10
								} )
						)
				)
				.appendTo( 'body' );
	
			var outer = n.children();
			var inner = outer.children();
	
			// Numbers below, in order, are:
			// inner.offsetWidth, inner.clientWidth, outer.offsetWidth, outer.clientWidth
			//
			// IE6 XP:                           100 100 100  83
			// IE7 Vista:                        100 100 100  83
			// IE 8+ Windows:                     83  83 100  83
			// Evergreen Windows:                 83  83 100  83
			// Evergreen Mac with scrollbars:     85  85 100  85
			// Evergreen Mac without scrollbars: 100 100 100 100
	
			// Get scrollbar width
			browser.barWidth = outer[0].offsetWidth - outer[0].clientWidth;
	
			// IE6/7 will oversize a width 100% element inside a scrolling element, to
			// include the width of the scrollbar, while other browsers ensure the inner
			// element is contained without forcing scrolling
			browser.bScrollOversize = inner[0].offsetWidth === 100 && outer[0].clientWidth !== 100;
	
			// In rtl text layout, some browsers (most, but not all) will place the
			// scrollbar on the left, rather than the right.
			browser.bScrollbarLeft = Math.round( inner.offset().left ) !== 1;
	
			// IE8- don't provide height and width for getBoundingClientRect
			browser.bBounding = n[0].getBoundingClientRect().width ? true : false;
	
			n.remove();
		}
	
		$.extend( settings.oBrowser, DataTable.__browser );
		settings.oScroll.iBarWidth = DataTable.__browser.barWidth;
	}
	
	
	/**
	 * Array.prototype reduce[Right] method, used for browsers which don't support
	 * JS 1.6. Done this way to reduce code size, since we iterate either way
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnReduce ( that, fn, init, start, end, inc )
	{
		var
			i = start,
			value,
			isSet = false;
	
		if ( init !== undefined ) {
			value = init;
			isSet = true;
		}
	
		while ( i !== end ) {
			if ( ! that.hasOwnProperty(i) ) {
				continue;
			}
	
			value = isSet ?
				fn( value, that[i], i, that ) :
				that[i];
	
			isSet = true;
			i += inc;
		}
	
		return value;
	}
	
	/**
	 * Add a column to the list used for the table with default values
	 *  @param {object} oSettings dataTables settings object
	 *  @param {node} nTh The th element for this column
	 *  @memberof DataTable#oApi
	 */
	function _fnAddColumn( oSettings, nTh )
	{
		// Add column to aoColumns array
		var oDefaults = DataTable.defaults.column;
		var iCol = oSettings.aoColumns.length;
		var oCol = $.extend( {}, DataTable.models.oColumn, oDefaults, {
			"nTh": nTh ? nTh : document.createElement('th'),
			"sTitle":    oDefaults.sTitle    ? oDefaults.sTitle    : nTh ? nTh.innerHTML : '',
			"aDataSort": oDefaults.aDataSort ? oDefaults.aDataSort : [iCol],
			"mData": oDefaults.mData ? oDefaults.mData : iCol,
			idx: iCol
		} );
		oSettings.aoColumns.push( oCol );
	
		// Add search object for column specific search. Note that the `searchCols[ iCol ]`
		// passed into extend can be undefined. This allows the user to give a default
		// with only some of the parameters defined, and also not give a default
		var searchCols = oSettings.aoPreSearchCols;
		searchCols[ iCol ] = $.extend( {}, DataTable.models.oSearch, searchCols[ iCol ] );
	
		// Use the default column options function to initialise classes etc
		_fnColumnOptions( oSettings, iCol, $(nTh).data() );
	}
	
	
	/**
	 * Apply options for a column
	 *  @param {object} oSettings dataTables settings object
	 *  @param {int} iCol column index to consider
	 *  @param {object} oOptions object with sType, bVisible and bSearchable etc
	 *  @memberof DataTable#oApi
	 */
	function _fnColumnOptions( oSettings, iCol, oOptions )
	{
		var oCol = oSettings.aoColumns[ iCol ];
		var oClasses = oSettings.oClasses;
		var th = $(oCol.nTh);
	
		// Try to get width information from the DOM. We can't get it from CSS
		// as we'd need to parse the CSS stylesheet. `width` option can override
		if ( ! oCol.sWidthOrig ) {
			// Width attribute
			oCol.sWidthOrig = th.attr('width') || null;
	
			// Style attribute
			var t = (th.attr('style') || '').match(/width:\s*(\d+[pxem%]+)/);
			if ( t ) {
				oCol.sWidthOrig = t[1];
			}
		}
	
		/* User specified column options */
		if ( oOptions !== undefined && oOptions !== null )
		{
			// Backwards compatibility
			_fnCompatCols( oOptions );
	
			// Map camel case parameters to their Hungarian counterparts
			_fnCamelToHungarian( DataTable.defaults.column, oOptions );
	
			/* Backwards compatibility for mDataProp */
			if ( oOptions.mDataProp !== undefined && !oOptions.mData )
			{
				oOptions.mData = oOptions.mDataProp;
			}
	
			if ( oOptions.sType )
			{
				oCol._sManualType = oOptions.sType;
			}
	
			// `class` is a reserved word in Javascript, so we need to provide
			// the ability to use a valid name for the camel case input
			if ( oOptions.className && ! oOptions.sClass )
			{
				oOptions.sClass = oOptions.className;
			}
			if ( oOptions.sClass ) {
				th.addClass( oOptions.sClass );
			}
	
			$.extend( oCol, oOptions );
			_fnMap( oCol, oOptions, "sWidth", "sWidthOrig" );
	
			/* iDataSort to be applied (backwards compatibility), but aDataSort will take
			 * priority if defined
			 */
			if ( oOptions.iDataSort !== undefined )
			{
				oCol.aDataSort = [ oOptions.iDataSort ];
			}
			_fnMap( oCol, oOptions, "aDataSort" );
		}
	
		/* Cache the data get and set functions for speed */
		var mDataSrc = oCol.mData;
		var mData = _fnGetObjectDataFn( mDataSrc );
		var mRender = oCol.mRender ? _fnGetObjectDataFn( oCol.mRender ) : null;
	
		var attrTest = function( src ) {
			return typeof src === 'string' && src.indexOf('@') !== -1;
		};
		oCol._bAttrSrc = $.isPlainObject( mDataSrc ) && (
			attrTest(mDataSrc.sort) || attrTest(mDataSrc.type) || attrTest(mDataSrc.filter)
		);
		oCol._setter = null;
	
		oCol.fnGetData = function (rowData, type, meta) {
			var innerData = mData( rowData, type, undefined, meta );
	
			return mRender && type ?
				mRender( innerData, type, rowData, meta ) :
				innerData;
		};
		oCol.fnSetData = function ( rowData, val, meta ) {
			return _fnSetObjectDataFn( mDataSrc )( rowData, val, meta );
		};
	
		// Indicate if DataTables should read DOM data as an object or array
		// Used in _fnGetRowElements
		if ( typeof mDataSrc !== 'number' ) {
			oSettings._rowReadObject = true;
		}
	
		/* Feature sorting overrides column specific when off */
		if ( !oSettings.oFeatures.bSort )
		{
			oCol.bSortable = false;
			th.addClass( oClasses.sSortableNone ); // Have to add class here as order event isn't called
		}
	
		/* Check that the class assignment is correct for sorting */
		var bAsc = $.inArray('asc', oCol.asSorting) !== -1;
		var bDesc = $.inArray('desc', oCol.asSorting) !== -1;
		if ( !oCol.bSortable || (!bAsc && !bDesc) )
		{
			oCol.sSortingClass = oClasses.sSortableNone;
			oCol.sSortingClassJUI = "";
		}
		else if ( bAsc && !bDesc )
		{
			oCol.sSortingClass = oClasses.sSortableAsc;
			oCol.sSortingClassJUI = oClasses.sSortJUIAscAllowed;
		}
		else if ( !bAsc && bDesc )
		{
			oCol.sSortingClass = oClasses.sSortableDesc;
			oCol.sSortingClassJUI = oClasses.sSortJUIDescAllowed;
		}
		else
		{
			oCol.sSortingClass = oClasses.sSortable;
			oCol.sSortingClassJUI = oClasses.sSortJUI;
		}
	}
	
	
	/**
	 * Adjust the table column widths for new data. Note: you would probably want to
	 * do a redraw after calling this function!
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnAdjustColumnSizing ( settings )
	{
		/* Not interested in doing column width calculation if auto-width is disabled */
		if ( settings.oFeatures.bAutoWidth !== false )
		{
			var columns = settings.aoColumns;
	
			_fnCalculateColumnWidths( settings );
			for ( var i=0 , iLen=columns.length ; i<iLen ; i++ )
			{
				columns[i].nTh.style.width = columns[i].sWidth;
			}
		}
	
		var scroll = settings.oScroll;
		if ( scroll.sY !== '' || scroll.sX !== '')
		{
			_fnScrollDraw( settings );
		}
	
		_fnCallbackFire( settings, null, 'column-sizing', [settings] );
	}
	
	
	/**
	 * Covert the index of a visible column to the index in the data array (take account
	 * of hidden columns)
	 *  @param {object} oSettings dataTables settings object
	 *  @param {int} iMatch Visible column index to lookup
	 *  @returns {int} i the data index
	 *  @memberof DataTable#oApi
	 */
	function _fnVisibleToColumnIndex( oSettings, iMatch )
	{
		var aiVis = _fnGetColumns( oSettings, 'bVisible' );
	
		return typeof aiVis[iMatch] === 'number' ?
			aiVis[iMatch] :
			null;
	}
	
	
	/**
	 * Covert the index of an index in the data array and convert it to the visible
	 *   column index (take account of hidden columns)
	 *  @param {int} iMatch Column index to lookup
	 *  @param {object} oSettings dataTables settings object
	 *  @returns {int} i the data index
	 *  @memberof DataTable#oApi
	 */
	function _fnColumnIndexToVisible( oSettings, iMatch )
	{
		var aiVis = _fnGetColumns( oSettings, 'bVisible' );
		var iPos = $.inArray( iMatch, aiVis );
	
		return iPos !== -1 ? iPos : null;
	}
	
	
	/**
	 * Get the number of visible columns
	 *  @param {object} oSettings dataTables settings object
	 *  @returns {int} i the number of visible columns
	 *  @memberof DataTable#oApi
	 */
	function _fnVisbleColumns( oSettings )
	{
		var vis = 0;
	
		// No reduce in IE8, use a loop for now
		$.each( oSettings.aoColumns, function ( i, col ) {
			if ( col.bVisible && $(col.nTh).css('display') !== 'none' ) {
				vis++;
			}
		} );
	
		return vis;
	}
	
	
	/**
	 * Get an array of column indexes that match a given property
	 *  @param {object} oSettings dataTables settings object
	 *  @param {string} sParam Parameter in aoColumns to look for - typically
	 *    bVisible or bSearchable
	 *  @returns {array} Array of indexes with matched properties
	 *  @memberof DataTable#oApi
	 */
	function _fnGetColumns( oSettings, sParam )
	{
		var a = [];
	
		$.map( oSettings.aoColumns, function(val, i) {
			if ( val[sParam] ) {
				a.push( i );
			}
		} );
	
		return a;
	}
	
	
	/**
	 * Calculate the 'type' of a column
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnColumnTypes ( settings )
	{
		var columns = settings.aoColumns;
		var data = settings.aoData;
		var types = DataTable.ext.type.detect;
		var i, ien, j, jen, k, ken;
		var col, cell, detectedType, cache;
	
		// For each column, spin over the 
		for ( i=0, ien=columns.length ; i<ien ; i++ ) {
			col = columns[i];
			cache = [];
	
			if ( ! col.sType && col._sManualType ) {
				col.sType = col._sManualType;
			}
			else if ( ! col.sType ) {
				for ( j=0, jen=types.length ; j<jen ; j++ ) {
					for ( k=0, ken=data.length ; k<ken ; k++ ) {
						// Use a cache array so we only need to get the type data
						// from the formatter once (when using multiple detectors)
						if ( cache[k] === undefined ) {
							cache[k] = _fnGetCellData( settings, k, i, 'type' );
						}
	
						detectedType = types[j]( cache[k], settings );
	
						// If null, then this type can't apply to this column, so
						// rather than testing all cells, break out. There is an
						// exception for the last type which is `html`. We need to
						// scan all rows since it is possible to mix string and HTML
						// types
						if ( ! detectedType && j !== types.length-1 ) {
							break;
						}
	
						// Only a single match is needed for html type since it is
						// bottom of the pile and very similar to string
						if ( detectedType === 'html' ) {
							break;
						}
					}
	
					// Type is valid for all data points in the column - use this
					// type
					if ( detectedType ) {
						col.sType = detectedType;
						break;
					}
				}
	
				// Fall back - if no type was detected, always use string
				if ( ! col.sType ) {
					col.sType = 'string';
				}
			}
		}
	}
	
	
	/**
	 * Take the column definitions and static columns arrays and calculate how
	 * they relate to column indexes. The callback function will then apply the
	 * definition found for a column to a suitable configuration object.
	 *  @param {object} oSettings dataTables settings object
	 *  @param {array} aoColDefs The aoColumnDefs array that is to be applied
	 *  @param {array} aoCols The aoColumns array that defines columns individually
	 *  @param {function} fn Callback function - takes two parameters, the calculated
	 *    column index and the definition for that column.
	 *  @memberof DataTable#oApi
	 */
	function _fnApplyColumnDefs( oSettings, aoColDefs, aoCols, fn )
	{
		var i, iLen, j, jLen, k, kLen, def;
		var columns = oSettings.aoColumns;
	
		// Column definitions with aTargets
		if ( aoColDefs )
		{
			/* Loop over the definitions array - loop in reverse so first instance has priority */
			for ( i=aoColDefs.length-1 ; i>=0 ; i-- )
			{
				def = aoColDefs[i];
	
				/* Each definition can target multiple columns, as it is an array */
				var aTargets = def.targets !== undefined ?
					def.targets :
					def.aTargets;
	
				if ( ! $.isArray( aTargets ) )
				{
					aTargets = [ aTargets ];
				}
	
				for ( j=0, jLen=aTargets.length ; j<jLen ; j++ )
				{
					if ( typeof aTargets[j] === 'number' && aTargets[j] >= 0 )
					{
						/* Add columns that we don't yet know about */
						while( columns.length <= aTargets[j] )
						{
							_fnAddColumn( oSettings );
						}
	
						/* Integer, basic index */
						fn( aTargets[j], def );
					}
					else if ( typeof aTargets[j] === 'number' && aTargets[j] < 0 )
					{
						/* Negative integer, right to left column counting */
						fn( columns.length+aTargets[j], def );
					}
					else if ( typeof aTargets[j] === 'string' )
					{
						/* Class name matching on TH element */
						for ( k=0, kLen=columns.length ; k<kLen ; k++ )
						{
							if ( aTargets[j] == "_all" ||
							     $(columns[k].nTh).hasClass( aTargets[j] ) )
							{
								fn( k, def );
							}
						}
					}
				}
			}
		}
	
		// Statically defined columns array
		if ( aoCols )
		{
			for ( i=0, iLen=aoCols.length ; i<iLen ; i++ )
			{
				fn( i, aoCols[i] );
			}
		}
	}
	
	/**
	 * Add a data array to the table, creating DOM node etc. This is the parallel to
	 * _fnGatherData, but for adding rows from a Javascript source, rather than a
	 * DOM source.
	 *  @param {object} oSettings dataTables settings object
	 *  @param {array} aData data array to be added
	 *  @param {node} [nTr] TR element to add to the table - optional. If not given,
	 *    DataTables will create a row automatically
	 *  @param {array} [anTds] Array of TD|TH elements for the row - must be given
	 *    if nTr is.
	 *  @returns {int} >=0 if successful (index of new aoData entry), -1 if failed
	 *  @memberof DataTable#oApi
	 */
	function _fnAddData ( oSettings, aDataIn, nTr, anTds )
	{
		/* Create the object for storing information about this new row */
		var iRow = oSettings.aoData.length;
		var oData = $.extend( true, {}, DataTable.models.oRow, {
			src: nTr ? 'dom' : 'data',
			idx: iRow
		} );
	
		oData._aData = aDataIn;
		oSettings.aoData.push( oData );
	
		/* Create the cells */
		var nTd, sThisType;
		var columns = oSettings.aoColumns;
	
		// Invalidate the column types as the new data needs to be revalidated
		for ( var i=0, iLen=columns.length ; i<iLen ; i++ )
		{
			columns[i].sType = null;
		}
	
		/* Add to the display array */
		oSettings.aiDisplayMaster.push( iRow );
	
		var id = oSettings.rowIdFn( aDataIn );
		if ( id !== undefined ) {
			oSettings.aIds[ id ] = oData;
		}
	
		/* Create the DOM information, or register it if already present */
		if ( nTr || ! oSettings.oFeatures.bDeferRender )
		{
			_fnCreateTr( oSettings, iRow, nTr, anTds );
		}
	
		return iRow;
	}
	
	
	/**
	 * Add one or more TR elements to the table. Generally we'd expect to
	 * use this for reading data from a DOM sourced table, but it could be
	 * used for an TR element. Note that if a TR is given, it is used (i.e.
	 * it is not cloned).
	 *  @param {object} settings dataTables settings object
	 *  @param {array|node|jQuery} trs The TR element(s) to add to the table
	 *  @returns {array} Array of indexes for the added rows
	 *  @memberof DataTable#oApi
	 */
	function _fnAddTr( settings, trs )
	{
		var row;
	
		// Allow an individual node to be passed in
		if ( ! (trs instanceof $) ) {
			trs = $(trs);
		}
	
		return trs.map( function (i, el) {
			row = _fnGetRowElements( settings, el );
			return _fnAddData( settings, row.data, el, row.cells );
		} );
	}
	
	
	/**
	 * Take a TR element and convert it to an index in aoData
	 *  @param {object} oSettings dataTables settings object
	 *  @param {node} n the TR element to find
	 *  @returns {int} index if the node is found, null if not
	 *  @memberof DataTable#oApi
	 */
	function _fnNodeToDataIndex( oSettings, n )
	{
		return (n._DT_RowIndex!==undefined) ? n._DT_RowIndex : null;
	}
	
	
	/**
	 * Take a TD element and convert it into a column data index (not the visible index)
	 *  @param {object} oSettings dataTables settings object
	 *  @param {int} iRow The row number the TD/TH can be found in
	 *  @param {node} n The TD/TH element to find
	 *  @returns {int} index if the node is found, -1 if not
	 *  @memberof DataTable#oApi
	 */
	function _fnNodeToColumnIndex( oSettings, iRow, n )
	{
		return $.inArray( n, oSettings.aoData[ iRow ].anCells );
	}
	
	
	/**
	 * Get the data for a given cell from the internal cache, taking into account data mapping
	 *  @param {object} settings dataTables settings object
	 *  @param {int} rowIdx aoData row id
	 *  @param {int} colIdx Column index
	 *  @param {string} type data get type ('display', 'type' 'filter' 'sort')
	 *  @returns {*} Cell data
	 *  @memberof DataTable#oApi
	 */
	function _fnGetCellData( settings, rowIdx, colIdx, type )
	{
		var draw           = settings.iDraw;
		var col            = settings.aoColumns[colIdx];
		var rowData        = settings.aoData[rowIdx]._aData;
		var defaultContent = col.sDefaultContent;
		var cellData       = col.fnGetData( rowData, type, {
			settings: settings,
			row:      rowIdx,
			col:      colIdx
		} );
	
		if ( cellData === undefined ) {
			if ( settings.iDrawError != draw && defaultContent === null ) {
				_fnLog( settings, 0, "Requested unknown parameter "+
					(typeof col.mData=='function' ? '{function}' : "'"+col.mData+"'")+
					" for row "+rowIdx+", column "+colIdx, 4 );
				settings.iDrawError = draw;
			}
			return defaultContent;
		}
	
		// When the data source is null and a specific data type is requested (i.e.
		// not the original data), we can use default column data
		if ( (cellData === rowData || cellData === null) && defaultContent !== null && type !== undefined ) {
			cellData = defaultContent;
		}
		else if ( typeof cellData === 'function' ) {
			// If the data source is a function, then we run it and use the return,
			// executing in the scope of the data object (for instances)
			return cellData.call( rowData );
		}
	
		if ( cellData === null && type == 'display' ) {
			return '';
		}
		return cellData;
	}
	
	
	/**
	 * Set the value for a specific cell, into the internal data cache
	 *  @param {object} settings dataTables settings object
	 *  @param {int} rowIdx aoData row id
	 *  @param {int} colIdx Column index
	 *  @param {*} val Value to set
	 *  @memberof DataTable#oApi
	 */
	function _fnSetCellData( settings, rowIdx, colIdx, val )
	{
		var col     = settings.aoColumns[colIdx];
		var rowData = settings.aoData[rowIdx]._aData;
	
		col.fnSetData( rowData, val, {
			settings: settings,
			row:      rowIdx,
			col:      colIdx
		}  );
	}
	
	
	// Private variable that is used to match action syntax in the data property object
	var __reArray = /\[.*?\]$/;
	var __reFn = /\(\)$/;
	
	/**
	 * Split string on periods, taking into account escaped periods
	 * @param  {string} str String to split
	 * @return {array} Split string
	 */
	function _fnSplitObjNotation( str )
	{
		return $.map( str.match(/(\\.|[^\.])+/g) || [''], function ( s ) {
			return s.replace(/\\\./g, '.');
		} );
	}
	
	
	/**
	 * Return a function that can be used to get data from a source object, taking
	 * into account the ability to use nested objects as a source
	 *  @param {string|int|function} mSource The data source for the object
	 *  @returns {function} Data get function
	 *  @memberof DataTable#oApi
	 */
	function _fnGetObjectDataFn( mSource )
	{
		if ( $.isPlainObject( mSource ) )
		{
			/* Build an object of get functions, and wrap them in a single call */
			var o = {};
			$.each( mSource, function (key, val) {
				if ( val ) {
					o[key] = _fnGetObjectDataFn( val );
				}
			} );
	
			return function (data, type, row, meta) {
				var t = o[type] || o._;
				return t !== undefined ?
					t(data, type, row, meta) :
					data;
			};
		}
		else if ( mSource === null )
		{
			/* Give an empty string for rendering / sorting etc */
			return function (data) { // type, row and meta also passed, but not used
				return data;
			};
		}
		else if ( typeof mSource === 'function' )
		{
			return function (data, type, row, meta) {
				return mSource( data, type, row, meta );
			};
		}
		else if ( typeof mSource === 'string' && (mSource.indexOf('.') !== -1 ||
			      mSource.indexOf('[') !== -1 || mSource.indexOf('(') !== -1) )
		{
			/* If there is a . in the source string then the data source is in a
			 * nested object so we loop over the data for each level to get the next
			 * level down. On each loop we test for undefined, and if found immediately
			 * return. This allows entire objects to be missing and sDefaultContent to
			 * be used if defined, rather than throwing an error
			 */
			var fetchData = function (data, type, src) {
				var arrayNotation, funcNotation, out, innerSrc;
	
				if ( src !== "" )
				{
					var a = _fnSplitObjNotation( src );
	
					for ( var i=0, iLen=a.length ; i<iLen ; i++ )
					{
						// Check if we are dealing with special notation
						arrayNotation = a[i].match(__reArray);
						funcNotation = a[i].match(__reFn);
	
						if ( arrayNotation )
						{
							// Array notation
							a[i] = a[i].replace(__reArray, '');
	
							// Condition allows simply [] to be passed in
							if ( a[i] !== "" ) {
								data = data[ a[i] ];
							}
							out = [];
	
							// Get the remainder of the nested object to get
							a.splice( 0, i+1 );
							innerSrc = a.join('.');
	
							// Traverse each entry in the array getting the properties requested
							if ( $.isArray( data ) ) {
								for ( var j=0, jLen=data.length ; j<jLen ; j++ ) {
									out.push( fetchData( data[j], type, innerSrc ) );
								}
							}
	
							// If a string is given in between the array notation indicators, that
							// is used to join the strings together, otherwise an array is returned
							var join = arrayNotation[0].substring(1, arrayNotation[0].length-1);
							data = (join==="") ? out : out.join(join);
	
							// The inner call to fetchData has already traversed through the remainder
							// of the source requested, so we exit from the loop
							break;
						}
						else if ( funcNotation )
						{
							// Function call
							a[i] = a[i].replace(__reFn, '');
							data = data[ a[i] ]();
							continue;
						}
	
						if ( data === null || data[ a[i] ] === undefined )
						{
							return undefined;
						}
						data = data[ a[i] ];
					}
				}
	
				return data;
			};
	
			return function (data, type) { // row and meta also passed, but not used
				return fetchData( data, type, mSource );
			};
		}
		else
		{
			/* Array or flat object mapping */
			return function (data, type) { // row and meta also passed, but not used
				return data[mSource];
			};
		}
	}
	
	
	/**
	 * Return a function that can be used to set data from a source object, taking
	 * into account the ability to use nested objects as a source
	 *  @param {string|int|function} mSource The data source for the object
	 *  @returns {function} Data set function
	 *  @memberof DataTable#oApi
	 */
	function _fnSetObjectDataFn( mSource )
	{
		if ( $.isPlainObject( mSource ) )
		{
			/* Unlike get, only the underscore (global) option is used for for
			 * setting data since we don't know the type here. This is why an object
			 * option is not documented for `mData` (which is read/write), but it is
			 * for `mRender` which is read only.
			 */
			return _fnSetObjectDataFn( mSource._ );
		}
		else if ( mSource === null )
		{
			/* Nothing to do when the data source is null */
			return function () {};
		}
		else if ( typeof mSource === 'function' )
		{
			return function (data, val, meta) {
				mSource( data, 'set', val, meta );
			};
		}
		else if ( typeof mSource === 'string' && (mSource.indexOf('.') !== -1 ||
			      mSource.indexOf('[') !== -1 || mSource.indexOf('(') !== -1) )
		{
			/* Like the get, we need to get data from a nested object */
			var setData = function (data, val, src) {
				var a = _fnSplitObjNotation( src ), b;
				var aLast = a[a.length-1];
				var arrayNotation, funcNotation, o, innerSrc;
	
				for ( var i=0, iLen=a.length-1 ; i<iLen ; i++ )
				{
					// Check if we are dealing with an array notation request
					arrayNotation = a[i].match(__reArray);
					funcNotation = a[i].match(__reFn);
	
					if ( arrayNotation )
					{
						a[i] = a[i].replace(__reArray, '');
						data[ a[i] ] = [];
	
						// Get the remainder of the nested object to set so we can recurse
						b = a.slice();
						b.splice( 0, i+1 );
						innerSrc = b.join('.');
	
						// Traverse each entry in the array setting the properties requested
						if ( $.isArray( val ) )
						{
							for ( var j=0, jLen=val.length ; j<jLen ; j++ )
							{
								o = {};
								setData( o, val[j], innerSrc );
								data[ a[i] ].push( o );
							}
						}
						else
						{
							// We've been asked to save data to an array, but it
							// isn't array data to be saved. Best that can be done
							// is to just save the value.
							data[ a[i] ] = val;
						}
	
						// The inner call to setData has already traversed through the remainder
						// of the source and has set the data, thus we can exit here
						return;
					}
					else if ( funcNotation )
					{
						// Function call
						a[i] = a[i].replace(__reFn, '');
						data = data[ a[i] ]( val );
					}
	
					// If the nested object doesn't currently exist - since we are
					// trying to set the value - create it
					if ( data[ a[i] ] === null || data[ a[i] ] === undefined )
					{
						data[ a[i] ] = {};
					}
					data = data[ a[i] ];
				}
	
				// Last item in the input - i.e, the actual set
				if ( aLast.match(__reFn ) )
				{
					// Function call
					data = data[ aLast.replace(__reFn, '') ]( val );
				}
				else
				{
					// If array notation is used, we just want to strip it and use the property name
					// and assign the value. If it isn't used, then we get the result we want anyway
					data[ aLast.replace(__reArray, '') ] = val;
				}
			};
	
			return function (data, val) { // meta is also passed in, but not used
				return setData( data, val, mSource );
			};
		}
		else
		{
			/* Array or flat object mapping */
			return function (data, val) { // meta is also passed in, but not used
				data[mSource] = val;
			};
		}
	}
	
	
	/**
	 * Return an array with the full table data
	 *  @param {object} oSettings dataTables settings object
	 *  @returns array {array} aData Master data array
	 *  @memberof DataTable#oApi
	 */
	function _fnGetDataMaster ( settings )
	{
		return _pluck( settings.aoData, '_aData' );
	}
	
	
	/**
	 * Nuke the table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnClearTable( settings )
	{
		settings.aoData.length = 0;
		settings.aiDisplayMaster.length = 0;
		settings.aiDisplay.length = 0;
		settings.aIds = {};
	}
	
	
	 /**
	 * Take an array of integers (index array) and remove a target integer (value - not
	 * the key!)
	 *  @param {array} a Index array to target
	 *  @param {int} iTarget value to find
	 *  @memberof DataTable#oApi
	 */
	function _fnDeleteIndex( a, iTarget, splice )
	{
		var iTargetIndex = -1;
	
		for ( var i=0, iLen=a.length ; i<iLen ; i++ )
		{
			if ( a[i] == iTarget )
			{
				iTargetIndex = i;
			}
			else if ( a[i] > iTarget )
			{
				a[i]--;
			}
		}
	
		if ( iTargetIndex != -1 && splice === undefined )
		{
			a.splice( iTargetIndex, 1 );
		}
	}
	
	
	/**
	 * Mark cached data as invalid such that a re-read of the data will occur when
	 * the cached data is next requested. Also update from the data source object.
	 *
	 * @param {object} settings DataTables settings object
	 * @param {int}    rowIdx   Row index to invalidate
	 * @param {string} [src]    Source to invalidate from: undefined, 'auto', 'dom'
	 *     or 'data'
	 * @param {int}    [colIdx] Column index to invalidate. If undefined the whole
	 *     row will be invalidated
	 * @memberof DataTable#oApi
	 *
	 * @todo For the modularisation of v1.11 this will need to become a callback, so
	 *   the sort and filter methods can subscribe to it. That will required
	 *   initialisation options for sorting, which is why it is not already baked in
	 */
	function _fnInvalidate( settings, rowIdx, src, colIdx )
	{
		var row = settings.aoData[ rowIdx ];
		var i, ien;
		var cellWrite = function ( cell, col ) {
			// This is very frustrating, but in IE if you just write directly
			// to innerHTML, and elements that are overwritten are GC'ed,
			// even if there is a reference to them elsewhere
			while ( cell.childNodes.length ) {
				cell.removeChild( cell.firstChild );
			}
	
			cell.innerHTML = _fnGetCellData( settings, rowIdx, col, 'display' );
		};
	
		// Are we reading last data from DOM or the data object?
		if ( src === 'dom' || ((! src || src === 'auto') && row.src === 'dom') ) {
			// Read the data from the DOM
			row._aData = _fnGetRowElements(
					settings, row, colIdx, colIdx === undefined ? undefined : row._aData
				)
				.data;
		}
		else {
			// Reading from data object, update the DOM
			var cells = row.anCells;
	
			if ( cells ) {
				if ( colIdx !== undefined ) {
					cellWrite( cells[colIdx], colIdx );
				}
				else {
					for ( i=0, ien=cells.length ; i<ien ; i++ ) {
						cellWrite( cells[i], i );
					}
				}
			}
		}
	
		// For both row and cell invalidation, the cached data for sorting and
		// filtering is nulled out
		row._aSortData = null;
		row._aFilterData = null;
	
		// Invalidate the type for a specific column (if given) or all columns since
		// the data might have changed
		var cols = settings.aoColumns;
		if ( colIdx !== undefined ) {
			cols[ colIdx ].sType = null;
		}
		else {
			for ( i=0, ien=cols.length ; i<ien ; i++ ) {
				cols[i].sType = null;
			}
	
			// Update DataTables special `DT_*` attributes for the row
			_fnRowAttributes( settings, row );
		}
	}
	
	
	/**
	 * Build a data source object from an HTML row, reading the contents of the
	 * cells that are in the row.
	 *
	 * @param {object} settings DataTables settings object
	 * @param {node|object} TR element from which to read data or existing row
	 *   object from which to re-read the data from the cells
	 * @param {int} [colIdx] Optional column index
	 * @param {array|object} [d] Data source object. If `colIdx` is given then this
	 *   parameter should also be given and will be used to write the data into.
	 *   Only the column in question will be written
	 * @returns {object} Object with two parameters: `data` the data read, in
	 *   document order, and `cells` and array of nodes (they can be useful to the
	 *   caller, so rather than needing a second traversal to get them, just return
	 *   them from here).
	 * @memberof DataTable#oApi
	 */
	function _fnGetRowElements( settings, row, colIdx, d )
	{
		var
			tds = [],
			td = row.firstChild,
			name, col, o, i=0, contents,
			columns = settings.aoColumns,
			objectRead = settings._rowReadObject;
	
		// Allow the data object to be passed in, or construct
		d = d !== undefined ?
			d :
			objectRead ?
				{} :
				[];
	
		var attr = function ( str, td  ) {
			if ( typeof str === 'string' ) {
				var idx = str.indexOf('@');
	
				if ( idx !== -1 ) {
					var attr = str.substring( idx+1 );
					var setter = _fnSetObjectDataFn( str );
					setter( d, td.getAttribute( attr ) );
				}
			}
		};
	
		// Read data from a cell and store into the data object
		var cellProcess = function ( cell ) {
			if ( colIdx === undefined || colIdx === i ) {
				col = columns[i];
				contents = $.trim(cell.innerHTML);
	
				if ( col && col._bAttrSrc ) {
					var setter = _fnSetObjectDataFn( col.mData._ );
					setter( d, contents );
	
					attr( col.mData.sort, cell );
					attr( col.mData.type, cell );
					attr( col.mData.filter, cell );
				}
				else {
					// Depending on the `data` option for the columns the data can
					// be read to either an object or an array.
					if ( objectRead ) {
						if ( ! col._setter ) {
							// Cache the setter function
							col._setter = _fnSetObjectDataFn( col.mData );
						}
						col._setter( d, contents );
					}
					else {
						d[i] = contents;
					}
				}
			}
	
			i++;
		};
	
		if ( td ) {
			// `tr` element was passed in
			while ( td ) {
				name = td.nodeName.toUpperCase();
	
				if ( name == "TD" || name == "TH" ) {
					cellProcess( td );
					tds.push( td );
				}
	
				td = td.nextSibling;
			}
		}
		else {
			// Existing row object passed in
			tds = row.anCells;
	
			for ( var j=0, jen=tds.length ; j<jen ; j++ ) {
				cellProcess( tds[j] );
			}
		}
	
		// Read the ID from the DOM if present
		var rowNode = row.firstChild ? row : row.nTr;
	
		if ( rowNode ) {
			var id = rowNode.getAttribute( 'id' );
	
			if ( id ) {
				_fnSetObjectDataFn( settings.rowId )( d, id );
			}
		}
	
		return {
			data: d,
			cells: tds
		};
	}
	/**
	 * Create a new TR element (and it's TD children) for a row
	 *  @param {object} oSettings dataTables settings object
	 *  @param {int} iRow Row to consider
	 *  @param {node} [nTrIn] TR element to add to the table - optional. If not given,
	 *    DataTables will create a row automatically
	 *  @param {array} [anTds] Array of TD|TH elements for the row - must be given
	 *    if nTr is.
	 *  @memberof DataTable#oApi
	 */
	function _fnCreateTr ( oSettings, iRow, nTrIn, anTds )
	{
		var
			row = oSettings.aoData[iRow],
			rowData = row._aData,
			cells = [],
			nTr, nTd, oCol,
			i, iLen;
	
		if ( row.nTr === null )
		{
			nTr = nTrIn || document.createElement('tr');
	
			row.nTr = nTr;
			row.anCells = cells;
	
			/* Use a private property on the node to allow reserve mapping from the node
			 * to the aoData array for fast look up
			 */
			nTr._DT_RowIndex = iRow;
	
			/* Special parameters can be given by the data source to be used on the row */
			_fnRowAttributes( oSettings, row );
	
			/* Process each column */
			for ( i=0, iLen=oSettings.aoColumns.length ; i<iLen ; i++ )
			{
				oCol = oSettings.aoColumns[i];
	
				nTd = nTrIn ? anTds[i] : document.createElement( oCol.sCellType );
				nTd._DT_CellIndex = {
					row: iRow,
					column: i
				};
				
				cells.push( nTd );
	
				// Need to create the HTML if new, or if a rendering function is defined
				if ( (!nTrIn || oCol.mRender || oCol.mData !== i) &&
					 (!$.isPlainObject(oCol.mData) || oCol.mData._ !== i+'.display')
				) {
					nTd.innerHTML = _fnGetCellData( oSettings, iRow, i, 'display' );
				}
	
				/* Add user defined class */
				if ( oCol.sClass )
				{
					nTd.className += ' '+oCol.sClass;
				}
	
				// Visibility - add or remove as required
				if ( oCol.bVisible && ! nTrIn )
				{
					nTr.appendChild( nTd );
				}
				else if ( ! oCol.bVisible && nTrIn )
				{
					nTd.parentNode.removeChild( nTd );
				}
	
				if ( oCol.fnCreatedCell )
				{
					oCol.fnCreatedCell.call( oSettings.oInstance,
						nTd, _fnGetCellData( oSettings, iRow, i ), rowData, iRow, i
					);
				}
			}
	
			_fnCallbackFire( oSettings, 'aoRowCreatedCallback', null, [nTr, rowData, iRow] );
		}
	
		// Remove once webkit bug 131819 and Chromium bug 365619 have been resolved
		// and deployed
		row.nTr.setAttribute( 'role', 'row' );
	}
	
	
	/**
	 * Add attributes to a row based on the special `DT_*` parameters in a data
	 * source object.
	 *  @param {object} settings DataTables settings object
	 *  @param {object} DataTables row object for the row to be modified
	 *  @memberof DataTable#oApi
	 */
	function _fnRowAttributes( settings, row )
	{
		var tr = row.nTr;
		var data = row._aData;
	
		if ( tr ) {
			var id = settings.rowIdFn( data );
	
			if ( id ) {
				tr.id = id;
			}
	
			if ( data.DT_RowClass ) {
				// Remove any classes added by DT_RowClass before
				var a = data.DT_RowClass.split(' ');
				row.__rowc = row.__rowc ?
					_unique( row.__rowc.concat( a ) ) :
					a;
	
				$(tr)
					.removeClass( row.__rowc.join(' ') )
					.addClass( data.DT_RowClass );
			}
	
			if ( data.DT_RowAttr ) {
				$(tr).attr( data.DT_RowAttr );
			}
	
			if ( data.DT_RowData ) {
				$(tr).data( data.DT_RowData );
			}
		}
	}
	
	
	/**
	 * Create the HTML header for the table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnBuildHead( oSettings )
	{
		var i, ien, cell, row, column;
		var thead = oSettings.nTHead;
		var tfoot = oSettings.nTFoot;
		var createHeader = $('th, td', thead).length === 0;
		var classes = oSettings.oClasses;
		var columns = oSettings.aoColumns;
	
		if ( createHeader ) {
			row = $('<tr/>').appendTo( thead );
		}
	
		for ( i=0, ien=columns.length ; i<ien ; i++ ) {
			column = columns[i];
			cell = $( column.nTh ).addClass( column.sClass );
	
			if ( createHeader ) {
				cell.appendTo( row );
			}
	
			// 1.11 move into sorting
			if ( oSettings.oFeatures.bSort ) {
				cell.addClass( column.sSortingClass );
	
				if ( column.bSortable !== false ) {
					cell
						.attr( 'tabindex', oSettings.iTabIndex )
						.attr( 'aria-controls', oSettings.sTableId );
	
					_fnSortAttachListener( oSettings, column.nTh, i );
				}
			}
	
			if ( column.sTitle != cell[0].innerHTML ) {
				cell.html( column.sTitle );
			}
	
			_fnRenderer( oSettings, 'header' )(
				oSettings, cell, column, classes
			);
		}
	
		if ( createHeader ) {
			_fnDetectHeader( oSettings.aoHeader, thead );
		}
		
		/* ARIA role for the rows */
	 	$(thead).find('>tr').attr('role', 'row');
	
		/* Deal with the footer - add classes if required */
		$(thead).find('>tr>th, >tr>td').addClass( classes.sHeaderTH );
		$(tfoot).find('>tr>th, >tr>td').addClass( classes.sFooterTH );
	
		// Cache the footer cells. Note that we only take the cells from the first
		// row in the footer. If there is more than one row the user wants to
		// interact with, they need to use the table().foot() method. Note also this
		// allows cells to be used for multiple columns using colspan
		if ( tfoot !== null ) {
			var cells = oSettings.aoFooter[0];
	
			for ( i=0, ien=cells.length ; i<ien ; i++ ) {
				column = columns[i];
				column.nTf = cells[i].cell;
	
				if ( column.sClass ) {
					$(column.nTf).addClass( column.sClass );
				}
			}
		}
	}
	
	
	/**
	 * Draw the header (or footer) element based on the column visibility states. The
	 * methodology here is to use the layout array from _fnDetectHeader, modified for
	 * the instantaneous column visibility, to construct the new layout. The grid is
	 * traversed over cell at a time in a rows x columns grid fashion, although each
	 * cell insert can cover multiple elements in the grid - which is tracks using the
	 * aApplied array. Cell inserts in the grid will only occur where there isn't
	 * already a cell in that position.
	 *  @param {object} oSettings dataTables settings object
	 *  @param array {objects} aoSource Layout array from _fnDetectHeader
	 *  @param {boolean} [bIncludeHidden=false] If true then include the hidden columns in the calc,
	 *  @memberof DataTable#oApi
	 */
	function _fnDrawHead( oSettings, aoSource, bIncludeHidden )
	{
		var i, iLen, j, jLen, k, kLen, n, nLocalTr;
		var aoLocal = [];
		var aApplied = [];
		var iColumns = oSettings.aoColumns.length;
		var iRowspan, iColspan;
	
		if ( ! aoSource )
		{
			return;
		}
	
		if (  bIncludeHidden === undefined )
		{
			bIncludeHidden = false;
		}
	
		/* Make a copy of the master layout array, but without the visible columns in it */
		for ( i=0, iLen=aoSource.length ; i<iLen ; i++ )
		{
			aoLocal[i] = aoSource[i].slice();
			aoLocal[i].nTr = aoSource[i].nTr;
	
			/* Remove any columns which are currently hidden */
			for ( j=iColumns-1 ; j>=0 ; j-- )
			{
				if ( !oSettings.aoColumns[j].bVisible && !bIncludeHidden )
				{
					aoLocal[i].splice( j, 1 );
				}
			}
	
			/* Prep the applied array - it needs an element for each row */
			aApplied.push( [] );
		}
	
		for ( i=0, iLen=aoLocal.length ; i<iLen ; i++ )
		{
			nLocalTr = aoLocal[i].nTr;
	
			/* All cells are going to be replaced, so empty out the row */
			if ( nLocalTr )
			{
				while( (n = nLocalTr.firstChild) )
				{
					nLocalTr.removeChild( n );
				}
			}
	
			for ( j=0, jLen=aoLocal[i].length ; j<jLen ; j++ )
			{
				iRowspan = 1;
				iColspan = 1;
	
				/* Check to see if there is already a cell (row/colspan) covering our target
				 * insert point. If there is, then there is nothing to do.
				 */
				if ( aApplied[i][j] === undefined )
				{
					nLocalTr.appendChild( aoLocal[i][j].cell );
					aApplied[i][j] = 1;
	
					/* Expand the cell to cover as many rows as needed */
					while ( aoLocal[i+iRowspan] !== undefined &&
					        aoLocal[i][j].cell == aoLocal[i+iRowspan][j].cell )
					{
						aApplied[i+iRowspan][j] = 1;
						iRowspan++;
					}
	
					/* Expand the cell to cover as many columns as needed */
					while ( aoLocal[i][j+iColspan] !== undefined &&
					        aoLocal[i][j].cell == aoLocal[i][j+iColspan].cell )
					{
						/* Must update the applied array over the rows for the columns */
						for ( k=0 ; k<iRowspan ; k++ )
						{
							aApplied[i+k][j+iColspan] = 1;
						}
						iColspan++;
					}
	
					/* Do the actual expansion in the DOM */
					$(aoLocal[i][j].cell)
						.attr('rowspan', iRowspan)
						.attr('colspan', iColspan);
				}
			}
		}
	}
	
	
	/**
	 * Insert the required TR nodes into the table for display
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnDraw( oSettings )
	{
		/* Provide a pre-callback function which can be used to cancel the draw is false is returned */
		var aPreDraw = _fnCallbackFire( oSettings, 'aoPreDrawCallback', 'preDraw', [oSettings] );
		if ( $.inArray( false, aPreDraw ) !== -1 )
		{
			_fnProcessingDisplay( oSettings, false );
			return;
		}
	
		var i, iLen, n;
		var anRows = [];
		var iRowCount = 0;
		var asStripeClasses = oSettings.asStripeClasses;
		var iStripes = asStripeClasses.length;
		var iOpenRows = oSettings.aoOpenRows.length;
		var oLang = oSettings.oLanguage;
		var iInitDisplayStart = oSettings.iInitDisplayStart;
		var bServerSide = _fnDataSource( oSettings ) == 'ssp';
		var aiDisplay = oSettings.aiDisplay;
	
		oSettings.bDrawing = true;
	
		/* Check and see if we have an initial draw position from state saving */
		if ( iInitDisplayStart !== undefined && iInitDisplayStart !== -1 )
		{
			oSettings._iDisplayStart = bServerSide ?
				iInitDisplayStart :
				iInitDisplayStart >= oSettings.fnRecordsDisplay() ?
					0 :
					iInitDisplayStart;
	
			oSettings.iInitDisplayStart = -1;
		}
	
		var iDisplayStart = oSettings._iDisplayStart;
		var iDisplayEnd = oSettings.fnDisplayEnd();
	
		/* Server-side processing draw intercept */
		if ( oSettings.bDeferLoading )
		{
			oSettings.bDeferLoading = false;
			oSettings.iDraw++;
			_fnProcessingDisplay( oSettings, false );
		}
		else if ( !bServerSide )
		{
			oSettings.iDraw++;
		}
		else if ( !oSettings.bDestroying && !_fnAjaxUpdate( oSettings ) )
		{
			return;
		}
	
		if ( aiDisplay.length !== 0 )
		{
			var iStart = bServerSide ? 0 : iDisplayStart;
			var iEnd = bServerSide ? oSettings.aoData.length : iDisplayEnd;
	
			for ( var j=iStart ; j<iEnd ; j++ )
			{
				var iDataIndex = aiDisplay[j];
				var aoData = oSettings.aoData[ iDataIndex ];
				if ( aoData.nTr === null )
				{
					_fnCreateTr( oSettings, iDataIndex );
				}
	
				var nRow = aoData.nTr;
	
				/* Remove the old striping classes and then add the new one */
				if ( iStripes !== 0 )
				{
					var sStripe = asStripeClasses[ iRowCount % iStripes ];
					if ( aoData._sRowStripe != sStripe )
					{
						$(nRow).removeClass( aoData._sRowStripe ).addClass( sStripe );
						aoData._sRowStripe = sStripe;
					}
				}
	
				// Row callback functions - might want to manipulate the row
				// iRowCount and j are not currently documented. Are they at all
				// useful?
				_fnCallbackFire( oSettings, 'aoRowCallback', null,
					[nRow, aoData._aData, iRowCount, j] );
	
				anRows.push( nRow );
				iRowCount++;
			}
		}
		else
		{
			/* Table is empty - create a row with an empty message in it */
			var sZero = oLang.sZeroRecords;
			if ( oSettings.iDraw == 1 &&  _fnDataSource( oSettings ) == 'ajax' )
			{
				sZero = oLang.sLoadingRecords;
			}
			else if ( oLang.sEmptyTable && oSettings.fnRecordsTotal() === 0 )
			{
				sZero = oLang.sEmptyTable;
			}
	
			anRows[ 0 ] = $( '<tr/>', { 'class': iStripes ? asStripeClasses[0] : '' } )
				.append( $('<td />', {
					'valign':  'top',
					'colSpan': _fnVisbleColumns( oSettings ),
					'class':   oSettings.oClasses.sRowEmpty
				} ).html( sZero ) )[0];
		}
	
		/* Header and footer callbacks */
		_fnCallbackFire( oSettings, 'aoHeaderCallback', 'header', [ $(oSettings.nTHead).children('tr')[0],
			_fnGetDataMaster( oSettings ), iDisplayStart, iDisplayEnd, aiDisplay ] );
	
		_fnCallbackFire( oSettings, 'aoFooterCallback', 'footer', [ $(oSettings.nTFoot).children('tr')[0],
			_fnGetDataMaster( oSettings ), iDisplayStart, iDisplayEnd, aiDisplay ] );
	
		var body = $(oSettings.nTBody);
	
		body.children().detach();
		body.append( $(anRows) );
	
		/* Call all required callback functions for the end of a draw */
		_fnCallbackFire( oSettings, 'aoDrawCallback', 'draw', [oSettings] );
	
		/* Draw is complete, sorting and filtering must be as well */
		oSettings.bSorted = false;
		oSettings.bFiltered = false;
		oSettings.bDrawing = false;
	}
	
	
	/**
	 * Redraw the table - taking account of the various features which are enabled
	 *  @param {object} oSettings dataTables settings object
	 *  @param {boolean} [holdPosition] Keep the current paging position. By default
	 *    the paging is reset to the first page
	 *  @memberof DataTable#oApi
	 */
	function _fnReDraw( settings, holdPosition )
	{
		var
			features = settings.oFeatures,
			sort     = features.bSort,
			filter   = features.bFilter;
	
		if ( sort ) {
			_fnSort( settings );
		}
	
		if ( filter ) {
			_fnFilterComplete( settings, settings.oPreviousSearch );
		}
		else {
			// No filtering, so we want to just use the display master
			settings.aiDisplay = settings.aiDisplayMaster.slice();
		}
	
		if ( holdPosition !== true ) {
			settings._iDisplayStart = 0;
		}
	
		// Let any modules know about the draw hold position state (used by
		// scrolling internally)
		settings._drawHold = holdPosition;
	
		_fnDraw( settings );
	
		settings._drawHold = false;
	}
	
	
	/**
	 * Add the options to the page HTML for the table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnAddOptionsHtml ( oSettings )
	{
		var classes = oSettings.oClasses;
		var table = $(oSettings.nTable);
		var holding = $('<div/>').insertBefore( table ); // Holding element for speed
		var features = oSettings.oFeatures;
	
		// All DataTables are wrapped in a div
		var insert = $('<div/>', {
			id:      oSettings.sTableId+'_wrapper',
			'class': classes.sWrapper + (oSettings.nTFoot ? '' : ' '+classes.sNoFooter)
		} );
	
		oSettings.nHolding = holding[0];
		oSettings.nTableWrapper = insert[0];
		oSettings.nTableReinsertBefore = oSettings.nTable.nextSibling;
	
		/* Loop over the user set positioning and place the elements as needed */
		var aDom = oSettings.sDom.split('');
		var featureNode, cOption, nNewNode, cNext, sAttr, j;
		for ( var i=0 ; i<aDom.length ; i++ )
		{
			featureNode = null;
			cOption = aDom[i];
	
			if ( cOption == '<' )
			{
				/* New container div */
				nNewNode = $('<div/>')[0];
	
				/* Check to see if we should append an id and/or a class name to the container */
				cNext = aDom[i+1];
				if ( cNext == "'" || cNext == '"' )
				{
					sAttr = "";
					j = 2;
					while ( aDom[i+j] != cNext )
					{
						sAttr += aDom[i+j];
						j++;
					}
	
					/* Replace jQuery UI constants @todo depreciated */
					if ( sAttr == "H" )
					{
						sAttr = classes.sJUIHeader;
					}
					else if ( sAttr == "F" )
					{
						sAttr = classes.sJUIFooter;
					}
	
					/* The attribute can be in the format of "#id.class", "#id" or "class" This logic
					 * breaks the string into parts and applies them as needed
					 */
					if ( sAttr.indexOf('.') != -1 )
					{
						var aSplit = sAttr.split('.');
						nNewNode.id = aSplit[0].substr(1, aSplit[0].length-1);
						nNewNode.className = aSplit[1];
					}
					else if ( sAttr.charAt(0) == "#" )
					{
						nNewNode.id = sAttr.substr(1, sAttr.length-1);
					}
					else
					{
						nNewNode.className = sAttr;
					}
	
					i += j; /* Move along the position array */
				}
	
				insert.append( nNewNode );
				insert = $(nNewNode);
			}
			else if ( cOption == '>' )
			{
				/* End container div */
				insert = insert.parent();
			}
			// @todo Move options into their own plugins?
			else if ( cOption == 'l' && features.bPaginate && features.bLengthChange )
			{
				/* Length */
				featureNode = _fnFeatureHtmlLength( oSettings );
			}
			else if ( cOption == 'f' && features.bFilter )
			{
				/* Filter */
				featureNode = _fnFeatureHtmlFilter( oSettings );
			}
			else if ( cOption == 'r' && features.bProcessing )
			{
				/* pRocessing */
				featureNode = _fnFeatureHtmlProcessing( oSettings );
			}
			else if ( cOption == 't' )
			{
				/* Table */
				featureNode = _fnFeatureHtmlTable( oSettings );
			}
			else if ( cOption ==  'i' && features.bInfo )
			{
				/* Info */
				featureNode = _fnFeatureHtmlInfo( oSettings );
			}
			else if ( cOption == 'p' && features.bPaginate )
			{
				/* Pagination */
				featureNode = _fnFeatureHtmlPaginate( oSettings );
			}
			else if ( DataTable.ext.feature.length !== 0 )
			{
				/* Plug-in features */
				var aoFeatures = DataTable.ext.feature;
				for ( var k=0, kLen=aoFeatures.length ; k<kLen ; k++ )
				{
					if ( cOption == aoFeatures[k].cFeature )
					{
						featureNode = aoFeatures[k].fnInit( oSettings );
						break;
					}
				}
			}
	
			/* Add to the 2D features array */
			if ( featureNode )
			{
				var aanFeatures = oSettings.aanFeatures;
	
				if ( ! aanFeatures[cOption] )
				{
					aanFeatures[cOption] = [];
				}
	
				aanFeatures[cOption].push( featureNode );
				insert.append( featureNode );
			}
		}
	
		/* Built our DOM structure - replace the holding div with what we want */
		holding.replaceWith( insert );
		oSettings.nHolding = null;
	}
	
	
	/**
	 * Use the DOM source to create up an array of header cells. The idea here is to
	 * create a layout grid (array) of rows x columns, which contains a reference
	 * to the cell that that point in the grid (regardless of col/rowspan), such that
	 * any column / row could be removed and the new grid constructed
	 *  @param array {object} aLayout Array to store the calculated layout in
	 *  @param {node} nThead The header/footer element for the table
	 *  @memberof DataTable#oApi
	 */
	function _fnDetectHeader ( aLayout, nThead )
	{
		var nTrs = $(nThead).children('tr');
		var nTr, nCell;
		var i, k, l, iLen, jLen, iColShifted, iColumn, iColspan, iRowspan;
		var bUnique;
		var fnShiftCol = function ( a, i, j ) {
			var k = a[i];
	                while ( k[j] ) {
				j++;
			}
			return j;
		};
	
		aLayout.splice( 0, aLayout.length );
	
		/* We know how many rows there are in the layout - so prep it */
		for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
		{
			aLayout.push( [] );
		}
	
		/* Calculate a layout array */
		for ( i=0, iLen=nTrs.length ; i<iLen ; i++ )
		{
			nTr = nTrs[i];
			iColumn = 0;
	
			/* For every cell in the row... */
			nCell = nTr.firstChild;
			while ( nCell ) {
				if ( nCell.nodeName.toUpperCase() == "TD" ||
				     nCell.nodeName.toUpperCase() == "TH" )
				{
					/* Get the col and rowspan attributes from the DOM and sanitise them */
					iColspan = nCell.getAttribute('colspan') * 1;
					iRowspan = nCell.getAttribute('rowspan') * 1;
					iColspan = (!iColspan || iColspan===0 || iColspan===1) ? 1 : iColspan;
					iRowspan = (!iRowspan || iRowspan===0 || iRowspan===1) ? 1 : iRowspan;
	
					/* There might be colspan cells already in this row, so shift our target
					 * accordingly
					 */
					iColShifted = fnShiftCol( aLayout, i, iColumn );
	
					/* Cache calculation for unique columns */
					bUnique = iColspan === 1 ? true : false;
	
					/* If there is col / rowspan, copy the information into the layout grid */
					for ( l=0 ; l<iColspan ; l++ )
					{
						for ( k=0 ; k<iRowspan ; k++ )
						{
							aLayout[i+k][iColShifted+l] = {
								"cell": nCell,
								"unique": bUnique
							};
							aLayout[i+k].nTr = nTr;
						}
					}
				}
				nCell = nCell.nextSibling;
			}
		}
	}
	
	
	/**
	 * Get an array of unique th elements, one for each column
	 *  @param {object} oSettings dataTables settings object
	 *  @param {node} nHeader automatically detect the layout from this node - optional
	 *  @param {array} aLayout thead/tfoot layout from _fnDetectHeader - optional
	 *  @returns array {node} aReturn list of unique th's
	 *  @memberof DataTable#oApi
	 */
	function _fnGetUniqueThs ( oSettings, nHeader, aLayout )
	{
		var aReturn = [];
		if ( !aLayout )
		{
			aLayout = oSettings.aoHeader;
			if ( nHeader )
			{
				aLayout = [];
				_fnDetectHeader( aLayout, nHeader );
			}
		}
	
		for ( var i=0, iLen=aLayout.length ; i<iLen ; i++ )
		{
			for ( var j=0, jLen=aLayout[i].length ; j<jLen ; j++ )
			{
				if ( aLayout[i][j].unique &&
					 (!aReturn[j] || !oSettings.bSortCellsTop) )
				{
					aReturn[j] = aLayout[i][j].cell;
				}
			}
		}
	
		return aReturn;
	}
	
	/**
	 * Create an Ajax call based on the table's settings, taking into account that
	 * parameters can have multiple forms, and backwards compatibility.
	 *
	 * @param {object} oSettings dataTables settings object
	 * @param {array} data Data to send to the server, required by
	 *     DataTables - may be augmented by developer callbacks
	 * @param {function} fn Callback function to run when data is obtained
	 */
	function _fnBuildAjax( oSettings, data, fn )
	{
		// Compatibility with 1.9-, allow fnServerData and event to manipulate
		_fnCallbackFire( oSettings, 'aoServerParams', 'serverParams', [data] );
	
		// Convert to object based for 1.10+ if using the old array scheme which can
		// come from server-side processing or serverParams
		if ( data && $.isArray(data) ) {
			var tmp = {};
			var rbracket = /(.*?)\[\]$/;
	
			$.each( data, function (key, val) {
				var match = val.name.match(rbracket);
	
				if ( match ) {
					// Support for arrays
					var name = match[0];
	
					if ( ! tmp[ name ] ) {
						tmp[ name ] = [];
					}
					tmp[ name ].push( val.value );
				}
				else {
					tmp[val.name] = val.value;
				}
			} );
			data = tmp;
		}
	
		var ajaxData;
		var ajax = oSettings.ajax;
		var instance = oSettings.oInstance;
		var callback = function ( json ) {
			_fnCallbackFire( oSettings, null, 'xhr', [oSettings, json, oSettings.jqXHR] );
			fn( json );
		};
	
		if ( $.isPlainObject( ajax ) && ajax.data )
		{
			ajaxData = ajax.data;
	
			var newData = $.isFunction( ajaxData ) ?
				ajaxData( data, oSettings ) :  // fn can manipulate data or return
				ajaxData;                      // an object object or array to merge
	
			// If the function returned something, use that alone
			data = $.isFunction( ajaxData ) && newData ?
				newData :
				$.extend( true, data, newData );
	
			// Remove the data property as we've resolved it already and don't want
			// jQuery to do it again (it is restored at the end of the function)
			delete ajax.data;
		}
	
		var baseAjax = {
			"data": data,
			"success": function (json) {
				var error = json.error || json.sError;
				if ( error ) {
					_fnLog( oSettings, 0, error );
				}
	
				oSettings.json = json;
				callback( json );
			},
			"dataType": "json",
			"cache": false,
			"type": oSettings.sServerMethod,
			"error": function (xhr, error, thrown) {
				var ret = _fnCallbackFire( oSettings, null, 'xhr', [oSettings, null, oSettings.jqXHR] );
	
				if ( $.inArray( true, ret ) === -1 ) {
					if ( error == "parsererror" ) {
						_fnLog( oSettings, 0, 'Invalid JSON response', 1 );
					}
					else if ( xhr.readyState === 4 ) {
						_fnLog( oSettings, 0, 'Ajax error', 7 );
					}
				}
	
				_fnProcessingDisplay( oSettings, false );
			}
		};
	
		// Store the data submitted for the API
		oSettings.oAjaxData = data;
	
		// Allow plug-ins and external processes to modify the data
		_fnCallbackFire( oSettings, null, 'preXhr', [oSettings, data] );
	
		if ( oSettings.fnServerData )
		{
			// DataTables 1.9- compatibility
			oSettings.fnServerData.call( instance,
				oSettings.sAjaxSource,
				$.map( data, function (val, key) { // Need to convert back to 1.9 trad format
					return { name: key, value: val };
				} ),
				callback,
				oSettings
			);
		}
		else if ( oSettings.sAjaxSource || typeof ajax === 'string' )
		{
			// DataTables 1.9- compatibility
			oSettings.jqXHR = $.ajax( $.extend( baseAjax, {
				url: ajax || oSettings.sAjaxSource
			} ) );
		}
		else if ( $.isFunction( ajax ) )
		{
			// Is a function - let the caller define what needs to be done
			oSettings.jqXHR = ajax.call( instance, data, callback, oSettings );
		}
		else
		{
			// Object to extend the base settings
			oSettings.jqXHR = $.ajax( $.extend( baseAjax, ajax ) );
	
			// Restore for next time around
			ajax.data = ajaxData;
		}
	}
	
	
	/**
	 * Update the table using an Ajax call
	 *  @param {object} settings dataTables settings object
	 *  @returns {boolean} Block the table drawing or not
	 *  @memberof DataTable#oApi
	 */
	function _fnAjaxUpdate( settings )
	{
		if ( settings.bAjaxDataGet ) {
			settings.iDraw++;
			_fnProcessingDisplay( settings, true );
	
			_fnBuildAjax(
				settings,
				_fnAjaxParameters( settings ),
				function(json) {
					_fnAjaxUpdateDraw( settings, json );
				}
			);
	
			return false;
		}
		return true;
	}
	
	
	/**
	 * Build up the parameters in an object needed for a server-side processing
	 * request. Note that this is basically done twice, is different ways - a modern
	 * method which is used by default in DataTables 1.10 which uses objects and
	 * arrays, or the 1.9- method with is name / value pairs. 1.9 method is used if
	 * the sAjaxSource option is used in the initialisation, or the legacyAjax
	 * option is set.
	 *  @param {object} oSettings dataTables settings object
	 *  @returns {bool} block the table drawing or not
	 *  @memberof DataTable#oApi
	 */
	function _fnAjaxParameters( settings )
	{
		var
			columns = settings.aoColumns,
			columnCount = columns.length,
			features = settings.oFeatures,
			preSearch = settings.oPreviousSearch,
			preColSearch = settings.aoPreSearchCols,
			i, data = [], dataProp, column, columnSearch,
			sort = _fnSortFlatten( settings ),
			displayStart = settings._iDisplayStart,
			displayLength = features.bPaginate !== false ?
				settings._iDisplayLength :
				-1;
	
		var param = function ( name, value ) {
			data.push( { 'name': name, 'value': value } );
		};
	
		// DataTables 1.9- compatible method
		param( 'sEcho',          settings.iDraw );
		param( 'iColumns',       columnCount );
		param( 'sColumns',       _pluck( columns, 'sName' ).join(',') );
		param( 'iDisplayStart',  displayStart );
		param( 'iDisplayLength', displayLength );
	
		// DataTables 1.10+ method
		var d = {
			draw:    settings.iDraw,
			columns: [],
			order:   [],
			start:   displayStart,
			length:  displayLength,
			search:  {
				value: preSearch.sSearch,
				regex: preSearch.bRegex
			}
		};
	
		for ( i=0 ; i<columnCount ; i++ ) {
			column = columns[i];
			columnSearch = preColSearch[i];
			dataProp = typeof column.mData=="function" ? 'function' : column.mData ;
	
			d.columns.push( {
				data:       dataProp,
				name:       column.sName,
				searchable: column.bSearchable,
				orderable:  column.bSortable,
				search:     {
					value: columnSearch.sSearch,
					regex: columnSearch.bRegex
				}
			} );
	
			param( "mDataProp_"+i, dataProp );
	
			if ( features.bFilter ) {
				param( 'sSearch_'+i,     columnSearch.sSearch );
				param( 'bRegex_'+i,      columnSearch.bRegex );
				param( 'bSearchable_'+i, column.bSearchable );
			}
	
			if ( features.bSort ) {
				param( 'bSortable_'+i, column.bSortable );
			}
		}
	
		if ( features.bFilter ) {
			param( 'sSearch', preSearch.sSearch );
			param( 'bRegex', preSearch.bRegex );
		}
	
		if ( features.bSort ) {
			$.each( sort, function ( i, val ) {
				d.order.push( { column: val.col, dir: val.dir } );
	
				param( 'iSortCol_'+i, val.col );
				param( 'sSortDir_'+i, val.dir );
			} );
	
			param( 'iSortingCols', sort.length );
		}
	
		// If the legacy.ajax parameter is null, then we automatically decide which
		// form to use, based on sAjaxSource
		var legacy = DataTable.ext.legacy.ajax;
		if ( legacy === null ) {
			return settings.sAjaxSource ? data : d;
		}
	
		// Otherwise, if legacy has been specified then we use that to decide on the
		// form
		return legacy ? data : d;
	}
	
	
	/**
	 * Data the data from the server (nuking the old) and redraw the table
	 *  @param {object} oSettings dataTables settings object
	 *  @param {object} json json data return from the server.
	 *  @param {string} json.sEcho Tracking flag for DataTables to match requests
	 *  @param {int} json.iTotalRecords Number of records in the data set, not accounting for filtering
	 *  @param {int} json.iTotalDisplayRecords Number of records in the data set, accounting for filtering
	 *  @param {array} json.aaData The data to display on this page
	 *  @param {string} [json.sColumns] Column ordering (sName, comma separated)
	 *  @memberof DataTable#oApi
	 */
	function _fnAjaxUpdateDraw ( settings, json )
	{
		// v1.10 uses camelCase variables, while 1.9 uses Hungarian notation.
		// Support both
		var compat = function ( old, modern ) {
			return json[old] !== undefined ? json[old] : json[modern];
		};
	
		var data = _fnAjaxDataSrc( settings, json );
		var draw            = compat( 'sEcho',                'draw' );
		var recordsTotal    = compat( 'iTotalRecords',        'recordsTotal' );
		var recordsFiltered = compat( 'iTotalDisplayRecords', 'recordsFiltered' );
	
		if ( draw ) {
			// Protect against out of sequence returns
			if ( draw*1 < settings.iDraw ) {
				return;
			}
			settings.iDraw = draw * 1;
		}
	
		_fnClearTable( settings );
		settings._iRecordsTotal   = parseInt(recordsTotal, 10);
		settings._iRecordsDisplay = parseInt(recordsFiltered, 10);
	
		for ( var i=0, ien=data.length ; i<ien ; i++ ) {
			_fnAddData( settings, data[i] );
		}
		settings.aiDisplay = settings.aiDisplayMaster.slice();
	
		settings.bAjaxDataGet = false;
		_fnDraw( settings );
	
		if ( ! settings._bInitComplete ) {
			_fnInitComplete( settings, json );
		}
	
		settings.bAjaxDataGet = true;
		_fnProcessingDisplay( settings, false );
	}
	
	
	/**
	 * Get the data from the JSON data source to use for drawing a table. Using
	 * `_fnGetObjectDataFn` allows the data to be sourced from a property of the
	 * source object, or from a processing function.
	 *  @param {object} oSettings dataTables settings object
	 *  @param  {object} json Data source object / array from the server
	 *  @return {array} Array of data to use
	 */
	function _fnAjaxDataSrc ( oSettings, json )
	{
		var dataSrc = $.isPlainObject( oSettings.ajax ) && oSettings.ajax.dataSrc !== undefined ?
			oSettings.ajax.dataSrc :
			oSettings.sAjaxDataProp; // Compatibility with 1.9-.
	
		// Compatibility with 1.9-. In order to read from aaData, check if the
		// default has been changed, if not, check for aaData
		if ( dataSrc === 'data' ) {
			return json.aaData || json[dataSrc];
		}
	
		return dataSrc !== "" ?
			_fnGetObjectDataFn( dataSrc )( json ) :
			json;
	}
	
	/**
	 * Generate the node required for filtering text
	 *  @returns {node} Filter control element
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlFilter ( settings )
	{
		var classes = settings.oClasses;
		var tableId = settings.sTableId;
		var language = settings.oLanguage;
		var previousSearch = settings.oPreviousSearch;
		var features = settings.aanFeatures;
		var input = '<input type="search" class="'+classes.sFilterInput+'"/>';
	
		var str = language.sSearch;
		str = str.match(/_INPUT_/) ?
			str.replace('_INPUT_', input) :
			str+input;
	
		var filter = $('<div/>', {
				'id': ! features.f ? tableId+'_filter' : null,
				'class': classes.sFilter
			} )
			.append( $('<label/>' ).append( str ) );
	
		var searchFn = function() {
			/* Update all other filter input elements for the new display */
			var n = features.f;
			var val = !this.value ? "" : this.value; // mental IE8 fix :-(
	
			/* Now do the filter */
			if ( val != previousSearch.sSearch ) {
				_fnFilterComplete( settings, {
					"sSearch": val,
					"bRegex": previousSearch.bRegex,
					"bSmart": previousSearch.bSmart ,
					"bCaseInsensitive": previousSearch.bCaseInsensitive
				} );
	
				// Need to redraw, without resorting
				settings._iDisplayStart = 0;
				_fnDraw( settings );
			}
		};
	
		var searchDelay = settings.searchDelay !== null ?
			settings.searchDelay :
			_fnDataSource( settings ) === 'ssp' ?
				400 :
				0;
	
		var jqFilter = $('input', filter)
			.val( previousSearch.sSearch )
			.attr( 'placeholder', language.sSearchPlaceholder )
			.on(
				'keyup.DT search.DT input.DT paste.DT cut.DT',
				searchDelay ?
					_fnThrottle( searchFn, searchDelay ) :
					searchFn
			)
			.on( 'keypress.DT', function(e) {
				/* Prevent form submission */
				if ( e.keyCode == 13 ) {
					return false;
				}
			} )
			.attr('aria-controls', tableId);
	
		// Update the input elements whenever the table is filtered
		$(settings.nTable).on( 'search.dt.DT', function ( ev, s ) {
			if ( settings === s ) {
				// IE9 throws an 'unknown error' if document.activeElement is used
				// inside an iframe or frame...
				try {
					if ( jqFilter[0] !== document.activeElement ) {
						jqFilter.val( previousSearch.sSearch );
					}
				}
				catch ( e ) {}
			}
		} );
	
		return filter[0];
	}
	
	
	/**
	 * Filter the table using both the global filter and column based filtering
	 *  @param {object} oSettings dataTables settings object
	 *  @param {object} oSearch search information
	 *  @param {int} [iForce] force a research of the master array (1) or not (undefined or 0)
	 *  @memberof DataTable#oApi
	 */
	function _fnFilterComplete ( oSettings, oInput, iForce )
	{
		var oPrevSearch = oSettings.oPreviousSearch;
		var aoPrevSearch = oSettings.aoPreSearchCols;
		var fnSaveFilter = function ( oFilter ) {
			/* Save the filtering values */
			oPrevSearch.sSearch = oFilter.sSearch;
			oPrevSearch.bRegex = oFilter.bRegex;
			oPrevSearch.bSmart = oFilter.bSmart;
			oPrevSearch.bCaseInsensitive = oFilter.bCaseInsensitive;
		};
		var fnRegex = function ( o ) {
			// Backwards compatibility with the bEscapeRegex option
			return o.bEscapeRegex !== undefined ? !o.bEscapeRegex : o.bRegex;
		};
	
		// Resolve any column types that are unknown due to addition or invalidation
		// @todo As per sort - can this be moved into an event handler?
		_fnColumnTypes( oSettings );
	
		/* In server-side processing all filtering is done by the server, so no point hanging around here */
		if ( _fnDataSource( oSettings ) != 'ssp' )
		{
			/* Global filter */
			_fnFilter( oSettings, oInput.sSearch, iForce, fnRegex(oInput), oInput.bSmart, oInput.bCaseInsensitive );
			fnSaveFilter( oInput );
	
			/* Now do the individual column filter */
			for ( var i=0 ; i<aoPrevSearch.length ; i++ )
			{
				_fnFilterColumn( oSettings, aoPrevSearch[i].sSearch, i, fnRegex(aoPrevSearch[i]),
					aoPrevSearch[i].bSmart, aoPrevSearch[i].bCaseInsensitive );
			}
	
			/* Custom filtering */
			_fnFilterCustom( oSettings );
		}
		else
		{
			fnSaveFilter( oInput );
		}
	
		/* Tell the draw function we have been filtering */
		oSettings.bFiltered = true;
		_fnCallbackFire( oSettings, null, 'search', [oSettings] );
	}
	
	
	/**
	 * Apply custom filtering functions
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnFilterCustom( settings )
	{
		var filters = DataTable.ext.search;
		var displayRows = settings.aiDisplay;
		var row, rowIdx;
	
		for ( var i=0, ien=filters.length ; i<ien ; i++ ) {
			var rows = [];
	
			// Loop over each row and see if it should be included
			for ( var j=0, jen=displayRows.length ; j<jen ; j++ ) {
				rowIdx = displayRows[ j ];
				row = settings.aoData[ rowIdx ];
	
				if ( filters[i]( settings, row._aFilterData, rowIdx, row._aData, j ) ) {
					rows.push( rowIdx );
				}
			}
	
			// So the array reference doesn't break set the results into the
			// existing array
			displayRows.length = 0;
			$.merge( displayRows, rows );
		}
	}
	
	
	/**
	 * Filter the table on a per-column basis
	 *  @param {object} oSettings dataTables settings object
	 *  @param {string} sInput string to filter on
	 *  @param {int} iColumn column to filter
	 *  @param {bool} bRegex treat search string as a regular expression or not
	 *  @param {bool} bSmart use smart filtering or not
	 *  @param {bool} bCaseInsensitive Do case insenstive matching or not
	 *  @memberof DataTable#oApi
	 */
	function _fnFilterColumn ( settings, searchStr, colIdx, regex, smart, caseInsensitive )
	{
		if ( searchStr === '' ) {
			return;
		}
	
		var data;
		var out = [];
		var display = settings.aiDisplay;
		var rpSearch = _fnFilterCreateSearch( searchStr, regex, smart, caseInsensitive );
	
		for ( var i=0 ; i<display.length ; i++ ) {
			data = settings.aoData[ display[i] ]._aFilterData[ colIdx ];
	
			if ( rpSearch.test( data ) ) {
				out.push( display[i] );
			}
		}
	
		settings.aiDisplay = out;
	}
	
	
	/**
	 * Filter the data table based on user input and draw the table
	 *  @param {object} settings dataTables settings object
	 *  @param {string} input string to filter on
	 *  @param {int} force optional - force a research of the master array (1) or not (undefined or 0)
	 *  @param {bool} regex treat as a regular expression or not
	 *  @param {bool} smart perform smart filtering or not
	 *  @param {bool} caseInsensitive Do case insenstive matching or not
	 *  @memberof DataTable#oApi
	 */
	function _fnFilter( settings, input, force, regex, smart, caseInsensitive )
	{
		var rpSearch = _fnFilterCreateSearch( input, regex, smart, caseInsensitive );
		var prevSearch = settings.oPreviousSearch.sSearch;
		var displayMaster = settings.aiDisplayMaster;
		var display, invalidated, i;
		var filtered = [];
	
		// Need to take account of custom filtering functions - always filter
		if ( DataTable.ext.search.length !== 0 ) {
			force = true;
		}
	
		// Check if any of the rows were invalidated
		invalidated = _fnFilterData( settings );
	
		// If the input is blank - we just want the full data set
		if ( input.length <= 0 ) {
			settings.aiDisplay = displayMaster.slice();
		}
		else {
			// New search - start from the master array
			if ( invalidated ||
				 force ||
				 prevSearch.length > input.length ||
				 input.indexOf(prevSearch) !== 0 ||
				 settings.bSorted // On resort, the display master needs to be
				                  // re-filtered since indexes will have changed
			) {
				settings.aiDisplay = displayMaster.slice();
			}
	
			// Search the display array
			display = settings.aiDisplay;
	
			for ( i=0 ; i<display.length ; i++ ) {
				if ( rpSearch.test( settings.aoData[ display[i] ]._sFilterRow ) ) {
					filtered.push( display[i] );
				}
			}
	
			settings.aiDisplay = filtered;
		}
	}
	
	
	/**
	 * Build a regular expression object suitable for searching a table
	 *  @param {string} sSearch string to search for
	 *  @param {bool} bRegex treat as a regular expression or not
	 *  @param {bool} bSmart perform smart filtering or not
	 *  @param {bool} bCaseInsensitive Do case insensitive matching or not
	 *  @returns {RegExp} constructed object
	 *  @memberof DataTable#oApi
	 */
	function _fnFilterCreateSearch( search, regex, smart, caseInsensitive )
	{
		search = regex ?
			search :
			_fnEscapeRegex( search );
		
		if ( smart ) {
			/* For smart filtering we want to allow the search to work regardless of
			 * word order. We also want double quoted text to be preserved, so word
			 * order is important - a la google. So this is what we want to
			 * generate:
			 * 
			 * ^(?=.*?\bone\b)(?=.*?\btwo three\b)(?=.*?\bfour\b).*$
			 */
			var a = $.map( search.match( /"[^"]+"|[^ ]+/g ) || [''], function ( word ) {
				if ( word.charAt(0) === '"' ) {
					var m = word.match( /^"(.*)"$/ );
					word = m ? m[1] : word;
				}
	
				return word.replace('"', '');
			} );
	
			search = '^(?=.*?'+a.join( ')(?=.*?' )+').*$';
		}
	
		return new RegExp( search, caseInsensitive ? 'i' : '' );
	}
	
	
	/**
	 * Escape a string such that it can be used in a regular expression
	 *  @param {string} sVal string to escape
	 *  @returns {string} escaped string
	 *  @memberof DataTable#oApi
	 */
	var _fnEscapeRegex = DataTable.util.escapeRegex;
	
	var __filter_div = $('<div>')[0];
	var __filter_div_textContent = __filter_div.textContent !== undefined;
	
	// Update the filtering data for each row if needed (by invalidation or first run)
	function _fnFilterData ( settings )
	{
		var columns = settings.aoColumns;
		var column;
		var i, j, ien, jen, filterData, cellData, row;
		var fomatters = DataTable.ext.type.search;
		var wasInvalidated = false;
	
		for ( i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
			row = settings.aoData[i];
	
			if ( ! row._aFilterData ) {
				filterData = [];
	
				for ( j=0, jen=columns.length ; j<jen ; j++ ) {
					column = columns[j];
	
					if ( column.bSearchable ) {
						cellData = _fnGetCellData( settings, i, j, 'filter' );
	
						if ( fomatters[ column.sType ] ) {
							cellData = fomatters[ column.sType ]( cellData );
						}
	
						// Search in DataTables 1.10 is string based. In 1.11 this
						// should be altered to also allow strict type checking.
						if ( cellData === null ) {
							cellData = '';
						}
	
						if ( typeof cellData !== 'string' && cellData.toString ) {
							cellData = cellData.toString();
						}
					}
					else {
						cellData = '';
					}
	
					// If it looks like there is an HTML entity in the string,
					// attempt to decode it so sorting works as expected. Note that
					// we could use a single line of jQuery to do this, but the DOM
					// method used here is much faster http://jsperf.com/html-decode
					if ( cellData.indexOf && cellData.indexOf('&') !== -1 ) {
						__filter_div.innerHTML = cellData;
						cellData = __filter_div_textContent ?
							__filter_div.textContent :
							__filter_div.innerText;
					}
	
					if ( cellData.replace ) {
						cellData = cellData.replace(/[\r\n]/g, '');
					}
	
					filterData.push( cellData );
				}
	
				row._aFilterData = filterData;
				row._sFilterRow = filterData.join('  ');
				wasInvalidated = true;
			}
		}
	
		return wasInvalidated;
	}
	
	
	/**
	 * Convert from the internal Hungarian notation to camelCase for external
	 * interaction
	 *  @param {object} obj Object to convert
	 *  @returns {object} Inverted object
	 *  @memberof DataTable#oApi
	 */
	function _fnSearchToCamel ( obj )
	{
		return {
			search:          obj.sSearch,
			smart:           obj.bSmart,
			regex:           obj.bRegex,
			caseInsensitive: obj.bCaseInsensitive
		};
	}
	
	
	
	/**
	 * Convert from camelCase notation to the internal Hungarian. We could use the
	 * Hungarian convert function here, but this is cleaner
	 *  @param {object} obj Object to convert
	 *  @returns {object} Inverted object
	 *  @memberof DataTable#oApi
	 */
	function _fnSearchToHung ( obj )
	{
		return {
			sSearch:          obj.search,
			bSmart:           obj.smart,
			bRegex:           obj.regex,
			bCaseInsensitive: obj.caseInsensitive
		};
	}
	
	/**
	 * Generate the node required for the info display
	 *  @param {object} oSettings dataTables settings object
	 *  @returns {node} Information element
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlInfo ( settings )
	{
		var
			tid = settings.sTableId,
			nodes = settings.aanFeatures.i,
			n = $('<div/>', {
				'class': settings.oClasses.sInfo,
				'id': ! nodes ? tid+'_info' : null
			} );
	
		if ( ! nodes ) {
			// Update display on each draw
			settings.aoDrawCallback.push( {
				"fn": _fnUpdateInfo,
				"sName": "information"
			} );
	
			n
				.attr( 'role', 'status' )
				.attr( 'aria-live', 'polite' );
	
			// Table is described by our info div
			$(settings.nTable).attr( 'aria-describedby', tid+'_info' );
		}
	
		return n[0];
	}
	
	
	/**
	 * Update the information elements in the display
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnUpdateInfo ( settings )
	{
		/* Show information about the table */
		var nodes = settings.aanFeatures.i;
		if ( nodes.length === 0 ) {
			return;
		}
	
		var
			lang  = settings.oLanguage,
			start = settings._iDisplayStart+1,
			end   = settings.fnDisplayEnd(),
			max   = settings.fnRecordsTotal(),
			total = settings.fnRecordsDisplay(),
			out   = total ?
				lang.sInfo :
				lang.sInfoEmpty;
	
		if ( total !== max ) {
			/* Record set after filtering */
			out += ' ' + lang.sInfoFiltered;
		}
	
		// Convert the macros
		out += lang.sInfoPostFix;
		out = _fnInfoMacros( settings, out );
	
		var callback = lang.fnInfoCallback;
		if ( callback !== null ) {
			out = callback.call( settings.oInstance,
				settings, start, end, max, total, out
			);
		}
	
		$(nodes).html( out );
	}
	
	
	function _fnInfoMacros ( settings, str )
	{
		// When infinite scrolling, we are always starting at 1. _iDisplayStart is used only
		// internally
		var
			formatter  = settings.fnFormatNumber,
			start      = settings._iDisplayStart+1,
			len        = settings._iDisplayLength,
			vis        = settings.fnRecordsDisplay(),
			all        = len === -1;
	
		return str.
			replace(/_START_/g, formatter.call( settings, start ) ).
			replace(/_END_/g,   formatter.call( settings, settings.fnDisplayEnd() ) ).
			replace(/_MAX_/g,   formatter.call( settings, settings.fnRecordsTotal() ) ).
			replace(/_TOTAL_/g, formatter.call( settings, vis ) ).
			replace(/_PAGE_/g,  formatter.call( settings, all ? 1 : Math.ceil( start / len ) ) ).
			replace(/_PAGES_/g, formatter.call( settings, all ? 1 : Math.ceil( vis / len ) ) );
	}
	
	
	
	/**
	 * Draw the table for the first time, adding all required features
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnInitialise ( settings )
	{
		var i, iLen, iAjaxStart=settings.iInitDisplayStart;
		var columns = settings.aoColumns, column;
		var features = settings.oFeatures;
		var deferLoading = settings.bDeferLoading; // value modified by the draw
	
		/* Ensure that the table data is fully initialised */
		if ( ! settings.bInitialised ) {
			setTimeout( function(){ _fnInitialise( settings ); }, 200 );
			return;
		}
	
		/* Show the display HTML options */
		_fnAddOptionsHtml( settings );
	
		/* Build and draw the header / footer for the table */
		_fnBuildHead( settings );
		_fnDrawHead( settings, settings.aoHeader );
		_fnDrawHead( settings, settings.aoFooter );
	
		/* Okay to show that something is going on now */
		_fnProcessingDisplay( settings, true );
	
		/* Calculate sizes for columns */
		if ( features.bAutoWidth ) {
			_fnCalculateColumnWidths( settings );
		}
	
		for ( i=0, iLen=columns.length ; i<iLen ; i++ ) {
			column = columns[i];
	
			if ( column.sWidth ) {
				column.nTh.style.width = _fnStringToCss( column.sWidth );
			}
		}
	
		_fnCallbackFire( settings, null, 'preInit', [settings] );
	
		// If there is default sorting required - let's do it. The sort function
		// will do the drawing for us. Otherwise we draw the table regardless of the
		// Ajax source - this allows the table to look initialised for Ajax sourcing
		// data (show 'loading' message possibly)
		_fnReDraw( settings );
	
		// Server-side processing init complete is done by _fnAjaxUpdateDraw
		var dataSrc = _fnDataSource( settings );
		if ( dataSrc != 'ssp' || deferLoading ) {
			// if there is an ajax source load the data
			if ( dataSrc == 'ajax' ) {
				_fnBuildAjax( settings, [], function(json) {
					var aData = _fnAjaxDataSrc( settings, json );
	
					// Got the data - add it to the table
					for ( i=0 ; i<aData.length ; i++ ) {
						_fnAddData( settings, aData[i] );
					}
	
					// Reset the init display for cookie saving. We've already done
					// a filter, and therefore cleared it before. So we need to make
					// it appear 'fresh'
					settings.iInitDisplayStart = iAjaxStart;
	
					_fnReDraw( settings );
	
					_fnProcessingDisplay( settings, false );
					_fnInitComplete( settings, json );
				}, settings );
			}
			else {
				_fnProcessingDisplay( settings, false );
				_fnInitComplete( settings );
			}
		}
	}
	
	
	/**
	 * Draw the table for the first time, adding all required features
	 *  @param {object} oSettings dataTables settings object
	 *  @param {object} [json] JSON from the server that completed the table, if using Ajax source
	 *    with client-side processing (optional)
	 *  @memberof DataTable#oApi
	 */
	function _fnInitComplete ( settings, json )
	{
		settings._bInitComplete = true;
	
		// When data was added after the initialisation (data or Ajax) we need to
		// calculate the column sizing
		if ( json || settings.oInit.aaData ) {
			_fnAdjustColumnSizing( settings );
		}
	
		_fnCallbackFire( settings, null, 'plugin-init', [settings, json] );
		_fnCallbackFire( settings, 'aoInitComplete', 'init', [settings, json] );
	}
	
	
	function _fnLengthChange ( settings, val )
	{
		var len = parseInt( val, 10 );
		settings._iDisplayLength = len;
	
		_fnLengthOverflow( settings );
	
		// Fire length change event
		_fnCallbackFire( settings, null, 'length', [settings, len] );
	}
	
	
	/**
	 * Generate the node required for user display length changing
	 *  @param {object} settings dataTables settings object
	 *  @returns {node} Display length feature node
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlLength ( settings )
	{
		var
			classes  = settings.oClasses,
			tableId  = settings.sTableId,
			menu     = settings.aLengthMenu,
			d2       = $.isArray( menu[0] ),
			lengths  = d2 ? menu[0] : menu,
			language = d2 ? menu[1] : menu;
	
		var select = $('<select/>', {
			'name':          tableId+'_length',
			'aria-controls': tableId,
			'class':         classes.sLengthSelect
		} );
	
		for ( var i=0, ien=lengths.length ; i<ien ; i++ ) {
			select[0][ i ] = new Option(
				typeof language[i] === 'number' ?
					settings.fnFormatNumber( language[i] ) :
					language[i],
				lengths[i]
			);
		}
	
		var div = $('<div><label/></div>').addClass( classes.sLength );
		if ( ! settings.aanFeatures.l ) {
			div[0].id = tableId+'_length';
		}
	
		div.children().append(
			settings.oLanguage.sLengthMenu.replace( '_MENU_', select[0].outerHTML )
		);
	
		// Can't use `select` variable as user might provide their own and the
		// reference is broken by the use of outerHTML
		$('select', div)
			.val( settings._iDisplayLength )
			.on( 'change.DT', function(e) {
				_fnLengthChange( settings, $(this).val() );
				_fnDraw( settings );
			} );
	
		// Update node value whenever anything changes the table's length
		$(settings.nTable).on( 'length.dt.DT', function (e, s, len) {
			if ( settings === s ) {
				$('select', div).val( len );
			}
		} );
	
		return div[0];
	}
	
	
	
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Note that most of the paging logic is done in
	 * DataTable.ext.pager
	 */
	
	/**
	 * Generate the node required for default pagination
	 *  @param {object} oSettings dataTables settings object
	 *  @returns {node} Pagination feature node
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlPaginate ( settings )
	{
		var
			type   = settings.sPaginationType,
			plugin = DataTable.ext.pager[ type ],
			modern = typeof plugin === 'function',
			redraw = function( settings ) {
				_fnDraw( settings );
			},
			node = $('<div/>').addClass( settings.oClasses.sPaging + type )[0],
			features = settings.aanFeatures;
	
		if ( ! modern ) {
			plugin.fnInit( settings, node, redraw );
		}
	
		/* Add a draw callback for the pagination on first instance, to update the paging display */
		if ( ! features.p )
		{
			node.id = settings.sTableId+'_paginate';
	
			settings.aoDrawCallback.push( {
				"fn": function( settings ) {
					if ( modern ) {
						var
							start      = settings._iDisplayStart,
							len        = settings._iDisplayLength,
							visRecords = settings.fnRecordsDisplay(),
							all        = len === -1,
							page = all ? 0 : Math.ceil( start / len ),
							pages = all ? 1 : Math.ceil( visRecords / len ),
							buttons = plugin(page, pages),
							i, ien;
	
						for ( i=0, ien=features.p.length ; i<ien ; i++ ) {
							_fnRenderer( settings, 'pageButton' )(
								settings, features.p[i], i, buttons, page, pages
							);
						}
					}
					else {
						plugin.fnUpdate( settings, redraw );
					}
				},
				"sName": "pagination"
			} );
		}
	
		return node;
	}
	
	
	/**
	 * Alter the display settings to change the page
	 *  @param {object} settings DataTables settings object
	 *  @param {string|int} action Paging action to take: "first", "previous",
	 *    "next" or "last" or page number to jump to (integer)
	 *  @param [bool] redraw Automatically draw the update or not
	 *  @returns {bool} true page has changed, false - no change
	 *  @memberof DataTable#oApi
	 */
	function _fnPageChange ( settings, action, redraw )
	{
		var
			start     = settings._iDisplayStart,
			len       = settings._iDisplayLength,
			records   = settings.fnRecordsDisplay();
	
		if ( records === 0 || len === -1 )
		{
			start = 0;
		}
		else if ( typeof action === "number" )
		{
			start = action * len;
	
			if ( start > records )
			{
				start = 0;
			}
		}
		else if ( action == "first" )
		{
			start = 0;
		}
		else if ( action == "previous" )
		{
			start = len >= 0 ?
				start - len :
				0;
	
			if ( start < 0 )
			{
			  start = 0;
			}
		}
		else if ( action == "next" )
		{
			if ( start + len < records )
			{
				start += len;
			}
		}
		else if ( action == "last" )
		{
			start = Math.floor( (records-1) / len) * len;
		}
		else
		{
			_fnLog( settings, 0, "Unknown paging action: "+action, 5 );
		}
	
		var changed = settings._iDisplayStart !== start;
		settings._iDisplayStart = start;
	
		if ( changed ) {
			_fnCallbackFire( settings, null, 'page', [settings] );
	
			if ( redraw ) {
				_fnDraw( settings );
			}
		}
	
		return changed;
	}
	
	
	
	/**
	 * Generate the node required for the processing node
	 *  @param {object} settings dataTables settings object
	 *  @returns {node} Processing element
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlProcessing ( settings )
	{
		return $('<div/>', {
				'id': ! settings.aanFeatures.r ? settings.sTableId+'_processing' : null,
				'class': settings.oClasses.sProcessing
			} )
			.html( settings.oLanguage.sProcessing )
			.insertBefore( settings.nTable )[0];
	}
	
	
	/**
	 * Display or hide the processing indicator
	 *  @param {object} settings dataTables settings object
	 *  @param {bool} show Show the processing indicator (true) or not (false)
	 *  @memberof DataTable#oApi
	 */
	function _fnProcessingDisplay ( settings, show )
	{
		if ( settings.oFeatures.bProcessing ) {
			$(settings.aanFeatures.r).css( 'display', show ? 'block' : 'none' );
		}
	
		_fnCallbackFire( settings, null, 'processing', [settings, show] );
	}
	
	/**
	 * Add any control elements for the table - specifically scrolling
	 *  @param {object} settings dataTables settings object
	 *  @returns {node} Node to add to the DOM
	 *  @memberof DataTable#oApi
	 */
	function _fnFeatureHtmlTable ( settings )
	{
		var table = $(settings.nTable);
	
		// Add the ARIA grid role to the table
		table.attr( 'role', 'grid' );
	
		// Scrolling from here on in
		var scroll = settings.oScroll;
	
		if ( scroll.sX === '' && scroll.sY === '' ) {
			return settings.nTable;
		}
	
		var scrollX = scroll.sX;
		var scrollY = scroll.sY;
		var classes = settings.oClasses;
		var caption = table.children('caption');
		var captionSide = caption.length ? caption[0]._captionSide : null;
		var headerClone = $( table[0].cloneNode(false) );
		var footerClone = $( table[0].cloneNode(false) );
		var footer = table.children('tfoot');
		var _div = '<div/>';
		var size = function ( s ) {
			return !s ? null : _fnStringToCss( s );
		};
	
		if ( ! footer.length ) {
			footer = null;
		}
	
		/*
		 * The HTML structure that we want to generate in this function is:
		 *  div - scroller
		 *    div - scroll head
		 *      div - scroll head inner
		 *        table - scroll head table
		 *          thead - thead
		 *    div - scroll body
		 *      table - table (master table)
		 *        thead - thead clone for sizing
		 *        tbody - tbody
		 *    div - scroll foot
		 *      div - scroll foot inner
		 *        table - scroll foot table
		 *          tfoot - tfoot
		 */
		var scroller = $( _div, { 'class': classes.sScrollWrapper } )
			.append(
				$(_div, { 'class': classes.sScrollHead } )
					.css( {
						overflow: 'hidden',
						position: 'relative',
						border: 0,
						width: scrollX ? size(scrollX) : '100%'
					} )
					.append(
						$(_div, { 'class': classes.sScrollHeadInner } )
							.css( {
								'box-sizing': 'content-box',
								width: scroll.sXInner || '100%'
							} )
							.append(
								headerClone
									.removeAttr('id')
									.css( 'margin-left', 0 )
									.append( captionSide === 'top' ? caption : null )
									.append(
										table.children('thead')
									)
							)
					)
			)
			.append(
				$(_div, { 'class': classes.sScrollBody } )
					.css( {
						position: 'relative',
						overflow: 'auto',
						width: size( scrollX )
					} )
					.append( table )
			);
	
		if ( footer ) {
			scroller.append(
				$(_div, { 'class': classes.sScrollFoot } )
					.css( {
						overflow: 'hidden',
						border: 0,
						width: scrollX ? size(scrollX) : '100%'
					} )
					.append(
						$(_div, { 'class': classes.sScrollFootInner } )
							.append(
								footerClone
									.removeAttr('id')
									.css( 'margin-left', 0 )
									.append( captionSide === 'bottom' ? caption : null )
									.append(
										table.children('tfoot')
									)
							)
					)
			);
		}
	
		var children = scroller.children();
		var scrollHead = children[0];
		var scrollBody = children[1];
		var scrollFoot = footer ? children[2] : null;
	
		// When the body is scrolled, then we also want to scroll the headers
		if ( scrollX ) {
			$(scrollBody).on( 'scroll.DT', function (e) {
				var scrollLeft = this.scrollLeft;
	
				scrollHead.scrollLeft = scrollLeft;
	
				if ( footer ) {
					scrollFoot.scrollLeft = scrollLeft;
				}
			} );
		}
	
		$(scrollBody).css(
			scrollY && scroll.bCollapse ? 'max-height' : 'height', 
			scrollY
		);
	
		settings.nScrollHead = scrollHead;
		settings.nScrollBody = scrollBody;
		settings.nScrollFoot = scrollFoot;
	
		// On redraw - align columns
		settings.aoDrawCallback.push( {
			"fn": _fnScrollDraw,
			"sName": "scrolling"
		} );
	
		return scroller[0];
	}
	
	
	
	/**
	 * Update the header, footer and body tables for resizing - i.e. column
	 * alignment.
	 *
	 * Welcome to the most horrible function DataTables. The process that this
	 * function follows is basically:
	 *   1. Re-create the table inside the scrolling div
	 *   2. Take live measurements from the DOM
	 *   3. Apply the measurements to align the columns
	 *   4. Clean up
	 *
	 *  @param {object} settings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnScrollDraw ( settings )
	{
		// Given that this is such a monster function, a lot of variables are use
		// to try and keep the minimised size as small as possible
		var
			scroll         = settings.oScroll,
			scrollX        = scroll.sX,
			scrollXInner   = scroll.sXInner,
			scrollY        = scroll.sY,
			barWidth       = scroll.iBarWidth,
			divHeader      = $(settings.nScrollHead),
			divHeaderStyle = divHeader[0].style,
			divHeaderInner = divHeader.children('div'),
			divHeaderInnerStyle = divHeaderInner[0].style,
			divHeaderTable = divHeaderInner.children('table'),
			divBodyEl      = settings.nScrollBody,
			divBody        = $(divBodyEl),
			divBodyStyle   = divBodyEl.style,
			divFooter      = $(settings.nScrollFoot),
			divFooterInner = divFooter.children('div'),
			divFooterTable = divFooterInner.children('table'),
			header         = $(settings.nTHead),
			table          = $(settings.nTable),
			tableEl        = table[0],
			tableStyle     = tableEl.style,
			footer         = settings.nTFoot ? $(settings.nTFoot) : null,
			browser        = settings.oBrowser,
			ie67           = browser.bScrollOversize,
			dtHeaderCells  = _pluck( settings.aoColumns, 'nTh' ),
			headerTrgEls, footerTrgEls,
			headerSrcEls, footerSrcEls,
			headerCopy, footerCopy,
			headerWidths=[], footerWidths=[],
			headerContent=[], footerContent=[],
			idx, correction, sanityWidth,
			zeroOut = function(nSizer) {
				var style = nSizer.style;
				style.paddingTop = "0";
				style.paddingBottom = "0";
				style.borderTopWidth = "0";
				style.borderBottomWidth = "0";
				style.height = 0;
			};
	
		// If the scrollbar visibility has changed from the last draw, we need to
		// adjust the column sizes as the table width will have changed to account
		// for the scrollbar
		var scrollBarVis = divBodyEl.scrollHeight > divBodyEl.clientHeight;
		
		if ( settings.scrollBarVis !== scrollBarVis && settings.scrollBarVis !== undefined ) {
			settings.scrollBarVis = scrollBarVis;
			_fnAdjustColumnSizing( settings );
			return; // adjust column sizing will call this function again
		}
		else {
			settings.scrollBarVis = scrollBarVis;
		}
	
		/*
		 * 1. Re-create the table inside the scrolling div
		 */
	
		// Remove the old minimised thead and tfoot elements in the inner table
		table.children('thead, tfoot').remove();
	
		if ( footer ) {
			footerCopy = footer.clone().prependTo( table );
			footerTrgEls = footer.find('tr'); // the original tfoot is in its own table and must be sized
			footerSrcEls = footerCopy.find('tr');
		}
	
		// Clone the current header and footer elements and then place it into the inner table
		headerCopy = header.clone().prependTo( table );
		headerTrgEls = header.find('tr'); // original header is in its own table
		headerSrcEls = headerCopy.find('tr');
		headerCopy.find('th, td').removeAttr('tabindex');
	
	
		/*
		 * 2. Take live measurements from the DOM - do not alter the DOM itself!
		 */
	
		// Remove old sizing and apply the calculated column widths
		// Get the unique column headers in the newly created (cloned) header. We want to apply the
		// calculated sizes to this header
		if ( ! scrollX )
		{
			divBodyStyle.width = '100%';
			divHeader[0].style.width = '100%';
		}
	
		$.each( _fnGetUniqueThs( settings, headerCopy ), function ( i, el ) {
			idx = _fnVisibleToColumnIndex( settings, i );
			el.style.width = settings.aoColumns[idx].sWidth;
		} );
	
		if ( footer ) {
			_fnApplyToChildren( function(n) {
				n.style.width = "";
			}, footerSrcEls );
		}
	
		// Size the table as a whole
		sanityWidth = table.outerWidth();
		if ( scrollX === "" ) {
			// No x scrolling
			tableStyle.width = "100%";
	
			// IE7 will make the width of the table when 100% include the scrollbar
			// - which is shouldn't. When there is a scrollbar we need to take this
			// into account.
			if ( ie67 && (table.find('tbody').height() > divBodyEl.offsetHeight ||
				divBody.css('overflow-y') == "scroll")
			) {
				tableStyle.width = _fnStringToCss( table.outerWidth() - barWidth);
			}
	
			// Recalculate the sanity width
			sanityWidth = table.outerWidth();
		}
		else if ( scrollXInner !== "" ) {
			// legacy x scroll inner has been given - use it
			tableStyle.width = _fnStringToCss(scrollXInner);
	
			// Recalculate the sanity width
			sanityWidth = table.outerWidth();
		}
	
		// Hidden header should have zero height, so remove padding and borders. Then
		// set the width based on the real headers
	
		// Apply all styles in one pass
		_fnApplyToChildren( zeroOut, headerSrcEls );
	
		// Read all widths in next pass
		_fnApplyToChildren( function(nSizer) {
			headerContent.push( nSizer.innerHTML );
			headerWidths.push( _fnStringToCss( $(nSizer).css('width') ) );
		}, headerSrcEls );
	
		// Apply all widths in final pass
		_fnApplyToChildren( function(nToSize, i) {
			// Only apply widths to the DataTables detected header cells - this
			// prevents complex headers from having contradictory sizes applied
			if ( $.inArray( nToSize, dtHeaderCells ) !== -1 ) {
				nToSize.style.width = headerWidths[i];
			}
		}, headerTrgEls );
	
		$(headerSrcEls).height(0);
	
		/* Same again with the footer if we have one */
		if ( footer )
		{
			_fnApplyToChildren( zeroOut, footerSrcEls );
	
			_fnApplyToChildren( function(nSizer) {
				footerContent.push( nSizer.innerHTML );
				footerWidths.push( _fnStringToCss( $(nSizer).css('width') ) );
			}, footerSrcEls );
	
			_fnApplyToChildren( function(nToSize, i) {
				nToSize.style.width = footerWidths[i];
			}, footerTrgEls );
	
			$(footerSrcEls).height(0);
		}
	
	
		/*
		 * 3. Apply the measurements
		 */
	
		// "Hide" the header and footer that we used for the sizing. We need to keep
		// the content of the cell so that the width applied to the header and body
		// both match, but we want to hide it completely. We want to also fix their
		// width to what they currently are
		_fnApplyToChildren( function(nSizer, i) {
			nSizer.innerHTML = '<div class="dataTables_sizing" style="height:0;overflow:hidden;">'+headerContent[i]+'</div>';
			nSizer.style.width = headerWidths[i];
		}, headerSrcEls );
	
		if ( footer )
		{
			_fnApplyToChildren( function(nSizer, i) {
				nSizer.innerHTML = '<div class="dataTables_sizing" style="height:0;overflow:hidden;">'+footerContent[i]+'</div>';
				nSizer.style.width = footerWidths[i];
			}, footerSrcEls );
		}
	
		// Sanity check that the table is of a sensible width. If not then we are going to get
		// misalignment - try to prevent this by not allowing the table to shrink below its min width
		if ( table.outerWidth() < sanityWidth )
		{
			// The min width depends upon if we have a vertical scrollbar visible or not */
			correction = ((divBodyEl.scrollHeight > divBodyEl.offsetHeight ||
				divBody.css('overflow-y') == "scroll")) ?
					sanityWidth+barWidth :
					sanityWidth;
	
			// IE6/7 are a law unto themselves...
			if ( ie67 && (divBodyEl.scrollHeight >
				divBodyEl.offsetHeight || divBody.css('overflow-y') == "scroll")
			) {
				tableStyle.width = _fnStringToCss( correction-barWidth );
			}
	
			// And give the user a warning that we've stopped the table getting too small
			if ( scrollX === "" || scrollXInner !== "" ) {
				_fnLog( settings, 1, 'Possible column misalignment', 6 );
			}
		}
		else
		{
			correction = '100%';
		}
	
		// Apply to the container elements
		divBodyStyle.width = _fnStringToCss( correction );
		divHeaderStyle.width = _fnStringToCss( correction );
	
		if ( footer ) {
			settings.nScrollFoot.style.width = _fnStringToCss( correction );
		}
	
	
		/*
		 * 4. Clean up
		 */
		if ( ! scrollY ) {
			/* IE7< puts a vertical scrollbar in place (when it shouldn't be) due to subtracting
			 * the scrollbar height from the visible display, rather than adding it on. We need to
			 * set the height in order to sort this. Don't want to do it in any other browsers.
			 */
			if ( ie67 ) {
				divBodyStyle.height = _fnStringToCss( tableEl.offsetHeight+barWidth );
			}
		}
	
		/* Finally set the width's of the header and footer tables */
		var iOuterWidth = table.outerWidth();
		divHeaderTable[0].style.width = _fnStringToCss( iOuterWidth );
		divHeaderInnerStyle.width = _fnStringToCss( iOuterWidth );
	
		// Figure out if there are scrollbar present - if so then we need a the header and footer to
		// provide a bit more space to allow "overflow" scrolling (i.e. past the scrollbar)
		var bScrolling = table.height() > divBodyEl.clientHeight || divBody.css('overflow-y') == "scroll";
		var padding = 'padding' + (browser.bScrollbarLeft ? 'Left' : 'Right' );
		divHeaderInnerStyle[ padding ] = bScrolling ? barWidth+"px" : "0px";
	
		if ( footer ) {
			divFooterTable[0].style.width = _fnStringToCss( iOuterWidth );
			divFooterInner[0].style.width = _fnStringToCss( iOuterWidth );
			divFooterInner[0].style[padding] = bScrolling ? barWidth+"px" : "0px";
		}
	
		// Correct DOM ordering for colgroup - comes before the thead
		table.children('colgroup').insertBefore( table.children('thead') );
	
		/* Adjust the position of the header in case we loose the y-scrollbar */
		divBody.scroll();
	
		// If sorting or filtering has occurred, jump the scrolling back to the top
		// only if we aren't holding the position
		if ( (settings.bSorted || settings.bFiltered) && ! settings._drawHold ) {
			divBodyEl.scrollTop = 0;
		}
	}
	
	
	
	/**
	 * Apply a given function to the display child nodes of an element array (typically
	 * TD children of TR rows
	 *  @param {function} fn Method to apply to the objects
	 *  @param array {nodes} an1 List of elements to look through for display children
	 *  @param array {nodes} an2 Another list (identical structure to the first) - optional
	 *  @memberof DataTable#oApi
	 */
	function _fnApplyToChildren( fn, an1, an2 )
	{
		var index=0, i=0, iLen=an1.length;
		var nNode1, nNode2;
	
		while ( i < iLen ) {
			nNode1 = an1[i].firstChild;
			nNode2 = an2 ? an2[i].firstChild : null;
	
			while ( nNode1 ) {
				if ( nNode1.nodeType === 1 ) {
					if ( an2 ) {
						fn( nNode1, nNode2, index );
					}
					else {
						fn( nNode1, index );
					}
	
					index++;
				}
	
				nNode1 = nNode1.nextSibling;
				nNode2 = an2 ? nNode2.nextSibling : null;
			}
	
			i++;
		}
	}
	
	
	
	var __re_html_remove = /<.*?>/g;
	
	
	/**
	 * Calculate the width of columns for the table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnCalculateColumnWidths ( oSettings )
	{
		var
			table = oSettings.nTable,
			columns = oSettings.aoColumns,
			scroll = oSettings.oScroll,
			scrollY = scroll.sY,
			scrollX = scroll.sX,
			scrollXInner = scroll.sXInner,
			columnCount = columns.length,
			visibleColumns = _fnGetColumns( oSettings, 'bVisible' ),
			headerCells = $('th', oSettings.nTHead),
			tableWidthAttr = table.getAttribute('width'), // from DOM element
			tableContainer = table.parentNode,
			userInputs = false,
			i, column, columnIdx, width, outerWidth,
			browser = oSettings.oBrowser,
			ie67 = browser.bScrollOversize;
	
		var styleWidth = table.style.width;
		if ( styleWidth && styleWidth.indexOf('%') !== -1 ) {
			tableWidthAttr = styleWidth;
		}
	
		/* Convert any user input sizes into pixel sizes */
		for ( i=0 ; i<visibleColumns.length ; i++ ) {
			column = columns[ visibleColumns[i] ];
	
			if ( column.sWidth !== null ) {
				column.sWidth = _fnConvertToWidth( column.sWidthOrig, tableContainer );
	
				userInputs = true;
			}
		}
	
		/* If the number of columns in the DOM equals the number that we have to
		 * process in DataTables, then we can use the offsets that are created by
		 * the web- browser. No custom sizes can be set in order for this to happen,
		 * nor scrolling used
		 */
		if ( ie67 || ! userInputs && ! scrollX && ! scrollY &&
		     columnCount == _fnVisbleColumns( oSettings ) &&
		     columnCount == headerCells.length
		) {
			for ( i=0 ; i<columnCount ; i++ ) {
				var colIdx = _fnVisibleToColumnIndex( oSettings, i );
	
				if ( colIdx !== null ) {
					columns[ colIdx ].sWidth = _fnStringToCss( headerCells.eq(i).width() );
				}
			}
		}
		else
		{
			// Otherwise construct a single row, worst case, table with the widest
			// node in the data, assign any user defined widths, then insert it into
			// the DOM and allow the browser to do all the hard work of calculating
			// table widths
			var tmpTable = $(table).clone() // don't use cloneNode - IE8 will remove events on the main table
				.css( 'visibility', 'hidden' )
				.removeAttr( 'id' );
	
			// Clean up the table body
			tmpTable.find('tbody tr').remove();
			var tr = $('<tr/>').appendTo( tmpTable.find('tbody') );
	
			// Clone the table header and footer - we can't use the header / footer
			// from the cloned table, since if scrolling is active, the table's
			// real header and footer are contained in different table tags
			tmpTable.find('thead, tfoot').remove();
			tmpTable
				.append( $(oSettings.nTHead).clone() )
				.append( $(oSettings.nTFoot).clone() );
	
			// Remove any assigned widths from the footer (from scrolling)
			tmpTable.find('tfoot th, tfoot td').css('width', '');
	
			// Apply custom sizing to the cloned header
			headerCells = _fnGetUniqueThs( oSettings, tmpTable.find('thead')[0] );
	
			for ( i=0 ; i<visibleColumns.length ; i++ ) {
				column = columns[ visibleColumns[i] ];
	
				headerCells[i].style.width = column.sWidthOrig !== null && column.sWidthOrig !== '' ?
					_fnStringToCss( column.sWidthOrig ) :
					'';
	
				// For scrollX we need to force the column width otherwise the
				// browser will collapse it. If this width is smaller than the
				// width the column requires, then it will have no effect
				if ( column.sWidthOrig && scrollX ) {
					$( headerCells[i] ).append( $('<div/>').css( {
						width: column.sWidthOrig,
						margin: 0,
						padding: 0,
						border: 0,
						height: 1
					} ) );
				}
			}
	
			// Find the widest cell for each column and put it into the table
			if ( oSettings.aoData.length ) {
				for ( i=0 ; i<visibleColumns.length ; i++ ) {
					columnIdx = visibleColumns[i];
					column = columns[ columnIdx ];
	
					$( _fnGetWidestNode( oSettings, columnIdx ) )
						.clone( false )
						.append( column.sContentPadding )
						.appendTo( tr );
				}
			}
	
			// Tidy the temporary table - remove name attributes so there aren't
			// duplicated in the dom (radio elements for example)
			$('[name]', tmpTable).removeAttr('name');
	
			// Table has been built, attach to the document so we can work with it.
			// A holding element is used, positioned at the top of the container
			// with minimal height, so it has no effect on if the container scrolls
			// or not. Otherwise it might trigger scrolling when it actually isn't
			// needed
			var holder = $('<div/>').css( scrollX || scrollY ?
					{
						position: 'absolute',
						top: 0,
						left: 0,
						height: 1,
						right: 0,
						overflow: 'hidden'
					} :
					{}
				)
				.append( tmpTable )
				.appendTo( tableContainer );
	
			// When scrolling (X or Y) we want to set the width of the table as 
			// appropriate. However, when not scrolling leave the table width as it
			// is. This results in slightly different, but I think correct behaviour
			if ( scrollX && scrollXInner ) {
				tmpTable.width( scrollXInner );
			}
			else if ( scrollX ) {
				tmpTable.css( 'width', 'auto' );
				tmpTable.removeAttr('width');
	
				// If there is no width attribute or style, then allow the table to
				// collapse
				if ( tmpTable.width() < tableContainer.clientWidth && tableWidthAttr ) {
					tmpTable.width( tableContainer.clientWidth );
				}
			}
			else if ( scrollY ) {
				tmpTable.width( tableContainer.clientWidth );
			}
			else if ( tableWidthAttr ) {
				tmpTable.width( tableWidthAttr );
			}
	
			// Get the width of each column in the constructed table - we need to
			// know the inner width (so it can be assigned to the other table's
			// cells) and the outer width so we can calculate the full width of the
			// table. This is safe since DataTables requires a unique cell for each
			// column, but if ever a header can span multiple columns, this will
			// need to be modified.
			var total = 0;
			for ( i=0 ; i<visibleColumns.length ; i++ ) {
				var cell = $(headerCells[i]);
				var border = cell.outerWidth() - cell.width();
	
				// Use getBounding... where possible (not IE8-) because it can give
				// sub-pixel accuracy, which we then want to round up!
				var bounding = browser.bBounding ?
					Math.ceil( headerCells[i].getBoundingClientRect().width ) :
					cell.outerWidth();
	
				// Total is tracked to remove any sub-pixel errors as the outerWidth
				// of the table might not equal the total given here (IE!).
				total += bounding;
	
				// Width for each column to use
				columns[ visibleColumns[i] ].sWidth = _fnStringToCss( bounding - border );
			}
	
			table.style.width = _fnStringToCss( total );
	
			// Finished with the table - ditch it
			holder.remove();
		}
	
		// If there is a width attr, we want to attach an event listener which
		// allows the table sizing to automatically adjust when the window is
		// resized. Use the width attr rather than CSS, since we can't know if the
		// CSS is a relative value or absolute - DOM read is always px.
		if ( tableWidthAttr ) {
			table.style.width = _fnStringToCss( tableWidthAttr );
		}
	
		if ( (tableWidthAttr || scrollX) && ! oSettings._reszEvt ) {
			var bindResize = function () {
				$(window).on('resize.DT-'+oSettings.sInstance, _fnThrottle( function () {
					_fnAdjustColumnSizing( oSettings );
				} ) );
			};
	
			// IE6/7 will crash if we bind a resize event handler on page load.
			// To be removed in 1.11 which drops IE6/7 support
			if ( ie67 ) {
				setTimeout( bindResize, 1000 );
			}
			else {
				bindResize();
			}
	
			oSettings._reszEvt = true;
		}
	}
	
	
	/**
	 * Throttle the calls to a function. Arguments and context are maintained for
	 * the throttled function
	 *  @param {function} fn Function to be called
	 *  @param {int} [freq=200] call frequency in mS
	 *  @returns {function} wrapped function
	 *  @memberof DataTable#oApi
	 */
	var _fnThrottle = DataTable.util.throttle;
	
	
	/**
	 * Convert a CSS unit width to pixels (e.g. 2em)
	 *  @param {string} width width to be converted
	 *  @param {node} parent parent to get the with for (required for relative widths) - optional
	 *  @returns {int} width in pixels
	 *  @memberof DataTable#oApi
	 */
	function _fnConvertToWidth ( width, parent )
	{
		if ( ! width ) {
			return 0;
		}
	
		var n = $('<div/>')
			.css( 'width', _fnStringToCss( width ) )
			.appendTo( parent || document.body );
	
		var val = n[0].offsetWidth;
		n.remove();
	
		return val;
	}
	
	
	/**
	 * Get the widest node
	 *  @param {object} settings dataTables settings object
	 *  @param {int} colIdx column of interest
	 *  @returns {node} widest table node
	 *  @memberof DataTable#oApi
	 */
	function _fnGetWidestNode( settings, colIdx )
	{
		var idx = _fnGetMaxLenString( settings, colIdx );
		if ( idx < 0 ) {
			return null;
		}
	
		var data = settings.aoData[ idx ];
		return ! data.nTr ? // Might not have been created when deferred rendering
			$('<td/>').html( _fnGetCellData( settings, idx, colIdx, 'display' ) )[0] :
			data.anCells[ colIdx ];
	}
	
	
	/**
	 * Get the maximum strlen for each data column
	 *  @param {object} settings dataTables settings object
	 *  @param {int} colIdx column of interest
	 *  @returns {string} max string length for each column
	 *  @memberof DataTable#oApi
	 */
	function _fnGetMaxLenString( settings, colIdx )
	{
		var s, max=-1, maxIdx = -1;
	
		for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
			s = _fnGetCellData( settings, i, colIdx, 'display' )+'';
			s = s.replace( __re_html_remove, '' );
			s = s.replace( /&nbsp;/g, ' ' );
	
			if ( s.length > max ) {
				max = s.length;
				maxIdx = i;
			}
		}
	
		return maxIdx;
	}
	
	
	/**
	 * Append a CSS unit (only if required) to a string
	 *  @param {string} value to css-ify
	 *  @returns {string} value with css unit
	 *  @memberof DataTable#oApi
	 */
	function _fnStringToCss( s )
	{
		if ( s === null ) {
			return '0px';
		}
	
		if ( typeof s == 'number' ) {
			return s < 0 ?
				'0px' :
				s+'px';
		}
	
		// Check it has a unit character already
		return s.match(/\d$/) ?
			s+'px' :
			s;
	}
	
	
	
	function _fnSortFlatten ( settings )
	{
		var
			i, iLen, k, kLen,
			aSort = [],
			aiOrig = [],
			aoColumns = settings.aoColumns,
			aDataSort, iCol, sType, srcCol,
			fixed = settings.aaSortingFixed,
			fixedObj = $.isPlainObject( fixed ),
			nestedSort = [],
			add = function ( a ) {
				if ( a.length && ! $.isArray( a[0] ) ) {
					// 1D array
					nestedSort.push( a );
				}
				else {
					// 2D array
					$.merge( nestedSort, a );
				}
			};
	
		// Build the sort array, with pre-fix and post-fix options if they have been
		// specified
		if ( $.isArray( fixed ) ) {
			add( fixed );
		}
	
		if ( fixedObj && fixed.pre ) {
			add( fixed.pre );
		}
	
		add( settings.aaSorting );
	
		if (fixedObj && fixed.post ) {
			add( fixed.post );
		}
	
		for ( i=0 ; i<nestedSort.length ; i++ )
		{
			srcCol = nestedSort[i][0];
			aDataSort = aoColumns[ srcCol ].aDataSort;
	
			for ( k=0, kLen=aDataSort.length ; k<kLen ; k++ )
			{
				iCol = aDataSort[k];
				sType = aoColumns[ iCol ].sType || 'string';
	
				if ( nestedSort[i]._idx === undefined ) {
					nestedSort[i]._idx = $.inArray( nestedSort[i][1], aoColumns[iCol].asSorting );
				}
	
				aSort.push( {
					src:       srcCol,
					col:       iCol,
					dir:       nestedSort[i][1],
					index:     nestedSort[i]._idx,
					type:      sType,
					formatter: DataTable.ext.type.order[ sType+"-pre" ]
				} );
			}
		}
	
		return aSort;
	}
	
	/**
	 * Change the order of the table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 *  @todo This really needs split up!
	 */
	function _fnSort ( oSettings )
	{
		var
			i, ien, iLen, j, jLen, k, kLen,
			sDataType, nTh,
			aiOrig = [],
			oExtSort = DataTable.ext.type.order,
			aoData = oSettings.aoData,
			aoColumns = oSettings.aoColumns,
			aDataSort, data, iCol, sType, oSort,
			formatters = 0,
			sortCol,
			displayMaster = oSettings.aiDisplayMaster,
			aSort;
	
		// Resolve any column types that are unknown due to addition or invalidation
		// @todo Can this be moved into a 'data-ready' handler which is called when
		//   data is going to be used in the table?
		_fnColumnTypes( oSettings );
	
		aSort = _fnSortFlatten( oSettings );
	
		for ( i=0, ien=aSort.length ; i<ien ; i++ ) {
			sortCol = aSort[i];
	
			// Track if we can use the fast sort algorithm
			if ( sortCol.formatter ) {
				formatters++;
			}
	
			// Load the data needed for the sort, for each cell
			_fnSortData( oSettings, sortCol.col );
		}
	
		/* No sorting required if server-side or no sorting array */
		if ( _fnDataSource( oSettings ) != 'ssp' && aSort.length !== 0 )
		{
			// Create a value - key array of the current row positions such that we can use their
			// current position during the sort, if values match, in order to perform stable sorting
			for ( i=0, iLen=displayMaster.length ; i<iLen ; i++ ) {
				aiOrig[ displayMaster[i] ] = i;
			}
	
			/* Do the sort - here we want multi-column sorting based on a given data source (column)
			 * and sorting function (from oSort) in a certain direction. It's reasonably complex to
			 * follow on it's own, but this is what we want (example two column sorting):
			 *  fnLocalSorting = function(a,b){
			 *    var iTest;
			 *    iTest = oSort['string-asc']('data11', 'data12');
			 *      if (iTest !== 0)
			 *        return iTest;
			 *    iTest = oSort['numeric-desc']('data21', 'data22');
			 *    if (iTest !== 0)
			 *      return iTest;
			 *    return oSort['numeric-asc']( aiOrig[a], aiOrig[b] );
			 *  }
			 * Basically we have a test for each sorting column, if the data in that column is equal,
			 * test the next column. If all columns match, then we use a numeric sort on the row
			 * positions in the original data array to provide a stable sort.
			 *
			 * Note - I know it seems excessive to have two sorting methods, but the first is around
			 * 15% faster, so the second is only maintained for backwards compatibility with sorting
			 * methods which do not have a pre-sort formatting function.
			 */
			if ( formatters === aSort.length ) {
				// All sort types have formatting functions
				displayMaster.sort( function ( a, b ) {
					var
						x, y, k, test, sort,
						len=aSort.length,
						dataA = aoData[a]._aSortData,
						dataB = aoData[b]._aSortData;
	
					for ( k=0 ; k<len ; k++ ) {
						sort = aSort[k];
	
						x = dataA[ sort.col ];
						y = dataB[ sort.col ];
	
						test = x<y ? -1 : x>y ? 1 : 0;
						if ( test !== 0 ) {
							return sort.dir === 'asc' ? test : -test;
						}
					}
	
					x = aiOrig[a];
					y = aiOrig[b];
					return x<y ? -1 : x>y ? 1 : 0;
				} );
			}
			else {
				// Depreciated - remove in 1.11 (providing a plug-in option)
				// Not all sort types have formatting methods, so we have to call their sorting
				// methods.
				displayMaster.sort( function ( a, b ) {
					var
						x, y, k, l, test, sort, fn,
						len=aSort.length,
						dataA = aoData[a]._aSortData,
						dataB = aoData[b]._aSortData;
	
					for ( k=0 ; k<len ; k++ ) {
						sort = aSort[k];
	
						x = dataA[ sort.col ];
						y = dataB[ sort.col ];
	
						fn = oExtSort[ sort.type+"-"+sort.dir ] || oExtSort[ "string-"+sort.dir ];
						test = fn( x, y );
						if ( test !== 0 ) {
							return test;
						}
					}
	
					x = aiOrig[a];
					y = aiOrig[b];
					return x<y ? -1 : x>y ? 1 : 0;
				} );
			}
		}
	
		/* Tell the draw function that we have sorted the data */
		oSettings.bSorted = true;
	}
	
	
	function _fnSortAria ( settings )
	{
		var label;
		var nextSort;
		var columns = settings.aoColumns;
		var aSort = _fnSortFlatten( settings );
		var oAria = settings.oLanguage.oAria;
	
		// ARIA attributes - need to loop all columns, to update all (removing old
		// attributes as needed)
		for ( var i=0, iLen=columns.length ; i<iLen ; i++ )
		{
			var col = columns[i];
			var asSorting = col.asSorting;
			var sTitle = col.sTitle.replace( /<.*?>/g, "" );
			var th = col.nTh;
	
			// IE7 is throwing an error when setting these properties with jQuery's
			// attr() and removeAttr() methods...
			th.removeAttribute('aria-sort');
	
			/* In ARIA only the first sorting column can be marked as sorting - no multi-sort option */
			if ( col.bSortable ) {
				if ( aSort.length > 0 && aSort[0].col == i ) {
					th.setAttribute('aria-sort', aSort[0].dir=="asc" ? "ascending" : "descending" );
					nextSort = asSorting[ aSort[0].index+1 ] || asSorting[0];
				}
				else {
					nextSort = asSorting[0];
				}
	
				label = sTitle + ( nextSort === "asc" ?
					oAria.sSortAscending :
					oAria.sSortDescending
				);
			}
			else {
				label = sTitle;
			}
	
			th.setAttribute('aria-label', label);
		}
	}
	
	
	/**
	 * Function to run on user sort request
	 *  @param {object} settings dataTables settings object
	 *  @param {node} attachTo node to attach the handler to
	 *  @param {int} colIdx column sorting index
	 *  @param {boolean} [append=false] Append the requested sort to the existing
	 *    sort if true (i.e. multi-column sort)
	 *  @param {function} [callback] callback function
	 *  @memberof DataTable#oApi
	 */
	function _fnSortListener ( settings, colIdx, append, callback )
	{
		var col = settings.aoColumns[ colIdx ];
		var sorting = settings.aaSorting;
		var asSorting = col.asSorting;
		var nextSortIdx;
		var next = function ( a, overflow ) {
			var idx = a._idx;
			if ( idx === undefined ) {
				idx = $.inArray( a[1], asSorting );
			}
	
			return idx+1 < asSorting.length ?
				idx+1 :
				overflow ?
					null :
					0;
		};
	
		// Convert to 2D array if needed
		if ( typeof sorting[0] === 'number' ) {
			sorting = settings.aaSorting = [ sorting ];
		}
	
		// If appending the sort then we are multi-column sorting
		if ( append && settings.oFeatures.bSortMulti ) {
			// Are we already doing some kind of sort on this column?
			var sortIdx = $.inArray( colIdx, _pluck(sorting, '0') );
	
			if ( sortIdx !== -1 ) {
				// Yes, modify the sort
				nextSortIdx = next( sorting[sortIdx], true );
	
				if ( nextSortIdx === null && sorting.length === 1 ) {
					nextSortIdx = 0; // can't remove sorting completely
				}
	
				if ( nextSortIdx === null ) {
					sorting.splice( sortIdx, 1 );
				}
				else {
					sorting[sortIdx][1] = asSorting[ nextSortIdx ];
					sorting[sortIdx]._idx = nextSortIdx;
				}
			}
			else {
				// No sort on this column yet
				sorting.push( [ colIdx, asSorting[0], 0 ] );
				sorting[sorting.length-1]._idx = 0;
			}
		}
		else if ( sorting.length && sorting[0][0] == colIdx ) {
			// Single column - already sorting on this column, modify the sort
			nextSortIdx = next( sorting[0] );
	
			sorting.length = 1;
			sorting[0][1] = asSorting[ nextSortIdx ];
			sorting[0]._idx = nextSortIdx;
		}
		else {
			// Single column - sort only on this column
			sorting.length = 0;
			sorting.push( [ colIdx, asSorting[0] ] );
			sorting[0]._idx = 0;
		}
	
		// Run the sort by calling a full redraw
		_fnReDraw( settings );
	
		// callback used for async user interaction
		if ( typeof callback == 'function' ) {
			callback( settings );
		}
	}
	
	
	/**
	 * Attach a sort handler (click) to a node
	 *  @param {object} settings dataTables settings object
	 *  @param {node} attachTo node to attach the handler to
	 *  @param {int} colIdx column sorting index
	 *  @param {function} [callback] callback function
	 *  @memberof DataTable#oApi
	 */
	function _fnSortAttachListener ( settings, attachTo, colIdx, callback )
	{
		var col = settings.aoColumns[ colIdx ];
	
		_fnBindAction( attachTo, {}, function (e) {
			/* If the column is not sortable - don't to anything */
			if ( col.bSortable === false ) {
				return;
			}
	
			// If processing is enabled use a timeout to allow the processing
			// display to be shown - otherwise to it synchronously
			if ( settings.oFeatures.bProcessing ) {
				_fnProcessingDisplay( settings, true );
	
				setTimeout( function() {
					_fnSortListener( settings, colIdx, e.shiftKey, callback );
	
					// In server-side processing, the draw callback will remove the
					// processing display
					if ( _fnDataSource( settings ) !== 'ssp' ) {
						_fnProcessingDisplay( settings, false );
					}
				}, 0 );
			}
			else {
				_fnSortListener( settings, colIdx, e.shiftKey, callback );
			}
		} );
	}
	
	
	/**
	 * Set the sorting classes on table's body, Note: it is safe to call this function
	 * when bSort and bSortClasses are false
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnSortingClasses( settings )
	{
		var oldSort = settings.aLastSort;
		var sortClass = settings.oClasses.sSortColumn;
		var sort = _fnSortFlatten( settings );
		var features = settings.oFeatures;
		var i, ien, colIdx;
	
		if ( features.bSort && features.bSortClasses ) {
			// Remove old sorting classes
			for ( i=0, ien=oldSort.length ; i<ien ; i++ ) {
				colIdx = oldSort[i].src;
	
				// Remove column sorting
				$( _pluck( settings.aoData, 'anCells', colIdx ) )
					.removeClass( sortClass + (i<2 ? i+1 : 3) );
			}
	
			// Add new column sorting
			for ( i=0, ien=sort.length ; i<ien ; i++ ) {
				colIdx = sort[i].src;
	
				$( _pluck( settings.aoData, 'anCells', colIdx ) )
					.addClass( sortClass + (i<2 ? i+1 : 3) );
			}
		}
	
		settings.aLastSort = sort;
	}
	
	
	// Get the data to sort a column, be it from cache, fresh (populating the
	// cache), or from a sort formatter
	function _fnSortData( settings, idx )
	{
		// Custom sorting function - provided by the sort data type
		var column = settings.aoColumns[ idx ];
		var customSort = DataTable.ext.order[ column.sSortDataType ];
		var customData;
	
		if ( customSort ) {
			customData = customSort.call( settings.oInstance, settings, idx,
				_fnColumnIndexToVisible( settings, idx )
			);
		}
	
		// Use / populate cache
		var row, cellData;
		var formatter = DataTable.ext.type.order[ column.sType+"-pre" ];
	
		for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
			row = settings.aoData[i];
	
			if ( ! row._aSortData ) {
				row._aSortData = [];
			}
	
			if ( ! row._aSortData[idx] || customSort ) {
				cellData = customSort ?
					customData[i] : // If there was a custom sort function, use data from there
					_fnGetCellData( settings, i, idx, 'sort' );
	
				row._aSortData[ idx ] = formatter ?
					formatter( cellData ) :
					cellData;
			}
		}
	}
	
	
	
	/**
	 * Save the state of a table
	 *  @param {object} oSettings dataTables settings object
	 *  @memberof DataTable#oApi
	 */
	function _fnSaveState ( settings )
	{
		if ( !settings.oFeatures.bStateSave || settings.bDestroying )
		{
			return;
		}
	
		/* Store the interesting variables */
		var state = {
			time:    +new Date(),
			start:   settings._iDisplayStart,
			length:  settings._iDisplayLength,
			order:   $.extend( true, [], settings.aaSorting ),
			search:  _fnSearchToCamel( settings.oPreviousSearch ),
			columns: $.map( settings.aoColumns, function ( col, i ) {
				return {
					visible: col.bVisible,
					search: _fnSearchToCamel( settings.aoPreSearchCols[i] )
				};
			} )
		};
	
		_fnCallbackFire( settings, "aoStateSaveParams", 'stateSaveParams', [settings, state] );
	
		settings.oSavedState = state;
		settings.fnStateSaveCallback.call( settings.oInstance, settings, state );
	}
	
	
	/**
	 * Attempt to load a saved table state
	 *  @param {object} oSettings dataTables settings object
	 *  @param {object} oInit DataTables init object so we can override settings
	 *  @param {function} callback Callback to execute when the state has been loaded
	 *  @memberof DataTable#oApi
	 */
	function _fnLoadState ( settings, oInit, callback )
	{
		var i, ien;
		var columns = settings.aoColumns;
		var loaded = function ( s ) {
			if ( ! s || ! s.time ) {
				callback();
				return;
			}
	
			// Allow custom and plug-in manipulation functions to alter the saved data set and
			// cancelling of loading by returning false
			var abStateLoad = _fnCallbackFire( settings, 'aoStateLoadParams', 'stateLoadParams', [settings, s] );
			if ( $.inArray( false, abStateLoad ) !== -1 ) {
				callback();
				return;
			}
	
			// Reject old data
			var duration = settings.iStateDuration;
			if ( duration > 0 && s.time < +new Date() - (duration*1000) ) {
				callback();
				return;
			}
	
			// Number of columns have changed - all bets are off, no restore of settings
			if ( s.columns && columns.length !== s.columns.length ) {
				callback();
				return;
			}
	
			// Store the saved state so it might be accessed at any time
			settings.oLoadedState = $.extend( true, {}, s );
	
			// Restore key features - todo - for 1.11 this needs to be done by
			// subscribed events
			if ( s.start !== undefined ) {
				settings._iDisplayStart    = s.start;
				settings.iInitDisplayStart = s.start;
			}
			if ( s.length !== undefined ) {
				settings._iDisplayLength   = s.length;
			}
	
			// Order
			if ( s.order !== undefined ) {
				settings.aaSorting = [];
				$.each( s.order, function ( i, col ) {
					settings.aaSorting.push( col[0] >= columns.length ?
						[ 0, col[1] ] :
						col
					);
				} );
			}
	
			// Search
			if ( s.search !== undefined ) {
				$.extend( settings.oPreviousSearch, _fnSearchToHung( s.search ) );
			}
	
			// Columns
			//
			if ( s.columns ) {
				for ( i=0, ien=s.columns.length ; i<ien ; i++ ) {
					var col = s.columns[i];
	
					// Visibility
					if ( col.visible !== undefined ) {
						columns[i].bVisible = col.visible;
					}
	
					// Search
					if ( col.search !== undefined ) {
						$.extend( settings.aoPreSearchCols[i], _fnSearchToHung( col.search ) );
					}
				}
			}
	
			_fnCallbackFire( settings, 'aoStateLoaded', 'stateLoaded', [settings, s] );
			callback();
		}
	
		if ( ! settings.oFeatures.bStateSave ) {
			callback();
			return;
		}
	
		var state = settings.fnStateLoadCallback.call( settings.oInstance, settings, loaded );
	
		if ( state !== undefined ) {
			loaded( state );
		}
		// otherwise, wait for the loaded callback to be executed
	}
	
	
	/**
	 * Return the settings object for a particular table
	 *  @param {node} table table we are using as a dataTable
	 *  @returns {object} Settings object - or null if not found
	 *  @memberof DataTable#oApi
	 */
	function _fnSettingsFromNode ( table )
	{
		var settings = DataTable.settings;
		var idx = $.inArray( table, _pluck( settings, 'nTable' ) );
	
		return idx !== -1 ?
			settings[ idx ] :
			null;
	}
	
	
	/**
	 * Log an error message
	 *  @param {object} settings dataTables settings object
	 *  @param {int} level log error messages, or display them to the user
	 *  @param {string} msg error message
	 *  @param {int} tn Technical note id to get more information about the error.
	 *  @memberof DataTable#oApi
	 */
	function _fnLog( settings, level, msg, tn )
	{
		msg = 'DataTables warning: '+
			(settings ? 'table id='+settings.sTableId+' - ' : '')+msg;
	
		if ( tn ) {
			msg += '. For more information about this error, please see '+
			'http://datatables.net/tn/'+tn;
		}
	
		if ( ! level  ) {
			// Backwards compatibility pre 1.10
			var ext = DataTable.ext;
			var type = ext.sErrMode || ext.errMode;
	
			if ( settings ) {
				_fnCallbackFire( settings, null, 'error', [ settings, tn, msg ] );
			}
	
			if ( type == 'alert' ) {
				alert( msg );
			}
			else if ( type == 'throw' ) {
				throw new Error(msg);
			}
			else if ( typeof type == 'function' ) {
				type( settings, tn, msg );
			}
		}
		else if ( window.console && console.log ) {
			console.log( msg );
		}
	}
	
	
	/**
	 * See if a property is defined on one object, if so assign it to the other object
	 *  @param {object} ret target object
	 *  @param {object} src source object
	 *  @param {string} name property
	 *  @param {string} [mappedName] name to map too - optional, name used if not given
	 *  @memberof DataTable#oApi
	 */
	function _fnMap( ret, src, name, mappedName )
	{
		if ( $.isArray( name ) ) {
			$.each( name, function (i, val) {
				if ( $.isArray( val ) ) {
					_fnMap( ret, src, val[0], val[1] );
				}
				else {
					_fnMap( ret, src, val );
				}
			} );
	
			return;
		}
	
		if ( mappedName === undefined ) {
			mappedName = name;
		}
	
		if ( src[name] !== undefined ) {
			ret[mappedName] = src[name];
		}
	}
	
	
	/**
	 * Extend objects - very similar to jQuery.extend, but deep copy objects, and
	 * shallow copy arrays. The reason we need to do this, is that we don't want to
	 * deep copy array init values (such as aaSorting) since the dev wouldn't be
	 * able to override them, but we do want to deep copy arrays.
	 *  @param {object} out Object to extend
	 *  @param {object} extender Object from which the properties will be applied to
	 *      out
	 *  @param {boolean} breakRefs If true, then arrays will be sliced to take an
	 *      independent copy with the exception of the `data` or `aaData` parameters
	 *      if they are present. This is so you can pass in a collection to
	 *      DataTables and have that used as your data source without breaking the
	 *      references
	 *  @returns {object} out Reference, just for convenience - out === the return.
	 *  @memberof DataTable#oApi
	 *  @todo This doesn't take account of arrays inside the deep copied objects.
	 */
	function _fnExtend( out, extender, breakRefs )
	{
		var val;
	
		for ( var prop in extender ) {
			if ( extender.hasOwnProperty(prop) ) {
				val = extender[prop];
	
				if ( $.isPlainObject( val ) ) {
					if ( ! $.isPlainObject( out[prop] ) ) {
						out[prop] = {};
					}
					$.extend( true, out[prop], val );
				}
				else if ( breakRefs && prop !== 'data' && prop !== 'aaData' && $.isArray(val) ) {
					out[prop] = val.slice();
				}
				else {
					out[prop] = val;
				}
			}
		}
	
		return out;
	}
	
	
	/**
	 * Bind an event handers to allow a click or return key to activate the callback.
	 * This is good for accessibility since a return on the keyboard will have the
	 * same effect as a click, if the element has focus.
	 *  @param {element} n Element to bind the action to
	 *  @param {object} oData Data object to pass to the triggered function
	 *  @param {function} fn Callback function for when the event is triggered
	 *  @memberof DataTable#oApi
	 */
	function _fnBindAction( n, oData, fn )
	{
		$(n)
			.on( 'click.DT', oData, function (e) {
					n.blur(); // Remove focus outline for mouse users
					fn(e);
				} )
			.on( 'keypress.DT', oData, function (e){
					if ( e.which === 13 ) {
						e.preventDefault();
						fn(e);
					}
				} )
			.on( 'selectstart.DT', function () {
					/* Take the brutal approach to cancelling text selection */
					return false;
				} );
	}
	
	
	/**
	 * Register a callback function. Easily allows a callback function to be added to
	 * an array store of callback functions that can then all be called together.
	 *  @param {object} oSettings dataTables settings object
	 *  @param {string} sStore Name of the array storage for the callbacks in oSettings
	 *  @param {function} fn Function to be called back
	 *  @param {string} sName Identifying name for the callback (i.e. a label)
	 *  @memberof DataTable#oApi
	 */
	function _fnCallbackReg( oSettings, sStore, fn, sName )
	{
		if ( fn )
		{
			oSettings[sStore].push( {
				"fn": fn,
				"sName": sName
			} );
		}
	}
	
	
	/**
	 * Fire callback functions and trigger events. Note that the loop over the
	 * callback array store is done backwards! Further note that you do not want to
	 * fire off triggers in time sensitive applications (for example cell creation)
	 * as its slow.
	 *  @param {object} settings dataTables settings object
	 *  @param {string} callbackArr Name of the array storage for the callbacks in
	 *      oSettings
	 *  @param {string} eventName Name of the jQuery custom event to trigger. If
	 *      null no trigger is fired
	 *  @param {array} args Array of arguments to pass to the callback function /
	 *      trigger
	 *  @memberof DataTable#oApi
	 */
	function _fnCallbackFire( settings, callbackArr, eventName, args )
	{
		var ret = [];
	
		if ( callbackArr ) {
			ret = $.map( settings[callbackArr].slice().reverse(), function (val, i) {
				return val.fn.apply( settings.oInstance, args );
			} );
		}
	
		if ( eventName !== null ) {
			var e = $.Event( eventName+'.dt' );
	
			$(settings.nTable).trigger( e, args );
	
			ret.push( e.result );
		}
	
		return ret;
	}
	
	
	function _fnLengthOverflow ( settings )
	{
		var
			start = settings._iDisplayStart,
			end = settings.fnDisplayEnd(),
			len = settings._iDisplayLength;
	
		/* If we have space to show extra rows (backing up from the end point - then do so */
		if ( start >= end )
		{
			start = end - len;
		}
	
		// Keep the start record on the current page
		start -= (start % len);
	
		if ( len === -1 || start < 0 )
		{
			start = 0;
		}
	
		settings._iDisplayStart = start;
	}
	
	
	function _fnRenderer( settings, type )
	{
		var renderer = settings.renderer;
		var host = DataTable.ext.renderer[type];
	
		if ( $.isPlainObject( renderer ) && renderer[type] ) {
			// Specific renderer for this type. If available use it, otherwise use
			// the default.
			return host[renderer[type]] || host._;
		}
		else if ( typeof renderer === 'string' ) {
			// Common renderer - if there is one available for this type use it,
			// otherwise use the default
			return host[renderer] || host._;
		}
	
		// Use the default
		return host._;
	}
	
	
	/**
	 * Detect the data source being used for the table. Used to simplify the code
	 * a little (ajax) and to make it compress a little smaller.
	 *
	 *  @param {object} settings dataTables settings object
	 *  @returns {string} Data source
	 *  @memberof DataTable#oApi
	 */
	function _fnDataSource ( settings )
	{
		if ( settings.oFeatures.bServerSide ) {
			return 'ssp';
		}
		else if ( settings.ajax || settings.sAjaxSource ) {
			return 'ajax';
		}
		return 'dom';
	}
	

	
	
	/**
	 * Computed structure of the DataTables API, defined by the options passed to
	 * `DataTable.Api.register()` when building the API.
	 *
	 * The structure is built in order to speed creation and extension of the Api
	 * objects since the extensions are effectively pre-parsed.
	 *
	 * The array is an array of objects with the following structure, where this
	 * base array represents the Api prototype base:
	 *
	 *     [
	 *       {
	 *         name:      'data'                -- string   - Property name
	 *         val:       function () {},       -- function - Api method (or undefined if just an object
	 *         methodExt: [ ... ],              -- array    - Array of Api object definitions to extend the method result
	 *         propExt:   [ ... ]               -- array    - Array of Api object definitions to extend the property
	 *       },
	 *       {
	 *         name:     'row'
	 *         val:       {},
	 *         methodExt: [ ... ],
	 *         propExt:   [
	 *           {
	 *             name:      'data'
	 *             val:       function () {},
	 *             methodExt: [ ... ],
	 *             propExt:   [ ... ]
	 *           },
	 *           ...
	 *         ]
	 *       }
	 *     ]
	 *
	 * @type {Array}
	 * @ignore
	 */
	var __apiStruct = [];
	
	
	/**
	 * `Array.prototype` reference.
	 *
	 * @type object
	 * @ignore
	 */
	var __arrayProto = Array.prototype;
	
	
	/**
	 * Abstraction for `context` parameter of the `Api` constructor to allow it to
	 * take several different forms for ease of use.
	 *
	 * Each of the input parameter types will be converted to a DataTables settings
	 * object where possible.
	 *
	 * @param  {string|node|jQuery|object} mixed DataTable identifier. Can be one
	 *   of:
	 *
	 *   * `string` - jQuery selector. Any DataTables' matching the given selector
	 *     with be found and used.
	 *   * `node` - `TABLE` node which has already been formed into a DataTable.
	 *   * `jQuery` - A jQuery object of `TABLE` nodes.
	 *   * `object` - DataTables settings object
	 *   * `DataTables.Api` - API instance
	 * @return {array|null} Matching DataTables settings objects. `null` or
	 *   `undefined` is returned if no matching DataTable is found.
	 * @ignore
	 */
	var _toSettings = function ( mixed )
	{
		var idx, jq;
		var settings = DataTable.settings;
		var tables = $.map( settings, function (el, i) {
			return el.nTable;
		} );
	
		if ( ! mixed ) {
			return [];
		}
		else if ( mixed.nTable && mixed.oApi ) {
			// DataTables settings object
			return [ mixed ];
		}
		else if ( mixed.nodeName && mixed.nodeName.toLowerCase() === 'table' ) {
			// Table node
			idx = $.inArray( mixed, tables );
			return idx !== -1 ? [ settings[idx] ] : null;
		}
		else if ( mixed && typeof mixed.settings === 'function' ) {
			return mixed.settings().toArray();
		}
		else if ( typeof mixed === 'string' ) {
			// jQuery selector
			jq = $(mixed);
		}
		else if ( mixed instanceof $ ) {
			// jQuery object (also DataTables instance)
			jq = mixed;
		}
	
		if ( jq ) {
			return jq.map( function(i) {
				idx = $.inArray( this, tables );
				return idx !== -1 ? settings[idx] : null;
			} ).toArray();
		}
	};
	
	
	/**
	 * DataTables API class - used to control and interface with  one or more
	 * DataTables enhanced tables.
	 *
	 * The API class is heavily based on jQuery, presenting a chainable interface
	 * that you can use to interact with tables. Each instance of the API class has
	 * a "context" - i.e. the tables that it will operate on. This could be a single
	 * table, all tables on a page or a sub-set thereof.
	 *
	 * Additionally the API is designed to allow you to easily work with the data in
	 * the tables, retrieving and manipulating it as required. This is done by
	 * presenting the API class as an array like interface. The contents of the
	 * array depend upon the actions requested by each method (for example
	 * `rows().nodes()` will return an array of nodes, while `rows().data()` will
	 * return an array of objects or arrays depending upon your table's
	 * configuration). The API object has a number of array like methods (`push`,
	 * `pop`, `reverse` etc) as well as additional helper methods (`each`, `pluck`,
	 * `unique` etc) to assist your working with the data held in a table.
	 *
	 * Most methods (those which return an Api instance) are chainable, which means
	 * the return from a method call also has all of the methods available that the
	 * top level object had. For example, these two calls are equivalent:
	 *
	 *     // Not chained
	 *     api.row.add( {...} );
	 *     api.draw();
	 *
	 *     // Chained
	 *     api.row.add( {...} ).draw();
	 *
	 * @class DataTable.Api
	 * @param {array|object|string|jQuery} context DataTable identifier. This is
	 *   used to define which DataTables enhanced tables this API will operate on.
	 *   Can be one of:
	 *
	 *   * `string` - jQuery selector. Any DataTables' matching the given selector
	 *     with be found and used.
	 *   * `node` - `TABLE` node which has already been formed into a DataTable.
	 *   * `jQuery` - A jQuery object of `TABLE` nodes.
	 *   * `object` - DataTables settings object
	 * @param {array} [data] Data to initialise the Api instance with.
	 *
	 * @example
	 *   // Direct initialisation during DataTables construction
	 *   var api = $('#example').DataTable();
	 *
	 * @example
	 *   // Initialisation using a DataTables jQuery object
	 *   var api = $('#example').dataTable().api();
	 *
	 * @example
	 *   // Initialisation as a constructor
	 *   var api = new $.fn.DataTable.Api( 'table.dataTable' );
	 */
	_Api = function ( context, data )
	{
		if ( ! (this instanceof _Api) ) {
			return new _Api( context, data );
		}
	
		var settings = [];
		var ctxSettings = function ( o ) {
			var a = _toSettings( o );
			if ( a ) {
				settings = settings.concat( a );
			}
		};
	
		if ( $.isArray( context ) ) {
			for ( var i=0, ien=context.length ; i<ien ; i++ ) {
				ctxSettings( context[i] );
			}
		}
		else {
			ctxSettings( context );
		}
	
		// Remove duplicates
		this.context = _unique( settings );
	
		// Initial data
		if ( data ) {
			$.merge( this, data );
		}
	
		// selector
		this.selector = {
			rows: null,
			cols: null,
			opts: null
		};
	
		_Api.extend( this, this, __apiStruct );
	};
	
	DataTable.Api = _Api;
	
	// Don't destroy the existing prototype, just extend it. Required for jQuery 2's
	// isPlainObject.
	$.extend( _Api.prototype, {
		any: function ()
		{
			return this.count() !== 0;
		},
	
	
		concat:  __arrayProto.concat,
	
	
		context: [], // array of table settings objects
	
	
		count: function ()
		{
			return this.flatten().length;
		},
	
	
		each: function ( fn )
		{
			for ( var i=0, ien=this.length ; i<ien; i++ ) {
				fn.call( this, this[i], i, this );
			}
	
			return this;
		},
	
	
		eq: function ( idx )
		{
			var ctx = this.context;
	
			return ctx.length > idx ?
				new _Api( ctx[idx], this[idx] ) :
				null;
		},
	
	
		filter: function ( fn )
		{
			var a = [];
	
			if ( __arrayProto.filter ) {
				a = __arrayProto.filter.call( this, fn, this );
			}
			else {
				// Compatibility for browsers without EMCA-252-5 (JS 1.6)
				for ( var i=0, ien=this.length ; i<ien ; i++ ) {
					if ( fn.call( this, this[i], i, this ) ) {
						a.push( this[i] );
					}
				}
			}
	
			return new _Api( this.context, a );
		},
	
	
		flatten: function ()
		{
			var a = [];
			return new _Api( this.context, a.concat.apply( a, this.toArray() ) );
		},
	
	
		join:    __arrayProto.join,
	
	
		indexOf: __arrayProto.indexOf || function (obj, start)
		{
			for ( var i=(start || 0), ien=this.length ; i<ien ; i++ ) {
				if ( this[i] === obj ) {
					return i;
				}
			}
			return -1;
		},
	
		iterator: function ( flatten, type, fn, alwaysNew ) {
			var
				a = [], ret,
				i, ien, j, jen,
				context = this.context,
				rows, items, item,
				selector = this.selector;
	
			// Argument shifting
			if ( typeof flatten === 'string' ) {
				alwaysNew = fn;
				fn = type;
				type = flatten;
				flatten = false;
			}
	
			for ( i=0, ien=context.length ; i<ien ; i++ ) {
				var apiInst = new _Api( context[i] );
	
				if ( type === 'table' ) {
					ret = fn.call( apiInst, context[i], i );
	
					if ( ret !== undefined ) {
						a.push( ret );
					}
				}
				else if ( type === 'columns' || type === 'rows' ) {
					// this has same length as context - one entry for each table
					ret = fn.call( apiInst, context[i], this[i], i );
	
					if ( ret !== undefined ) {
						a.push( ret );
					}
				}
				else if ( type === 'column' || type === 'column-rows' || type === 'row' || type === 'cell' ) {
					// columns and rows share the same structure.
					// 'this' is an array of column indexes for each context
					items = this[i];
	
					if ( type === 'column-rows' ) {
						rows = _selector_row_indexes( context[i], selector.opts );
					}
	
					for ( j=0, jen=items.length ; j<jen ; j++ ) {
						item = items[j];
	
						if ( type === 'cell' ) {
							ret = fn.call( apiInst, context[i], item.row, item.column, i, j );
						}
						else {
							ret = fn.call( apiInst, context[i], item, i, j, rows );
						}
	
						if ( ret !== undefined ) {
							a.push( ret );
						}
					}
				}
			}
	
			if ( a.length || alwaysNew ) {
				var api = new _Api( context, flatten ? a.concat.apply( [], a ) : a );
				var apiSelector = api.selector;
				apiSelector.rows = selector.rows;
				apiSelector.cols = selector.cols;
				apiSelector.opts = selector.opts;
				return api;
			}
			return this;
		},
	
	
		lastIndexOf: __arrayProto.lastIndexOf || function (obj, start)
		{
			// Bit cheeky...
			return this.indexOf.apply( this.toArray.reverse(), arguments );
		},
	
	
		length:  0,
	
	
		map: function ( fn )
		{
			var a = [];
	
			if ( __arrayProto.map ) {
				a = __arrayProto.map.call( this, fn, this );
			}
			else {
				// Compatibility for browsers without EMCA-252-5 (JS 1.6)
				for ( var i=0, ien=this.length ; i<ien ; i++ ) {
					a.push( fn.call( this, this[i], i ) );
				}
			}
	
			return new _Api( this.context, a );
		},
	
	
		pluck: function ( prop )
		{
			return this.map( function ( el ) {
				return el[ prop ];
			} );
		},
	
		pop:     __arrayProto.pop,
	
	
		push:    __arrayProto.push,
	
	
		// Does not return an API instance
		reduce: __arrayProto.reduce || function ( fn, init )
		{
			return _fnReduce( this, fn, init, 0, this.length, 1 );
		},
	
	
		reduceRight: __arrayProto.reduceRight || function ( fn, init )
		{
			return _fnReduce( this, fn, init, this.length-1, -1, -1 );
		},
	
	
		reverse: __arrayProto.reverse,
	
	
		// Object with rows, columns and opts
		selector: null,
	
	
		shift:   __arrayProto.shift,
	
	
		slice: function () {
			return new _Api( this.context, this );
		},
	
	
		sort:    __arrayProto.sort, // ? name - order?
	
	
		splice:  __arrayProto.splice,
	
	
		toArray: function ()
		{
			return __arrayProto.slice.call( this );
		},
	
	
		to$: function ()
		{
			return $( this );
		},
	
	
		toJQuery: function ()
		{
			return $( this );
		},
	
	
		unique: function ()
		{
			return new _Api( this.context, _unique(this) );
		},
	
	
		unshift: __arrayProto.unshift
	} );
	
	
	_Api.extend = function ( scope, obj, ext )
	{
		// Only extend API instances and static properties of the API
		if ( ! ext.length || ! obj || ( ! (obj instanceof _Api) && ! obj.__dt_wrapper ) ) {
			return;
		}
	
		var
			i, ien,
			j, jen,
			struct, inner,
			methodScoping = function ( scope, fn, struc ) {
				return function () {
					var ret = fn.apply( scope, arguments );
	
					// Method extension
					_Api.extend( ret, ret, struc.methodExt );
					return ret;
				};
			};
	
		for ( i=0, ien=ext.length ; i<ien ; i++ ) {
			struct = ext[i];
	
			// Value
			obj[ struct.name ] = typeof struct.val === 'function' ?
				methodScoping( scope, struct.val, struct ) :
				$.isPlainObject( struct.val ) ?
					{} :
					struct.val;
	
			obj[ struct.name ].__dt_wrapper = true;
	
			// Property extension
			_Api.extend( scope, obj[ struct.name ], struct.propExt );
		}
	};
	
	
	// @todo - Is there need for an augment function?
	// _Api.augment = function ( inst, name )
	// {
	// 	// Find src object in the structure from the name
	// 	var parts = name.split('.');
	
	// 	_Api.extend( inst, obj );
	// };
	
	
	//     [
	//       {
	//         name:      'data'                -- string   - Property name
	//         val:       function () {},       -- function - Api method (or undefined if just an object
	//         methodExt: [ ... ],              -- array    - Array of Api object definitions to extend the method result
	//         propExt:   [ ... ]               -- array    - Array of Api object definitions to extend the property
	//       },
	//       {
	//         name:     'row'
	//         val:       {},
	//         methodExt: [ ... ],
	//         propExt:   [
	//           {
	//             name:      'data'
	//             val:       function () {},
	//             methodExt: [ ... ],
	//             propExt:   [ ... ]
	//           },
	//           ...
	//         ]
	//       }
	//     ]
	
	_Api.register = _api_register = function ( name, val )
	{
		if ( $.isArray( name ) ) {
			for ( var j=0, jen=name.length ; j<jen ; j++ ) {
				_Api.register( name[j], val );
			}
			return;
		}
	
		var
			i, ien,
			heir = name.split('.'),
			struct = __apiStruct,
			key, method;
	
		var find = function ( src, name ) {
			for ( var i=0, ien=src.length ; i<ien ; i++ ) {
				if ( src[i].name === name ) {
					return src[i];
				}
			}
			return null;
		};
	
		for ( i=0, ien=heir.length ; i<ien ; i++ ) {
			method = heir[i].indexOf('()') !== -1;
			key = method ?
				heir[i].replace('()', '') :
				heir[i];
	
			var src = find( struct, key );
			if ( ! src ) {
				src = {
					name:      key,
					val:       {},
					methodExt: [],
					propExt:   []
				};
				struct.push( src );
			}
	
			if ( i === ien-1 ) {
				src.val = val;
			}
			else {
				struct = method ?
					src.methodExt :
					src.propExt;
			}
		}
	};
	
	
	_Api.registerPlural = _api_registerPlural = function ( pluralName, singularName, val ) {
		_Api.register( pluralName, val );
	
		_Api.register( singularName, function () {
			var ret = val.apply( this, arguments );
	
			if ( ret === this ) {
				// Returned item is the API instance that was passed in, return it
				return this;
			}
			else if ( ret instanceof _Api ) {
				// New API instance returned, want the value from the first item
				// in the returned array for the singular result.
				return ret.length ?
					$.isArray( ret[0] ) ?
						new _Api( ret.context, ret[0] ) : // Array results are 'enhanced'
						ret[0] :
					undefined;
			}
	
			// Non-API return - just fire it back
			return ret;
		} );
	};
	
	
	/**
	 * Selector for HTML tables. Apply the given selector to the give array of
	 * DataTables settings objects.
	 *
	 * @param {string|integer} [selector] jQuery selector string or integer
	 * @param  {array} Array of DataTables settings objects to be filtered
	 * @return {array}
	 * @ignore
	 */
	var __table_selector = function ( selector, a )
	{
		// Integer is used to pick out a table by index
		if ( typeof selector === 'number' ) {
			return [ a[ selector ] ];
		}
	
		// Perform a jQuery selector on the table nodes
		var nodes = $.map( a, function (el, i) {
			return el.nTable;
		} );
	
		return $(nodes)
			.filter( selector )
			.map( function (i) {
				// Need to translate back from the table node to the settings
				var idx = $.inArray( this, nodes );
				return a[ idx ];
			} )
			.toArray();
	};
	
	
	
	/**
	 * Context selector for the API's context (i.e. the tables the API instance
	 * refers to.
	 *
	 * @name    DataTable.Api#tables
	 * @param {string|integer} [selector] Selector to pick which tables the iterator
	 *   should operate on. If not given, all tables in the current context are
	 *   used. This can be given as a jQuery selector (for example `':gt(0)'`) to
	 *   select multiple tables or as an integer to select a single table.
	 * @returns {DataTable.Api} Returns a new API instance if a selector is given.
	 */
	_api_register( 'tables()', function ( selector ) {
		// A new instance is created if there was a selector specified
		return selector ?
			new _Api( __table_selector( selector, this.context ) ) :
			this;
	} );
	
	
	_api_register( 'table()', function ( selector ) {
		var tables = this.tables( selector );
		var ctx = tables.context;
	
		// Truncate to the first matched table
		return ctx.length ?
			new _Api( ctx[0] ) :
			tables;
	} );
	
	
	_api_registerPlural( 'tables().nodes()', 'table().node()' , function () {
		return this.iterator( 'table', function ( ctx ) {
			return ctx.nTable;
		}, 1 );
	} );
	
	
	_api_registerPlural( 'tables().body()', 'table().body()' , function () {
		return this.iterator( 'table', function ( ctx ) {
			return ctx.nTBody;
		}, 1 );
	} );
	
	
	_api_registerPlural( 'tables().header()', 'table().header()' , function () {
		return this.iterator( 'table', function ( ctx ) {
			return ctx.nTHead;
		}, 1 );
	} );
	
	
	_api_registerPlural( 'tables().footer()', 'table().footer()' , function () {
		return this.iterator( 'table', function ( ctx ) {
			return ctx.nTFoot;
		}, 1 );
	} );
	
	
	_api_registerPlural( 'tables().containers()', 'table().container()' , function () {
		return this.iterator( 'table', function ( ctx ) {
			return ctx.nTableWrapper;
		}, 1 );
	} );
	
	
	
	/**
	 * Redraw the tables in the current context.
	 */
	_api_register( 'draw()', function ( paging ) {
		return this.iterator( 'table', function ( settings ) {
			if ( paging === 'page' ) {
				_fnDraw( settings );
			}
			else {
				if ( typeof paging === 'string' ) {
					paging = paging === 'full-hold' ?
						false :
						true;
				}
	
				_fnReDraw( settings, paging===false );
			}
		} );
	} );
	
	
	
	/**
	 * Get the current page index.
	 *
	 * @return {integer} Current page index (zero based)
	 *//**
	 * Set the current page.
	 *
	 * Note that if you attempt to show a page which does not exist, DataTables will
	 * not throw an error, but rather reset the paging.
	 *
	 * @param {integer|string} action The paging action to take. This can be one of:
	 *  * `integer` - The page index to jump to
	 *  * `string` - An action to take:
	 *    * `first` - Jump to first page.
	 *    * `next` - Jump to the next page
	 *    * `previous` - Jump to previous page
	 *    * `last` - Jump to the last page.
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'page()', function ( action ) {
		if ( action === undefined ) {
			return this.page.info().page; // not an expensive call
		}
	
		// else, have an action to take on all tables
		return this.iterator( 'table', function ( settings ) {
			_fnPageChange( settings, action );
		} );
	} );
	
	
	/**
	 * Paging information for the first table in the current context.
	 *
	 * If you require paging information for another table, use the `table()` method
	 * with a suitable selector.
	 *
	 * @return {object} Object with the following properties set:
	 *  * `page` - Current page index (zero based - i.e. the first page is `0`)
	 *  * `pages` - Total number of pages
	 *  * `start` - Display index for the first record shown on the current page
	 *  * `end` - Display index for the last record shown on the current page
	 *  * `length` - Display length (number of records). Note that generally `start
	 *    + length = end`, but this is not always true, for example if there are
	 *    only 2 records to show on the final page, with a length of 10.
	 *  * `recordsTotal` - Full data set length
	 *  * `recordsDisplay` - Data set length once the current filtering criterion
	 *    are applied.
	 */
	_api_register( 'page.info()', function ( action ) {
		if ( this.context.length === 0 ) {
			return undefined;
		}
	
		var
			settings   = this.context[0],
			start      = settings._iDisplayStart,
			len        = settings.oFeatures.bPaginate ? settings._iDisplayLength : -1,
			visRecords = settings.fnRecordsDisplay(),
			all        = len === -1;
	
		return {
			"page":           all ? 0 : Math.floor( start / len ),
			"pages":          all ? 1 : Math.ceil( visRecords / len ),
			"start":          start,
			"end":            settings.fnDisplayEnd(),
			"length":         len,
			"recordsTotal":   settings.fnRecordsTotal(),
			"recordsDisplay": visRecords,
			"serverSide":     _fnDataSource( settings ) === 'ssp'
		};
	} );
	
	
	/**
	 * Get the current page length.
	 *
	 * @return {integer} Current page length. Note `-1` indicates that all records
	 *   are to be shown.
	 *//**
	 * Set the current page length.
	 *
	 * @param {integer} Page length to set. Use `-1` to show all records.
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'page.len()', function ( len ) {
		// Note that we can't call this function 'length()' because `length`
		// is a Javascript property of functions which defines how many arguments
		// the function expects.
		if ( len === undefined ) {
			return this.context.length !== 0 ?
				this.context[0]._iDisplayLength :
				undefined;
		}
	
		// else, set the page length
		return this.iterator( 'table', function ( settings ) {
			_fnLengthChange( settings, len );
		} );
	} );
	
	
	
	var __reload = function ( settings, holdPosition, callback ) {
		// Use the draw event to trigger a callback
		if ( callback ) {
			var api = new _Api( settings );
	
			api.one( 'draw', function () {
				callback( api.ajax.json() );
			} );
		}
	
		if ( _fnDataSource( settings ) == 'ssp' ) {
			_fnReDraw( settings, holdPosition );
		}
		else {
			_fnProcessingDisplay( settings, true );
	
			// Cancel an existing request
			var xhr = settings.jqXHR;
			if ( xhr && xhr.readyState !== 4 ) {
				xhr.abort();
			}
	
			// Trigger xhr
			_fnBuildAjax( settings, [], function( json ) {
				_fnClearTable( settings );
	
				var data = _fnAjaxDataSrc( settings, json );
				for ( var i=0, ien=data.length ; i<ien ; i++ ) {
					_fnAddData( settings, data[i] );
				}
	
				_fnReDraw( settings, holdPosition );
				_fnProcessingDisplay( settings, false );
			} );
		}
	};
	
	
	/**
	 * Get the JSON response from the last Ajax request that DataTables made to the
	 * server. Note that this returns the JSON from the first table in the current
	 * context.
	 *
	 * @return {object} JSON received from the server.
	 */
	_api_register( 'ajax.json()', function () {
		var ctx = this.context;
	
		if ( ctx.length > 0 ) {
			return ctx[0].json;
		}
	
		// else return undefined;
	} );
	
	
	/**
	 * Get the data submitted in the last Ajax request
	 */
	_api_register( 'ajax.params()', function () {
		var ctx = this.context;
	
		if ( ctx.length > 0 ) {
			return ctx[0].oAjaxData;
		}
	
		// else return undefined;
	} );
	
	
	/**
	 * Reload tables from the Ajax data source. Note that this function will
	 * automatically re-draw the table when the remote data has been loaded.
	 *
	 * @param {boolean} [reset=true] Reset (default) or hold the current paging
	 *   position. A full re-sort and re-filter is performed when this method is
	 *   called, which is why the pagination reset is the default action.
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'ajax.reload()', function ( callback, resetPaging ) {
		return this.iterator( 'table', function (settings) {
			__reload( settings, resetPaging===false, callback );
		} );
	} );
	
	
	/**
	 * Get the current Ajax URL. Note that this returns the URL from the first
	 * table in the current context.
	 *
	 * @return {string} Current Ajax source URL
	 *//**
	 * Set the Ajax URL. Note that this will set the URL for all tables in the
	 * current context.
	 *
	 * @param {string} url URL to set.
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'ajax.url()', function ( url ) {
		var ctx = this.context;
	
		if ( url === undefined ) {
			// get
			if ( ctx.length === 0 ) {
				return undefined;
			}
			ctx = ctx[0];
	
			return ctx.ajax ?
				$.isPlainObject( ctx.ajax ) ?
					ctx.ajax.url :
					ctx.ajax :
				ctx.sAjaxSource;
		}
	
		// set
		return this.iterator( 'table', function ( settings ) {
			if ( $.isPlainObject( settings.ajax ) ) {
				settings.ajax.url = url;
			}
			else {
				settings.ajax = url;
			}
			// No need to consider sAjaxSource here since DataTables gives priority
			// to `ajax` over `sAjaxSource`. So setting `ajax` here, renders any
			// value of `sAjaxSource` redundant.
		} );
	} );
	
	
	/**
	 * Load data from the newly set Ajax URL. Note that this method is only
	 * available when `ajax.url()` is used to set a URL. Additionally, this method
	 * has the same effect as calling `ajax.reload()` but is provided for
	 * convenience when setting a new URL. Like `ajax.reload()` it will
	 * automatically redraw the table once the remote data has been loaded.
	 *
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'ajax.url().load()', function ( callback, resetPaging ) {
		// Same as a reload, but makes sense to present it for easy access after a
		// url change
		return this.iterator( 'table', function ( ctx ) {
			__reload( ctx, resetPaging===false, callback );
		} );
	} );
	
	
	
	
	var _selector_run = function ( type, selector, selectFn, settings, opts )
	{
		var
			out = [], res,
			a, i, ien, j, jen,
			selectorType = typeof selector;
	
		// Can't just check for isArray here, as an API or jQuery instance might be
		// given with their array like look
		if ( ! selector || selectorType === 'string' || selectorType === 'function' || selector.length === undefined ) {
			selector = [ selector ];
		}
	
		for ( i=0, ien=selector.length ; i<ien ; i++ ) {
			// Only split on simple strings - complex expressions will be jQuery selectors
			a = selector[i] && selector[i].split && ! selector[i].match(/[\[\(:]/) ?
				selector[i].split(',') :
				[ selector[i] ];
	
			for ( j=0, jen=a.length ; j<jen ; j++ ) {
				res = selectFn( typeof a[j] === 'string' ? $.trim(a[j]) : a[j] );
	
				if ( res && res.length ) {
					out = out.concat( res );
				}
			}
		}
	
		// selector extensions
		var ext = _ext.selector[ type ];
		if ( ext.length ) {
			for ( i=0, ien=ext.length ; i<ien ; i++ ) {
				out = ext[i]( settings, opts, out );
			}
		}
	
		return _unique( out );
	};
	
	
	var _selector_opts = function ( opts )
	{
		if ( ! opts ) {
			opts = {};
		}
	
		// Backwards compatibility for 1.9- which used the terminology filter rather
		// than search
		if ( opts.filter && opts.search === undefined ) {
			opts.search = opts.filter;
		}
	
		return $.extend( {
			search: 'none',
			order: 'current',
			page: 'all'
		}, opts );
	};
	
	
	var _selector_first = function ( inst )
	{
		// Reduce the API instance to the first item found
		for ( var i=0, ien=inst.length ; i<ien ; i++ ) {
			if ( inst[i].length > 0 ) {
				// Assign the first element to the first item in the instance
				// and truncate the instance and context
				inst[0] = inst[i];
				inst[0].length = 1;
				inst.length = 1;
				inst.context = [ inst.context[i] ];
	
				return inst;
			}
		}
	
		// Not found - return an empty instance
		inst.length = 0;
		return inst;
	};
	
	
	var _selector_row_indexes = function ( settings, opts )
	{
		var
			i, ien, tmp, a=[],
			displayFiltered = settings.aiDisplay,
			displayMaster = settings.aiDisplayMaster;
	
		var
			search = opts.search,  // none, applied, removed
			order  = opts.order,   // applied, current, index (original - compatibility with 1.9)
			page   = opts.page;    // all, current
	
		if ( _fnDataSource( settings ) == 'ssp' ) {
			// In server-side processing mode, most options are irrelevant since
			// rows not shown don't exist and the index order is the applied order
			// Removed is a special case - for consistency just return an empty
			// array
			return search === 'removed' ?
				[] :
				_range( 0, displayMaster.length );
		}
		else if ( page == 'current' ) {
			// Current page implies that order=current and fitler=applied, since it is
			// fairly senseless otherwise, regardless of what order and search actually
			// are
			for ( i=settings._iDisplayStart, ien=settings.fnDisplayEnd() ; i<ien ; i++ ) {
				a.push( displayFiltered[i] );
			}
		}
		else if ( order == 'current' || order == 'applied' ) {
			a = search == 'none' ?
				displayMaster.slice() :                      // no search
				search == 'applied' ?
					displayFiltered.slice() :                // applied search
					$.map( displayMaster, function (el, i) { // removed search
						return $.inArray( el, displayFiltered ) === -1 ? el : null;
					} );
		}
		else if ( order == 'index' || order == 'original' ) {
			for ( i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
				if ( search == 'none' ) {
					a.push( i );
				}
				else { // applied | removed
					tmp = $.inArray( i, displayFiltered );
	
					if ((tmp === -1 && search == 'removed') ||
						(tmp >= 0   && search == 'applied') )
					{
						a.push( i );
					}
				}
			}
		}
	
		return a;
	};
	
	
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Rows
	 *
	 * {}          - no selector - use all available rows
	 * {integer}   - row aoData index
	 * {node}      - TR node
	 * {string}    - jQuery selector to apply to the TR elements
	 * {array}     - jQuery array of nodes, or simply an array of TR nodes
	 *
	 */
	
	
	var __row_selector = function ( settings, selector, opts )
	{
		var rows;
		var run = function ( sel ) {
			var selInt = _intVal( sel );
			var i, ien;
	
			// Short cut - selector is a number and no options provided (default is
			// all records, so no need to check if the index is in there, since it
			// must be - dev error if the index doesn't exist).
			if ( selInt !== null && ! opts ) {
				return [ selInt ];
			}
	
			if ( ! rows ) {
				rows = _selector_row_indexes( settings, opts );
			}
	
			if ( selInt !== null && $.inArray( selInt, rows ) !== -1 ) {
				// Selector - integer
				return [ selInt ];
			}
			else if ( sel === null || sel === undefined || sel === '' ) {
				// Selector - none
				return rows;
			}
	
			// Selector - function
			if ( typeof sel === 'function' ) {
				return $.map( rows, function (idx) {
					var row = settings.aoData[ idx ];
					return sel( idx, row._aData, row.nTr ) ? idx : null;
				} );
			}
	
			// Get nodes in the order from the `rows` array with null values removed
			var nodes = _removeEmpty(
				_pluck_order( settings.aoData, rows, 'nTr' )
			);
	
			// Selector - node
			if ( sel.nodeName ) {
				if ( sel._DT_RowIndex !== undefined ) {
					return [ sel._DT_RowIndex ]; // Property added by DT for fast lookup
				}
				else if ( sel._DT_CellIndex ) {
					return [ sel._DT_CellIndex.row ];
				}
				else {
					var host = $(sel).closest('*[data-dt-row]');
					return host.length ?
						[ host.data('dt-row') ] :
						[];
				}
			}
	
			// ID selector. Want to always be able to select rows by id, regardless
			// of if the tr element has been created or not, so can't rely upon
			// jQuery here - hence a custom implementation. This does not match
			// Sizzle's fast selector or HTML4 - in HTML5 the ID can be anything,
			// but to select it using a CSS selector engine (like Sizzle or
			// querySelect) it would need to need to be escaped for some characters.
			// DataTables simplifies this for row selectors since you can select
			// only a row. A # indicates an id any anything that follows is the id -
			// unescaped.
			if ( typeof sel === 'string' && sel.charAt(0) === '#' ) {
				// get row index from id
				var rowObj = settings.aIds[ sel.replace( /^#/, '' ) ];
				if ( rowObj !== undefined ) {
					return [ rowObj.idx ];
				}
	
				// need to fall through to jQuery in case there is DOM id that
				// matches
			}
	
			// Selector - jQuery selector string, array of nodes or jQuery object/
			// As jQuery's .filter() allows jQuery objects to be passed in filter,
			// it also allows arrays, so this will cope with all three options
			return $(nodes)
				.filter( sel )
				.map( function () {
					return this._DT_RowIndex;
				} )
				.toArray();
		};
	
		return _selector_run( 'row', selector, run, settings, opts );
	};
	
	
	_api_register( 'rows()', function ( selector, opts ) {
		// argument shifting
		if ( selector === undefined ) {
			selector = '';
		}
		else if ( $.isPlainObject( selector ) ) {
			opts = selector;
			selector = '';
		}
	
		opts = _selector_opts( opts );
	
		var inst = this.iterator( 'table', function ( settings ) {
			return __row_selector( settings, selector, opts );
		}, 1 );
	
		// Want argument shifting here and in __row_selector?
		inst.selector.rows = selector;
		inst.selector.opts = opts;
	
		return inst;
	} );
	
	_api_register( 'rows().nodes()', function () {
		return this.iterator( 'row', function ( settings, row ) {
			return settings.aoData[ row ].nTr || undefined;
		}, 1 );
	} );
	
	_api_register( 'rows().data()', function () {
		return this.iterator( true, 'rows', function ( settings, rows ) {
			return _pluck_order( settings.aoData, rows, '_aData' );
		}, 1 );
	} );
	
	_api_registerPlural( 'rows().cache()', 'row().cache()', function ( type ) {
		return this.iterator( 'row', function ( settings, row ) {
			var r = settings.aoData[ row ];
			return type === 'search' ? r._aFilterData : r._aSortData;
		}, 1 );
	} );
	
	_api_registerPlural( 'rows().invalidate()', 'row().invalidate()', function ( src ) {
		return this.iterator( 'row', function ( settings, row ) {
			_fnInvalidate( settings, row, src );
		} );
	} );
	
	_api_registerPlural( 'rows().indexes()', 'row().index()', function () {
		return this.iterator( 'row', function ( settings, row ) {
			return row;
		}, 1 );
	} );
	
	_api_registerPlural( 'rows().ids()', 'row().id()', function ( hash ) {
		var a = [];
		var context = this.context;
	
		// `iterator` will drop undefined values, but in this case we want them
		for ( var i=0, ien=context.length ; i<ien ; i++ ) {
			for ( var j=0, jen=this[i].length ; j<jen ; j++ ) {
				var id = context[i].rowIdFn( context[i].aoData[ this[i][j] ]._aData );
				a.push( (hash === true ? '#' : '' )+ id );
			}
		}
	
		return new _Api( context, a );
	} );
	
	_api_registerPlural( 'rows().remove()', 'row().remove()', function () {
		var that = this;
	
		this.iterator( 'row', function ( settings, row, thatIdx ) {
			var data = settings.aoData;
			var rowData = data[ row ];
			var i, ien, j, jen;
			var loopRow, loopCells;
	
			data.splice( row, 1 );
	
			// Update the cached indexes
			for ( i=0, ien=data.length ; i<ien ; i++ ) {
				loopRow = data[i];
				loopCells = loopRow.anCells;
	
				// Rows
				if ( loopRow.nTr !== null ) {
					loopRow.nTr._DT_RowIndex = i;
				}
	
				// Cells
				if ( loopCells !== null ) {
					for ( j=0, jen=loopCells.length ; j<jen ; j++ ) {
						loopCells[j]._DT_CellIndex.row = i;
					}
				}
			}
	
			// Delete from the display arrays
			_fnDeleteIndex( settings.aiDisplayMaster, row );
			_fnDeleteIndex( settings.aiDisplay, row );
			_fnDeleteIndex( that[ thatIdx ], row, false ); // maintain local indexes
	
			// For server-side processing tables - subtract the deleted row from the count
			if ( settings._iRecordsDisplay > 0 ) {
				settings._iRecordsDisplay--;
			}
	
			// Check for an 'overflow' they case for displaying the table
			_fnLengthOverflow( settings );
	
			// Remove the row's ID reference if there is one
			var id = settings.rowIdFn( rowData._aData );
			if ( id !== undefined ) {
				delete settings.aIds[ id ];
			}
		} );
	
		this.iterator( 'table', function ( settings ) {
			for ( var i=0, ien=settings.aoData.length ; i<ien ; i++ ) {
				settings.aoData[i].idx = i;
			}
		} );
	
		return this;
	} );
	
	
	_api_register( 'rows.add()', function ( rows ) {
		var newRows = this.iterator( 'table', function ( settings ) {
				var row, i, ien;
				var out = [];
	
				for ( i=0, ien=rows.length ; i<ien ; i++ ) {
					row = rows[i];
	
					if ( row.nodeName && row.nodeName.toUpperCase() === 'TR' ) {
						out.push( _fnAddTr( settings, row )[0] );
					}
					else {
						out.push( _fnAddData( settings, row ) );
					}
				}
	
				return out;
			}, 1 );
	
		// Return an Api.rows() extended instance, so rows().nodes() etc can be used
		var modRows = this.rows( -1 );
		modRows.pop();
		$.merge( modRows, newRows );
	
		return modRows;
	} );
	
	
	
	
	
	/**
	 *
	 */
	_api_register( 'row()', function ( selector, opts ) {
		return _selector_first( this.rows( selector, opts ) );
	} );
	
	
	_api_register( 'row().data()', function ( data ) {
		var ctx = this.context;
	
		if ( data === undefined ) {
			// Get
			return ctx.length && this.length ?
				ctx[0].aoData[ this[0] ]._aData :
				undefined;
		}
	
		// Set
		ctx[0].aoData[ this[0] ]._aData = data;
	
		// Automatically invalidate
		_fnInvalidate( ctx[0], this[0], 'data' );
	
		return this;
	} );
	
	
	_api_register( 'row().node()', function () {
		var ctx = this.context;
	
		return ctx.length && this.length ?
			ctx[0].aoData[ this[0] ].nTr || null :
			null;
	} );
	
	
	_api_register( 'row.add()', function ( row ) {
		// Allow a jQuery object to be passed in - only a single row is added from
		// it though - the first element in the set
		if ( row instanceof $ && row.length ) {
			row = row[0];
		}
	
		var rows = this.iterator( 'table', function ( settings ) {
			if ( row.nodeName && row.nodeName.toUpperCase() === 'TR' ) {
				return _fnAddTr( settings, row )[0];
			}
			return _fnAddData( settings, row );
		} );
	
		// Return an Api.rows() extended instance, with the newly added row selected
		return this.row( rows[0] );
	} );
	
	
	
	var __details_add = function ( ctx, row, data, klass )
	{
		// Convert to array of TR elements
		var rows = [];
		var addRow = function ( r, k ) {
			// Recursion to allow for arrays of jQuery objects
			if ( $.isArray( r ) || r instanceof $ ) {
				for ( var i=0, ien=r.length ; i<ien ; i++ ) {
					addRow( r[i], k );
				}
				return;
			}
	
			// If we get a TR element, then just add it directly - up to the dev
			// to add the correct number of columns etc
			if ( r.nodeName && r.nodeName.toLowerCase() === 'tr' ) {
				rows.push( r );
			}
			else {
				// Otherwise create a row with a wrapper
				var created = $('<tr><td/></tr>').addClass( k );
				$('td', created)
					.addClass( k )
					.html( r )
					[0].colSpan = _fnVisbleColumns( ctx );
	
				rows.push( created[0] );
			}
		};
	
		addRow( data, klass );
	
		if ( row._details ) {
			row._details.detach();
		}
	
		row._details = $(rows);
	
		// If the children were already shown, that state should be retained
		if ( row._detailsShow ) {
			row._details.insertAfter( row.nTr );
		}
	};
	
	
	var __details_remove = function ( api, idx )
	{
		var ctx = api.context;
	
		if ( ctx.length ) {
			var row = ctx[0].aoData[ idx !== undefined ? idx : api[0] ];
	
			if ( row && row._details ) {
				row._details.remove();
	
				row._detailsShow = undefined;
				row._details = undefined;
			}
		}
	};
	
	
	var __details_display = function ( api, show ) {
		var ctx = api.context;
	
		if ( ctx.length && api.length ) {
			var row = ctx[0].aoData[ api[0] ];
	
			if ( row._details ) {
				row._detailsShow = show;
	
				if ( show ) {
					row._details.insertAfter( row.nTr );
				}
				else {
					row._details.detach();
				}
	
				__details_events( ctx[0] );
			}
		}
	};
	
	
	var __details_events = function ( settings )
	{
		var api = new _Api( settings );
		var namespace = '.dt.DT_details';
		var drawEvent = 'draw'+namespace;
		var colvisEvent = 'column-visibility'+namespace;
		var destroyEvent = 'destroy'+namespace;
		var data = settings.aoData;
	
		api.off( drawEvent +' '+ colvisEvent +' '+ destroyEvent );
	
		if ( _pluck( data, '_details' ).length > 0 ) {
			// On each draw, insert the required elements into the document
			api.on( drawEvent, function ( e, ctx ) {
				if ( settings !== ctx ) {
					return;
				}
	
				api.rows( {page:'current'} ).eq(0).each( function (idx) {
					// Internal data grab
					var row = data[ idx ];
	
					if ( row._detailsShow ) {
						row._details.insertAfter( row.nTr );
					}
				} );
			} );
	
			// Column visibility change - update the colspan
			api.on( colvisEvent, function ( e, ctx, idx, vis ) {
				if ( settings !== ctx ) {
					return;
				}
	
				// Update the colspan for the details rows (note, only if it already has
				// a colspan)
				var row, visible = _fnVisbleColumns( ctx );
	
				for ( var i=0, ien=data.length ; i<ien ; i++ ) {
					row = data[i];
	
					if ( row._details ) {
						row._details.children('td[colspan]').attr('colspan', visible );
					}
				}
			} );
	
			// Table destroyed - nuke any child rows
			api.on( destroyEvent, function ( e, ctx ) {
				if ( settings !== ctx ) {
					return;
				}
	
				for ( var i=0, ien=data.length ; i<ien ; i++ ) {
					if ( data[i]._details ) {
						__details_remove( api, i );
					}
				}
			} );
		}
	};
	
	// Strings for the method names to help minification
	var _emp = '';
	var _child_obj = _emp+'row().child';
	var _child_mth = _child_obj+'()';
	
	// data can be:
	//  tr
	//  string
	//  jQuery or array of any of the above
	_api_register( _child_mth, function ( data, klass ) {
		var ctx = this.context;
	
		if ( data === undefined ) {
			// get
			return ctx.length && this.length ?
				ctx[0].aoData[ this[0] ]._details :
				undefined;
		}
		else if ( data === true ) {
			// show
			this.child.show();
		}
		else if ( data === false ) {
			// remove
			__details_remove( this );
		}
		else if ( ctx.length && this.length ) {
			// set
			__details_add( ctx[0], ctx[0].aoData[ this[0] ], data, klass );
		}
	
		return this;
	} );
	
	
	_api_register( [
		_child_obj+'.show()',
		_child_mth+'.show()' // only when `child()` was called with parameters (without
	], function ( show ) {   // it returns an object and this method is not executed)
		__details_display( this, true );
		return this;
	} );
	
	
	_api_register( [
		_child_obj+'.hide()',
		_child_mth+'.hide()' // only when `child()` was called with parameters (without
	], function () {         // it returns an object and this method is not executed)
		__details_display( this, false );
		return this;
	} );
	
	
	_api_register( [
		_child_obj+'.remove()',
		_child_mth+'.remove()' // only when `child()` was called with parameters (without
	], function () {           // it returns an object and this method is not executed)
		__details_remove( this );
		return this;
	} );
	
	
	_api_register( _child_obj+'.isShown()', function () {
		var ctx = this.context;
	
		if ( ctx.length && this.length ) {
			// _detailsShown as false or undefined will fall through to return false
			return ctx[0].aoData[ this[0] ]._detailsShow || false;
		}
		return false;
	} );
	
	
	
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Columns
	 *
	 * {integer}           - column index (>=0 count from left, <0 count from right)
	 * "{integer}:visIdx"  - visible column index (i.e. translate to column index)  (>=0 count from left, <0 count from right)
	 * "{integer}:visible" - alias for {integer}:visIdx  (>=0 count from left, <0 count from right)
	 * "{string}:name"     - column name
	 * "{string}"          - jQuery selector on column header nodes
	 *
	 */
	
	// can be an array of these items, comma separated list, or an array of comma
	// separated lists
	
	var __re_column_selector = /^([^:]+):(name|visIdx|visible)$/;
	
	
	// r1 and r2 are redundant - but it means that the parameters match for the
	// iterator callback in columns().data()
	var __columnData = function ( settings, column, r1, r2, rows ) {
		var a = [];
		for ( var row=0, ien=rows.length ; row<ien ; row++ ) {
			a.push( _fnGetCellData( settings, rows[row], column ) );
		}
		return a;
	};
	
	
	var __column_selector = function ( settings, selector, opts )
	{
		var
			columns = settings.aoColumns,
			names = _pluck( columns, 'sName' ),
			nodes = _pluck( columns, 'nTh' );
	
		var run = function ( s ) {
			var selInt = _intVal( s );
	
			// Selector - all
			if ( s === '' ) {
				return _range( columns.length );
			}
	
			// Selector - index
			if ( selInt !== null ) {
				return [ selInt >= 0 ?
					selInt : // Count from left
					columns.length + selInt // Count from right (+ because its a negative value)
				];
			}
	
			// Selector = function
			if ( typeof s === 'function' ) {
				var rows = _selector_row_indexes( settings, opts );
	
				return $.map( columns, function (col, idx) {
					return s(
							idx,
							__columnData( settings, idx, 0, 0, rows ),
							nodes[ idx ]
						) ? idx : null;
				} );
			}
	
			// jQuery or string selector
			var match = typeof s === 'string' ?
				s.match( __re_column_selector ) :
				'';
	
			if ( match ) {
				switch( match[2] ) {
					case 'visIdx':
					case 'visible':
						var idx = parseInt( match[1], 10 );
						// Visible index given, convert to column index
						if ( idx < 0 ) {
							// Counting from the right
							var visColumns = $.map( columns, function (col,i) {
								return col.bVisible ? i : null;
							} );
							return [ visColumns[ visColumns.length + idx ] ];
						}
						// Counting from the left
						return [ _fnVisibleToColumnIndex( settings, idx ) ];
	
					case 'name':
						// match by name. `names` is column index complete and in order
						return $.map( names, function (name, i) {
							return name === match[1] ? i : null;
						} );
	
					default:
						return [];
				}
			}
	
			// Cell in the table body
			if ( s.nodeName && s._DT_CellIndex ) {
				return [ s._DT_CellIndex.column ];
			}
	
			// jQuery selector on the TH elements for the columns
			var jqResult = $( nodes )
				.filter( s )
				.map( function () {
					return $.inArray( this, nodes ); // `nodes` is column index complete and in order
				} )
				.toArray();
	
			if ( jqResult.length || ! s.nodeName ) {
				return jqResult;
			}
	
			// Otherwise a node which might have a `dt-column` data attribute, or be
			// a child or such an element
			var host = $(s).closest('*[data-dt-column]');
			return host.length ?
				[ host.data('dt-column') ] :
				[];
		};
	
		return _selector_run( 'column', selector, run, settings, opts );
	};
	
	
	var __setColumnVis = function ( settings, column, vis ) {
		var
			cols = settings.aoColumns,
			col  = cols[ column ],
			data = settings.aoData,
			row, cells, i, ien, tr;
	
		// Get
		if ( vis === undefined ) {
			return col.bVisible;
		}
	
		// Set
		// No change
		if ( col.bVisible === vis ) {
			return;
		}
	
		if ( vis ) {
			// Insert column
			// Need to decide if we should use appendChild or insertBefore
			var insertBefore = $.inArray( true, _pluck(cols, 'bVisible'), column+1 );
	
			for ( i=0, ien=data.length ; i<ien ; i++ ) {
				tr = data[i].nTr;
				cells = data[i].anCells;
	
				if ( tr ) {
					// insertBefore can act like appendChild if 2nd arg is null
					tr.insertBefore( cells[ column ], cells[ insertBefore ] || null );
				}
			}
		}
		else {
			// Remove column
			$( _pluck( settings.aoData, 'anCells', column ) ).detach();
		}
	
		// Common actions
		col.bVisible = vis;
		_fnDrawHead( settings, settings.aoHeader );
		_fnDrawHead( settings, settings.aoFooter );
	
		_fnSaveState( settings );
	};
	
	
	_api_register( 'columns()', function ( selector, opts ) {
		// argument shifting
		if ( selector === undefined ) {
			selector = '';
		}
		else if ( $.isPlainObject( selector ) ) {
			opts = selector;
			selector = '';
		}
	
		opts = _selector_opts( opts );
	
		var inst = this.iterator( 'table', function ( settings ) {
			return __column_selector( settings, selector, opts );
		}, 1 );
	
		// Want argument shifting here and in _row_selector?
		inst.selector.cols = selector;
		inst.selector.opts = opts;
	
		return inst;
	} );
	
	_api_registerPlural( 'columns().header()', 'column().header()', function ( selector, opts ) {
		return this.iterator( 'column', function ( settings, column ) {
			return settings.aoColumns[column].nTh;
		}, 1 );
	} );
	
	_api_registerPlural( 'columns().footer()', 'column().footer()', function ( selector, opts ) {
		return this.iterator( 'column', function ( settings, column ) {
			return settings.aoColumns[column].nTf;
		}, 1 );
	} );
	
	_api_registerPlural( 'columns().data()', 'column().data()', function () {
		return this.iterator( 'column-rows', __columnData, 1 );
	} );
	
	_api_registerPlural( 'columns().dataSrc()', 'column().dataSrc()', function () {
		return this.iterator( 'column', function ( settings, column ) {
			return settings.aoColumns[column].mData;
		}, 1 );
	} );
	
	_api_registerPlural( 'columns().cache()', 'column().cache()', function ( type ) {
		return this.iterator( 'column-rows', function ( settings, column, i, j, rows ) {
			return _pluck_order( settings.aoData, rows,
				type === 'search' ? '_aFilterData' : '_aSortData', column
			);
		}, 1 );
	} );
	
	_api_registerPlural( 'columns().nodes()', 'column().nodes()', function () {
		return this.iterator( 'column-rows', function ( settings, column, i, j, rows ) {
			return _pluck_order( settings.aoData, rows, 'anCells', column ) ;
		}, 1 );
	} );
	
	_api_registerPlural( 'columns().visible()', 'column().visible()', function ( vis, calc ) {
		var ret = this.iterator( 'column', function ( settings, column ) {
			if ( vis === undefined ) {
				return settings.aoColumns[ column ].bVisible;
			} // else
			__setColumnVis( settings, column, vis );
		} );
	
		// Group the column visibility changes
		if ( vis !== undefined ) {
			// Second loop once the first is done for events
			this.iterator( 'column', function ( settings, column ) {
				_fnCallbackFire( settings, null, 'column-visibility', [settings, column, vis, calc] );
			} );
	
			if ( calc === undefined || calc ) {
				this.columns.adjust();
			}
		}
	
		return ret;
	} );
	
	_api_registerPlural( 'columns().indexes()', 'column().index()', function ( type ) {
		return this.iterator( 'column', function ( settings, column ) {
			return type === 'visible' ?
				_fnColumnIndexToVisible( settings, column ) :
				column;
		}, 1 );
	} );
	
	_api_register( 'columns.adjust()', function () {
		return this.iterator( 'table', function ( settings ) {
			_fnAdjustColumnSizing( settings );
		}, 1 );
	} );
	
	_api_register( 'column.index()', function ( type, idx ) {
		if ( this.context.length !== 0 ) {
			var ctx = this.context[0];
	
			if ( type === 'fromVisible' || type === 'toData' ) {
				return _fnVisibleToColumnIndex( ctx, idx );
			}
			else if ( type === 'fromData' || type === 'toVisible' ) {
				return _fnColumnIndexToVisible( ctx, idx );
			}
		}
	} );
	
	_api_register( 'column()', function ( selector, opts ) {
		return _selector_first( this.columns( selector, opts ) );
	} );
	
	
	
	var __cell_selector = function ( settings, selector, opts )
	{
		var data = settings.aoData;
		var rows = _selector_row_indexes( settings, opts );
		var cells = _removeEmpty( _pluck_order( data, rows, 'anCells' ) );
		var allCells = $( [].concat.apply([], cells) );
		var row;
		var columns = settings.aoColumns.length;
		var a, i, ien, j, o, host;
	
		var run = function ( s ) {
			var fnSelector = typeof s === 'function';
	
			if ( s === null || s === undefined || fnSelector ) {
				// All cells and function selectors
				a = [];
	
				for ( i=0, ien=rows.length ; i<ien ; i++ ) {
					row = rows[i];
	
					for ( j=0 ; j<columns ; j++ ) {
						o = {
							row: row,
							column: j
						};
	
						if ( fnSelector ) {
							// Selector - function
							host = data[ row ];
	
							if ( s( o, _fnGetCellData(settings, row, j), host.anCells ? host.anCells[j] : null ) ) {
								a.push( o );
							}
						}
						else {
							// Selector - all
							a.push( o );
						}
					}
				}
	
				return a;
			}
			
			// Selector - index
			if ( $.isPlainObject( s ) ) {
				return [s];
			}
	
			// Selector - jQuery filtered cells
			var jqResult = allCells
				.filter( s )
				.map( function (i, el) {
					return { // use a new object, in case someone changes the values
						row:    el._DT_CellIndex.row,
						column: el._DT_CellIndex.column
	 				};
				} )
				.toArray();
	
			if ( jqResult.length || ! s.nodeName ) {
				return jqResult;
			}
	
			// Otherwise the selector is a node, and there is one last option - the
			// element might be a child of an element which has dt-row and dt-column
			// data attributes
			host = $(s).closest('*[data-dt-row]');
			return host.length ?
				[ {
					row: host.data('dt-row'),
					column: host.data('dt-column')
				} ] :
				[];
		};
	
		return _selector_run( 'cell', selector, run, settings, opts );
	};
	
	
	
	
	_api_register( 'cells()', function ( rowSelector, columnSelector, opts ) {
		// Argument shifting
		if ( $.isPlainObject( rowSelector ) ) {
			// Indexes
			if ( rowSelector.row === undefined ) {
				// Selector options in first parameter
				opts = rowSelector;
				rowSelector = null;
			}
			else {
				// Cell index objects in first parameter
				opts = columnSelector;
				columnSelector = null;
			}
		}
		if ( $.isPlainObject( columnSelector ) ) {
			opts = columnSelector;
			columnSelector = null;
		}
	
		// Cell selector
		if ( columnSelector === null || columnSelector === undefined ) {
			return this.iterator( 'table', function ( settings ) {
				return __cell_selector( settings, rowSelector, _selector_opts( opts ) );
			} );
		}
	
		// Row + column selector
		var columns = this.columns( columnSelector, opts );
		var rows = this.rows( rowSelector, opts );
		var a, i, ien, j, jen;
	
		var cells = this.iterator( 'table', function ( settings, idx ) {
			a = [];
	
			for ( i=0, ien=rows[idx].length ; i<ien ; i++ ) {
				for ( j=0, jen=columns[idx].length ; j<jen ; j++ ) {
					a.push( {
						row:    rows[idx][i],
						column: columns[idx][j]
					} );
				}
			}
	
			return a;
		}, 1 );
	
		$.extend( cells.selector, {
			cols: columnSelector,
			rows: rowSelector,
			opts: opts
		} );
	
		return cells;
	} );
	
	
	_api_registerPlural( 'cells().nodes()', 'cell().node()', function () {
		return this.iterator( 'cell', function ( settings, row, column ) {
			var data = settings.aoData[ row ];
	
			return data && data.anCells ?
				data.anCells[ column ] :
				undefined;
		}, 1 );
	} );
	
	
	_api_register( 'cells().data()', function () {
		return this.iterator( 'cell', function ( settings, row, column ) {
			return _fnGetCellData( settings, row, column );
		}, 1 );
	} );
	
	
	_api_registerPlural( 'cells().cache()', 'cell().cache()', function ( type ) {
		type = type === 'search' ? '_aFilterData' : '_aSortData';
	
		return this.iterator( 'cell', function ( settings, row, column ) {
			return settings.aoData[ row ][ type ][ column ];
		}, 1 );
	} );
	
	
	_api_registerPlural( 'cells().render()', 'cell().render()', function ( type ) {
		return this.iterator( 'cell', function ( settings, row, column ) {
			return _fnGetCellData( settings, row, column, type );
		}, 1 );
	} );
	
	
	_api_registerPlural( 'cells().indexes()', 'cell().index()', function () {
		return this.iterator( 'cell', function ( settings, row, column ) {
			return {
				row: row,
				column: column,
				columnVisible: _fnColumnIndexToVisible( settings, column )
			};
		}, 1 );
	} );
	
	
	_api_registerPlural( 'cells().invalidate()', 'cell().invalidate()', function ( src ) {
		return this.iterator( 'cell', function ( settings, row, column ) {
			_fnInvalidate( settings, row, src, column );
		} );
	} );
	
	
	
	_api_register( 'cell()', function ( rowSelector, columnSelector, opts ) {
		return _selector_first( this.cells( rowSelector, columnSelector, opts ) );
	} );
	
	
	_api_register( 'cell().data()', function ( data ) {
		var ctx = this.context;
		var cell = this[0];
	
		if ( data === undefined ) {
			// Get
			return ctx.length && cell.length ?
				_fnGetCellData( ctx[0], cell[0].row, cell[0].column ) :
				undefined;
		}
	
		// Set
		_fnSetCellData( ctx[0], cell[0].row, cell[0].column, data );
		_fnInvalidate( ctx[0], cell[0].row, 'data', cell[0].column );
	
		return this;
	} );
	
	
	
	/**
	 * Get current ordering (sorting) that has been applied to the table.
	 *
	 * @returns {array} 2D array containing the sorting information for the first
	 *   table in the current context. Each element in the parent array represents
	 *   a column being sorted upon (i.e. multi-sorting with two columns would have
	 *   2 inner arrays). The inner arrays may have 2 or 3 elements. The first is
	 *   the column index that the sorting condition applies to, the second is the
	 *   direction of the sort (`desc` or `asc`) and, optionally, the third is the
	 *   index of the sorting order from the `column.sorting` initialisation array.
	 *//**
	 * Set the ordering for the table.
	 *
	 * @param {integer} order Column index to sort upon.
	 * @param {string} direction Direction of the sort to be applied (`asc` or `desc`)
	 * @returns {DataTables.Api} this
	 *//**
	 * Set the ordering for the table.
	 *
	 * @param {array} order 1D array of sorting information to be applied.
	 * @param {array} [...] Optional additional sorting conditions
	 * @returns {DataTables.Api} this
	 *//**
	 * Set the ordering for the table.
	 *
	 * @param {array} order 2D array of sorting information to be applied.
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'order()', function ( order, dir ) {
		var ctx = this.context;
	
		if ( order === undefined ) {
			// get
			return ctx.length !== 0 ?
				ctx[0].aaSorting :
				undefined;
		}
	
		// set
		if ( typeof order === 'number' ) {
			// Simple column / direction passed in
			order = [ [ order, dir ] ];
		}
		else if ( order.length && ! $.isArray( order[0] ) ) {
			// Arguments passed in (list of 1D arrays)
			order = Array.prototype.slice.call( arguments );
		}
		// otherwise a 2D array was passed in
	
		return this.iterator( 'table', function ( settings ) {
			settings.aaSorting = order.slice();
		} );
	} );
	
	
	/**
	 * Attach a sort listener to an element for a given column
	 *
	 * @param {node|jQuery|string} node Identifier for the element(s) to attach the
	 *   listener to. This can take the form of a single DOM node, a jQuery
	 *   collection of nodes or a jQuery selector which will identify the node(s).
	 * @param {integer} column the column that a click on this node will sort on
	 * @param {function} [callback] callback function when sort is run
	 * @returns {DataTables.Api} this
	 */
	_api_register( 'order.listener()', function ( node, column, callback ) {
		return this.iterator( 'table', function ( settings ) {
			_fnSortAttachListener( settings, node, column, callback );
		} );
	} );
	
	
	_api_register( 'order.fixed()', function ( set ) {
		if ( ! set ) {
			var ctx = this.context;
			var fixed = ctx.length ?
				ctx[0].aaSortingFixed :
				undefined;
	
			return $.isArray( fixed ) ?
				{ pre: fixed } :
				fixed;
		}
	
		return this.iterator( 'table', function ( settings ) {
			settings.aaSortingFixed = $.extend( true, {}, set );
		} );
	} );
	
	
	// Order by the selected column(s)
	_api_register( [
		'columns().order()',
		'column().order()'
	], function ( dir ) {
		var that = this;
	
		return this.iterator( 'table', function ( settings, i ) {
			var sort = [];
	
			$.each( that[i], function (j, col) {
				sort.push( [ col, dir ] );
			} );
	
			settings.aaSorting = sort;
		} );
	} );
	
	
	
	_api_register( 'search()', function ( input, regex, smart, caseInsen ) {
		var ctx = this.context;
	
		if ( input === undefined ) {
			// get
			return ctx.length !== 0 ?
				ctx[0].oPreviousSearch.sSearch :
				undefined;
		}
	
		// set
		return this.iterator( 'table', function ( settings ) {
			if ( ! settings.oFeatures.bFilter ) {
				return;
			}
	
			_fnFilterComplete( settings, $.extend( {}, settings.oPreviousSearch, {
				"sSearch": input+"",
				"bRegex":  regex === null ? false : regex,
				"bSmart":  smart === null ? true  : smart,
				"bCaseInsensitive": caseInsen === null ? true : caseInsen
			} ), 1 );
		} );
	} );
	
	
	_api_registerPlural(
		'columns().search()',
		'column().search()',
		function ( input, regex, smart, caseInsen ) {
			return this.iterator( 'column', function ( settings, column ) {
				var preSearch = settings.aoPreSearchCols;
	
				if ( input === undefined ) {
					// get
					return preSearch[ column ].sSearch;
				}
	
				// set
				if ( ! settings.oFeatures.bFilter ) {
					return;
				}
	
				$.extend( preSearch[ column ], {
					"sSearch": input+"",
					"bRegex":  regex === null ? false : regex,
					"bSmart":  smart === null ? true  : smart,
					"bCaseInsensitive": caseInsen === null ? true : caseInsen
				} );
	
				_fnFilterComplete( settings, settings.oPreviousSearch, 1 );
			} );
		}
	);
	
	/*
	 * State API methods
	 */
	
	_api_register( 'state()', function () {
		return this.context.length ?
			this.context[0].oSavedState :
			null;
	} );
	
	
	_api_register( 'state.clear()', function () {
		return this.iterator( 'table', function ( settings ) {
			// Save an empty object
			settings.fnStateSaveCallback.call( settings.oInstance, settings, {} );
		} );
	} );
	
	
	_api_register( 'state.loaded()', function () {
		return this.context.length ?
			this.context[0].oLoadedState :
			null;
	} );
	
	
	_api_register( 'state.save()', function () {
		return this.iterator( 'table', function ( settings ) {
			_fnSaveState( settings );
		} );
	} );
	
	
	
	/**
	 * Provide a common method for plug-ins to check the version of DataTables being
	 * used, in order to ensure compatibility.
	 *
	 *  @param {string} version Version string to check for, in the format "X.Y.Z".
	 *    Note that the formats "X" and "X.Y" are also acceptable.
	 *  @returns {boolean} true if this version of DataTables is greater or equal to
	 *    the required version, or false if this version of DataTales is not
	 *    suitable
	 *  @static
	 *  @dtopt API-Static
	 *
	 *  @example
	 *    alert( $.fn.dataTable.versionCheck( '1.9.0' ) );
	 */
	DataTable.versionCheck = DataTable.fnVersionCheck = function( version )
	{
		var aThis = DataTable.version.split('.');
		var aThat = version.split('.');
		var iThis, iThat;
	
		for ( var i=0, iLen=aThat.length ; i<iLen ; i++ ) {
			iThis = parseInt( aThis[i], 10 ) || 0;
			iThat = parseInt( aThat[i], 10 ) || 0;
	
			// Parts are the same, keep comparing
			if (iThis === iThat) {
				continue;
			}
	
			// Parts are different, return immediately
			return iThis > iThat;
		}
	
		return true;
	};
	
	
	/**
	 * Check if a `<table>` node is a DataTable table already or not.
	 *
	 *  @param {node|jquery|string} table Table node, jQuery object or jQuery
	 *      selector for the table to test. Note that if more than more than one
	 *      table is passed on, only the first will be checked
	 *  @returns {boolean} true the table given is a DataTable, or false otherwise
	 *  @static
	 *  @dtopt API-Static
	 *
	 *  @example
	 *    if ( ! $.fn.DataTable.isDataTable( '#example' ) ) {
	 *      $('#example').dataTable();
	 *    }
	 */
	DataTable.isDataTable = DataTable.fnIsDataTable = function ( table )
	{
		var t = $(table).get(0);
		var is = false;
	
		if ( table instanceof DataTable.Api ) {
			return true;
		}
	
		$.each( DataTable.settings, function (i, o) {
			var head = o.nScrollHead ? $('table', o.nScrollHead)[0] : null;
			var foot = o.nScrollFoot ? $('table', o.nScrollFoot)[0] : null;
	
			if ( o.nTable === t || head === t || foot === t ) {
				is = true;
			}
		} );
	
		return is;
	};
	
	
	/**
	 * Get all DataTable tables that have been initialised - optionally you can
	 * select to get only currently visible tables.
	 *
	 *  @param {boolean} [visible=false] Flag to indicate if you want all (default)
	 *    or visible tables only.
	 *  @returns {array} Array of `table` nodes (not DataTable instances) which are
	 *    DataTables
	 *  @static
	 *  @dtopt API-Static
	 *
	 *  @example
	 *    $.each( $.fn.dataTable.tables(true), function () {
	 *      $(table).DataTable().columns.adjust();
	 *    } );
	 */
	DataTable.tables = DataTable.fnTables = function ( visible )
	{
		var api = false;
	
		if ( $.isPlainObject( visible ) ) {
			api = visible.api;
			visible = visible.visible;
		}
	
		var a = $.map( DataTable.settings, function (o) {
			if ( !visible || (visible && $(o.nTable).is(':visible')) ) {
				return o.nTable;
			}
		} );
	
		return api ?
			new _Api( a ) :
			a;
	};
	
	
	/**
	 * Convert from camel case parameters to Hungarian notation. This is made public
	 * for the extensions to provide the same ability as DataTables core to accept
	 * either the 1.9 style Hungarian notation, or the 1.10+ style camelCase
	 * parameters.
	 *
	 *  @param {object} src The model object which holds all parameters that can be
	 *    mapped.
	 *  @param {object} user The object to convert from camel case to Hungarian.
	 *  @param {boolean} force When set to `true`, properties which already have a
	 *    Hungarian value in the `user` object will be overwritten. Otherwise they
	 *    won't be.
	 */
	DataTable.camelToHungarian = _fnCamelToHungarian;
	
	
	
	/**
	 *
	 */
	_api_register( '$()', function ( selector, opts ) {
		var
			rows   = this.rows( opts ).nodes(), // Get all rows
			jqRows = $(rows);
	
		return $( [].concat(
			jqRows.filter( selector ).toArray(),
			jqRows.find( selector ).toArray()
		) );
	} );
	
	
	// jQuery functions to operate on the tables
	$.each( [ 'on', 'one', 'off' ], function (i, key) {
		_api_register( key+'()', function ( /* event, handler */ ) {
			var args = Array.prototype.slice.call(arguments);
	
			// Add the `dt` namespace automatically if it isn't already present
			args[0] = $.map( args[0].split( /\s/ ), function ( e ) {
				return ! e.match(/\.dt\b/) ?
					e+'.dt' :
					e;
				} ).join( ' ' );
	
			var inst = $( this.tables().nodes() );
			inst[key].apply( inst, args );
			return this;
		} );
	} );
	
	
	_api_register( 'clear()', function () {
		return this.iterator( 'table', function ( settings ) {
			_fnClearTable( settings );
		} );
	} );
	
	
	_api_register( 'settings()', function () {
		return new _Api( this.context, this.context );
	} );
	
	
	_api_register( 'init()', function () {
		var ctx = this.context;
		return ctx.length ? ctx[0].oInit : null;
	} );
	
	
	_api_register( 'data()', function () {
		return this.iterator( 'table', function ( settings ) {
			return _pluck( settings.aoData, '_aData' );
		} ).flatten();
	} );
	
	
	_api_register( 'destroy()', function ( remove ) {
		remove = remove || false;
	
		return this.iterator( 'table', function ( settings ) {
			var orig      = settings.nTableWrapper.parentNode;
			var classes   = settings.oClasses;
			var table     = settings.nTable;
			var tbody     = settings.nTBody;
			var thead     = settings.nTHead;
			var tfoot     = settings.nTFoot;
			var jqTable   = $(table);
			var jqTbody   = $(tbody);
			var jqWrapper = $(settings.nTableWrapper);
			var rows      = $.map( settings.aoData, function (r) { return r.nTr; } );
			var i, ien;
	
			// Flag to note that the table is currently being destroyed - no action
			// should be taken
			settings.bDestroying = true;
	
			// Fire off the destroy callbacks for plug-ins etc
			_fnCallbackFire( settings, "aoDestroyCallback", "destroy", [settings] );
	
			// If not being removed from the document, make all columns visible
			if ( ! remove ) {
				new _Api( settings ).columns().visible( true );
			}
	
			// Blitz all `DT` namespaced events (these are internal events, the
			// lowercase, `dt` events are user subscribed and they are responsible
			// for removing them
			jqWrapper.off('.DT').find(':not(tbody *)').off('.DT');
			$(window).off('.DT-'+settings.sInstance);
	
			// When scrolling we had to break the table up - restore it
			if ( table != thead.parentNode ) {
				jqTable.children('thead').detach();
				jqTable.append( thead );
			}
	
			if ( tfoot && table != tfoot.parentNode ) {
				jqTable.children('tfoot').detach();
				jqTable.append( tfoot );
			}
	
			settings.aaSorting = [];
			settings.aaSortingFixed = [];
			_fnSortingClasses( settings );
	
			$( rows ).removeClass( settings.asStripeClasses.join(' ') );
	
			$('th, td', thead).removeClass( classes.sSortable+' '+
				classes.sSortableAsc+' '+classes.sSortableDesc+' '+classes.sSortableNone
			);
	
			// Add the TR elements back into the table in their original order
			jqTbody.children().detach();
			jqTbody.append( rows );
	
			// Remove the DataTables generated nodes, events and classes
			var removedMethod = remove ? 'remove' : 'detach';
			jqTable[ removedMethod ]();
			jqWrapper[ removedMethod ]();
	
			// If we need to reattach the table to the document
			if ( ! remove && orig ) {
				// insertBefore acts like appendChild if !arg[1]
				orig.insertBefore( table, settings.nTableReinsertBefore );
	
				// Restore the width of the original table - was read from the style property,
				// so we can restore directly to that
				jqTable
					.css( 'width', settings.sDestroyWidth )
					.removeClass( classes.sTable );
	
				// If the were originally stripe classes - then we add them back here.
				// Note this is not fool proof (for example if not all rows had stripe
				// classes - but it's a good effort without getting carried away
				ien = settings.asDestroyStripes.length;
	
				if ( ien ) {
					jqTbody.children().each( function (i) {
						$(this).addClass( settings.asDestroyStripes[i % ien] );
					} );
				}
			}
	
			/* Remove the settings object from the settings array */
			var idx = $.inArray( settings, DataTable.settings );
			if ( idx !== -1 ) {
				DataTable.settings.splice( idx, 1 );
			}
		} );
	} );
	
	
	// Add the `every()` method for rows, columns and cells in a compact form
	$.each( [ 'column', 'row', 'cell' ], function ( i, type ) {
		_api_register( type+'s().every()', function ( fn ) {
			var opts = this.selector.opts;
			var api = this;
	
			return this.iterator( type, function ( settings, arg1, arg2, arg3, arg4 ) {
				// Rows and columns:
				//  arg1 - index
				//  arg2 - table counter
				//  arg3 - loop counter
				//  arg4 - undefined
				// Cells:
				//  arg1 - row index
				//  arg2 - column index
				//  arg3 - table counter
				//  arg4 - loop counter
				fn.call(
					api[ type ](
						arg1,
						type==='cell' ? arg2 : opts,
						type==='cell' ? opts : undefined
					),
					arg1, arg2, arg3, arg4
				);
			} );
		} );
	} );
	
	
	// i18n method for extensions to be able to use the language object from the
	// DataTable
	_api_register( 'i18n()', function ( token, def, plural ) {
		var ctx = this.context[0];
		var resolved = _fnGetObjectDataFn( token )( ctx.oLanguage );
	
		if ( resolved === undefined ) {
			resolved = def;
		}
	
		if ( plural !== undefined && $.isPlainObject( resolved ) ) {
			resolved = resolved[ plural ] !== undefined ?
				resolved[ plural ] :
				resolved._;
		}
	
		return resolved.replace( '%d', plural ); // nb: plural might be undefined,
	} );

	/**
	 * Version string for plug-ins to check compatibility. Allowed format is
	 * `a.b.c-d` where: a:int, b:int, c:int, d:string(dev|beta|alpha). `d` is used
	 * only for non-release builds. See http://semver.org/ for more information.
	 *  @member
	 *  @type string
	 *  @default Version number
	 */
	DataTable.version = "1.10.16";

	/**
	 * Private data store, containing all of the settings objects that are
	 * created for the tables on a given page.
	 *
	 * Note that the `DataTable.settings` object is aliased to
	 * `jQuery.fn.dataTableExt` through which it may be accessed and
	 * manipulated, or `jQuery.fn.dataTable.settings`.
	 *  @member
	 *  @type array
	 *  @default []
	 *  @private
	 */
	DataTable.settings = [];

	/**
	 * Object models container, for the various models that DataTables has
	 * available to it. These models define the objects that are used to hold
	 * the active state and configuration of the table.
	 *  @namespace
	 */
	DataTable.models = {};
	
	
	
	/**
	 * Template object for the way in which DataTables holds information about
	 * search information for the global filter and individual column filters.
	 *  @namespace
	 */
	DataTable.models.oSearch = {
		/**
		 * Flag to indicate if the filtering should be case insensitive or not
		 *  @type boolean
		 *  @default true
		 */
		"bCaseInsensitive": true,
	
		/**
		 * Applied search term
		 *  @type string
		 *  @default <i>Empty string</i>
		 */
		"sSearch": "",
	
		/**
		 * Flag to indicate if the search term should be interpreted as a
		 * regular expression (true) or not (false) and therefore and special
		 * regex characters escaped.
		 *  @type boolean
		 *  @default false
		 */
		"bRegex": false,
	
		/**
		 * Flag to indicate if DataTables is to use its smart filtering or not.
		 *  @type boolean
		 *  @default true
		 */
		"bSmart": true
	};
	
	
	
	
	/**
	 * Template object for the way in which DataTables holds information about
	 * each individual row. This is the object format used for the settings
	 * aoData array.
	 *  @namespace
	 */
	DataTable.models.oRow = {
		/**
		 * TR element for the row
		 *  @type node
		 *  @default null
		 */
		"nTr": null,
	
		/**
		 * Array of TD elements for each row. This is null until the row has been
		 * created.
		 *  @type array nodes
		 *  @default []
		 */
		"anCells": null,
	
		/**
		 * Data object from the original data source for the row. This is either
		 * an array if using the traditional form of DataTables, or an object if
		 * using mData options. The exact type will depend on the passed in
		 * data from the data source, or will be an array if using DOM a data
		 * source.
		 *  @type array|object
		 *  @default []
		 */
		"_aData": [],
	
		/**
		 * Sorting data cache - this array is ostensibly the same length as the
		 * number of columns (although each index is generated only as it is
		 * needed), and holds the data that is used for sorting each column in the
		 * row. We do this cache generation at the start of the sort in order that
		 * the formatting of the sort data need be done only once for each cell
		 * per sort. This array should not be read from or written to by anything
		 * other than the master sorting methods.
		 *  @type array
		 *  @default null
		 *  @private
		 */
		"_aSortData": null,
	
		/**
		 * Per cell filtering data cache. As per the sort data cache, used to
		 * increase the performance of the filtering in DataTables
		 *  @type array
		 *  @default null
		 *  @private
		 */
		"_aFilterData": null,
	
		/**
		 * Filtering data cache. This is the same as the cell filtering cache, but
		 * in this case a string rather than an array. This is easily computed with
		 * a join on `_aFilterData`, but is provided as a cache so the join isn't
		 * needed on every search (memory traded for performance)
		 *  @type array
		 *  @default null
		 *  @private
		 */
		"_sFilterRow": null,
	
		/**
		 * Cache of the class name that DataTables has applied to the row, so we
		 * can quickly look at this variable rather than needing to do a DOM check
		 * on className for the nTr property.
		 *  @type string
		 *  @default <i>Empty string</i>
		 *  @private
		 */
		"_sRowStripe": "",
	
		/**
		 * Denote if the original data source was from the DOM, or the data source
		 * object. This is used for invalidating data, so DataTables can
		 * automatically read data from the original source, unless uninstructed
		 * otherwise.
		 *  @type string
		 *  @default null
		 *  @private
		 */
		"src": null,
	
		/**
		 * Index in the aoData array. This saves an indexOf lookup when we have the
		 * object, but want to know the index
		 *  @type integer
		 *  @default -1
		 *  @private
		 */
		"idx": -1
	};
	
	
	/**
	 * Template object for the column information object in DataTables. This object
	 * is held in the settings aoColumns array and contains all the information that
	 * DataTables needs about each individual column.
	 *
	 * Note that this object is related to {@link DataTable.defaults.column}
	 * but this one is the internal data store for DataTables's cache of columns.
	 * It should NOT be manipulated outside of DataTables. Any configuration should
	 * be done through the initialisation options.
	 *  @namespace
	 */
	DataTable.models.oColumn = {
		/**
		 * Column index. This could be worked out on-the-fly with $.inArray, but it
		 * is faster to just hold it as a variable
		 *  @type integer
		 *  @default null
		 */
		"idx": null,
	
		/**
		 * A list of the columns that sorting should occur on when this column
		 * is sorted. That this property is an array allows multi-column sorting
		 * to be defined for a column (for example first name / last name columns
		 * would benefit from this). The values are integers pointing to the
		 * columns to be sorted on (typically it will be a single integer pointing
		 * at itself, but that doesn't need to be the case).
		 *  @type array
		 */
		"aDataSort": null,
	
		/**
		 * Define the sorting directions that are applied to the column, in sequence
		 * as the column is repeatedly sorted upon - i.e. the first value is used
		 * as the sorting direction when the column if first sorted (clicked on).
		 * Sort it again (click again) and it will move on to the next index.
		 * Repeat until loop.
		 *  @type array
		 */
		"asSorting": null,
	
		/**
		 * Flag to indicate if the column is searchable, and thus should be included
		 * in the filtering or not.
		 *  @type boolean
		 */
		"bSearchable": null,
	
		/**
		 * Flag to indicate if the column is sortable or not.
		 *  @type boolean
		 */
		"bSortable": null,
	
		/**
		 * Flag to indicate if the column is currently visible in the table or not
		 *  @type boolean
		 */
		"bVisible": null,
	
		/**
		 * Store for manual type assignment using the `column.type` option. This
		 * is held in store so we can manipulate the column's `sType` property.
		 *  @type string
		 *  @default null
		 *  @private
		 */
		"_sManualType": null,
	
		/**
		 * Flag to indicate if HTML5 data attributes should be used as the data
		 * source for filtering or sorting. True is either are.
		 *  @type boolean
		 *  @default false
		 *  @private
		 */
		"_bAttrSrc": false,
	
		/**
		 * Developer definable function that is called whenever a cell is created (Ajax source,
		 * etc) or processed for input (DOM source). This can be used as a compliment to mRender
		 * allowing you to modify the DOM element (add background colour for example) when the
		 * element is available.
		 *  @type function
		 *  @param {element} nTd The TD node that has been created
		 *  @param {*} sData The Data for the cell
		 *  @param {array|object} oData The data for the whole row
		 *  @param {int} iRow The row index for the aoData data store
		 *  @default null
		 */
		"fnCreatedCell": null,
	
		/**
		 * Function to get data from a cell in a column. You should <b>never</b>
		 * access data directly through _aData internally in DataTables - always use
		 * the method attached to this property. It allows mData to function as
		 * required. This function is automatically assigned by the column
		 * initialisation method
		 *  @type function
		 *  @param {array|object} oData The data array/object for the array
		 *    (i.e. aoData[]._aData)
		 *  @param {string} sSpecific The specific data type you want to get -
		 *    'display', 'type' 'filter' 'sort'
		 *  @returns {*} The data for the cell from the given row's data
		 *  @default null
		 */
		"fnGetData": null,
	
		/**
		 * Function to set data for a cell in the column. You should <b>never</b>
		 * set the data directly to _aData internally in DataTables - always use
		 * this method. It allows mData to function as required. This function
		 * is automatically assigned by the column initialisation method
		 *  @type function
		 *  @param {array|object} oData The data array/object for the array
		 *    (i.e. aoData[]._aData)
		 *  @param {*} sValue Value to set
		 *  @default null
		 */
		"fnSetData": null,
	
		/**
		 * Property to read the value for the cells in the column from the data
		 * source array / object. If null, then the default content is used, if a
		 * function is given then the return from the function is used.
		 *  @type function|int|string|null
		 *  @default null
		 */
		"mData": null,
	
		/**
		 * Partner property to mData which is used (only when defined) to get
		 * the data - i.e. it is basically the same as mData, but without the
		 * 'set' option, and also the data fed to it is the result from mData.
		 * This is the rendering method to match the data method of mData.
		 *  @type function|int|string|null
		 *  @default null
		 */
		"mRender": null,
	
		/**
		 * Unique header TH/TD element for this column - this is what the sorting
		 * listener is attached to (if sorting is enabled.)
		 *  @type node
		 *  @default null
		 */
		"nTh": null,
	
		/**
		 * Unique footer TH/TD element for this column (if there is one). Not used
		 * in DataTables as such, but can be used for plug-ins to reference the
		 * footer for each column.
		 *  @type node
		 *  @default null
		 */
		"nTf": null,
	
		/**
		 * The class to apply to all TD elements in the table's TBODY for the column
		 *  @type string
		 *  @default null
		 */
		"sClass": null,
	
		/**
		 * When DataTables calculates the column widths to assign to each column,
		 * it finds the longest string in each column and then constructs a
		 * temporary table and reads the widths from that. The problem with this
		 * is that "mmm" is much wider then "iiii", but the latter is a longer
		 * string - thus the calculation can go wrong (doing it properly and putting
		 * it into an DOM object and measuring that is horribly(!) slow). Thus as
		 * a "work around" we provide this option. It will append its value to the
		 * text that is found to be the longest string for the column - i.e. padding.
		 *  @type string
		 */
		"sContentPadding": null,
	
		/**
		 * Allows a default value to be given for a column's data, and will be used
		 * whenever a null data source is encountered (this can be because mData
		 * is set to null, or because the data source itself is null).
		 *  @type string
		 *  @default null
		 */
		"sDefaultContent": null,
	
		/**
		 * Name for the column, allowing reference to the column by name as well as
		 * by index (needs a lookup to work by name).
		 *  @type string
		 */
		"sName": null,
	
		/**
		 * Custom sorting data type - defines which of the available plug-ins in
		 * afnSortData the custom sorting will use - if any is defined.
		 *  @type string
		 *  @default std
		 */
		"sSortDataType": 'std',
	
		/**
		 * Class to be applied to the header element when sorting on this column
		 *  @type string
		 *  @default null
		 */
		"sSortingClass": null,
	
		/**
		 * Class to be applied to the header element when sorting on this column -
		 * when jQuery UI theming is used.
		 *  @type string
		 *  @default null
		 */
		"sSortingClassJUI": null,
	
		/**
		 * Title of the column - what is seen in the TH element (nTh).
		 *  @type string
		 */
		"sTitle": null,
	
		/**
		 * Column sorting and filtering type
		 *  @type string
		 *  @default null
		 */
		"sType": null,
	
		/**
		 * Width of the column
		 *  @type string
		 *  @default null
		 */
		"sWidth": null,
	
		/**
		 * Width of the column when it was first "encountered"
		 *  @type string
		 *  @default null
		 */
		"sWidthOrig": null
	};
	
	
	/*
	 * Developer note: The properties of the object below are given in Hungarian
	 * notation, that was used as the interface for DataTables prior to v1.10, however
	 * from v1.10 onwards the primary interface is camel case. In order to avoid
	 * breaking backwards compatibility utterly with this change, the Hungarian
	 * version is still, internally the primary interface, but is is not documented
	 * - hence the @name tags in each doc comment. This allows a Javascript function
	 * to create a map from Hungarian notation to camel case (going the other direction
	 * would require each property to be listed, which would at around 3K to the size
	 * of DataTables, while this method is about a 0.5K hit.
	 *
	 * Ultimately this does pave the way for Hungarian notation to be dropped
	 * completely, but that is a massive amount of work and will break current
	 * installs (therefore is on-hold until v2).
	 */
	
	/**
	 * Initialisation options that can be given to DataTables at initialisation
	 * time.
	 *  @namespace
	 */
	DataTable.defaults = {
		/**
		 * An array of data to use for the table, passed in at initialisation which
		 * will be used in preference to any data which is already in the DOM. This is
		 * particularly useful for constructing tables purely in Javascript, for
		 * example with a custom Ajax call.
		 *  @type array
		 *  @default null
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.data
		 *
		 *  @example
		 *    // Using a 2D array data source
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "data": [
		 *          ['Trident', 'Internet Explorer 4.0', 'Win 95+', 4, 'X'],
		 *          ['Trident', 'Internet Explorer 5.0', 'Win 95+', 5, 'C'],
		 *        ],
		 *        "columns": [
		 *          { "title": "Engine" },
		 *          { "title": "Browser" },
		 *          { "title": "Platform" },
		 *          { "title": "Version" },
		 *          { "title": "Grade" }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using an array of objects as a data source (`data`)
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "data": [
		 *          {
		 *            "engine":   "Trident",
		 *            "browser":  "Internet Explorer 4.0",
		 *            "platform": "Win 95+",
		 *            "version":  4,
		 *            "grade":    "X"
		 *          },
		 *          {
		 *            "engine":   "Trident",
		 *            "browser":  "Internet Explorer 5.0",
		 *            "platform": "Win 95+",
		 *            "version":  5,
		 *            "grade":    "C"
		 *          }
		 *        ],
		 *        "columns": [
		 *          { "title": "Engine",   "data": "engine" },
		 *          { "title": "Browser",  "data": "browser" },
		 *          { "title": "Platform", "data": "platform" },
		 *          { "title": "Version",  "data": "version" },
		 *          { "title": "Grade",    "data": "grade" }
		 *        ]
		 *      } );
		 *    } );
		 */
		"aaData": null,
	
	
		/**
		 * If ordering is enabled, then DataTables will perform a first pass sort on
		 * initialisation. You can define which column(s) the sort is performed
		 * upon, and the sorting direction, with this variable. The `sorting` array
		 * should contain an array for each column to be sorted initially containing
		 * the column's index and a direction string ('asc' or 'desc').
		 *  @type array
		 *  @default [[0,'asc']]
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.order
		 *
		 *  @example
		 *    // Sort by 3rd column first, and then 4th column
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "order": [[2,'asc'], [3,'desc']]
		 *      } );
		 *    } );
		 *
		 *    // No initial sorting
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "order": []
		 *      } );
		 *    } );
		 */
		"aaSorting": [[0,'asc']],
	
	
		/**
		 * This parameter is basically identical to the `sorting` parameter, but
		 * cannot be overridden by user interaction with the table. What this means
		 * is that you could have a column (visible or hidden) which the sorting
		 * will always be forced on first - any sorting after that (from the user)
		 * will then be performed as required. This can be useful for grouping rows
		 * together.
		 *  @type array
		 *  @default null
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.orderFixed
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "orderFixed": [[0,'asc']]
		 *      } );
		 *    } )
		 */
		"aaSortingFixed": [],
	
	
		/**
		 * DataTables can be instructed to load data to display in the table from a
		 * Ajax source. This option defines how that Ajax call is made and where to.
		 *
		 * The `ajax` property has three different modes of operation, depending on
		 * how it is defined. These are:
		 *
		 * * `string` - Set the URL from where the data should be loaded from.
		 * * `object` - Define properties for `jQuery.ajax`.
		 * * `function` - Custom data get function
		 *
		 * `string`
		 * --------
		 *
		 * As a string, the `ajax` property simply defines the URL from which
		 * DataTables will load data.
		 *
		 * `object`
		 * --------
		 *
		 * As an object, the parameters in the object are passed to
		 * [jQuery.ajax](http://api.jquery.com/jQuery.ajax/) allowing fine control
		 * of the Ajax request. DataTables has a number of default parameters which
		 * you can override using this option. Please refer to the jQuery
		 * documentation for a full description of the options available, although
		 * the following parameters provide additional options in DataTables or
		 * require special consideration:
		 *
		 * * `data` - As with jQuery, `data` can be provided as an object, but it
		 *   can also be used as a function to manipulate the data DataTables sends
		 *   to the server. The function takes a single parameter, an object of
		 *   parameters with the values that DataTables has readied for sending. An
		 *   object may be returned which will be merged into the DataTables
		 *   defaults, or you can add the items to the object that was passed in and
		 *   not return anything from the function. This supersedes `fnServerParams`
		 *   from DataTables 1.9-.
		 *
		 * * `dataSrc` - By default DataTables will look for the property `data` (or
		 *   `aaData` for compatibility with DataTables 1.9-) when obtaining data
		 *   from an Ajax source or for server-side processing - this parameter
		 *   allows that property to be changed. You can use Javascript dotted
		 *   object notation to get a data source for multiple levels of nesting, or
		 *   it my be used as a function. As a function it takes a single parameter,
		 *   the JSON returned from the server, which can be manipulated as
		 *   required, with the returned value being that used by DataTables as the
		 *   data source for the table. This supersedes `sAjaxDataProp` from
		 *   DataTables 1.9-.
		 *
		 * * `success` - Should not be overridden it is used internally in
		 *   DataTables. To manipulate / transform the data returned by the server
		 *   use `ajax.dataSrc`, or use `ajax` as a function (see below).
		 *
		 * `function`
		 * ----------
		 *
		 * As a function, making the Ajax call is left up to yourself allowing
		 * complete control of the Ajax request. Indeed, if desired, a method other
		 * than Ajax could be used to obtain the required data, such as Web storage
		 * or an AIR database.
		 *
		 * The function is given four parameters and no return is required. The
		 * parameters are:
		 *
		 * 1. _object_ - Data to send to the server
		 * 2. _function_ - Callback function that must be executed when the required
		 *    data has been obtained. That data should be passed into the callback
		 *    as the only parameter
		 * 3. _object_ - DataTables settings object for the table
		 *
		 * Note that this supersedes `fnServerData` from DataTables 1.9-.
		 *
		 *  @type string|object|function
		 *  @default null
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.ajax
		 *  @since 1.10.0
		 *
		 * @example
		 *   // Get JSON data from a file via Ajax.
		 *   // Note DataTables expects data in the form `{ data: [ ...data... ] }` by default).
		 *   $('#example').dataTable( {
		 *     "ajax": "data.json"
		 *   } );
		 *
		 * @example
		 *   // Get JSON data from a file via Ajax, using `dataSrc` to change
		 *   // `data` to `tableData` (i.e. `{ tableData: [ ...data... ] }`)
		 *   $('#example').dataTable( {
		 *     "ajax": {
		 *       "url": "data.json",
		 *       "dataSrc": "tableData"
		 *     }
		 *   } );
		 *
		 * @example
		 *   // Get JSON data from a file via Ajax, using `dataSrc` to read data
		 *   // from a plain array rather than an array in an object
		 *   $('#example').dataTable( {
		 *     "ajax": {
		 *       "url": "data.json",
		 *       "dataSrc": ""
		 *     }
		 *   } );
		 *
		 * @example
		 *   // Manipulate the data returned from the server - add a link to data
		 *   // (note this can, should, be done using `render` for the column - this
		 *   // is just a simple example of how the data can be manipulated).
		 *   $('#example').dataTable( {
		 *     "ajax": {
		 *       "url": "data.json",
		 *       "dataSrc": function ( json ) {
		 *         for ( var i=0, ien=json.length ; i<ien ; i++ ) {
		 *           json[i][0] = '<a href="/message/'+json[i][0]+'>View message</a>';
		 *         }
		 *         return json;
		 *       }
		 *     }
		 *   } );
		 *
		 * @example
		 *   // Add data to the request
		 *   $('#example').dataTable( {
		 *     "ajax": {
		 *       "url": "data.json",
		 *       "data": function ( d ) {
		 *         return {
		 *           "extra_search": $('#extra').val()
		 *         };
		 *       }
		 *     }
		 *   } );
		 *
		 * @example
		 *   // Send request as POST
		 *   $('#example').dataTable( {
		 *     "ajax": {
		 *       "url": "data.json",
		 *       "type": "POST"
		 *     }
		 *   } );
		 *
		 * @example
		 *   // Get the data from localStorage (could interface with a form for
		 *   // adding, editing and removing rows).
		 *   $('#example').dataTable( {
		 *     "ajax": function (data, callback, settings) {
		 *       callback(
		 *         JSON.parse( localStorage.getItem('dataTablesData') )
		 *       );
		 *     }
		 *   } );
		 */
		"ajax": null,
	
	
		/**
		 * This parameter allows you to readily specify the entries in the length drop
		 * down menu that DataTables shows when pagination is enabled. It can be
		 * either a 1D array of options which will be used for both the displayed
		 * option and the value, or a 2D array which will use the array in the first
		 * position as the value, and the array in the second position as the
		 * displayed options (useful for language strings such as 'All').
		 *
		 * Note that the `pageLength` property will be automatically set to the
		 * first value given in this array, unless `pageLength` is also provided.
		 *  @type array
		 *  @default [ 10, 25, 50, 100 ]
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.lengthMenu
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]]
		 *      } );
		 *    } );
		 */
		"aLengthMenu": [ 10, 25, 50, 100 ],
	
	
		/**
		 * The `columns` option in the initialisation parameter allows you to define
		 * details about the way individual columns behave. For a full list of
		 * column options that can be set, please see
		 * {@link DataTable.defaults.column}. Note that if you use `columns` to
		 * define your columns, you must have an entry in the array for every single
		 * column that you have in your table (these can be null if you don't which
		 * to specify any options).
		 *  @member
		 *
		 *  @name DataTable.defaults.column
		 */
		"aoColumns": null,
	
		/**
		 * Very similar to `columns`, `columnDefs` allows you to target a specific
		 * column, multiple columns, or all columns, using the `targets` property of
		 * each object in the array. This allows great flexibility when creating
		 * tables, as the `columnDefs` arrays can be of any length, targeting the
		 * columns you specifically want. `columnDefs` may use any of the column
		 * options available: {@link DataTable.defaults.column}, but it _must_
		 * have `targets` defined in each object in the array. Values in the `targets`
		 * array may be:
		 *   <ul>
		 *     <li>a string - class name will be matched on the TH for the column</li>
		 *     <li>0 or a positive integer - column index counting from the left</li>
		 *     <li>a negative integer - column index counting from the right</li>
		 *     <li>the string "_all" - all columns (i.e. assign a default)</li>
		 *   </ul>
		 *  @member
		 *
		 *  @name DataTable.defaults.columnDefs
		 */
		"aoColumnDefs": null,
	
	
		/**
		 * Basically the same as `search`, this parameter defines the individual column
		 * filtering state at initialisation time. The array must be of the same size
		 * as the number of columns, and each element be an object with the parameters
		 * `search` and `escapeRegex` (the latter is optional). 'null' is also
		 * accepted and the default will be used.
		 *  @type array
		 *  @default []
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.searchCols
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "searchCols": [
		 *          null,
		 *          { "search": "My filter" },
		 *          null,
		 *          { "search": "^[0-9]", "escapeRegex": false }
		 *        ]
		 *      } );
		 *    } )
		 */
		"aoSearchCols": [],
	
	
		/**
		 * An array of CSS classes that should be applied to displayed rows. This
		 * array may be of any length, and DataTables will apply each class
		 * sequentially, looping when required.
		 *  @type array
		 *  @default null <i>Will take the values determined by the `oClasses.stripe*`
		 *    options</i>
		 *
		 *  @dtopt Option
		 *  @name DataTable.defaults.stripeClasses
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stripeClasses": [ 'strip1', 'strip2', 'strip3' ]
		 *      } );
		 *    } )
		 */
		"asStripeClasses": null,
	
	
		/**
		 * Enable or disable automatic column width calculation. This can be disabled
		 * as an optimisation (it takes some time to calculate the widths) if the
		 * tables widths are passed in using `columns`.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.autoWidth
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "autoWidth": false
		 *      } );
		 *    } );
		 */
		"bAutoWidth": true,
	
	
		/**
		 * Deferred rendering can provide DataTables with a huge speed boost when you
		 * are using an Ajax or JS data source for the table. This option, when set to
		 * true, will cause DataTables to defer the creation of the table elements for
		 * each row until they are needed for a draw - saving a significant amount of
		 * time.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.deferRender
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "ajax": "sources/arrays.txt",
		 *        "deferRender": true
		 *      } );
		 *    } );
		 */
		"bDeferRender": false,
	
	
		/**
		 * Replace a DataTable which matches the given selector and replace it with
		 * one which has the properties of the new initialisation object passed. If no
		 * table matches the selector, then the new DataTable will be constructed as
		 * per normal.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.destroy
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "srollY": "200px",
		 *        "paginate": false
		 *      } );
		 *
		 *      // Some time later....
		 *      $('#example').dataTable( {
		 *        "filter": false,
		 *        "destroy": true
		 *      } );
		 *    } );
		 */
		"bDestroy": false,
	
	
		/**
		 * Enable or disable filtering of data. Filtering in DataTables is "smart" in
		 * that it allows the end user to input multiple words (space separated) and
		 * will match a row containing those words, even if not in the order that was
		 * specified (this allow matching across multiple columns). Note that if you
		 * wish to use filtering in DataTables this must remain 'true' - to remove the
		 * default filtering input box and retain filtering abilities, please use
		 * {@link DataTable.defaults.dom}.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.searching
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "searching": false
		 *      } );
		 *    } );
		 */
		"bFilter": true,
	
	
		/**
		 * Enable or disable the table information display. This shows information
		 * about the data that is currently visible on the page, including information
		 * about filtered data if that action is being performed.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.info
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "info": false
		 *      } );
		 *    } );
		 */
		"bInfo": true,
	
	
		/**
		 * Allows the end user to select the size of a formatted page from a select
		 * menu (sizes are 10, 25, 50 and 100). Requires pagination (`paginate`).
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.lengthChange
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "lengthChange": false
		 *      } );
		 *    } );
		 */
		"bLengthChange": true,
	
	
		/**
		 * Enable or disable pagination.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.paging
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "paging": false
		 *      } );
		 *    } );
		 */
		"bPaginate": true,
	
	
		/**
		 * Enable or disable the display of a 'processing' indicator when the table is
		 * being processed (e.g. a sort). This is particularly useful for tables with
		 * large amounts of data where it can take a noticeable amount of time to sort
		 * the entries.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.processing
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "processing": true
		 *      } );
		 *    } );
		 */
		"bProcessing": false,
	
	
		/**
		 * Retrieve the DataTables object for the given selector. Note that if the
		 * table has already been initialised, this parameter will cause DataTables
		 * to simply return the object that has already been set up - it will not take
		 * account of any changes you might have made to the initialisation object
		 * passed to DataTables (setting this parameter to true is an acknowledgement
		 * that you understand this). `destroy` can be used to reinitialise a table if
		 * you need.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.retrieve
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      initTable();
		 *      tableActions();
		 *    } );
		 *
		 *    function initTable ()
		 *    {
		 *      return $('#example').dataTable( {
		 *        "scrollY": "200px",
		 *        "paginate": false,
		 *        "retrieve": true
		 *      } );
		 *    }
		 *
		 *    function tableActions ()
		 *    {
		 *      var table = initTable();
		 *      // perform API operations with oTable
		 *    }
		 */
		"bRetrieve": false,
	
	
		/**
		 * When vertical (y) scrolling is enabled, DataTables will force the height of
		 * the table's viewport to the given height at all times (useful for layout).
		 * However, this can look odd when filtering data down to a small data set,
		 * and the footer is left "floating" further down. This parameter (when
		 * enabled) will cause DataTables to collapse the table's viewport down when
		 * the result set will fit within the given Y height.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.scrollCollapse
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "scrollY": "200",
		 *        "scrollCollapse": true
		 *      } );
		 *    } );
		 */
		"bScrollCollapse": false,
	
	
		/**
		 * Configure DataTables to use server-side processing. Note that the
		 * `ajax` parameter must also be given in order to give DataTables a
		 * source to obtain the required data for each draw.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Features
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.serverSide
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "serverSide": true,
		 *        "ajax": "xhr.php"
		 *      } );
		 *    } );
		 */
		"bServerSide": false,
	
	
		/**
		 * Enable or disable sorting of columns. Sorting of individual columns can be
		 * disabled by the `sortable` option for each column.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.ordering
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "ordering": false
		 *      } );
		 *    } );
		 */
		"bSort": true,
	
	
		/**
		 * Enable or display DataTables' ability to sort multiple columns at the
		 * same time (activated by shift-click by the user).
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.orderMulti
		 *
		 *  @example
		 *    // Disable multiple column sorting ability
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "orderMulti": false
		 *      } );
		 *    } );
		 */
		"bSortMulti": true,
	
	
		/**
		 * Allows control over whether DataTables should use the top (true) unique
		 * cell that is found for a single column, or the bottom (false - default).
		 * This is useful when using complex headers.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.orderCellsTop
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "orderCellsTop": true
		 *      } );
		 *    } );
		 */
		"bSortCellsTop": false,
	
	
		/**
		 * Enable or disable the addition of the classes `sorting\_1`, `sorting\_2` and
		 * `sorting\_3` to the columns which are currently being sorted on. This is
		 * presented as a feature switch as it can increase processing time (while
		 * classes are removed and added) so for large data sets you might want to
		 * turn this off.
		 *  @type boolean
		 *  @default true
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.orderClasses
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "orderClasses": false
		 *      } );
		 *    } );
		 */
		"bSortClasses": true,
	
	
		/**
		 * Enable or disable state saving. When enabled HTML5 `localStorage` will be
		 * used to save table display information such as pagination information,
		 * display length, filtering and sorting. As such when the end user reloads
		 * the page the display display will match what thy had previously set up.
		 *
		 * Due to the use of `localStorage` the default state saving is not supported
		 * in IE6 or 7. If state saving is required in those browsers, use
		 * `stateSaveCallback` to provide a storage solution such as cookies.
		 *  @type boolean
		 *  @default false
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.stateSave
		 *
		 *  @example
		 *    $(document).ready( function () {
		 *      $('#example').dataTable( {
		 *        "stateSave": true
		 *      } );
		 *    } );
		 */
		"bStateSave": false,
	
	
		/**
		 * This function is called when a TR element is created (and all TD child
		 * elements have been inserted), or registered if using a DOM source, allowing
		 * manipulation of the TR element (adding classes etc).
		 *  @type function
		 *  @param {node} row "TR" element for the current row
		 *  @param {array} data Raw data array for this row
		 *  @param {int} dataIndex The index of this row in the internal aoData array
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.createdRow
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "createdRow": function( row, data, dataIndex ) {
		 *          // Bold the grade for all 'A' grade browsers
		 *          if ( data[4] == "A" )
		 *          {
		 *            $('td:eq(4)', row).html( '<b>A</b>' );
		 *          }
		 *        }
		 *      } );
		 *    } );
		 */
		"fnCreatedRow": null,
	
	
		/**
		 * This function is called on every 'draw' event, and allows you to
		 * dynamically modify any aspect you want about the created DOM.
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.drawCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "drawCallback": function( settings ) {
		 *          alert( 'DataTables has redrawn the table' );
		 *        }
		 *      } );
		 *    } );
		 */
		"fnDrawCallback": null,
	
	
		/**
		 * Identical to fnHeaderCallback() but for the table footer this function
		 * allows you to modify the table footer on every 'draw' event.
		 *  @type function
		 *  @param {node} foot "TR" element for the footer
		 *  @param {array} data Full table data (as derived from the original HTML)
		 *  @param {int} start Index for the current display starting point in the
		 *    display array
		 *  @param {int} end Index for the current display ending point in the
		 *    display array
		 *  @param {array int} display Index array to translate the visual position
		 *    to the full data array
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.footerCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "footerCallback": function( tfoot, data, start, end, display ) {
		 *          tfoot.getElementsByTagName('th')[0].innerHTML = "Starting index is "+start;
		 *        }
		 *      } );
		 *    } )
		 */
		"fnFooterCallback": null,
	
	
		/**
		 * When rendering large numbers in the information element for the table
		 * (i.e. "Showing 1 to 10 of 57 entries") DataTables will render large numbers
		 * to have a comma separator for the 'thousands' units (e.g. 1 million is
		 * rendered as "1,000,000") to help readability for the end user. This
		 * function will override the default method DataTables uses.
		 *  @type function
		 *  @member
		 *  @param {int} toFormat number to be formatted
		 *  @returns {string} formatted string for DataTables to show the number
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.formatNumber
		 *
		 *  @example
		 *    // Format a number using a single quote for the separator (note that
		 *    // this can also be done with the language.thousands option)
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "formatNumber": function ( toFormat ) {
		 *          return toFormat.toString().replace(
		 *            /\B(?=(\d{3})+(?!\d))/g, "'"
		 *          );
		 *        };
		 *      } );
		 *    } );
		 */
		"fnFormatNumber": function ( toFormat ) {
			return toFormat.toString().replace(
				/\B(?=(\d{3})+(?!\d))/g,
				this.oLanguage.sThousands
			);
		},
	
	
		/**
		 * This function is called on every 'draw' event, and allows you to
		 * dynamically modify the header row. This can be used to calculate and
		 * display useful information about the table.
		 *  @type function
		 *  @param {node} head "TR" element for the header
		 *  @param {array} data Full table data (as derived from the original HTML)
		 *  @param {int} start Index for the current display starting point in the
		 *    display array
		 *  @param {int} end Index for the current display ending point in the
		 *    display array
		 *  @param {array int} display Index array to translate the visual position
		 *    to the full data array
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.headerCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "fheaderCallback": function( head, data, start, end, display ) {
		 *          head.getElementsByTagName('th')[0].innerHTML = "Displaying "+(end-start)+" records";
		 *        }
		 *      } );
		 *    } )
		 */
		"fnHeaderCallback": null,
	
	
		/**
		 * The information element can be used to convey information about the current
		 * state of the table. Although the internationalisation options presented by
		 * DataTables are quite capable of dealing with most customisations, there may
		 * be times where you wish to customise the string further. This callback
		 * allows you to do exactly that.
		 *  @type function
		 *  @param {object} oSettings DataTables settings object
		 *  @param {int} start Starting position in data for the draw
		 *  @param {int} end End position in data for the draw
		 *  @param {int} max Total number of rows in the table (regardless of
		 *    filtering)
		 *  @param {int} total Total number of rows in the data set, after filtering
		 *  @param {string} pre The string that DataTables has formatted using it's
		 *    own rules
		 *  @returns {string} The string to be displayed in the information element.
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.infoCallback
		 *
		 *  @example
		 *    $('#example').dataTable( {
		 *      "infoCallback": function( settings, start, end, max, total, pre ) {
		 *        return start +" to "+ end;
		 *      }
		 *    } );
		 */
		"fnInfoCallback": null,
	
	
		/**
		 * Called when the table has been initialised. Normally DataTables will
		 * initialise sequentially and there will be no need for this function,
		 * however, this does not hold true when using external language information
		 * since that is obtained using an async XHR call.
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *  @param {object} json The JSON object request from the server - only
		 *    present if client-side Ajax sourced data is used
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.initComplete
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "initComplete": function(settings, json) {
		 *          alert( 'DataTables has finished its initialisation.' );
		 *        }
		 *      } );
		 *    } )
		 */
		"fnInitComplete": null,
	
	
		/**
		 * Called at the very start of each table draw and can be used to cancel the
		 * draw by returning false, any other return (including undefined) results in
		 * the full draw occurring).
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *  @returns {boolean} False will cancel the draw, anything else (including no
		 *    return) will allow it to complete.
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.preDrawCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "preDrawCallback": function( settings ) {
		 *          if ( $('#test').val() == 1 ) {
		 *            return false;
		 *          }
		 *        }
		 *      } );
		 *    } );
		 */
		"fnPreDrawCallback": null,
	
	
		/**
		 * This function allows you to 'post process' each row after it have been
		 * generated for each table draw, but before it is rendered on screen. This
		 * function might be used for setting the row class name etc.
		 *  @type function
		 *  @param {node} row "TR" element for the current row
		 *  @param {array} data Raw data array for this row
		 *  @param {int} displayIndex The display index for the current table draw
		 *  @param {int} displayIndexFull The index of the data in the full list of
		 *    rows (after filtering)
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.rowCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "rowCallback": function( row, data, displayIndex, displayIndexFull ) {
		 *          // Bold the grade for all 'A' grade browsers
		 *          if ( data[4] == "A" ) {
		 *            $('td:eq(4)', row).html( '<b>A</b>' );
		 *          }
		 *        }
		 *      } );
		 *    } );
		 */
		"fnRowCallback": null,
	
	
		/**
		 * __Deprecated__ The functionality provided by this parameter has now been
		 * superseded by that provided through `ajax`, which should be used instead.
		 *
		 * This parameter allows you to override the default function which obtains
		 * the data from the server so something more suitable for your application.
		 * For example you could use POST data, or pull information from a Gears or
		 * AIR database.
		 *  @type function
		 *  @member
		 *  @param {string} source HTTP source to obtain the data from (`ajax`)
		 *  @param {array} data A key/value pair object containing the data to send
		 *    to the server
		 *  @param {function} callback to be called on completion of the data get
		 *    process that will draw the data on the page.
		 *  @param {object} settings DataTables settings object
		 *
		 *  @dtopt Callbacks
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.serverData
		 *
		 *  @deprecated 1.10. Please use `ajax` for this functionality now.
		 */
		"fnServerData": null,
	
	
		/**
		 * __Deprecated__ The functionality provided by this parameter has now been
		 * superseded by that provided through `ajax`, which should be used instead.
		 *
		 *  It is often useful to send extra data to the server when making an Ajax
		 * request - for example custom filtering information, and this callback
		 * function makes it trivial to send extra information to the server. The
		 * passed in parameter is the data set that has been constructed by
		 * DataTables, and you can add to this or modify it as you require.
		 *  @type function
		 *  @param {array} data Data array (array of objects which are name/value
		 *    pairs) that has been constructed by DataTables and will be sent to the
		 *    server. In the case of Ajax sourced data with server-side processing
		 *    this will be an empty array, for server-side processing there will be a
		 *    significant number of parameters!
		 *  @returns {undefined} Ensure that you modify the data array passed in,
		 *    as this is passed by reference.
		 *
		 *  @dtopt Callbacks
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.serverParams
		 *
		 *  @deprecated 1.10. Please use `ajax` for this functionality now.
		 */
		"fnServerParams": null,
	
	
		/**
		 * Load the table state. With this function you can define from where, and how, the
		 * state of a table is loaded. By default DataTables will load from `localStorage`
		 * but you might wish to use a server-side database or cookies.
		 *  @type function
		 *  @member
		 *  @param {object} settings DataTables settings object
		 *  @param {object} callback Callback that can be executed when done. It
		 *    should be passed the loaded state object.
		 *  @return {object} The DataTables state object to be loaded
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.stateLoadCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateLoadCallback": function (settings, callback) {
		 *          $.ajax( {
		 *            "url": "/state_load",
		 *            "dataType": "json",
		 *            "success": function (json) {
		 *              callback( json );
		 *            }
		 *          } );
		 *        }
		 *      } );
		 *    } );
		 */
		"fnStateLoadCallback": function ( settings ) {
			try {
				return JSON.parse(
					(settings.iStateDuration === -1 ? sessionStorage : localStorage).getItem(
						'DataTables_'+settings.sInstance+'_'+location.pathname
					)
				);
			} catch (e) {}
		},
	
	
		/**
		 * Callback which allows modification of the saved state prior to loading that state.
		 * This callback is called when the table is loading state from the stored data, but
		 * prior to the settings object being modified by the saved state. Note that for
		 * plug-in authors, you should use the `stateLoadParams` event to load parameters for
		 * a plug-in.
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *  @param {object} data The state object that is to be loaded
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.stateLoadParams
		 *
		 *  @example
		 *    // Remove a saved filter, so filtering is never loaded
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateLoadParams": function (settings, data) {
		 *          data.oSearch.sSearch = "";
		 *        }
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Disallow state loading by returning false
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateLoadParams": function (settings, data) {
		 *          return false;
		 *        }
		 *      } );
		 *    } );
		 */
		"fnStateLoadParams": null,
	
	
		/**
		 * Callback that is called when the state has been loaded from the state saving method
		 * and the DataTables settings object has been modified as a result of the loaded state.
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *  @param {object} data The state object that was loaded
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.stateLoaded
		 *
		 *  @example
		 *    // Show an alert with the filtering value that was saved
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateLoaded": function (settings, data) {
		 *          alert( 'Saved filter was: '+data.oSearch.sSearch );
		 *        }
		 *      } );
		 *    } );
		 */
		"fnStateLoaded": null,
	
	
		/**
		 * Save the table state. This function allows you to define where and how the state
		 * information for the table is stored By default DataTables will use `localStorage`
		 * but you might wish to use a server-side database or cookies.
		 *  @type function
		 *  @member
		 *  @param {object} settings DataTables settings object
		 *  @param {object} data The state object to be saved
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.stateSaveCallback
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateSaveCallback": function (settings, data) {
		 *          // Send an Ajax request to the server with the state object
		 *          $.ajax( {
		 *            "url": "/state_save",
		 *            "data": data,
		 *            "dataType": "json",
		 *            "method": "POST"
		 *            "success": function () {}
		 *          } );
		 *        }
		 *      } );
		 *    } );
		 */
		"fnStateSaveCallback": function ( settings, data ) {
			try {
				(settings.iStateDuration === -1 ? sessionStorage : localStorage).setItem(
					'DataTables_'+settings.sInstance+'_'+location.pathname,
					JSON.stringify( data )
				);
			} catch (e) {}
		},
	
	
		/**
		 * Callback which allows modification of the state to be saved. Called when the table
		 * has changed state a new state save is required. This method allows modification of
		 * the state saving object prior to actually doing the save, including addition or
		 * other state properties or modification. Note that for plug-in authors, you should
		 * use the `stateSaveParams` event to save parameters for a plug-in.
		 *  @type function
		 *  @param {object} settings DataTables settings object
		 *  @param {object} data The state object to be saved
		 *
		 *  @dtopt Callbacks
		 *  @name DataTable.defaults.stateSaveParams
		 *
		 *  @example
		 *    // Remove a saved filter, so filtering is never saved
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateSave": true,
		 *        "stateSaveParams": function (settings, data) {
		 *          data.oSearch.sSearch = "";
		 *        }
		 *      } );
		 *    } );
		 */
		"fnStateSaveParams": null,
	
	
		/**
		 * Duration for which the saved state information is considered valid. After this period
		 * has elapsed the state will be returned to the default.
		 * Value is given in seconds.
		 *  @type int
		 *  @default 7200 <i>(2 hours)</i>
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.stateDuration
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "stateDuration": 60*60*24; // 1 day
		 *      } );
		 *    } )
		 */
		"iStateDuration": 7200,
	
	
		/**
		 * When enabled DataTables will not make a request to the server for the first
		 * page draw - rather it will use the data already on the page (no sorting etc
		 * will be applied to it), thus saving on an XHR at load time. `deferLoading`
		 * is used to indicate that deferred loading is required, but it is also used
		 * to tell DataTables how many records there are in the full table (allowing
		 * the information element and pagination to be displayed correctly). In the case
		 * where a filtering is applied to the table on initial load, this can be
		 * indicated by giving the parameter as an array, where the first element is
		 * the number of records available after filtering and the second element is the
		 * number of records without filtering (allowing the table information element
		 * to be shown correctly).
		 *  @type int | array
		 *  @default null
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.deferLoading
		 *
		 *  @example
		 *    // 57 records available in the table, no filtering applied
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "serverSide": true,
		 *        "ajax": "scripts/server_processing.php",
		 *        "deferLoading": 57
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // 57 records after filtering, 100 without filtering (an initial filter applied)
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "serverSide": true,
		 *        "ajax": "scripts/server_processing.php",
		 *        "deferLoading": [ 57, 100 ],
		 *        "search": {
		 *          "search": "my_filter"
		 *        }
		 *      } );
		 *    } );
		 */
		"iDeferLoading": null,
	
	
		/**
		 * Number of rows to display on a single page when using pagination. If
		 * feature enabled (`lengthChange`) then the end user will be able to override
		 * this to a custom setting using a pop-up menu.
		 *  @type int
		 *  @default 10
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.pageLength
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "pageLength": 50
		 *      } );
		 *    } )
		 */
		"iDisplayLength": 10,
	
	
		/**
		 * Define the starting point for data display when using DataTables with
		 * pagination. Note that this parameter is the number of records, rather than
		 * the page number, so if you have 10 records per page and want to start on
		 * the third page, it should be "20".
		 *  @type int
		 *  @default 0
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.displayStart
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "displayStart": 20
		 *      } );
		 *    } )
		 */
		"iDisplayStart": 0,
	
	
		/**
		 * By default DataTables allows keyboard navigation of the table (sorting, paging,
		 * and filtering) by adding a `tabindex` attribute to the required elements. This
		 * allows you to tab through the controls and press the enter key to activate them.
		 * The tabindex is default 0, meaning that the tab follows the flow of the document.
		 * You can overrule this using this parameter if you wish. Use a value of -1 to
		 * disable built-in keyboard navigation.
		 *  @type int
		 *  @default 0
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.tabIndex
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "tabIndex": 1
		 *      } );
		 *    } );
		 */
		"iTabIndex": 0,
	
	
		/**
		 * Classes that DataTables assigns to the various components and features
		 * that it adds to the HTML table. This allows classes to be configured
		 * during initialisation in addition to through the static
		 * {@link DataTable.ext.oStdClasses} object).
		 *  @namespace
		 *  @name DataTable.defaults.classes
		 */
		"oClasses": {},
	
	
		/**
		 * All strings that DataTables uses in the user interface that it creates
		 * are defined in this object, allowing you to modified them individually or
		 * completely replace them all as required.
		 *  @namespace
		 *  @name DataTable.defaults.language
		 */
		"oLanguage": {
			/**
			 * Strings that are used for WAI-ARIA labels and controls only (these are not
			 * actually visible on the page, but will be read by screenreaders, and thus
			 * must be internationalised as well).
			 *  @namespace
			 *  @name DataTable.defaults.language.aria
			 */
			"oAria": {
				/**
				 * ARIA label that is added to the table headers when the column may be
				 * sorted ascending by activing the column (click or return when focused).
				 * Note that the column header is prefixed to this string.
				 *  @type string
				 *  @default : activate to sort column ascending
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.aria.sortAscending
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "aria": {
				 *            "sortAscending": " - click/return to sort ascending"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sSortAscending": ": activate to sort column ascending",
	
				/**
				 * ARIA label that is added to the table headers when the column may be
				 * sorted descending by activing the column (click or return when focused).
				 * Note that the column header is prefixed to this string.
				 *  @type string
				 *  @default : activate to sort column ascending
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.aria.sortDescending
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "aria": {
				 *            "sortDescending": " - click/return to sort descending"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sSortDescending": ": activate to sort column descending"
			},
	
			/**
			 * Pagination string used by DataTables for the built-in pagination
			 * control types.
			 *  @namespace
			 *  @name DataTable.defaults.language.paginate
			 */
			"oPaginate": {
				/**
				 * Text to use when using the 'full_numbers' type of pagination for the
				 * button to take the user to the first page.
				 *  @type string
				 *  @default First
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.paginate.first
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "paginate": {
				 *            "first": "First page"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sFirst": "First",
	
	
				/**
				 * Text to use when using the 'full_numbers' type of pagination for the
				 * button to take the user to the last page.
				 *  @type string
				 *  @default Last
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.paginate.last
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "paginate": {
				 *            "last": "Last page"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sLast": "Last",
	
	
				/**
				 * Text to use for the 'next' pagination button (to take the user to the
				 * next page).
				 *  @type string
				 *  @default Next
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.paginate.next
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "paginate": {
				 *            "next": "Next page"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sNext": "Next",
	
	
				/**
				 * Text to use for the 'previous' pagination button (to take the user to
				 * the previous page).
				 *  @type string
				 *  @default Previous
				 *
				 *  @dtopt Language
				 *  @name DataTable.defaults.language.paginate.previous
				 *
				 *  @example
				 *    $(document).ready( function() {
				 *      $('#example').dataTable( {
				 *        "language": {
				 *          "paginate": {
				 *            "previous": "Previous page"
				 *          }
				 *        }
				 *      } );
				 *    } );
				 */
				"sPrevious": "Previous"
			},
	
			/**
			 * This string is shown in preference to `zeroRecords` when the table is
			 * empty of data (regardless of filtering). Note that this is an optional
			 * parameter - if it is not given, the value of `zeroRecords` will be used
			 * instead (either the default or given value).
			 *  @type string
			 *  @default No data available in table
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.emptyTable
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "emptyTable": "No data available in table"
			 *        }
			 *      } );
			 *    } );
			 */
			"sEmptyTable": "No data available in table",
	
	
			/**
			 * This string gives information to the end user about the information
			 * that is current on display on the page. The following tokens can be
			 * used in the string and will be dynamically replaced as the table
			 * display updates. This tokens can be placed anywhere in the string, or
			 * removed as needed by the language requires:
			 *
			 * * `\_START\_` - Display index of the first record on the current page
			 * * `\_END\_` - Display index of the last record on the current page
			 * * `\_TOTAL\_` - Number of records in the table after filtering
			 * * `\_MAX\_` - Number of records in the table without filtering
			 * * `\_PAGE\_` - Current page number
			 * * `\_PAGES\_` - Total number of pages of data in the table
			 *
			 *  @type string
			 *  @default Showing _START_ to _END_ of _TOTAL_ entries
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.info
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "info": "Showing page _PAGE_ of _PAGES_"
			 *        }
			 *      } );
			 *    } );
			 */
			"sInfo": "Showing _START_ to _END_ of _TOTAL_ entries",
	
	
			/**
			 * Display information string for when the table is empty. Typically the
			 * format of this string should match `info`.
			 *  @type string
			 *  @default Showing 0 to 0 of 0 entries
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.infoEmpty
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "infoEmpty": "No entries to show"
			 *        }
			 *      } );
			 *    } );
			 */
			"sInfoEmpty": "Showing 0 to 0 of 0 entries",
	
	
			/**
			 * When a user filters the information in a table, this string is appended
			 * to the information (`info`) to give an idea of how strong the filtering
			 * is. The variable _MAX_ is dynamically updated.
			 *  @type string
			 *  @default (filtered from _MAX_ total entries)
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.infoFiltered
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "infoFiltered": " - filtering from _MAX_ records"
			 *        }
			 *      } );
			 *    } );
			 */
			"sInfoFiltered": "(filtered from _MAX_ total entries)",
	
	
			/**
			 * If can be useful to append extra information to the info string at times,
			 * and this variable does exactly that. This information will be appended to
			 * the `info` (`infoEmpty` and `infoFiltered` in whatever combination they are
			 * being used) at all times.
			 *  @type string
			 *  @default <i>Empty string</i>
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.infoPostFix
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "infoPostFix": "All records shown are derived from real information."
			 *        }
			 *      } );
			 *    } );
			 */
			"sInfoPostFix": "",
	
	
			/**
			 * This decimal place operator is a little different from the other
			 * language options since DataTables doesn't output floating point
			 * numbers, so it won't ever use this for display of a number. Rather,
			 * what this parameter does is modify the sort methods of the table so
			 * that numbers which are in a format which has a character other than
			 * a period (`.`) as a decimal place will be sorted numerically.
			 *
			 * Note that numbers with different decimal places cannot be shown in
			 * the same table and still be sortable, the table must be consistent.
			 * However, multiple different tables on the page can use different
			 * decimal place characters.
			 *  @type string
			 *  @default 
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.decimal
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "decimal": ","
			 *          "thousands": "."
			 *        }
			 *      } );
			 *    } );
			 */
			"sDecimal": "",
	
	
			/**
			 * DataTables has a build in number formatter (`formatNumber`) which is
			 * used to format large numbers that are used in the table information.
			 * By default a comma is used, but this can be trivially changed to any
			 * character you wish with this parameter.
			 *  @type string
			 *  @default ,
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.thousands
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "thousands": "'"
			 *        }
			 *      } );
			 *    } );
			 */
			"sThousands": ",",
	
	
			/**
			 * Detail the action that will be taken when the drop down menu for the
			 * pagination length option is changed. The '_MENU_' variable is replaced
			 * with a default select list of 10, 25, 50 and 100, and can be replaced
			 * with a custom select box if required.
			 *  @type string
			 *  @default Show _MENU_ entries
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.lengthMenu
			 *
			 *  @example
			 *    // Language change only
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "lengthMenu": "Display _MENU_ records"
			 *        }
			 *      } );
			 *    } );
			 *
			 *  @example
			 *    // Language and options change
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "lengthMenu": 'Display <select>'+
			 *            '<option value="10">10</option>'+
			 *            '<option value="20">20</option>'+
			 *            '<option value="30">30</option>'+
			 *            '<option value="40">40</option>'+
			 *            '<option value="50">50</option>'+
			 *            '<option value="-1">All</option>'+
			 *            '</select> records'
			 *        }
			 *      } );
			 *    } );
			 */
			"sLengthMenu": "Show _MENU_ entries",
	
	
			/**
			 * When using Ajax sourced data and during the first draw when DataTables is
			 * gathering the data, this message is shown in an empty row in the table to
			 * indicate to the end user the the data is being loaded. Note that this
			 * parameter is not used when loading data by server-side processing, just
			 * Ajax sourced data with client-side processing.
			 *  @type string
			 *  @default Loading...
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.loadingRecords
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "loadingRecords": "Please wait - loading..."
			 *        }
			 *      } );
			 *    } );
			 */
			"sLoadingRecords": "Loading...",
	
	
			/**
			 * Text which is displayed when the table is processing a user action
			 * (usually a sort command or similar).
			 *  @type string
			 *  @default Processing...
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.processing
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "processing": "DataTables is currently busy"
			 *        }
			 *      } );
			 *    } );
			 */
			"sProcessing": "Processing...",
	
	
			/**
			 * Details the actions that will be taken when the user types into the
			 * filtering input text box. The variable "_INPUT_", if used in the string,
			 * is replaced with the HTML text box for the filtering input allowing
			 * control over where it appears in the string. If "_INPUT_" is not given
			 * then the input box is appended to the string automatically.
			 *  @type string
			 *  @default Search:
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.search
			 *
			 *  @example
			 *    // Input text box will be appended at the end automatically
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "search": "Filter records:"
			 *        }
			 *      } );
			 *    } );
			 *
			 *  @example
			 *    // Specify where the filter should appear
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "search": "Apply filter _INPUT_ to table"
			 *        }
			 *      } );
			 *    } );
			 */
			"sSearch": "Search:",
	
	
			/**
			 * Assign a `placeholder` attribute to the search `input` element
			 *  @type string
			 *  @default 
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.searchPlaceholder
			 */
			"sSearchPlaceholder": "",
	
	
			/**
			 * All of the language information can be stored in a file on the
			 * server-side, which DataTables will look up if this parameter is passed.
			 * It must store the URL of the language file, which is in a JSON format,
			 * and the object has the same properties as the oLanguage object in the
			 * initialiser object (i.e. the above parameters). Please refer to one of
			 * the example language files to see how this works in action.
			 *  @type string
			 *  @default <i>Empty string - i.e. disabled</i>
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.url
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "url": "http://www.sprymedia.co.uk/dataTables/lang.txt"
			 *        }
			 *      } );
			 *    } );
			 */
			"sUrl": "",
	
	
			/**
			 * Text shown inside the table records when the is no information to be
			 * displayed after filtering. `emptyTable` is shown when there is simply no
			 * information in the table at all (regardless of filtering).
			 *  @type string
			 *  @default No matching records found
			 *
			 *  @dtopt Language
			 *  @name DataTable.defaults.language.zeroRecords
			 *
			 *  @example
			 *    $(document).ready( function() {
			 *      $('#example').dataTable( {
			 *        "language": {
			 *          "zeroRecords": "No records to display"
			 *        }
			 *      } );
			 *    } );
			 */
			"sZeroRecords": "No matching records found"
		},
	
	
		/**
		 * This parameter allows you to have define the global filtering state at
		 * initialisation time. As an object the `search` parameter must be
		 * defined, but all other parameters are optional. When `regex` is true,
		 * the search string will be treated as a regular expression, when false
		 * (default) it will be treated as a straight string. When `smart`
		 * DataTables will use it's smart filtering methods (to word match at
		 * any point in the data), when false this will not be done.
		 *  @namespace
		 *  @extends DataTable.models.oSearch
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.search
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "search": {"search": "Initial search"}
		 *      } );
		 *    } )
		 */
		"oSearch": $.extend( {}, DataTable.models.oSearch ),
	
	
		/**
		 * __Deprecated__ The functionality provided by this parameter has now been
		 * superseded by that provided through `ajax`, which should be used instead.
		 *
		 * By default DataTables will look for the property `data` (or `aaData` for
		 * compatibility with DataTables 1.9-) when obtaining data from an Ajax
		 * source or for server-side processing - this parameter allows that
		 * property to be changed. You can use Javascript dotted object notation to
		 * get a data source for multiple levels of nesting.
		 *  @type string
		 *  @default data
		 *
		 *  @dtopt Options
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.ajaxDataProp
		 *
		 *  @deprecated 1.10. Please use `ajax` for this functionality now.
		 */
		"sAjaxDataProp": "data",
	
	
		/**
		 * __Deprecated__ The functionality provided by this parameter has now been
		 * superseded by that provided through `ajax`, which should be used instead.
		 *
		 * You can instruct DataTables to load data from an external
		 * source using this parameter (use aData if you want to pass data in you
		 * already have). Simply provide a url a JSON object can be obtained from.
		 *  @type string
		 *  @default null
		 *
		 *  @dtopt Options
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.ajaxSource
		 *
		 *  @deprecated 1.10. Please use `ajax` for this functionality now.
		 */
		"sAjaxSource": null,
	
	
		/**
		 * This initialisation variable allows you to specify exactly where in the
		 * DOM you want DataTables to inject the various controls it adds to the page
		 * (for example you might want the pagination controls at the top of the
		 * table). DIV elements (with or without a custom class) can also be added to
		 * aid styling. The follow syntax is used:
		 *   <ul>
		 *     <li>The following options are allowed:
		 *       <ul>
		 *         <li>'l' - Length changing</li>
		 *         <li>'f' - Filtering input</li>
		 *         <li>'t' - The table!</li>
		 *         <li>'i' - Information</li>
		 *         <li>'p' - Pagination</li>
		 *         <li>'r' - pRocessing</li>
		 *       </ul>
		 *     </li>
		 *     <li>The following constants are allowed:
		 *       <ul>
		 *         <li>'H' - jQueryUI theme "header" classes ('fg-toolbar ui-widget-header ui-corner-tl ui-corner-tr ui-helper-clearfix')</li>
		 *         <li>'F' - jQueryUI theme "footer" classes ('fg-toolbar ui-widget-header ui-corner-bl ui-corner-br ui-helper-clearfix')</li>
		 *       </ul>
		 *     </li>
		 *     <li>The following syntax is expected:
		 *       <ul>
		 *         <li>'&lt;' and '&gt;' - div elements</li>
		 *         <li>'&lt;"class" and '&gt;' - div with a class</li>
		 *         <li>'&lt;"#id" and '&gt;' - div with an ID</li>
		 *       </ul>
		 *     </li>
		 *     <li>Examples:
		 *       <ul>
		 *         <li>'&lt;"wrapper"flipt&gt;'</li>
		 *         <li>'&lt;lf&lt;t&gt;ip&gt;'</li>
		 *       </ul>
		 *     </li>
		 *   </ul>
		 *  @type string
		 *  @default lfrtip <i>(when `jQueryUI` is false)</i> <b>or</b>
		 *    <"H"lfr>t<"F"ip> <i>(when `jQueryUI` is true)</i>
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.dom
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "dom": '&lt;"top"i&gt;rt&lt;"bottom"flp&gt;&lt;"clear"&gt;'
		 *      } );
		 *    } );
		 */
		"sDom": "lfrtip",
	
	
		/**
		 * Search delay option. This will throttle full table searches that use the
		 * DataTables provided search input element (it does not effect calls to
		 * `dt-api search()`, providing a delay before the search is made.
		 *  @type integer
		 *  @default 0
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.searchDelay
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "searchDelay": 200
		 *      } );
		 *    } )
		 */
		"searchDelay": null,
	
	
		/**
		 * DataTables features six different built-in options for the buttons to
		 * display for pagination control:
		 *
		 * * `numbers` - Page number buttons only
		 * * `simple` - 'Previous' and 'Next' buttons only
		 * * 'simple_numbers` - 'Previous' and 'Next' buttons, plus page numbers
		 * * `full` - 'First', 'Previous', 'Next' and 'Last' buttons
		 * * `full_numbers` - 'First', 'Previous', 'Next' and 'Last' buttons, plus page numbers
		 * * `first_last_numbers` - 'First' and 'Last' buttons, plus page numbers
		 *  
		 * Further methods can be added using {@link DataTable.ext.oPagination}.
		 *  @type string
		 *  @default simple_numbers
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.pagingType
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "pagingType": "full_numbers"
		 *      } );
		 *    } )
		 */
		"sPaginationType": "simple_numbers",
	
	
		/**
		 * Enable horizontal scrolling. When a table is too wide to fit into a
		 * certain layout, or you have a large number of columns in the table, you
		 * can enable x-scrolling to show the table in a viewport, which can be
		 * scrolled. This property can be `true` which will allow the table to
		 * scroll horizontally when needed, or any CSS unit, or a number (in which
		 * case it will be treated as a pixel measurement). Setting as simply `true`
		 * is recommended.
		 *  @type boolean|string
		 *  @default <i>blank string - i.e. disabled</i>
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.scrollX
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "scrollX": true,
		 *        "scrollCollapse": true
		 *      } );
		 *    } );
		 */
		"sScrollX": "",
	
	
		/**
		 * This property can be used to force a DataTable to use more width than it
		 * might otherwise do when x-scrolling is enabled. For example if you have a
		 * table which requires to be well spaced, this parameter is useful for
		 * "over-sizing" the table, and thus forcing scrolling. This property can by
		 * any CSS unit, or a number (in which case it will be treated as a pixel
		 * measurement).
		 *  @type string
		 *  @default <i>blank string - i.e. disabled</i>
		 *
		 *  @dtopt Options
		 *  @name DataTable.defaults.scrollXInner
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "scrollX": "100%",
		 *        "scrollXInner": "110%"
		 *      } );
		 *    } );
		 */
		"sScrollXInner": "",
	
	
		/**
		 * Enable vertical scrolling. Vertical scrolling will constrain the DataTable
		 * to the given height, and enable scrolling for any data which overflows the
		 * current viewport. This can be used as an alternative to paging to display
		 * a lot of data in a small area (although paging and scrolling can both be
		 * enabled at the same time). This property can be any CSS unit, or a number
		 * (in which case it will be treated as a pixel measurement).
		 *  @type string
		 *  @default <i>blank string - i.e. disabled</i>
		 *
		 *  @dtopt Features
		 *  @name DataTable.defaults.scrollY
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "scrollY": "200px",
		 *        "paginate": false
		 *      } );
		 *    } );
		 */
		"sScrollY": "",
	
	
		/**
		 * __Deprecated__ The functionality provided by this parameter has now been
		 * superseded by that provided through `ajax`, which should be used instead.
		 *
		 * Set the HTTP method that is used to make the Ajax call for server-side
		 * processing or Ajax sourced data.
		 *  @type string
		 *  @default GET
		 *
		 *  @dtopt Options
		 *  @dtopt Server-side
		 *  @name DataTable.defaults.serverMethod
		 *
		 *  @deprecated 1.10. Please use `ajax` for this functionality now.
		 */
		"sServerMethod": "GET",
	
	
		/**
		 * DataTables makes use of renderers when displaying HTML elements for
		 * a table. These renderers can be added or modified by plug-ins to
		 * generate suitable mark-up for a site. For example the Bootstrap
		 * integration plug-in for DataTables uses a paging button renderer to
		 * display pagination buttons in the mark-up required by Bootstrap.
		 *
		 * For further information about the renderers available see
		 * DataTable.ext.renderer
		 *  @type string|object
		 *  @default null
		 *
		 *  @name DataTable.defaults.renderer
		 *
		 */
		"renderer": null,
	
	
		/**
		 * Set the data property name that DataTables should use to get a row's id
		 * to set as the `id` property in the node.
		 *  @type string
		 *  @default DT_RowId
		 *
		 *  @name DataTable.defaults.rowId
		 */
		"rowId": "DT_RowId"
	};
	
	_fnHungarianMap( DataTable.defaults );
	
	
	
	/*
	 * Developer note - See note in model.defaults.js about the use of Hungarian
	 * notation and camel case.
	 */
	
	/**
	 * Column options that can be given to DataTables at initialisation time.
	 *  @namespace
	 */
	DataTable.defaults.column = {
		/**
		 * Define which column(s) an order will occur on for this column. This
		 * allows a column's ordering to take multiple columns into account when
		 * doing a sort or use the data from a different column. For example first
		 * name / last name columns make sense to do a multi-column sort over the
		 * two columns.
		 *  @type array|int
		 *  @default null <i>Takes the value of the column index automatically</i>
		 *
		 *  @name DataTable.defaults.column.orderData
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "orderData": [ 0, 1 ], "targets": [ 0 ] },
		 *          { "orderData": [ 1, 0 ], "targets": [ 1 ] },
		 *          { "orderData": 2, "targets": [ 2 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "orderData": [ 0, 1 ] },
		 *          { "orderData": [ 1, 0 ] },
		 *          { "orderData": 2 },
		 *          null,
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"aDataSort": null,
		"iDataSort": -1,
	
	
		/**
		 * You can control the default ordering direction, and even alter the
		 * behaviour of the sort handler (i.e. only allow ascending ordering etc)
		 * using this parameter.
		 *  @type array
		 *  @default [ 'asc', 'desc' ]
		 *
		 *  @name DataTable.defaults.column.orderSequence
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "orderSequence": [ "asc" ], "targets": [ 1 ] },
		 *          { "orderSequence": [ "desc", "asc", "asc" ], "targets": [ 2 ] },
		 *          { "orderSequence": [ "desc" ], "targets": [ 3 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          null,
		 *          { "orderSequence": [ "asc" ] },
		 *          { "orderSequence": [ "desc", "asc", "asc" ] },
		 *          { "orderSequence": [ "desc" ] },
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"asSorting": [ 'asc', 'desc' ],
	
	
		/**
		 * Enable or disable filtering on the data in this column.
		 *  @type boolean
		 *  @default true
		 *
		 *  @name DataTable.defaults.column.searchable
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "searchable": false, "targets": [ 0 ] }
		 *        ] } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "searchable": false },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ] } );
		 *    } );
		 */
		"bSearchable": true,
	
	
		/**
		 * Enable or disable ordering on this column.
		 *  @type boolean
		 *  @default true
		 *
		 *  @name DataTable.defaults.column.orderable
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "orderable": false, "targets": [ 0 ] }
		 *        ] } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "orderable": false },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ] } );
		 *    } );
		 */
		"bSortable": true,
	
	
		/**
		 * Enable or disable the display of this column.
		 *  @type boolean
		 *  @default true
		 *
		 *  @name DataTable.defaults.column.visible
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "visible": false, "targets": [ 0 ] }
		 *        ] } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "visible": false },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ] } );
		 *    } );
		 */
		"bVisible": true,
	
	
		/**
		 * Developer definable function that is called whenever a cell is created (Ajax source,
		 * etc) or processed for input (DOM source). This can be used as a compliment to mRender
		 * allowing you to modify the DOM element (add background colour for example) when the
		 * element is available.
		 *  @type function
		 *  @param {element} td The TD node that has been created
		 *  @param {*} cellData The Data for the cell
		 *  @param {array|object} rowData The data for the whole row
		 *  @param {int} row The row index for the aoData data store
		 *  @param {int} col The column index for aoColumns
		 *
		 *  @name DataTable.defaults.column.createdCell
		 *  @dtopt Columns
		 *
		 *  @example
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [3],
		 *          "createdCell": function (td, cellData, rowData, row, col) {
		 *            if ( cellData == "1.7" ) {
		 *              $(td).css('color', 'blue')
		 *            }
		 *          }
		 *        } ]
		 *      });
		 *    } );
		 */
		"fnCreatedCell": null,
	
	
		/**
		 * This parameter has been replaced by `data` in DataTables to ensure naming
		 * consistency. `dataProp` can still be used, as there is backwards
		 * compatibility in DataTables for this option, but it is strongly
		 * recommended that you use `data` in preference to `dataProp`.
		 *  @name DataTable.defaults.column.dataProp
		 */
	
	
		/**
		 * This property can be used to read data from any data source property,
		 * including deeply nested objects / properties. `data` can be given in a
		 * number of different ways which effect its behaviour:
		 *
		 * * `integer` - treated as an array index for the data source. This is the
		 *   default that DataTables uses (incrementally increased for each column).
		 * * `string` - read an object property from the data source. There are
		 *   three 'special' options that can be used in the string to alter how
		 *   DataTables reads the data from the source object:
		 *    * `.` - Dotted Javascript notation. Just as you use a `.` in
		 *      Javascript to read from nested objects, so to can the options
		 *      specified in `data`. For example: `browser.version` or
		 *      `browser.name`. If your object parameter name contains a period, use
		 *      `\\` to escape it - i.e. `first\\.name`.
		 *    * `[]` - Array notation. DataTables can automatically combine data
		 *      from and array source, joining the data with the characters provided
		 *      between the two brackets. For example: `name[, ]` would provide a
		 *      comma-space separated list from the source array. If no characters
		 *      are provided between the brackets, the original array source is
		 *      returned.
		 *    * `()` - Function notation. Adding `()` to the end of a parameter will
		 *      execute a function of the name given. For example: `browser()` for a
		 *      simple function on the data source, `browser.version()` for a
		 *      function in a nested property or even `browser().version` to get an
		 *      object property if the function called returns an object. Note that
		 *      function notation is recommended for use in `render` rather than
		 *      `data` as it is much simpler to use as a renderer.
		 * * `null` - use the original data source for the row rather than plucking
		 *   data directly from it. This action has effects on two other
		 *   initialisation options:
		 *    * `defaultContent` - When null is given as the `data` option and
		 *      `defaultContent` is specified for the column, the value defined by
		 *      `defaultContent` will be used for the cell.
		 *    * `render` - When null is used for the `data` option and the `render`
		 *      option is specified for the column, the whole data source for the
		 *      row is used for the renderer.
		 * * `function` - the function given will be executed whenever DataTables
		 *   needs to set or get the data for a cell in the column. The function
		 *   takes three parameters:
		 *    * Parameters:
		 *      * `{array|object}` The data source for the row
		 *      * `{string}` The type call data requested - this will be 'set' when
		 *        setting data or 'filter', 'display', 'type', 'sort' or undefined
		 *        when gathering data. Note that when `undefined` is given for the
		 *        type DataTables expects to get the raw data for the object back<
		 *      * `{*}` Data to set when the second parameter is 'set'.
		 *    * Return:
		 *      * The return value from the function is not required when 'set' is
		 *        the type of call, but otherwise the return is what will be used
		 *        for the data requested.
		 *
		 * Note that `data` is a getter and setter option. If you just require
		 * formatting of data for output, you will likely want to use `render` which
		 * is simply a getter and thus simpler to use.
		 *
		 * Note that prior to DataTables 1.9.2 `data` was called `mDataProp`. The
		 * name change reflects the flexibility of this property and is consistent
		 * with the naming of mRender. If 'mDataProp' is given, then it will still
		 * be used by DataTables, as it automatically maps the old name to the new
		 * if required.
		 *
		 *  @type string|int|function|null
		 *  @default null <i>Use automatically calculated column index</i>
		 *
		 *  @name DataTable.defaults.column.data
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Read table data from objects
		 *    // JSON structure for each row:
		 *    //   {
		 *    //      "engine": {value},
		 *    //      "browser": {value},
		 *    //      "platform": {value},
		 *    //      "version": {value},
		 *    //      "grade": {value}
		 *    //   }
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "ajaxSource": "sources/objects.txt",
		 *        "columns": [
		 *          { "data": "engine" },
		 *          { "data": "browser" },
		 *          { "data": "platform" },
		 *          { "data": "version" },
		 *          { "data": "grade" }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Read information from deeply nested objects
		 *    // JSON structure for each row:
		 *    //   {
		 *    //      "engine": {value},
		 *    //      "browser": {value},
		 *    //      "platform": {
		 *    //         "inner": {value}
		 *    //      },
		 *    //      "details": [
		 *    //         {value}, {value}
		 *    //      ]
		 *    //   }
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "ajaxSource": "sources/deep.txt",
		 *        "columns": [
		 *          { "data": "engine" },
		 *          { "data": "browser" },
		 *          { "data": "platform.inner" },
		 *          { "data": "platform.details.0" },
		 *          { "data": "platform.details.1" }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `data` as a function to provide different information for
		 *    // sorting, filtering and display. In this case, currency (price)
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": function ( source, type, val ) {
		 *            if (type === 'set') {
		 *              source.price = val;
		 *              // Store the computed dislay and filter values for efficiency
		 *              source.price_display = val=="" ? "" : "$"+numberFormat(val);
		 *              source.price_filter  = val=="" ? "" : "$"+numberFormat(val)+" "+val;
		 *              return;
		 *            }
		 *            else if (type === 'display') {
		 *              return source.price_display;
		 *            }
		 *            else if (type === 'filter') {
		 *              return source.price_filter;
		 *            }
		 *            // 'sort', 'type' and undefined all just use the integer
		 *            return source.price;
		 *          }
		 *        } ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using default content
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": null,
		 *          "defaultContent": "Click to edit"
		 *        } ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using array notation - outputting a list from an array
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": "name[, ]"
		 *        } ]
		 *      } );
		 *    } );
		 *
		 */
		"mData": null,
	
	
		/**
		 * This property is the rendering partner to `data` and it is suggested that
		 * when you want to manipulate data for display (including filtering,
		 * sorting etc) without altering the underlying data for the table, use this
		 * property. `render` can be considered to be the the read only companion to
		 * `data` which is read / write (then as such more complex). Like `data`
		 * this option can be given in a number of different ways to effect its
		 * behaviour:
		 *
		 * * `integer` - treated as an array index for the data source. This is the
		 *   default that DataTables uses (incrementally increased for each column).
		 * * `string` - read an object property from the data source. There are
		 *   three 'special' options that can be used in the string to alter how
		 *   DataTables reads the data from the source object:
		 *    * `.` - Dotted Javascript notation. Just as you use a `.` in
		 *      Javascript to read from nested objects, so to can the options
		 *      specified in `data`. For example: `browser.version` or
		 *      `browser.name`. If your object parameter name contains a period, use
		 *      `\\` to escape it - i.e. `first\\.name`.
		 *    * `[]` - Array notation. DataTables can automatically combine data
		 *      from and array source, joining the data with the characters provided
		 *      between the two brackets. For example: `name[, ]` would provide a
		 *      comma-space separated list from the source array. If no characters
		 *      are provided between the brackets, the original array source is
		 *      returned.
		 *    * `()` - Function notation. Adding `()` to the end of a parameter will
		 *      execute a function of the name given. For example: `browser()` for a
		 *      simple function on the data source, `browser.version()` for a
		 *      function in a nested property or even `browser().version` to get an
		 *      object property if the function called returns an object.
		 * * `object` - use different data for the different data types requested by
		 *   DataTables ('filter', 'display', 'type' or 'sort'). The property names
		 *   of the object is the data type the property refers to and the value can
		 *   defined using an integer, string or function using the same rules as
		 *   `render` normally does. Note that an `_` option _must_ be specified.
		 *   This is the default value to use if you haven't specified a value for
		 *   the data type requested by DataTables.
		 * * `function` - the function given will be executed whenever DataTables
		 *   needs to set or get the data for a cell in the column. The function
		 *   takes three parameters:
		 *    * Parameters:
		 *      * {array|object} The data source for the row (based on `data`)
		 *      * {string} The type call data requested - this will be 'filter',
		 *        'display', 'type' or 'sort'.
		 *      * {array|object} The full data source for the row (not based on
		 *        `data`)
		 *    * Return:
		 *      * The return value from the function is what will be used for the
		 *        data requested.
		 *
		 *  @type string|int|function|object|null
		 *  @default null Use the data source value.
		 *
		 *  @name DataTable.defaults.column.render
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Create a comma separated list from an array of objects
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "ajaxSource": "sources/deep.txt",
		 *        "columns": [
		 *          { "data": "engine" },
		 *          { "data": "browser" },
		 *          {
		 *            "data": "platform",
		 *            "render": "[, ].name"
		 *          }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Execute a function to obtain data
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": null, // Use the full data source object for the renderer's source
		 *          "render": "browserName()"
		 *        } ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // As an object, extracting different data for the different types
		 *    // This would be used with a data source such as:
		 *    //   { "phone": 5552368, "phone_filter": "5552368 555-2368", "phone_display": "555-2368" }
		 *    // Here the `phone` integer is used for sorting and type detection, while `phone_filter`
		 *    // (which has both forms) is used for filtering for if a user inputs either format, while
		 *    // the formatted phone number is the one that is shown in the table.
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": null, // Use the full data source object for the renderer's source
		 *          "render": {
		 *            "_": "phone",
		 *            "filter": "phone_filter",
		 *            "display": "phone_display"
		 *          }
		 *        } ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Use as a function to create a link from the data source
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "data": "download_link",
		 *          "render": function ( data, type, full ) {
		 *            return '<a href="'+data+'">Download</a>';
		 *          }
		 *        } ]
		 *      } );
		 *    } );
		 */
		"mRender": null,
	
	
		/**
		 * Change the cell type created for the column - either TD cells or TH cells. This
		 * can be useful as TH cells have semantic meaning in the table body, allowing them
		 * to act as a header for a row (you may wish to add scope='row' to the TH elements).
		 *  @type string
		 *  @default td
		 *
		 *  @name DataTable.defaults.column.cellType
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Make the first column use TH cells
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [ {
		 *          "targets": [ 0 ],
		 *          "cellType": "th"
		 *        } ]
		 *      } );
		 *    } );
		 */
		"sCellType": "td",
	
	
		/**
		 * Class to give to each cell in this column.
		 *  @type string
		 *  @default <i>Empty string</i>
		 *
		 *  @name DataTable.defaults.column.class
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "class": "my_class", "targets": [ 0 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "class": "my_class" },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"sClass": "",
	
		/**
		 * When DataTables calculates the column widths to assign to each column,
		 * it finds the longest string in each column and then constructs a
		 * temporary table and reads the widths from that. The problem with this
		 * is that "mmm" is much wider then "iiii", but the latter is a longer
		 * string - thus the calculation can go wrong (doing it properly and putting
		 * it into an DOM object and measuring that is horribly(!) slow). Thus as
		 * a "work around" we provide this option. It will append its value to the
		 * text that is found to be the longest string for the column - i.e. padding.
		 * Generally you shouldn't need this!
		 *  @type string
		 *  @default <i>Empty string<i>
		 *
		 *  @name DataTable.defaults.column.contentPadding
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          null,
		 *          null,
		 *          null,
		 *          {
		 *            "contentPadding": "mmm"
		 *          }
		 *        ]
		 *      } );
		 *    } );
		 */
		"sContentPadding": "",
	
	
		/**
		 * Allows a default value to be given for a column's data, and will be used
		 * whenever a null data source is encountered (this can be because `data`
		 * is set to null, or because the data source itself is null).
		 *  @type string
		 *  @default null
		 *
		 *  @name DataTable.defaults.column.defaultContent
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          {
		 *            "data": null,
		 *            "defaultContent": "Edit",
		 *            "targets": [ -1 ]
		 *          }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          null,
		 *          null,
		 *          null,
		 *          {
		 *            "data": null,
		 *            "defaultContent": "Edit"
		 *          }
		 *        ]
		 *      } );
		 *    } );
		 */
		"sDefaultContent": null,
	
	
		/**
		 * This parameter is only used in DataTables' server-side processing. It can
		 * be exceptionally useful to know what columns are being displayed on the
		 * client side, and to map these to database fields. When defined, the names
		 * also allow DataTables to reorder information from the server if it comes
		 * back in an unexpected order (i.e. if you switch your columns around on the
		 * client-side, your server-side code does not also need updating).
		 *  @type string
		 *  @default <i>Empty string</i>
		 *
		 *  @name DataTable.defaults.column.name
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "name": "engine", "targets": [ 0 ] },
		 *          { "name": "browser", "targets": [ 1 ] },
		 *          { "name": "platform", "targets": [ 2 ] },
		 *          { "name": "version", "targets": [ 3 ] },
		 *          { "name": "grade", "targets": [ 4 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "name": "engine" },
		 *          { "name": "browser" },
		 *          { "name": "platform" },
		 *          { "name": "version" },
		 *          { "name": "grade" }
		 *        ]
		 *      } );
		 *    } );
		 */
		"sName": "",
	
	
		/**
		 * Defines a data source type for the ordering which can be used to read
		 * real-time information from the table (updating the internally cached
		 * version) prior to ordering. This allows ordering to occur on user
		 * editable elements such as form inputs.
		 *  @type string
		 *  @default std
		 *
		 *  @name DataTable.defaults.column.orderDataType
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "orderDataType": "dom-text", "targets": [ 2, 3 ] },
		 *          { "type": "numeric", "targets": [ 3 ] },
		 *          { "orderDataType": "dom-select", "targets": [ 4 ] },
		 *          { "orderDataType": "dom-checkbox", "targets": [ 5 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          null,
		 *          null,
		 *          { "orderDataType": "dom-text" },
		 *          { "orderDataType": "dom-text", "type": "numeric" },
		 *          { "orderDataType": "dom-select" },
		 *          { "orderDataType": "dom-checkbox" }
		 *        ]
		 *      } );
		 *    } );
		 */
		"sSortDataType": "std",
	
	
		/**
		 * The title of this column.
		 *  @type string
		 *  @default null <i>Derived from the 'TH' value for this column in the
		 *    original HTML table.</i>
		 *
		 *  @name DataTable.defaults.column.title
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "title": "My column title", "targets": [ 0 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "title": "My column title" },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"sTitle": null,
	
	
		/**
		 * The type allows you to specify how the data for this column will be
		 * ordered. Four types (string, numeric, date and html (which will strip
		 * HTML tags before ordering)) are currently available. Note that only date
		 * formats understood by Javascript's Date() object will be accepted as type
		 * date. For example: "Mar 26, 2008 5:03 PM". May take the values: 'string',
		 * 'numeric', 'date' or 'html' (by default). Further types can be adding
		 * through plug-ins.
		 *  @type string
		 *  @default null <i>Auto-detected from raw data</i>
		 *
		 *  @name DataTable.defaults.column.type
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "type": "html", "targets": [ 0 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "type": "html" },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"sType": null,
	
	
		/**
		 * Defining the width of the column, this parameter may take any CSS value
		 * (3em, 20px etc). DataTables applies 'smart' widths to columns which have not
		 * been given a specific width through this interface ensuring that the table
		 * remains readable.
		 *  @type string
		 *  @default null <i>Automatic</i>
		 *
		 *  @name DataTable.defaults.column.width
		 *  @dtopt Columns
		 *
		 *  @example
		 *    // Using `columnDefs`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columnDefs": [
		 *          { "width": "20%", "targets": [ 0 ] }
		 *        ]
		 *      } );
		 *    } );
		 *
		 *  @example
		 *    // Using `columns`
		 *    $(document).ready( function() {
		 *      $('#example').dataTable( {
		 *        "columns": [
		 *          { "width": "20%" },
		 *          null,
		 *          null,
		 *          null,
		 *          null
		 *        ]
		 *      } );
		 *    } );
		 */
		"sWidth": null
	};
	
	_fnHungarianMap( DataTable.defaults.column );
	
	
	
	/**
	 * DataTables settings object - this holds all the information needed for a
	 * given table, including configuration, data and current application of the
	 * table options. DataTables does not have a single instance for each DataTable
	 * with the settings attached to that instance, but rather instances of the
	 * DataTable "class" are created on-the-fly as needed (typically by a
	 * $().dataTable() call) and the settings object is then applied to that
	 * instance.
	 *
	 * Note that this object is related to {@link DataTable.defaults} but this
	 * one is the internal data store for DataTables's cache of columns. It should
	 * NOT be manipulated outside of DataTables. Any configuration should be done
	 * through the initialisation options.
	 *  @namespace
	 *  @todo Really should attach the settings object to individual instances so we
	 *    don't need to create new instances on each $().dataTable() call (if the
	 *    table already exists). It would also save passing oSettings around and
	 *    into every single function. However, this is a very significant
	 *    architecture change for DataTables and will almost certainly break
	 *    backwards compatibility with older installations. This is something that
	 *    will be done in 2.0.
	 */
	DataTable.models.oSettings = {
		/**
		 * Primary features of DataTables and their enablement state.
		 *  @namespace
		 */
		"oFeatures": {
	
			/**
			 * Flag to say if DataTables should automatically try to calculate the
			 * optimum table and columns widths (true) or not (false).
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bAutoWidth": null,
	
			/**
			 * Delay the creation of TR and TD elements until they are actually
			 * needed by a driven page draw. This can give a significant speed
			 * increase for Ajax source and Javascript source data, but makes no
			 * difference at all fro DOM and server-side processing tables.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bDeferRender": null,
	
			/**
			 * Enable filtering on the table or not. Note that if this is disabled
			 * then there is no filtering at all on the table, including fnFilter.
			 * To just remove the filtering input use sDom and remove the 'f' option.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bFilter": null,
	
			/**
			 * Table information element (the 'Showing x of y records' div) enable
			 * flag.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bInfo": null,
	
			/**
			 * Present a user control allowing the end user to change the page size
			 * when pagination is enabled.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bLengthChange": null,
	
			/**
			 * Pagination enabled or not. Note that if this is disabled then length
			 * changing must also be disabled.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bPaginate": null,
	
			/**
			 * Processing indicator enable flag whenever DataTables is enacting a
			 * user request - typically an Ajax request for server-side processing.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bProcessing": null,
	
			/**
			 * Server-side processing enabled flag - when enabled DataTables will
			 * get all data from the server for every draw - there is no filtering,
			 * sorting or paging done on the client-side.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bServerSide": null,
	
			/**
			 * Sorting enablement flag.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bSort": null,
	
			/**
			 * Multi-column sorting
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bSortMulti": null,
	
			/**
			 * Apply a class to the columns which are being sorted to provide a
			 * visual highlight or not. This can slow things down when enabled since
			 * there is a lot of DOM interaction.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bSortClasses": null,
	
			/**
			 * State saving enablement flag.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bStateSave": null
		},
	
	
		/**
		 * Scrolling settings for a table.
		 *  @namespace
		 */
		"oScroll": {
			/**
			 * When the table is shorter in height than sScrollY, collapse the
			 * table container down to the height of the table (when true).
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type boolean
			 */
			"bCollapse": null,
	
			/**
			 * Width of the scrollbar for the web-browser's platform. Calculated
			 * during table initialisation.
			 *  @type int
			 *  @default 0
			 */
			"iBarWidth": 0,
	
			/**
			 * Viewport width for horizontal scrolling. Horizontal scrolling is
			 * disabled if an empty string.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type string
			 */
			"sX": null,
	
			/**
			 * Width to expand the table to when using x-scrolling. Typically you
			 * should not need to use this.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type string
			 *  @deprecated
			 */
			"sXInner": null,
	
			/**
			 * Viewport height for vertical scrolling. Vertical scrolling is disabled
			 * if an empty string.
			 * Note that this parameter will be set by the initialisation routine. To
			 * set a default use {@link DataTable.defaults}.
			 *  @type string
			 */
			"sY": null
		},
	
		/**
		 * Language information for the table.
		 *  @namespace
		 *  @extends DataTable.defaults.oLanguage
		 */
		"oLanguage": {
			/**
			 * Information callback function. See
			 * {@link DataTable.defaults.fnInfoCallback}
			 *  @type function
			 *  @default null
			 */
			"fnInfoCallback": null
		},
	
		/**
		 * Browser support parameters
		 *  @namespace
		 */
		"oBrowser": {
			/**
			 * Indicate if the browser incorrectly calculates width:100% inside a
			 * scrolling element (IE6/7)
			 *  @type boolean
			 *  @default false
			 */
			"bScrollOversize": false,
	
			/**
			 * Determine if the vertical scrollbar is on the right or left of the
			 * scrolling container - needed for rtl language layout, although not
			 * all browsers move the scrollbar (Safari).
			 *  @type boolean
			 *  @default false
			 */
			"bScrollbarLeft": false,
	
			/**
			 * Flag for if `getBoundingClientRect` is fully supported or not
			 *  @type boolean
			 *  @default false
			 */
			"bBounding": false,
	
			/**
			 * Browser scrollbar width
			 *  @type integer
			 *  @default 0
			 */
			"barWidth": 0
		},
	
	
		"ajax": null,
	
	
		/**
		 * Array referencing the nodes which are used for the features. The
		 * parameters of this object match what is allowed by sDom - i.e.
		 *   <ul>
		 *     <li>'l' - Length changing</li>
		 *     <li>'f' - Filtering input</li>
		 *     <li>'t' - The table!</li>
		 *     <li>'i' - Information</li>
		 *     <li>'p' - Pagination</li>
		 *     <li>'r' - pRocessing</li>
		 *   </ul>
		 *  @type array
		 *  @default []
		 */
		"aanFeatures": [],
	
		/**
		 * Store data information - see {@link DataTable.models.oRow} for detailed
		 * information.
		 *  @type array
		 *  @default []
		 */
		"aoData": [],
	
		/**
		 * Array of indexes which are in the current display (after filtering etc)
		 *  @type array
		 *  @default []
		 */
		"aiDisplay": [],
	
		/**
		 * Array of indexes for display - no filtering
		 *  @type array
		 *  @default []
		 */
		"aiDisplayMaster": [],
	
		/**
		 * Map of row ids to data indexes
		 *  @type object
		 *  @default {}
		 */
		"aIds": {},
	
		/**
		 * Store information about each column that is in use
		 *  @type array
		 *  @default []
		 */
		"aoColumns": [],
	
		/**
		 * Store information about the table's header
		 *  @type array
		 *  @default []
		 */
		"aoHeader": [],
	
		/**
		 * Store information about the table's footer
		 *  @type array
		 *  @default []
		 */
		"aoFooter": [],
	
		/**
		 * Store the applied global search information in case we want to force a
		 * research or compare the old search to a new one.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @namespace
		 *  @extends DataTable.models.oSearch
		 */
		"oPreviousSearch": {},
	
		/**
		 * Store the applied search for each column - see
		 * {@link DataTable.models.oSearch} for the format that is used for the
		 * filtering information for each column.
		 *  @type array
		 *  @default []
		 */
		"aoPreSearchCols": [],
	
		/**
		 * Sorting that is applied to the table. Note that the inner arrays are
		 * used in the following manner:
		 * <ul>
		 *   <li>Index 0 - column number</li>
		 *   <li>Index 1 - current sorting direction</li>
		 * </ul>
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type array
		 *  @todo These inner arrays should really be objects
		 */
		"aaSorting": null,
	
		/**
		 * Sorting that is always applied to the table (i.e. prefixed in front of
		 * aaSorting).
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type array
		 *  @default []
		 */
		"aaSortingFixed": [],
	
		/**
		 * Classes to use for the striping of a table.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type array
		 *  @default []
		 */
		"asStripeClasses": null,
	
		/**
		 * If restoring a table - we should restore its striping classes as well
		 *  @type array
		 *  @default []
		 */
		"asDestroyStripes": [],
	
		/**
		 * If restoring a table - we should restore its width
		 *  @type int
		 *  @default 0
		 */
		"sDestroyWidth": 0,
	
		/**
		 * Callback functions array for every time a row is inserted (i.e. on a draw).
		 *  @type array
		 *  @default []
		 */
		"aoRowCallback": [],
	
		/**
		 * Callback functions for the header on each draw.
		 *  @type array
		 *  @default []
		 */
		"aoHeaderCallback": [],
	
		/**
		 * Callback function for the footer on each draw.
		 *  @type array
		 *  @default []
		 */
		"aoFooterCallback": [],
	
		/**
		 * Array of callback functions for draw callback functions
		 *  @type array
		 *  @default []
		 */
		"aoDrawCallback": [],
	
		/**
		 * Array of callback functions for row created function
		 *  @type array
		 *  @default []
		 */
		"aoRowCreatedCallback": [],
	
		/**
		 * Callback functions for just before the table is redrawn. A return of
		 * false will be used to cancel the draw.
		 *  @type array
		 *  @default []
		 */
		"aoPreDrawCallback": [],
	
		/**
		 * Callback functions for when the table has been initialised.
		 *  @type array
		 *  @default []
		 */
		"aoInitComplete": [],
	
	
		/**
		 * Callbacks for modifying the settings to be stored for state saving, prior to
		 * saving state.
		 *  @type array
		 *  @default []
		 */
		"aoStateSaveParams": [],
	
		/**
		 * Callbacks for modifying the settings that have been stored for state saving
		 * prior to using the stored values to restore the state.
		 *  @type array
		 *  @default []
		 */
		"aoStateLoadParams": [],
	
		/**
		 * Callbacks for operating on the settings object once the saved state has been
		 * loaded
		 *  @type array
		 *  @default []
		 */
		"aoStateLoaded": [],
	
		/**
		 * Cache the table ID for quick access
		 *  @type string
		 *  @default <i>Empty string</i>
		 */
		"sTableId": "",
	
		/**
		 * The TABLE node for the main table
		 *  @type node
		 *  @default null
		 */
		"nTable": null,
	
		/**
		 * Permanent ref to the thead element
		 *  @type node
		 *  @default null
		 */
		"nTHead": null,
	
		/**
		 * Permanent ref to the tfoot element - if it exists
		 *  @type node
		 *  @default null
		 */
		"nTFoot": null,
	
		/**
		 * Permanent ref to the tbody element
		 *  @type node
		 *  @default null
		 */
		"nTBody": null,
	
		/**
		 * Cache the wrapper node (contains all DataTables controlled elements)
		 *  @type node
		 *  @default null
		 */
		"nTableWrapper": null,
	
		/**
		 * Indicate if when using server-side processing the loading of data
		 * should be deferred until the second draw.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type boolean
		 *  @default false
		 */
		"bDeferLoading": false,
	
		/**
		 * Indicate if all required information has been read in
		 *  @type boolean
		 *  @default false
		 */
		"bInitialised": false,
	
		/**
		 * Information about open rows. Each object in the array has the parameters
		 * 'nTr' and 'nParent'
		 *  @type array
		 *  @default []
		 */
		"aoOpenRows": [],
	
		/**
		 * Dictate the positioning of DataTables' control elements - see
		 * {@link DataTable.model.oInit.sDom}.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type string
		 *  @default null
		 */
		"sDom": null,
	
		/**
		 * Search delay (in mS)
		 *  @type integer
		 *  @default null
		 */
		"searchDelay": null,
	
		/**
		 * Which type of pagination should be used.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type string
		 *  @default two_button
		 */
		"sPaginationType": "two_button",
	
		/**
		 * The state duration (for `stateSave`) in seconds.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type int
		 *  @default 0
		 */
		"iStateDuration": 0,
	
		/**
		 * Array of callback functions for state saving. Each array element is an
		 * object with the following parameters:
		 *   <ul>
		 *     <li>function:fn - function to call. Takes two parameters, oSettings
		 *       and the JSON string to save that has been thus far created. Returns
		 *       a JSON string to be inserted into a json object
		 *       (i.e. '"param": [ 0, 1, 2]')</li>
		 *     <li>string:sName - name of callback</li>
		 *   </ul>
		 *  @type array
		 *  @default []
		 */
		"aoStateSave": [],
	
		/**
		 * Array of callback functions for state loading. Each array element is an
		 * object with the following parameters:
		 *   <ul>
		 *     <li>function:fn - function to call. Takes two parameters, oSettings
		 *       and the object stored. May return false to cancel state loading</li>
		 *     <li>string:sName - name of callback</li>
		 *   </ul>
		 *  @type array
		 *  @default []
		 */
		"aoStateLoad": [],
	
		/**
		 * State that was saved. Useful for back reference
		 *  @type object
		 *  @default null
		 */
		"oSavedState": null,
	
		/**
		 * State that was loaded. Useful for back reference
		 *  @type object
		 *  @default null
		 */
		"oLoadedState": null,
	
		/**
		 * Source url for AJAX data for the table.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type string
		 *  @default null
		 */
		"sAjaxSource": null,
	
		/**
		 * Property from a given object from which to read the table data from. This
		 * can be an empty string (when not server-side processing), in which case
		 * it is  assumed an an array is given directly.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type string
		 */
		"sAjaxDataProp": null,
	
		/**
		 * Note if draw should be blocked while getting data
		 *  @type boolean
		 *  @default true
		 */
		"bAjaxDataGet": true,
	
		/**
		 * The last jQuery XHR object that was used for server-side data gathering.
		 * This can be used for working with the XHR information in one of the
		 * callbacks
		 *  @type object
		 *  @default null
		 */
		"jqXHR": null,
	
		/**
		 * JSON returned from the server in the last Ajax request
		 *  @type object
		 *  @default undefined
		 */
		"json": undefined,
	
		/**
		 * Data submitted as part of the last Ajax request
		 *  @type object
		 *  @default undefined
		 */
		"oAjaxData": undefined,
	
		/**
		 * Function to get the server-side data.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type function
		 */
		"fnServerData": null,
	
		/**
		 * Functions which are called prior to sending an Ajax request so extra
		 * parameters can easily be sent to the server
		 *  @type array
		 *  @default []
		 */
		"aoServerParams": [],
	
		/**
		 * Send the XHR HTTP method - GET or POST (could be PUT or DELETE if
		 * required).
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type string
		 */
		"sServerMethod": null,
	
		/**
		 * Format numbers for display.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type function
		 */
		"fnFormatNumber": null,
	
		/**
		 * List of options that can be used for the user selectable length menu.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type array
		 *  @default []
		 */
		"aLengthMenu": null,
	
		/**
		 * Counter for the draws that the table does. Also used as a tracker for
		 * server-side processing
		 *  @type int
		 *  @default 0
		 */
		"iDraw": 0,
	
		/**
		 * Indicate if a redraw is being done - useful for Ajax
		 *  @type boolean
		 *  @default false
		 */
		"bDrawing": false,
	
		/**
		 * Draw index (iDraw) of the last error when parsing the returned data
		 *  @type int
		 *  @default -1
		 */
		"iDrawError": -1,
	
		/**
		 * Paging display length
		 *  @type int
		 *  @default 10
		 */
		"_iDisplayLength": 10,
	
		/**
		 * Paging start point - aiDisplay index
		 *  @type int
		 *  @default 0
		 */
		"_iDisplayStart": 0,
	
		/**
		 * Server-side processing - number of records in the result set
		 * (i.e. before filtering), Use fnRecordsTotal rather than
		 * this property to get the value of the number of records, regardless of
		 * the server-side processing setting.
		 *  @type int
		 *  @default 0
		 *  @private
		 */
		"_iRecordsTotal": 0,
	
		/**
		 * Server-side processing - number of records in the current display set
		 * (i.e. after filtering). Use fnRecordsDisplay rather than
		 * this property to get the value of the number of records, regardless of
		 * the server-side processing setting.
		 *  @type boolean
		 *  @default 0
		 *  @private
		 */
		"_iRecordsDisplay": 0,
	
		/**
		 * The classes to use for the table
		 *  @type object
		 *  @default {}
		 */
		"oClasses": {},
	
		/**
		 * Flag attached to the settings object so you can check in the draw
		 * callback if filtering has been done in the draw. Deprecated in favour of
		 * events.
		 *  @type boolean
		 *  @default false
		 *  @deprecated
		 */
		"bFiltered": false,
	
		/**
		 * Flag attached to the settings object so you can check in the draw
		 * callback if sorting has been done in the draw. Deprecated in favour of
		 * events.
		 *  @type boolean
		 *  @default false
		 *  @deprecated
		 */
		"bSorted": false,
	
		/**
		 * Indicate that if multiple rows are in the header and there is more than
		 * one unique cell per column, if the top one (true) or bottom one (false)
		 * should be used for sorting / title by DataTables.
		 * Note that this parameter will be set by the initialisation routine. To
		 * set a default use {@link DataTable.defaults}.
		 *  @type boolean
		 */
		"bSortCellsTop": null,
	
		/**
		 * Initialisation object that is used for the table
		 *  @type object
		 *  @default null
		 */
		"oInit": null,
	
		/**
		 * Destroy callback functions - for plug-ins to attach themselves to the
		 * destroy so they can clean up markup and events.
		 *  @type array
		 *  @default []
		 */
		"aoDestroyCallback": [],
	
	
		/**
		 * Get the number of records in the current record set, before filtering
		 *  @type function
		 */
		"fnRecordsTotal": function ()
		{
			return _fnDataSource( this ) == 'ssp' ?
				this._iRecordsTotal * 1 :
				this.aiDisplayMaster.length;
		},
	
		/**
		 * Get the number of records in the current record set, after filtering
		 *  @type function
		 */
		"fnRecordsDisplay": function ()
		{
			return _fnDataSource( this ) == 'ssp' ?
				this._iRecordsDisplay * 1 :
				this.aiDisplay.length;
		},
	
		/**
		 * Get the display end point - aiDisplay index
		 *  @type function
		 */
		"fnDisplayEnd": function ()
		{
			var
				len      = this._iDisplayLength,
				start    = this._iDisplayStart,
				calc     = start + len,
				records  = this.aiDisplay.length,
				features = this.oFeatures,
				paginate = features.bPaginate;
	
			if ( features.bServerSide ) {
				return paginate === false || len === -1 ?
					start + records :
					Math.min( start+len, this._iRecordsDisplay );
			}
			else {
				return ! paginate || calc>records || len===-1 ?
					records :
					calc;
			}
		},
	
		/**
		 * The DataTables object for this table
		 *  @type object
		 *  @default null
		 */
		"oInstance": null,
	
		/**
		 * Unique identifier for each instance of the DataTables object. If there
		 * is an ID on the table node, then it takes that value, otherwise an
		 * incrementing internal counter is used.
		 *  @type string
		 *  @default null
		 */
		"sInstance": null,
	
		/**
		 * tabindex attribute value that is added to DataTables control elements, allowing
		 * keyboard navigation of the table and its controls.
		 */
		"iTabIndex": 0,
	
		/**
		 * DIV container for the footer scrolling table if scrolling
		 */
		"nScrollHead": null,
	
		/**
		 * DIV container for the footer scrolling table if scrolling
		 */
		"nScrollFoot": null,
	
		/**
		 * Last applied sort
		 *  @type array
		 *  @default []
		 */
		"aLastSort": [],
	
		/**
		 * Stored plug-in instances
		 *  @type object
		 *  @default {}
		 */
		"oPlugins": {},
	
		/**
		 * Function used to get a row's id from the row's data
		 *  @type function
		 *  @default null
		 */
		"rowIdFn": null,
	
		/**
		 * Data location where to store a row's id
		 *  @type string
		 *  @default null
		 */
		"rowId": null
	};

	/**
	 * Extension object for DataTables that is used to provide all extension
	 * options.
	 *
	 * Note that the `DataTable.ext` object is available through
	 * `jQuery.fn.dataTable.ext` where it may be accessed and manipulated. It is
	 * also aliased to `jQuery.fn.dataTableExt` for historic reasons.
	 *  @namespace
	 *  @extends DataTable.models.ext
	 */
	
	
	/**
	 * DataTables extensions
	 * 
	 * This namespace acts as a collection area for plug-ins that can be used to
	 * extend DataTables capabilities. Indeed many of the build in methods
	 * use this method to provide their own capabilities (sorting methods for
	 * example).
	 *
	 * Note that this namespace is aliased to `jQuery.fn.dataTableExt` for legacy
	 * reasons
	 *
	 *  @namespace
	 */
	DataTable.ext = _ext = {
		/**
		 * Buttons. For use with the Buttons extension for DataTables. This is
		 * defined here so other extensions can define buttons regardless of load
		 * order. It is _not_ used by DataTables core.
		 *
		 *  @type object
		 *  @default {}
		 */
		buttons: {},
	
	
		/**
		 * Element class names
		 *
		 *  @type object
		 *  @default {}
		 */
		classes: {},
	
	
		/**
		 * DataTables build type (expanded by the download builder)
		 *
		 *  @type string
		 */
		build:"dt/dt-1.10.16/e-1.6.5/b-1.4.2/b-print-1.4.2/r-2.2.0",
	
	
		/**
		 * Error reporting.
		 * 
		 * How should DataTables report an error. Can take the value 'alert',
		 * 'throw', 'none' or a function.
		 *
		 *  @type string|function
		 *  @default alert
		 */
		errMode: "alert",
	
	
		/**
		 * Feature plug-ins.
		 * 
		 * This is an array of objects which describe the feature plug-ins that are
		 * available to DataTables. These feature plug-ins are then available for
		 * use through the `dom` initialisation option.
		 * 
		 * Each feature plug-in is described by an object which must have the
		 * following properties:
		 * 
		 * * `fnInit` - function that is used to initialise the plug-in,
		 * * `cFeature` - a character so the feature can be enabled by the `dom`
		 *   instillation option. This is case sensitive.
		 *
		 * The `fnInit` function has the following input parameters:
		 *
		 * 1. `{object}` DataTables settings object: see
		 *    {@link DataTable.models.oSettings}
		 *
		 * And the following return is expected:
		 * 
		 * * {node|null} The element which contains your feature. Note that the
		 *   return may also be void if your plug-in does not require to inject any
		 *   DOM elements into DataTables control (`dom`) - for example this might
		 *   be useful when developing a plug-in which allows table control via
		 *   keyboard entry
		 *
		 *  @type array
		 *
		 *  @example
		 *    $.fn.dataTable.ext.features.push( {
		 *      "fnInit": function( oSettings ) {
		 *        return new TableTools( { "oDTSettings": oSettings } );
		 *      },
		 *      "cFeature": "T"
		 *    } );
		 */
		feature: [],
	
	
		/**
		 * Row searching.
		 * 
		 * This method of searching is complimentary to the default type based
		 * searching, and a lot more comprehensive as it allows you complete control
		 * over the searching logic. Each element in this array is a function
		 * (parameters described below) that is called for every row in the table,
		 * and your logic decides if it should be included in the searching data set
		 * or not.
		 *
		 * Searching functions have the following input parameters:
		 *
		 * 1. `{object}` DataTables settings object: see
		 *    {@link DataTable.models.oSettings}
		 * 2. `{array|object}` Data for the row to be processed (same as the
		 *    original format that was passed in as the data source, or an array
		 *    from a DOM data source
		 * 3. `{int}` Row index ({@link DataTable.models.oSettings.aoData}), which
		 *    can be useful to retrieve the `TR` element if you need DOM interaction.
		 *
		 * And the following return is expected:
		 *
		 * * {boolean} Include the row in the searched result set (true) or not
		 *   (false)
		 *
		 * Note that as with the main search ability in DataTables, technically this
		 * is "filtering", since it is subtractive. However, for consistency in
		 * naming we call it searching here.
		 *
		 *  @type array
		 *  @default []
		 *
		 *  @example
		 *    // The following example shows custom search being applied to the
		 *    // fourth column (i.e. the data[3] index) based on two input values
		 *    // from the end-user, matching the data in a certain range.
		 *    $.fn.dataTable.ext.search.push(
		 *      function( settings, data, dataIndex ) {
		 *        var min = document.getElementById('min').value * 1;
		 *        var max = document.getElementById('max').value * 1;
		 *        var version = data[3] == "-" ? 0 : data[3]*1;
		 *
		 *        if ( min == "" && max == "" ) {
		 *          return true;
		 *        }
		 *        else if ( min == "" && version < max ) {
		 *          return true;
		 *        }
		 *        else if ( min < version && "" == max ) {
		 *          return true;
		 *        }
		 *        else if ( min < version && version < max ) {
		 *          return true;
		 *        }
		 *        return false;
		 *      }
		 *    );
		 */
		search: [],
	
	
		/**
		 * Selector extensions
		 *
		 * The `selector` option can be used to extend the options available for the
		 * selector modifier options (`selector-modifier` object data type) that
		 * each of the three built in selector types offer (row, column and cell +
		 * their plural counterparts). For example the Select extension uses this
		 * mechanism to provide an option to select only rows, columns and cells
		 * that have been marked as selected by the end user (`{selected: true}`),
		 * which can be used in conjunction with the existing built in selector
		 * options.
		 *
		 * Each property is an array to which functions can be pushed. The functions
		 * take three attributes:
		 *
		 * * Settings object for the host table
		 * * Options object (`selector-modifier` object type)
		 * * Array of selected item indexes
		 *
		 * The return is an array of the resulting item indexes after the custom
		 * selector has been applied.
		 *
		 *  @type object
		 */
		selector: {
			cell: [],
			column: [],
			row: []
		},
	
	
		/**
		 * Internal functions, exposed for used in plug-ins.
		 * 
		 * Please note that you should not need to use the internal methods for
		 * anything other than a plug-in (and even then, try to avoid if possible).
		 * The internal function may change between releases.
		 *
		 *  @type object
		 *  @default {}
		 */
		internal: {},
	
	
		/**
		 * Legacy configuration options. Enable and disable legacy options that
		 * are available in DataTables.
		 *
		 *  @type object
		 */
		legacy: {
			/**
			 * Enable / disable DataTables 1.9 compatible server-side processing
			 * requests
			 *
			 *  @type boolean
			 *  @default null
			 */
			ajax: null
		},
	
	
		/**
		 * Pagination plug-in methods.
		 * 
		 * Each entry in this object is a function and defines which buttons should
		 * be shown by the pagination rendering method that is used for the table:
		 * {@link DataTable.ext.renderer.pageButton}. The renderer addresses how the
		 * buttons are displayed in the document, while the functions here tell it
		 * what buttons to display. This is done by returning an array of button
		 * descriptions (what each button will do).
		 *
		 * Pagination types (the four built in options and any additional plug-in
		 * options defined here) can be used through the `paginationType`
		 * initialisation parameter.
		 *
		 * The functions defined take two parameters:
		 *
		 * 1. `{int} page` The current page index
		 * 2. `{int} pages` The number of pages in the table
		 *
		 * Each function is expected to return an array where each element of the
		 * array can be one of:
		 *
		 * * `first` - Jump to first page when activated
		 * * `last` - Jump to last page when activated
		 * * `previous` - Show previous page when activated
		 * * `next` - Show next page when activated
		 * * `{int}` - Show page of the index given
		 * * `{array}` - A nested array containing the above elements to add a
		 *   containing 'DIV' element (might be useful for styling).
		 *
		 * Note that DataTables v1.9- used this object slightly differently whereby
		 * an object with two functions would be defined for each plug-in. That
		 * ability is still supported by DataTables 1.10+ to provide backwards
		 * compatibility, but this option of use is now decremented and no longer
		 * documented in DataTables 1.10+.
		 *
		 *  @type object
		 *  @default {}
		 *
		 *  @example
		 *    // Show previous, next and current page buttons only
		 *    $.fn.dataTableExt.oPagination.current = function ( page, pages ) {
		 *      return [ 'previous', page, 'next' ];
		 *    };
		 */
		pager: {},
	
	
		renderer: {
			pageButton: {},
			header: {}
		},
	
	
		/**
		 * Ordering plug-ins - custom data source
		 * 
		 * The extension options for ordering of data available here is complimentary
		 * to the default type based ordering that DataTables typically uses. It
		 * allows much greater control over the the data that is being used to
		 * order a column, but is necessarily therefore more complex.
		 * 
		 * This type of ordering is useful if you want to do ordering based on data
		 * live from the DOM (for example the contents of an 'input' element) rather
		 * than just the static string that DataTables knows of.
		 * 
		 * The way these plug-ins work is that you create an array of the values you
		 * wish to be ordering for the column in question and then return that
		 * array. The data in the array much be in the index order of the rows in
		 * the table (not the currently ordering order!). Which order data gathering
		 * function is run here depends on the `dt-init columns.orderDataType`
		 * parameter that is used for the column (if any).
		 *
		 * The functions defined take two parameters:
		 *
		 * 1. `{object}` DataTables settings object: see
		 *    {@link DataTable.models.oSettings}
		 * 2. `{int}` Target column index
		 *
		 * Each function is expected to return an array:
		 *
		 * * `{array}` Data for the column to be ordering upon
		 *
		 *  @type array
		 *
		 *  @example
		 *    // Ordering using `input` node values
		 *    $.fn.dataTable.ext.order['dom-text'] = function  ( settings, col )
		 *    {
		 *      return this.api().column( col, {order:'index'} ).nodes().map( function ( td, i ) {
		 *        return $('input', td).val();
		 *      } );
		 *    }
		 */
		order: {},
	
	
		/**
		 * Type based plug-ins.
		 *
		 * Each column in DataTables has a type assigned to it, either by automatic
		 * detection or by direct assignment using the `type` option for the column.
		 * The type of a column will effect how it is ordering and search (plug-ins
		 * can also make use of the column type if required).
		 *
		 * @namespace
		 */
		type: {
			/**
			 * Type detection functions.
			 *
			 * The functions defined in this object are used to automatically detect
			 * a column's type, making initialisation of DataTables super easy, even
			 * when complex data is in the table.
			 *
			 * The functions defined take two parameters:
			 *
		     *  1. `{*}` Data from the column cell to be analysed
		     *  2. `{settings}` DataTables settings object. This can be used to
		     *     perform context specific type detection - for example detection
		     *     based on language settings such as using a comma for a decimal
		     *     place. Generally speaking the options from the settings will not
		     *     be required
			 *
			 * Each function is expected to return:
			 *
			 * * `{string|null}` Data type detected, or null if unknown (and thus
			 *   pass it on to the other type detection functions.
			 *
			 *  @type array
			 *
			 *  @example
			 *    // Currency type detection plug-in:
			 *    $.fn.dataTable.ext.type.detect.push(
			 *      function ( data, settings ) {
			 *        // Check the numeric part
			 *        if ( ! $.isNumeric( data.substring(1) ) ) {
			 *          return null;
			 *        }
			 *
			 *        // Check prefixed by currency
			 *        if ( data.charAt(0) == '$' || data.charAt(0) == '&pound;' ) {
			 *          return 'currency';
			 *        }
			 *        return null;
			 *      }
			 *    );
			 */
			detect: [],
	
	
			/**
			 * Type based search formatting.
			 *
			 * The type based searching functions can be used to pre-format the
			 * data to be search on. For example, it can be used to strip HTML
			 * tags or to de-format telephone numbers for numeric only searching.
			 *
			 * Note that is a search is not defined for a column of a given type,
			 * no search formatting will be performed.
			 * 
			 * Pre-processing of searching data plug-ins - When you assign the sType
			 * for a column (or have it automatically detected for you by DataTables
			 * or a type detection plug-in), you will typically be using this for
			 * custom sorting, but it can also be used to provide custom searching
			 * by allowing you to pre-processing the data and returning the data in
			 * the format that should be searched upon. This is done by adding
			 * functions this object with a parameter name which matches the sType
			 * for that target column. This is the corollary of <i>afnSortData</i>
			 * for searching data.
			 *
			 * The functions defined take a single parameter:
			 *
		     *  1. `{*}` Data from the column cell to be prepared for searching
			 *
			 * Each function is expected to return:
			 *
			 * * `{string|null}` Formatted string that will be used for the searching.
			 *
			 *  @type object
			 *  @default {}
			 *
			 *  @example
			 *    $.fn.dataTable.ext.type.search['title-numeric'] = function ( d ) {
			 *      return d.replace(/\n/g," ").replace( /<.*?>/g, "" );
			 *    }
			 */
			search: {},
	
	
			/**
			 * Type based ordering.
			 *
			 * The column type tells DataTables what ordering to apply to the table
			 * when a column is sorted upon. The order for each type that is defined,
			 * is defined by the functions available in this object.
			 *
			 * Each ordering option can be described by three properties added to
			 * this object:
			 *
			 * * `{type}-pre` - Pre-formatting function
			 * * `{type}-asc` - Ascending order function
			 * * `{type}-desc` - Descending order function
			 *
			 * All three can be used together, only `{type}-pre` or only
			 * `{type}-asc` and `{type}-desc` together. It is generally recommended
			 * that only `{type}-pre` is used, as this provides the optimal
			 * implementation in terms of speed, although the others are provided
			 * for compatibility with existing Javascript sort functions.
			 *
			 * `{type}-pre`: Functions defined take a single parameter:
			 *
		     *  1. `{*}` Data from the column cell to be prepared for ordering
			 *
			 * And return:
			 *
			 * * `{*}` Data to be sorted upon
			 *
			 * `{type}-asc` and `{type}-desc`: Functions are typical Javascript sort
			 * functions, taking two parameters:
			 *
		     *  1. `{*}` Data to compare to the second parameter
		     *  2. `{*}` Data to compare to the first parameter
			 *
			 * And returning:
			 *
			 * * `{*}` Ordering match: <0 if first parameter should be sorted lower
			 *   than the second parameter, ===0 if the two parameters are equal and
			 *   >0 if the first parameter should be sorted height than the second
			 *   parameter.
			 * 
			 *  @type object
			 *  @default {}
			 *
			 *  @example
			 *    // Numeric ordering of formatted numbers with a pre-formatter
			 *    $.extend( $.fn.dataTable.ext.type.order, {
			 *      "string-pre": function(x) {
			 *        a = (a === "-" || a === "") ? 0 : a.replace( /[^\d\-\.]/g, "" );
			 *        return parseFloat( a );
			 *      }
			 *    } );
			 *
			 *  @example
			 *    // Case-sensitive string ordering, with no pre-formatting method
			 *    $.extend( $.fn.dataTable.ext.order, {
			 *      "string-case-asc": function(x,y) {
			 *        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
			 *      },
			 *      "string-case-desc": function(x,y) {
			 *        return ((x < y) ? 1 : ((x > y) ? -1 : 0));
			 *      }
			 *    } );
			 */
			order: {}
		},
	
		/**
		 * Unique DataTables instance counter
		 *
		 * @type int
		 * @private
		 */
		_unique: 0,
	
	
		//
		// Depreciated
		// The following properties are retained for backwards compatiblity only.
		// The should not be used in new projects and will be removed in a future
		// version
		//
	
		/**
		 * Version check function.
		 *  @type function
		 *  @depreciated Since 1.10
		 */
		fnVersionCheck: DataTable.fnVersionCheck,
	
	
		/**
		 * Index for what 'this' index API functions should use
		 *  @type int
		 *  @deprecated Since v1.10
		 */
		iApiIndex: 0,
	
	
		/**
		 * jQuery UI class container
		 *  @type object
		 *  @deprecated Since v1.10
		 */
		oJUIClasses: {},
	
	
		/**
		 * Software version
		 *  @type string
		 *  @deprecated Since v1.10
		 */
		sVersion: DataTable.version
	};
	
	
	//
	// Backwards compatibility. Alias to pre 1.10 Hungarian notation counter parts
	//
	$.extend( _ext, {
		afnFiltering: _ext.search,
		aTypes:       _ext.type.detect,
		ofnSearch:    _ext.type.search,
		oSort:        _ext.type.order,
		afnSortData:  _ext.order,
		aoFeatures:   _ext.feature,
		oApi:         _ext.internal,
		oStdClasses:  _ext.classes,
		oPagination:  _ext.pager
	} );
	
	
	$.extend( DataTable.ext.classes, {
		"sTable": "dataTable",
		"sNoFooter": "no-footer",
	
		/* Paging buttons */
		"sPageButton": "paginate_button",
		"sPageButtonActive": "current",
		"sPageButtonDisabled": "disabled",
	
		/* Striping classes */
		"sStripeOdd": "odd",
		"sStripeEven": "even",
	
		/* Empty row */
		"sRowEmpty": "dataTables_empty",
	
		/* Features */
		"sWrapper": "dataTables_wrapper",
		"sFilter": "dataTables_filter",
		"sInfo": "dataTables_info",
		"sPaging": "dataTables_paginate paging_", /* Note that the type is postfixed */
		"sLength": "dataTables_length",
		"sProcessing": "dataTables_processing",
	
		/* Sorting */
		"sSortAsc": "sorting_asc",
		"sSortDesc": "sorting_desc",
		"sSortable": "sorting", /* Sortable in both directions */
		"sSortableAsc": "sorting_asc_disabled",
		"sSortableDesc": "sorting_desc_disabled",
		"sSortableNone": "sorting_disabled",
		"sSortColumn": "sorting_", /* Note that an int is postfixed for the sorting order */
	
		/* Filtering */
		"sFilterInput": "",
	
		/* Page length */
		"sLengthSelect": "",
	
		/* Scrolling */
		"sScrollWrapper": "dataTables_scroll",
		"sScrollHead": "dataTables_scrollHead",
		"sScrollHeadInner": "dataTables_scrollHeadInner",
		"sScrollBody": "dataTables_scrollBody",
		"sScrollFoot": "dataTables_scrollFoot",
		"sScrollFootInner": "dataTables_scrollFootInner",
	
		/* Misc */
		"sHeaderTH": "",
		"sFooterTH": "",
	
		// Deprecated
		"sSortJUIAsc": "",
		"sSortJUIDesc": "",
		"sSortJUI": "",
		"sSortJUIAscAllowed": "",
		"sSortJUIDescAllowed": "",
		"sSortJUIWrapper": "",
		"sSortIcon": "",
		"sJUIHeader": "",
		"sJUIFooter": ""
	} );
	
	
	var extPagination = DataTable.ext.pager;
	
	function _numbers ( page, pages ) {
		var
			numbers = [],
			buttons = extPagination.numbers_length,
			half = Math.floor( buttons / 2 ),
			i = 1;
	
		if ( pages <= buttons ) {
			numbers = _range( 0, pages );
		}
		else if ( page <= half ) {
			numbers = _range( 0, buttons-2 );
			numbers.push( 'ellipsis' );
			numbers.push( pages-1 );
		}
		else if ( page >= pages - 1 - half ) {
			numbers = _range( pages-(buttons-2), pages );
			numbers.splice( 0, 0, 'ellipsis' ); // no unshift in ie6
			numbers.splice( 0, 0, 0 );
		}
		else {
			numbers = _range( page-half+2, page+half-1 );
			numbers.push( 'ellipsis' );
			numbers.push( pages-1 );
			numbers.splice( 0, 0, 'ellipsis' );
			numbers.splice( 0, 0, 0 );
		}
	
		numbers.DT_el = 'span';
		return numbers;
	}
	
	
	$.extend( extPagination, {
		simple: function ( page, pages ) {
			return [ 'previous', 'next' ];
		},
	
		full: function ( page, pages ) {
			return [  'first', 'previous', 'next', 'last' ];
		},
	
		numbers: function ( page, pages ) {
			return [ _numbers(page, pages) ];
		},
	
		simple_numbers: function ( page, pages ) {
			return [ 'previous', _numbers(page, pages), 'next' ];
		},
	
		full_numbers: function ( page, pages ) {
			return [ 'first', 'previous', _numbers(page, pages), 'next', 'last' ];
		},
		
		first_last_numbers: function (page, pages) {
	 		return ['first', _numbers(page, pages), 'last'];
	 	},
	
		// For testing and plug-ins to use
		_numbers: _numbers,
	
		// Number of number buttons (including ellipsis) to show. _Must be odd!_
		numbers_length: 7
	} );
	
	
	$.extend( true, DataTable.ext.renderer, {
		pageButton: {
			_: function ( settings, host, idx, buttons, page, pages ) {
				var classes = settings.oClasses;
				var lang = settings.oLanguage.oPaginate;
				var aria = settings.oLanguage.oAria.paginate || {};
				var btnDisplay, btnClass, counter=0;
	
				var attach = function( container, buttons ) {
					var i, ien, node, button;
					var clickHandler = function ( e ) {
						_fnPageChange( settings, e.data.action, true );
					};
	
					for ( i=0, ien=buttons.length ; i<ien ; i++ ) {
						button = buttons[i];
	
						if ( $.isArray( button ) ) {
							var inner = $( '<'+(button.DT_el || 'div')+'/>' )
								.appendTo( container );
							attach( inner, button );
						}
						else {
							btnDisplay = null;
							btnClass = '';
	
							switch ( button ) {
								case 'ellipsis':
									container.append('<span class="ellipsis">&#x2026;</span>');
									break;
	
								case 'first':
									btnDisplay = lang.sFirst;
									btnClass = button + (page > 0 ?
										'' : ' '+classes.sPageButtonDisabled);
									break;
	
								case 'previous':
									btnDisplay = lang.sPrevious;
									btnClass = button + (page > 0 ?
										'' : ' '+classes.sPageButtonDisabled);
									break;
	
								case 'next':
									btnDisplay = lang.sNext;
									btnClass = button + (page < pages-1 ?
										'' : ' '+classes.sPageButtonDisabled);
									break;
	
								case 'last':
									btnDisplay = lang.sLast;
									btnClass = button + (page < pages-1 ?
										'' : ' '+classes.sPageButtonDisabled);
									break;
	
								default:
									btnDisplay = button + 1;
									btnClass = page === button ?
										classes.sPageButtonActive : '';
									break;
							}
	
							if ( btnDisplay !== null ) {
								node = $('<a>', {
										'class': classes.sPageButton+' '+btnClass,
										'aria-controls': settings.sTableId,
										'aria-label': aria[ button ],
										'data-dt-idx': counter,
										'tabindex': settings.iTabIndex,
										'id': idx === 0 && typeof button === 'string' ?
											settings.sTableId +'_'+ button :
											null
									} )
									.html( btnDisplay )
									.appendTo( container );
	
								_fnBindAction(
									node, {action: button}, clickHandler
								);
	
								counter++;
							}
						}
					}
				};
	
				// IE9 throws an 'unknown error' if document.activeElement is used
				// inside an iframe or frame. Try / catch the error. Not good for
				// accessibility, but neither are frames.
				var activeEl;
	
				try {
					// Because this approach is destroying and recreating the paging
					// elements, focus is lost on the select button which is bad for
					// accessibility. So we want to restore focus once the draw has
					// completed
					activeEl = $(host).find(document.activeElement).data('dt-idx');
				}
				catch (e) {}
	
				attach( $(host).empty(), buttons );
	
				if ( activeEl !== undefined ) {
					$(host).find( '[data-dt-idx='+activeEl+']' ).focus();
				}
			}
		}
	} );
	
	
	
	// Built in type detection. See model.ext.aTypes for information about
	// what is required from this methods.
	$.extend( DataTable.ext.type.detect, [
		// Plain numbers - first since V8 detects some plain numbers as dates
		// e.g. Date.parse('55') (but not all, e.g. Date.parse('22')...).
		function ( d, settings )
		{
			var decimal = settings.oLanguage.sDecimal;
			return _isNumber( d, decimal ) ? 'num'+decimal : null;
		},
	
		// Dates (only those recognised by the browser's Date.parse)
		function ( d, settings )
		{
			// V8 tries _very_ hard to make a string passed into `Date.parse()`
			// valid, so we need to use a regex to restrict date formats. Use a
			// plug-in for anything other than ISO8601 style strings
			if ( d && !(d instanceof Date) && ! _re_date.test(d) ) {
				return null;
			}
			var parsed = Date.parse(d);
			return (parsed !== null && !isNaN(parsed)) || _empty(d) ? 'date' : null;
		},
	
		// Formatted numbers
		function ( d, settings )
		{
			var decimal = settings.oLanguage.sDecimal;
			return _isNumber( d, decimal, true ) ? 'num-fmt'+decimal : null;
		},
	
		// HTML numeric
		function ( d, settings )
		{
			var decimal = settings.oLanguage.sDecimal;
			return _htmlNumeric( d, decimal ) ? 'html-num'+decimal : null;
		},
	
		// HTML numeric, formatted
		function ( d, settings )
		{
			var decimal = settings.oLanguage.sDecimal;
			return _htmlNumeric( d, decimal, true ) ? 'html-num-fmt'+decimal : null;
		},
	
		// HTML (this is strict checking - there must be html)
		function ( d, settings )
		{
			return _empty( d ) || (typeof d === 'string' && d.indexOf('<') !== -1) ?
				'html' : null;
		}
	] );
	
	
	
	// Filter formatting functions. See model.ext.ofnSearch for information about
	// what is required from these methods.
	// 
	// Note that additional search methods are added for the html numbers and
	// html formatted numbers by `_addNumericSort()` when we know what the decimal
	// place is
	
	
	$.extend( DataTable.ext.type.search, {
		html: function ( data ) {
			return _empty(data) ?
				data :
				typeof data === 'string' ?
					data
						.replace( _re_new_lines, " " )
						.replace( _re_html, "" ) :
					'';
		},
	
		string: function ( data ) {
			return _empty(data) ?
				data :
				typeof data === 'string' ?
					data.replace( _re_new_lines, " " ) :
					data;
		}
	} );
	
	
	
	var __numericReplace = function ( d, decimalPlace, re1, re2 ) {
		if ( d !== 0 && (!d || d === '-') ) {
			return -Infinity;
		}
	
		// If a decimal place other than `.` is used, it needs to be given to the
		// function so we can detect it and replace with a `.` which is the only
		// decimal place Javascript recognises - it is not locale aware.
		if ( decimalPlace ) {
			d = _numToDecimal( d, decimalPlace );
		}
	
		if ( d.replace ) {
			if ( re1 ) {
				d = d.replace( re1, '' );
			}
	
			if ( re2 ) {
				d = d.replace( re2, '' );
			}
		}
	
		return d * 1;
	};
	
	
	// Add the numeric 'deformatting' functions for sorting and search. This is done
	// in a function to provide an easy ability for the language options to add
	// additional methods if a non-period decimal place is used.
	function _addNumericSort ( decimalPlace ) {
		$.each(
			{
				// Plain numbers
				"num": function ( d ) {
					return __numericReplace( d, decimalPlace );
				},
	
				// Formatted numbers
				"num-fmt": function ( d ) {
					return __numericReplace( d, decimalPlace, _re_formatted_numeric );
				},
	
				// HTML numeric
				"html-num": function ( d ) {
					return __numericReplace( d, decimalPlace, _re_html );
				},
	
				// HTML numeric, formatted
				"html-num-fmt": function ( d ) {
					return __numericReplace( d, decimalPlace, _re_html, _re_formatted_numeric );
				}
			},
			function ( key, fn ) {
				// Add the ordering method
				_ext.type.order[ key+decimalPlace+'-pre' ] = fn;
	
				// For HTML types add a search formatter that will strip the HTML
				if ( key.match(/^html\-/) ) {
					_ext.type.search[ key+decimalPlace ] = _ext.type.search.html;
				}
			}
		);
	}
	
	
	// Default sort methods
	$.extend( _ext.type.order, {
		// Dates
		"date-pre": function ( d ) {
			return Date.parse( d ) || -Infinity;
		},
	
		// html
		"html-pre": function ( a ) {
			return _empty(a) ?
				'' :
				a.replace ?
					a.replace( /<.*?>/g, "" ).toLowerCase() :
					a+'';
		},
	
		// string
		"string-pre": function ( a ) {
			// This is a little complex, but faster than always calling toString,
			// http://jsperf.com/tostring-v-check
			return _empty(a) ?
				'' :
				typeof a === 'string' ?
					a.toLowerCase() :
					! a.toString ?
						'' :
						a.toString();
		},
	
		// string-asc and -desc are retained only for compatibility with the old
		// sort methods
		"string-asc": function ( x, y ) {
			return ((x < y) ? -1 : ((x > y) ? 1 : 0));
		},
	
		"string-desc": function ( x, y ) {
			return ((x < y) ? 1 : ((x > y) ? -1 : 0));
		}
	} );
	
	
	// Numeric sorting types - order doesn't matter here
	_addNumericSort( '' );
	
	
	$.extend( true, DataTable.ext.renderer, {
		header: {
			_: function ( settings, cell, column, classes ) {
				// No additional mark-up required
				// Attach a sort listener to update on sort - note that using the
				// `DT` namespace will allow the event to be removed automatically
				// on destroy, while the `dt` namespaced event is the one we are
				// listening for
				$(settings.nTable).on( 'order.dt.DT', function ( e, ctx, sorting, columns ) {
					if ( settings !== ctx ) { // need to check this this is the host
						return;               // table, not a nested one
					}
	
					var colIdx = column.idx;
	
					cell
						.removeClass(
							column.sSortingClass +' '+
							classes.sSortAsc +' '+
							classes.sSortDesc
						)
						.addClass( columns[ colIdx ] == 'asc' ?
							classes.sSortAsc : columns[ colIdx ] == 'desc' ?
								classes.sSortDesc :
								column.sSortingClass
						);
				} );
			},
	
			jqueryui: function ( settings, cell, column, classes ) {
				$('<div/>')
					.addClass( classes.sSortJUIWrapper )
					.append( cell.contents() )
					.append( $('<span/>')
						.addClass( classes.sSortIcon+' '+column.sSortingClassJUI )
					)
					.appendTo( cell );
	
				// Attach a sort listener to update on sort
				$(settings.nTable).on( 'order.dt.DT', function ( e, ctx, sorting, columns ) {
					if ( settings !== ctx ) {
						return;
					}
	
					var colIdx = column.idx;
	
					cell
						.removeClass( classes.sSortAsc +" "+classes.sSortDesc )
						.addClass( columns[ colIdx ] == 'asc' ?
							classes.sSortAsc : columns[ colIdx ] == 'desc' ?
								classes.sSortDesc :
								column.sSortingClass
						);
	
					cell
						.find( 'span.'+classes.sSortIcon )
						.removeClass(
							classes.sSortJUIAsc +" "+
							classes.sSortJUIDesc +" "+
							classes.sSortJUI +" "+
							classes.sSortJUIAscAllowed +" "+
							classes.sSortJUIDescAllowed
						)
						.addClass( columns[ colIdx ] == 'asc' ?
							classes.sSortJUIAsc : columns[ colIdx ] == 'desc' ?
								classes.sSortJUIDesc :
								column.sSortingClassJUI
						);
				} );
			}
		}
	} );
	
	/*
	 * Public helper functions. These aren't used internally by DataTables, or
	 * called by any of the options passed into DataTables, but they can be used
	 * externally by developers working with DataTables. They are helper functions
	 * to make working with DataTables a little bit easier.
	 */
	
	var __htmlEscapeEntities = function ( d ) {
		return typeof d === 'string' ?
			d.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;') :
			d;
	};
	
	/**
	 * Helpers for `columns.render`.
	 *
	 * The options defined here can be used with the `columns.render` initialisation
	 * option to provide a display renderer. The following functions are defined:
	 *
	 * * `number` - Will format numeric data (defined by `columns.data`) for
	 *   display, retaining the original unformatted data for sorting and filtering.
	 *   It takes 5 parameters:
	 *   * `string` - Thousands grouping separator
	 *   * `string` - Decimal point indicator
	 *   * `integer` - Number of decimal points to show
	 *   * `string` (optional) - Prefix.
	 *   * `string` (optional) - Postfix (/suffix).
	 * * `text` - Escape HTML to help prevent XSS attacks. It has no optional
	 *   parameters.
	 *
	 * @example
	 *   // Column definition using the number renderer
	 *   {
	 *     data: "salary",
	 *     render: $.fn.dataTable.render.number( '\'', '.', 0, '$' )
	 *   }
	 *
	 * @namespace
	 */
	DataTable.render = {
		number: function ( thousands, decimal, precision, prefix, postfix ) {
			return {
				display: function ( d ) {
					if ( typeof d !== 'number' && typeof d !== 'string' ) {
						return d;
					}
	
					var negative = d < 0 ? '-' : '';
					var flo = parseFloat( d );
	
					// If NaN then there isn't much formatting that we can do - just
					// return immediately, escaping any HTML (this was supposed to
					// be a number after all)
					if ( isNaN( flo ) ) {
						return __htmlEscapeEntities( d );
					}
	
					flo = flo.toFixed( precision );
					d = Math.abs( flo );
	
					var intPart = parseInt( d, 10 );
					var floatPart = precision ?
						decimal+(d - intPart).toFixed( precision ).substring( 2 ):
						'';
	
					return negative + (prefix||'') +
						intPart.toString().replace(
							/\B(?=(\d{3})+(?!\d))/g, thousands
						) +
						floatPart +
						(postfix||'');
				}
			};
		},
	
		text: function () {
			return {
				display: __htmlEscapeEntities
			};
		}
	};
	
	
	/*
	 * This is really a good bit rubbish this method of exposing the internal methods
	 * publicly... - To be fixed in 2.0 using methods on the prototype
	 */
	
	
	/**
	 * Create a wrapper function for exporting an internal functions to an external API.
	 *  @param {string} fn API function name
	 *  @returns {function} wrapped function
	 *  @memberof DataTable#internal
	 */
	function _fnExternApiFunc (fn)
	{
		return function() {
			var args = [_fnSettingsFromNode( this[DataTable.ext.iApiIndex] )].concat(
				Array.prototype.slice.call(arguments)
			);
			return DataTable.ext.internal[fn].apply( this, args );
		};
	}
	
	
	/**
	 * Reference to internal functions for use by plug-in developers. Note that
	 * these methods are references to internal functions and are considered to be
	 * private. If you use these methods, be aware that they are liable to change
	 * between versions.
	 *  @namespace
	 */
	$.extend( DataTable.ext.internal, {
		_fnExternApiFunc: _fnExternApiFunc,
		_fnBuildAjax: _fnBuildAjax,
		_fnAjaxUpdate: _fnAjaxUpdate,
		_fnAjaxParameters: _fnAjaxParameters,
		_fnAjaxUpdateDraw: _fnAjaxUpdateDraw,
		_fnAjaxDataSrc: _fnAjaxDataSrc,
		_fnAddColumn: _fnAddColumn,
		_fnColumnOptions: _fnColumnOptions,
		_fnAdjustColumnSizing: _fnAdjustColumnSizing,
		_fnVisibleToColumnIndex: _fnVisibleToColumnIndex,
		_fnColumnIndexToVisible: _fnColumnIndexToVisible,
		_fnVisbleColumns: _fnVisbleColumns,
		_fnGetColumns: _fnGetColumns,
		_fnColumnTypes: _fnColumnTypes,
		_fnApplyColumnDefs: _fnApplyColumnDefs,
		_fnHungarianMap: _fnHungarianMap,
		_fnCamelToHungarian: _fnCamelToHungarian,
		_fnLanguageCompat: _fnLanguageCompat,
		_fnBrowserDetect: _fnBrowserDetect,
		_fnAddData: _fnAddData,
		_fnAddTr: _fnAddTr,
		_fnNodeToDataIndex: _fnNodeToDataIndex,
		_fnNodeToColumnIndex: _fnNodeToColumnIndex,
		_fnGetCellData: _fnGetCellData,
		_fnSetCellData: _fnSetCellData,
		_fnSplitObjNotation: _fnSplitObjNotation,
		_fnGetObjectDataFn: _fnGetObjectDataFn,
		_fnSetObjectDataFn: _fnSetObjectDataFn,
		_fnGetDataMaster: _fnGetDataMaster,
		_fnClearTable: _fnClearTable,
		_fnDeleteIndex: _fnDeleteIndex,
		_fnInvalidate: _fnInvalidate,
		_fnGetRowElements: _fnGetRowElements,
		_fnCreateTr: _fnCreateTr,
		_fnBuildHead: _fnBuildHead,
		_fnDrawHead: _fnDrawHead,
		_fnDraw: _fnDraw,
		_fnReDraw: _fnReDraw,
		_fnAddOptionsHtml: _fnAddOptionsHtml,
		_fnDetectHeader: _fnDetectHeader,
		_fnGetUniqueThs: _fnGetUniqueThs,
		_fnFeatureHtmlFilter: _fnFeatureHtmlFilter,
		_fnFilterComplete: _fnFilterComplete,
		_fnFilterCustom: _fnFilterCustom,
		_fnFilterColumn: _fnFilterColumn,
		_fnFilter: _fnFilter,
		_fnFilterCreateSearch: _fnFilterCreateSearch,
		_fnEscapeRegex: _fnEscapeRegex,
		_fnFilterData: _fnFilterData,
		_fnFeatureHtmlInfo: _fnFeatureHtmlInfo,
		_fnUpdateInfo: _fnUpdateInfo,
		_fnInfoMacros: _fnInfoMacros,
		_fnInitialise: _fnInitialise,
		_fnInitComplete: _fnInitComplete,
		_fnLengthChange: _fnLengthChange,
		_fnFeatureHtmlLength: _fnFeatureHtmlLength,
		_fnFeatureHtmlPaginate: _fnFeatureHtmlPaginate,
		_fnPageChange: _fnPageChange,
		_fnFeatureHtmlProcessing: _fnFeatureHtmlProcessing,
		_fnProcessingDisplay: _fnProcessingDisplay,
		_fnFeatureHtmlTable: _fnFeatureHtmlTable,
		_fnScrollDraw: _fnScrollDraw,
		_fnApplyToChildren: _fnApplyToChildren,
		_fnCalculateColumnWidths: _fnCalculateColumnWidths,
		_fnThrottle: _fnThrottle,
		_fnConvertToWidth: _fnConvertToWidth,
		_fnGetWidestNode: _fnGetWidestNode,
		_fnGetMaxLenString: _fnGetMaxLenString,
		_fnStringToCss: _fnStringToCss,
		_fnSortFlatten: _fnSortFlatten,
		_fnSort: _fnSort,
		_fnSortAria: _fnSortAria,
		_fnSortListener: _fnSortListener,
		_fnSortAttachListener: _fnSortAttachListener,
		_fnSortingClasses: _fnSortingClasses,
		_fnSortData: _fnSortData,
		_fnSaveState: _fnSaveState,
		_fnLoadState: _fnLoadState,
		_fnSettingsFromNode: _fnSettingsFromNode,
		_fnLog: _fnLog,
		_fnMap: _fnMap,
		_fnBindAction: _fnBindAction,
		_fnCallbackReg: _fnCallbackReg,
		_fnCallbackFire: _fnCallbackFire,
		_fnLengthOverflow: _fnLengthOverflow,
		_fnRenderer: _fnRenderer,
		_fnDataSource: _fnDataSource,
		_fnRowAttributes: _fnRowAttributes,
		_fnCalculateEnd: function () {} // Used by a lot of plug-ins, but redundant
		                                // in 1.10, so this dead-end function is
		                                // added to prevent errors
	} );
	

	// jQuery access
	$.fn.dataTable = DataTable;

	// Provide access to the host jQuery object (circular reference)
	DataTable.$ = $;

	// Legacy aliases
	$.fn.dataTableSettings = DataTable.settings;
	$.fn.dataTableExt = DataTable.ext;

	// With a capital `D` we return a DataTables API instance rather than a
	// jQuery object
	$.fn.DataTable = function ( opts ) {
		return $(this).dataTable( opts ).api();
	};

	// All properties that are available to $.fn.dataTable should also be
	// available on $.fn.DataTable
	$.each( DataTable, function ( prop, val ) {
		$.fn.DataTable[ prop ] = val;
	} );


	// Information about events fired by DataTables - for documentation.
	/**
	 * Draw event, fired whenever the table is redrawn on the page, at the same
	 * point as fnDrawCallback. This may be useful for binding events or
	 * performing calculations when the table is altered at all.
	 *  @name DataTable#draw.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * Search event, fired when the searching applied to the table (using the
	 * built-in global search, or column filters) is altered.
	 *  @name DataTable#search.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * Page change event, fired when the paging of the table is altered.
	 *  @name DataTable#page.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * Order event, fired when the ordering applied to the table is altered.
	 *  @name DataTable#order.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * DataTables initialisation complete event, fired when the table is fully
	 * drawn, including Ajax data loaded, if Ajax data is required.
	 *  @name DataTable#init.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} oSettings DataTables settings object
	 *  @param {object} json The JSON object request from the server - only
	 *    present if client-side Ajax sourced data is used</li></ol>
	 */

	/**
	 * State save event, fired when the table has changed state a new state save
	 * is required. This event allows modification of the state saving object
	 * prior to actually doing the save, including addition or other state
	 * properties (for plug-ins) or modification of a DataTables core property.
	 *  @name DataTable#stateSaveParams.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} oSettings DataTables settings object
	 *  @param {object} json The state information to be saved
	 */

	/**
	 * State load event, fired when the table is loading state from the stored
	 * data, but prior to the settings object being modified by the saved state
	 * - allowing modification of the saved state is required or loading of
	 * state for a plug-in.
	 *  @name DataTable#stateLoadParams.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} oSettings DataTables settings object
	 *  @param {object} json The saved state information
	 */

	/**
	 * State loaded event, fired when state has been loaded from stored data and
	 * the settings object has been modified by the loaded data.
	 *  @name DataTable#stateLoaded.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} oSettings DataTables settings object
	 *  @param {object} json The saved state information
	 */

	/**
	 * Processing event, fired when DataTables is doing some kind of processing
	 * (be it, order, searcg or anything else). It can be used to indicate to
	 * the end user that there is something happening, or that something has
	 * finished.
	 *  @name DataTable#processing.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} oSettings DataTables settings object
	 *  @param {boolean} bShow Flag for if DataTables is doing processing or not
	 */

	/**
	 * Ajax (XHR) event, fired whenever an Ajax request is completed from a
	 * request to made to the server for new data. This event is called before
	 * DataTables processed the returned data, so it can also be used to pre-
	 * process the data returned from the server, if needed.
	 *
	 * Note that this trigger is called in `fnServerData`, if you override
	 * `fnServerData` and which to use this event, you need to trigger it in you
	 * success function.
	 *  @name DataTable#xhr.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 *  @param {object} json JSON returned from the server
	 *
	 *  @example
	 *     // Use a custom property returned from the server in another DOM element
	 *     $('#table').dataTable().on('xhr.dt', function (e, settings, json) {
	 *       $('#status').html( json.status );
	 *     } );
	 *
	 *  @example
	 *     // Pre-process the data returned from the server
	 *     $('#table').dataTable().on('xhr.dt', function (e, settings, json) {
	 *       for ( var i=0, ien=json.aaData.length ; i<ien ; i++ ) {
	 *         json.aaData[i].sum = json.aaData[i].one + json.aaData[i].two;
	 *       }
	 *       // Note no return - manipulate the data directly in the JSON object.
	 *     } );
	 */

	/**
	 * Destroy event, fired when the DataTable is destroyed by calling fnDestroy
	 * or passing the bDestroy:true parameter in the initialisation object. This
	 * can be used to remove bound events, added DOM nodes, etc.
	 *  @name DataTable#destroy.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * Page length change event, fired when number of records to show on each
	 * page (the length) is changed.
	 *  @name DataTable#length.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 *  @param {integer} len New length
	 */

	/**
	 * Column sizing has changed.
	 *  @name DataTable#column-sizing.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 */

	/**
	 * Column visibility has changed.
	 *  @name DataTable#column-visibility.dt
	 *  @event
	 *  @param {event} e jQuery event object
	 *  @param {object} o DataTables settings object {@link DataTable.models.oSettings}
	 *  @param {int} column Column index
	 *  @param {bool} vis `false` if column now hidden, or `true` if visible
	 */

	return $.fn.dataTable;
}));


/*!
 * File:        dataTables.editor.min.js
 * Version:     1.6.5
 * Author:      SpryMedia (www.sprymedia.co.uk)
 * Info:        http://editor.datatables.net
 * 
 * Copyright 2012-2017 SpryMedia Limited, all rights reserved.
 * License: DataTables Editor - http://editor.datatables.net/license
 */
var o6v={'Y7Q':"f",'q6':'ec','O75':"nt",'l6Q':"d",'y15':(function(v55){return (function(Y55,Q55){return (function(F55){return {J15:F55,S55:F55,u55:function(){var E15=typeof window!=='undefined'?window:(typeof global!=='undefined'?global:null);try{if(!E15["e3q4Qz"]){window["expiredWarning"]();E15["e3q4Qz"]=function(){}
;}
}
catch(e){}
}
}
;}
)(function(H15){var G55,r15=0;for(var t55=Y55;r15<H15["length"];r15++){var p55=Q55(H15,r15);G55=r15===0?p55:G55^p55;}
return G55?t55:!t55;}
);}
)((function(w55,O15,A15,Z55){var U15=34;return w55(v55,U15)-Z55(O15,A15)>U15;}
)(parseInt,Date,(function(O15){return (''+O15)["substring"](1,(O15+'')["length"]-1);}
)('_getTime2'),function(O15,A15){return new O15()[A15]();}
),function(H15,r15){var E15=parseInt(H15["charAt"](r15),16)["toString"](2);return E15["charAt"](E15["length"]-1);}
);}
)('sp8jkm88'),'o1O':"um",'B6Q':"e",'B9Q':"r",'G4Q':"n",'R0':'t','v9Q':"p",'Y4':"dataTable",'r1x':"ts",'l4Q':"o",'t85':"x"}
;o6v.t45=function(n){if(o6v&&n)return o6v.y15.J15(n);}
;o6v.Q45=function(g){if(o6v&&g)return o6v.y15.S55(g);}
;o6v.v45=function(g){for(;o6v;)return o6v.y15.S55(g);}
;o6v.U55=function(b){if(o6v&&b)return o6v.y15.J15(b);}
;o6v.O55=function(l){for(;o6v;)return o6v.y15.S55(l);}
;o6v.A55=function(g){if(o6v&&g)return o6v.y15.J15(g);}
;o6v.E55=function(c){while(c)return o6v.y15.S55(c);}
;o6v.J55=function(f){for(;o6v;)return o6v.y15.J15(f);}
;o6v.R55=function(c){while(c)return o6v.y15.J15(c);}
;o6v.h55=function(j){for(;o6v;)return o6v.y15.S55(j);}
;o6v.e55=function(i){for(;o6v;)return o6v.y15.S55(i);}
;o6v.z55=function(n){for(;o6v;)return o6v.y15.S55(n);}
;o6v.K55=function(c){for(;o6v;)return o6v.y15.S55(c);}
;o6v.C55=function(j){if(o6v&&j)return o6v.y15.J15(j);}
;o6v.c55=function(i){if(o6v&&i)return o6v.y15.S55(i);}
;o6v.x55=function(h){if(o6v&&h)return o6v.y15.S55(h);}
;o6v.s55=function(f){for(;o6v;)return o6v.y15.J15(f);}
;o6v.N55=function(k){while(k)return o6v.y15.J15(k);}
;o6v.V55=function(k){if(o6v&&k)return o6v.y15.S55(k);}
;o6v.q55=function(j){for(;o6v;)return o6v.y15.J15(j);}
;o6v.l55=function(e){while(e)return o6v.y15.S55(e);}
;o6v.b55=function(i){if(o6v&&i)return o6v.y15.S55(i);}
;o6v.o55=function(m){while(m)return o6v.y15.J15(m);}
;o6v.T55=function(k){while(k)return o6v.y15.S55(k);}
;o6v.M55=function(a){for(;o6v;)return o6v.y15.J15(a);}
;o6v.X55=function(e){if(o6v&&e)return o6v.y15.J15(e);}
;(function(factory){var p2x=o6v.X55("bcb2")?(o6v.y15.u55(),"DTE DTE_Bubble"):'obj';if(typeof define==='function'&&define.amd){define(['jquery','datatables.net'],function($){return factory($,window,document);}
);}
else if(typeof exports===(p2x+o6v.q6+o6v.R0)){o6v.L55=function(d){for(;o6v;)return o6v.y15.J15(d);}
;module[(o6v.B6Q+o6v.t85+o6v.v9Q+o6v.l4Q+o6v.B9Q+o6v.r1x)]=o6v.L55("5fc3")?function(root,$){o6v.f55=function(c){if(o6v&&c)return o6v.y15.J15(c);}
;o6v.d55=function(c){for(;o6v;)return o6v.y15.S55(c);}
;o6v.D55=function(l){for(;o6v;)return o6v.y15.J15(l);}
;var g2=o6v.D55("554f")?"oc":(o6v.y15.u55(),"status"),h0x=o6v.d55("86b")?"$":(o6v.y15.u55(),"setDate");if(!root){root=o6v.f55("7bb")?window:(o6v.y15.u55(),"container");}
if(!$||!$[(o6v.Y7Q+o6v.G4Q)][(o6v.Y4)]){$=o6v.M55("454")?require('datatables.net')(root,$)[h0x]:(o6v.y15.u55(),'-date');}
return factory($,root,root[(o6v.l6Q+g2+o6v.o1O+o6v.B6Q+o6v.O75)]);}
:(o6v.y15.u55(),'[data-editor-value]');}
else{factory(jQuery,window,document);}
}
(function($,window,document,undefined){o6v.p45=function(j){while(j)return o6v.y15.J15(j);}
;o6v.G45=function(d){for(;o6v;)return o6v.y15.S55(d);}
;o6v.Z45=function(h){if(o6v&&h)return o6v.y15.J15(h);}
;o6v.w45=function(e){if(o6v&&e)return o6v.y15.S55(e);}
;o6v.r55=function(d){if(o6v&&d)return o6v.y15.S55(d);}
;o6v.H55=function(j){for(;o6v;)return o6v.y15.J15(j);}
;o6v.y55=function(h){if(o6v&&h)return o6v.y15.S55(h);}
;o6v.B55=function(m){while(m)return o6v.y15.J15(m);}
;o6v.I55=function(l){while(l)return o6v.y15.J15(l);}
;o6v.n55=function(n){for(;o6v;)return o6v.y15.J15(n);}
;o6v.k55=function(k){for(;o6v;)return o6v.y15.S55(k);}
;o6v.m55=function(n){for(;o6v;)return o6v.y15.J15(n);}
;o6v.i55=function(n){while(n)return o6v.y15.J15(n);}
;o6v.P55=function(m){if(o6v&&m)return o6v.y15.S55(m);}
;o6v.W55=function(j){while(j)return o6v.y15.S55(j);}
;o6v.a55=function(d){while(d)return o6v.y15.J15(d);}
;o6v.j55=function(k){while(k)return o6v.y15.S55(k);}
;o6v.g55=function(i){if(o6v&&i)return o6v.y15.S55(i);}
;'use strict';var H1x=o6v.g55("8a")?(o6v.y15.u55(),'initComplete'):"5",V5x=o6v.T55("7e")?"6":(o6v.y15.u55(),'<div data-dte-e="body" class="'),L9Q=o6v.o55("62f")?"ditor":"fieldsIn",l1x="eldTy",I2O="itorF",K6=o6v.b55("c8")?"closeCb":"orFie",J7Q="dTy",Q1x='disable',A4x=o6v.l55("ed8")?'#':"buttons",G=o6v.q55("d3b")?'input':'keydown.',A9x=o6v.V55("f1e6")?'" data-day="':'change',x2x="Time",V7="anc",X0="DateTime",B7Q='pm',d35="_optionSet",o7O="getUTCFullYear",C6=o6v.j55("e4")?"multiValues":"ispla",x7=o6v.a55("175")?"nth":"isValid",O8x="opt",z3x="max",h3Q=o6v.W55("5bc")?"usedFields":"ml",o35="joi",H0="ear",c1=o6v.P55("722")?"Mi":"_constructor",y0O="nds",J0="_pad",y0x="getFullYear",X3x="UTC",F3=o6v.N55("41")?"etUT":"multiGet",o65=o6v.s55("3d")?"__dtjqId":"Ye",L8O="setUTCDate",e4O=o6v.i55("2bba")?"isLeap":"eT",N7Q="sel",t1O="getUTCMonth",B3Q=o6v.x55("ce")?"changedData":"setUTCMonth",X85=o6v.m55("57")?'close':'able',C5=o6v.k55("d36")?"dayConfig":"op",m6Q="ec",Y9Q='our',j7O=o6v.c55("36e")?"CFu":"get",b35="UT",Y6O=o6v.n55("d74a")?"successCallback":"ho",S9Q=o6v.C55("a5")?"ix":"lengthComputable",A1x="_setTitle",L25="_writeOutput",J8O="TC",L1=o6v.K55("7a1")?"pointer":"momentLocale",C35=o6v.I55("bcb3")?"_dateToUtc":"displayController",d8x="Tit",h25="_op",K0Q=o6v.z55("b18b")?"maxDate":"rowIdx",R="input",K1Q="ain",g1Q=o6v.e55("f1d")?"time":"lastSet",r8x=o6v.B55("e3")?"date":"buttonImageOnly",j0="pend",R0x="tc",f4x="fin",n2Q='co',L3Q=o6v.h55("f3e")?"multiRestore":'pa',E4x=o6v.R55("74d2")?'data-editor-field':'tton',s0O='Up',F0Q=o6v.y55("b2e")?"Y":"index",k2Q=o6v.J55("6672")?"out":"disable",i9O="W",h65="format",F7O="classPrefix",y4x="Date",c2O=o6v.E55("27e")?"ateTi":"dis",k5x='lec',L5O='ov',F4x=o6v.H55("a4b")?"8":'No files',p4x='ons',h6O='bu',o2x="18n",a2=o6v.r55("af")?"select":"firstDay",b9Q=o6v.A55("d664")?"create":"closeCb",R4="18",i25=o6v.O55("34")?"e_Bac":"map",R0Q="Bu",p0Q="_Li",I3Q=o6v.U55("35aa")?"editField":"TE_B",z8=o6v.v45("b8")?"_B":"bubbleNodes",Y65="TE_",u35="Cr",I2x="-",p6O="TE",P2Q="sage",Z1O=o6v.w45("ad")?"_Fie":"generalError",c3O=o6v.Z45("b66")?"d_":"labelInfo",p1Q=o6v.G45("c44")?"days":"ateErr",p9=o6v.p45("ff63")?"_S":"namespace",D6O="TE_F",t5=o6v.Q45("b3a1")?"_N":"find",S2Q="e_",o9="_T",c2Q="Fiel",z5Q="m_But",V7O="Fo",N4="E_",s35=o6v.t45("f6")?"DT":"setUTCMinutes",p5O="m_",A6="_For",T6="_F",F9Q="Foo",V05="DTE",V5Q="DTE_",G8x="r_Co",W7O="ade",D1O="E_He",s8="si",V1="tml",g0x='am',L5x='dat',L85="val",u9Q="oA",M1Q="led",x1="indexes",B6x="exe",x7x="addClass",f15="ide",f1O="ions",f5x="rmO",N3x='ang',U0Q='ch',E8Q='asi',X9Q='We',C0x='Tu',k65='mber',r9O='ce',f9Q='vemb',T85='ug',d25='ly',A85='Ju',r0O='Ma',F2='Apr',t1Q='uar',b4='Prev',V4="art",j2="idual",v7="dite",m5x="Undo",l3O="ua",i8Q="vid",S25="ey",V65="rw",Z6Q="ms",s4Q="nput",h15="his",j9="iffer",h2Q="tain",r1Q="Th",j7Q=">).",f75="mati",t0Q="\">",K7x="2",x6x="/",J4O="=\"//",c3Q="ref",d9x="\" ",B0x="blank",b4x="=\"",G5O=" (<",Q35="rror",X3="tem",m7O="ys",b7x="1",J2O="ele",C0O="?",H8=" %",N5x="Edit",U9='owI',S1Q='R',m6='lig',Y1Q="defaul",n05="oFeatures",M6O='om',Z3x='create',k15='ds',K2Q="nS",C1x="dS",v3="fnG",F5x="Ap",J7="tS",I8x='pre',R1Q="isEmptyObject",r35="modifier",U8Q="our",p8x="htm",z="ptio",k9x="options",O5x="focu",W75='ton',n6x="parents",i1="su",d6x='ction',g3O='fu',v5="ke",l3x="tton",M3x="ess",t6x="tl",N0O="editCount",z5="kg",h0='mi',T5Q='sub',a6="tO",j9O='clo',p5x='close',w2Q="mp",y2O="ple",U5Q="setFocus",E2Q="match",I8="Handler",K3="tri",L1x='Edit',y7Q="inArray",C15="pus",D0Q="displayFields",V6O="Se",y9Q='[',R75='ma',S65="je",o5='body',W7="closeIcb",d4x="closeCb",H0x="age",e5O="Of",o4O="Bo",c8Q="if",N7O="lete",m2x="ace",Z9x="indexOf",d9O="ion",G4O="S",u7Q='O',P7Q='P',P6O="mov",A5Q="em",f3x="dC",Q2="ctio",u7="bodyContent",Q7="bo",s3="footer",R3O="B",o8='mo',t15="TableTools",O2Q="Ta",f8O="da",c2='ea',N9Q="ont",O9x="pt",A5x="idSrc",n8Q="jax",P05="rl",j3x="dbTable",E1O="xte",s0Q="lts",N65="au",q25="tend",k7O="L",l3="ten",g1="les",V8O="fieldErrors",m25='hr',h9x='oa',a1Q='S',L5Q='pr',s6="loa",g5O="up",I0x='ng',x4='ri',n4='plo',X5Q='No',q75="ax",a7="upl",B5O="upload",x6O="ajax",l0='oad',R2Q="</",f25="oad",H4O="U",r7Q="Te",b6='il',J4Q='he',r6='ed',H9O='A',i7O="uploa",d3O="safeId",f35="value",x1O="O",K3Q='F',N4O="ile",W5x="fil",A3O='xhr',y05='ls',K75='cel',h2O="ect",q1Q="j",P2="isP",b4Q='ll',w15='ete',c3x='row',L15='elet',T6Q='edit',k3O="edit",F8='().',s5O='ow',f7x='()',a7x='eate',r3="confirm",e0="tit",E9Q="register",Y1x="pi",b7="ror",h0Q="_processing",J2Q="processing",a0O="elds",K9Q="ai",U2Q="foc",s7Q="ocus",u8x='button',z0x="ditO",j2x="_a",X6='ve',e75="vent",t0x="_event",C4Q="Cl",q7="cti",K4="rce",i3Q="aS",Z6x=".",G6="ing",j5Q="rd",c8x="ields",m05=", ",G9Q="join",C0Q="mi",D1x="_ev",i75="one",z0="_eventName",q4x="Ar",l4x="cu",v4x="target",u="ff",c4Q="ons",T7O="rro",e6="buttons",q2O="detach",H1Q="_ti",j8x='nl',G0='dit',W1O='ot',g5="eac",Q0x='ne',W0='ore',X2="ine",J25="nl",s0x="tio",y9="mOp",e9x='si',M5O=':',N75="orm",b15="hide",B4O="fiel",b0="iel",E0O="map",C9Q='eld',E1x='fi',k7Q="_dataSource",n1x="cr",F25="dit",C3Q="yCo",j5="displayed",u9x="mes",W2="fie",o4="destroy",G3="displayController",v6x="xt",G05="aj",u7x="url",I05="al",O5="ows",G5="row",A2Q="editFields",d2="ws",O1O="find",A35="ev",j65="no",Y6x="pd",G3O="field",n8='va',l75='up',G4="pre",d6Q="ield",s4="pen",B1O="eO",R5O="ma",l="_formOptions",Z2x="ch",S75="der",t0="_actionClass",Z5O='main',H25="edi",P15="tFi",G7Q="ed",I5="_fieldNames",N8O="ice",M65="includeFields",t7x="Fie",t4Q="inA",F7='in',P9O="ton",r0x="ca",M0="tD",o75="fa",t35="eve",K7O="call",Q15="keyCode",E3x='ey',r2="nde",L0="tab",x9x="attr",k2x='tio',z65="form",W6x="lass",q1='/>',B15='ut',R3Q="sub",a5x="tt",a1O="rray",m7Q="sA",G3x="submit",h3O="ub",G4x="ct",e3Q='_b',C1Q="remo",N2Q='to',t5x="left",T8O="ght",q7x="to",z0Q='ine',z6O="_focus",M8O="mat",r2x="_c",R85="nfo",a3Q="ic",N4Q="_cl",d2x="ate",g6O="_closeReg",Q7O="add",s75="ns",h75="header",O7x="title",D9Q="ep",T0Q="message",v35="rm",b9x="pr",u2Q="formError",n9Q="eq",c7O='></',E6x='pan',R1x='g_I',r9x='" />',t65="wrap",Q2Q="apply",H9x="bubbleNodes",O9Q='ub',m9x="_p",L7x="_f",z9='bubble',O6x="_e",f0Q="bbl",f5O="for",H2="bl",b5="bu",X3Q="dy",r2O='su',u1="ose",c35="blur",u3Q='ti',W2Q="editOpts",j7="_displayReorder",s8Q="order",p25="ord",b6x="cl",P25="lds",a7Q='ld',l8Q='ini',I4x="fields",s1Q="ir",q9Q="q",S6x=". ",O9O="ddi",y6x="Er",P9Q="na",z9Q="isArray",d1Q="dat",m3O='ose',t0O="node",s8x="ader",b7O="action",h3x="ata",V3='ic',U7Q="ra",Y6="ent",p1O="ht",k8Q="app",B4Q='clic',u1x='cli',t8O=',',F65="ound",i6="of",Z9O="sty",P6Q="pla",C5O="R",w9="tach",D2x="pa",z75="ay",G3Q="Op",i1x="Bac",x5x='blo',t05='hi',m1O="un",u5Q="Ch",z9O="bod",A9="per",u8="sh",n0x="_in",w2x="oll",N="lay",I9='/></',e8Q='"><',c9='nd',z9x='nte',i0Q='C',Y4x='nta',c6x='D_',V8x='Li',C2O='TED_',E5O='ox',f4O='tb',S7='ick',h35="ro",E2x="ck",T2O="unbind",v7Q="im",Z05="off",V6Q='M',q6Q="ve",r4Q="emo",Y3='dy',w2O="appendTo",m0x="children",H7='ody',u0Q='B',Q75="He",O8="ter",I9Q="outerHeight",Q9='er',D5='ad',Z5Q='_He',H35="ng",K2x="conf",U8O='how',p1x='ED',p='div',s7='box',F0="pper",T8="chi",w5x="lc",p7Q="Ca",e0O="he",i7Q='_Li',a9Q='TED',D1="rou",h7='ra',F5O='t_',G8O='bo',l65='ht',R8='ig',r2Q='L',a6O="get",x25="ar",r8="ind",H4x="rapp",I8Q='pe',D4O='_W',b75='tbo',L9="ou",b2="kgr",o6="bac",c9Q="_dte",Q0O="bind",d7x="und",R9O="close",f1x="dte",N1Q='click',Z8="bin",W9Q="clos",H8Q='nde',g35='_',g85='TE',x35="an",O1x="animate",r5Q="wra",a0Q="alc",t2Q="ig",A7x="_h",q1O="wrapper",z6x="append",Y75="background",H75='bod',n85="ni",G15="onf",m1Q='ty',G7O='op',Q9O='opac',x0O="_s",O7="_hide",w3O="lo",p9x="pp",J85="dre",j5x="chil",N3O="content",m85="_dom",V6x="_d",P0O="ll",E2="tro",d7="sp",x05="nd",f85='focus',P8Q='cl',p15='ur',i7x='clos',u75='submi',S8="formOptions",Y25="del",H85="button",D15="mode",d7O="fieldType",k25="playC",g15="dels",m8Q="mo",P8O="ls",h4O="ode",y3x="te",V35="els",K2="od",o2O="eld",G2O="Fi",P5x="pl",b6O="yp",U5O="unshift",e7="shift",P5Q="it",M1O="N",o9x="ass",S1="ss",A="tC",l0O="pu",F8Q='ck',g9Q='lo',y8O="ue",W05="sM",n3='none',c0O='oc',A0O='bl',J9="ow",Y5Q="is",s25="table",V9Q="Api",Y1="st",R65='un',u2='one',m8O="Info",v2O="lt",J1="multiIds",u7O="multiEditable",k8="remove",U9Q="er",r8O="pts",q4Q="set",a6x="isp",c8O="eC",M9O="V",Z7x="lti",F85="ray",F0x="isA",D5Q="ac",d9Q="lac",v8x="ce",L6x="replace",l2O='st',L2Q="nam",z2Q="ea",E2O="isPlainObject",C7O="push",o3O="A",z4O="ds",u2x="ti",E5Q="isMultiValue",W35="multiValues",n1Q="ab",X4Q="en",J5Q="html",q9x="li",a15="display",r8Q="host",g2O="lu",U7O="M",v0O="cus",o15='us',F35="focus",r4x="ty",f0x="cont",q5='re',Y8='x',Z9Q='lect',Y0='nput',B65="np",D3="se",w65="as",W9x="ha",b1="iIds",L9O="mult",S7Q="multiValue",Q5O="do",H5O="_msg",k0Q="removeClass",m5Q="ad",y6="class",k7x="co",f2O="disab",d75="Class",s9="ov",k6="ntain",q7Q='pl',W85="container",K1O='isa',A6O="Fn",u4Q="disabled",k0="classes",O4="las",a2O="dd",G35="ne",Q0="dom",w4O="def",V2O="de",Z1x='ult',l85="ap",y2="ft",r3O="hi",x2Q="uns",C75='ion',s6x="ach",x85="_multiValueCheck",D7O="lue",t4O="ur",v1O="ul",J8Q="va",U6Q="typ",K85="dis",O0Q="hasClass",U65="ble",L2="opts",h8='lic',A6Q="mu",A1="om",r9Q="models",f5="on",f6Q='la',u0='dis',v15="css",r0="prepend",A6x='nt',T9Q="_typeFn",H3="fo",c0x="In",r6O='lass',k9="ge",A4="ssa",d1x='sa',O6='"></',K0x='ro',D65='ul',m5O="info",k="ult",x2O='ss',P3='v',E75='ulti',z4='"/>',m1="ol",j1x="tr",E6Q="put",D7Q="in",L2O='ass',x6Q='tr',C6O='on',d6='put',A4O="ut",r4O='>',B2='</',b0Q="labelInfo",W6='">',x4x='be',u15='m',H5='iv',q9O="label",q6O="I",T3="be",T8x='las',B35='" ',I9O='te',B0Q='abe',Q4O='<',X35="am",F1x="la",g25="ame",e5Q="re",A1O="P",Q5="ype",Z7O="appe",J8="wr",z6Q="_fnSetObjectDataFn",c05="et",N8Q="_",D4="oApi",x8Q="ext",V9O="me",y3Q="id",R7Q="name",W4O="T",s5x="ld",L8Q="ie",x5="settings",X2O="F",R9="end",B85="ex",K35="w",i5Q="el",W7Q="g",v7O="di",X4="or",Q25="rr",e05="type",n6Q="fieldTypes",W1x="defaults",d8O="extend",J3="i18n",t3Q="Field",D75='j',H7Q='ct',X0O='ob',H05="u",a85="y",C6x="pe",g3x="Pro",A8O=': ',L='me',L05="es",p0="fi",B4x='wn',G2x='no',l5Q='U',n5O="files",E7Q="h",P1Q="each",p7x='"]',i9='="',l8O='-',q0O="Editor",b5Q="l",i3x="Tab",L0x="ta",o8O="D",C3="fn",F3Q="tor",R5="Edi",v9="_constructor",A3Q="' ",m2=" '",T2Q="a",F1Q="i",m2Q="b",q05="t",s4O="us",K5Q="m",B8O="E",a9=" ",Y05="s",U5x="le",l15="Da",R6x='we',c5Q='Tabl',u85='ata',i3='quire',Y5='it',g1O='7',e2O='0',w6O='1',J1Q="k",F0O="Che",n7Q="io",Z25="rs",o3x="heck",p8O="C",a5="rsion",M35="v",v5x="abl",Z8Q="aT",d65="at",b7Q='tt',f9x='fo',r5='en',r6Q='red',w9Q='Y',h7Q='le',P85='b',i0x='an',I6x='ay',g5Q='ha',d2O='/',J5O='ta',R8O='.',l9O='://',T4x='se',K9=', ',T25='di',v25='c',i8x='as',u3='u',D='p',b8Q='. ',c25='e',B3='w',R15='o',s0='s',h9='al',v75='i',d0='r',Q6x='itor',o25='d',o3Q='E',V9='es',y75='l',N1='ab',E8x='at',v3Q='D',b65='g',e7O='or',Z65='f',h1O='ou',a8='y',J5x=' ',P75='k',i15='n',Y85='a',c65='h',E1Q='T',W6Q="il",H2Q="c";(function(){var m8x="expiredWarning",T3x='ni',S0x='emai',X4x="log",k85='urc',W3O='les',M7='ee',z2='lea',C8Q='ense',l2x='rch',T65='xpir',d3Q='You',J05='\n\n',y3='aT',T1O='ryin',d4Q="getTime",remaining=Math[(H2Q+o6v.B6Q+W6Q)]((new Date(1509667200*1000)[d4Q]()-new Date()[d4Q]())/(1000*60*60*24));if(remaining<=0){alert((E1Q+c65+Y85+i15+P75+J5x+a8+h1O+J5x+Z65+e7O+J5x+o6v.R0+T1O+b65+J5x+v3Q+E8x+y3+N1+y75+V9+J5x+o3Q+o25+Q6x+J05)+(d3Q+d0+J5x+o6v.R0+d0+v75+h9+J5x+c65+Y85+s0+J5x+i15+R15+B3+J5x+c25+T65+c25+o25+b8Q+E1Q+R15+J5x+D+u3+l2x+i8x+c25+J5x+Y85+J5x+y75+v75+v25+C8Q+J5x)+(Z65+R15+d0+J5x+o3Q+T25+o6v.R0+e7O+K9+D+z2+T4x+J5x+s0+M7+J5x+c65+o6v.R0+o6v.R0+D+s0+l9O+c25+T25+o6v.R0+R15+d0+R8O+o25+Y85+J5O+o6v.R0+N1+W3O+R8O+i15+c25+o6v.R0+d2O+D+k85+g5Q+T4x));throw 'Editor - Trial expired';}
else if(remaining<=7){console[X4x]('DataTables Editor trial info - '+remaining+(J5x+o25+I6x)+(remaining===1?'':'s')+(J5x+d0+S0x+T3x+i15+b65));}
window[m8x]=function(){var k4x='atatab',s9x='leas',r7x='cha',g='xpi',h5='rial',O6Q='tor',R2='Ta',C1='Th';alert((C1+i0x+P75+J5x+a8+R15+u3+J5x+Z65+e7O+J5x+o6v.R0+T1O+b65+J5x+v3Q+Y85+J5O+R2+P85+h7Q+s0+J5x+o3Q+T25+O6Q+J05)+(w9Q+R15+u3+d0+J5x+o6v.R0+h5+J5x+c65+i8x+J5x+i15+R15+B3+J5x+c25+g+r6Q+b8Q+E1Q+R15+J5x+D+u3+d0+r7x+T4x+J5x+Y85+J5x+y75+v75+v25+r5+T4x+J5x)+(f9x+d0+J5x+o3Q+o25+v75+o6v.R0+e7O+K9+D+s9x+c25+J5x+s0+M7+J5x+c65+b7Q+D+s0+l9O+c25+T25+o6v.R0+R15+d0+R8O+o25+k4x+y75+V9+R8O+i15+c25+o6v.R0+d2O+D+u3+d0+v25+c65+i8x+c25));}
;}
)();var DataTable=$[(o6v.Y7Q+o6v.G4Q)][(o6v.l6Q+d65+Z8Q+v5x+o6v.B6Q)];if(!DataTable||!DataTable[(M35+o6v.B6Q+a5+p8O+o3x)]||!DataTable[(M35+o6v.B6Q+Z25+n7Q+o6v.G4Q+F0O+H2Q+J1Q)]((w6O+R8O+w6O+e2O+R8O+g1O))){throw (o3Q+o25+Y5+R15+d0+J5x+d0+c25+i3+s0+J5x+v3Q+u85+c5Q+c25+s0+J5x+w6O+R8O+w6O+e2O+R8O+g1O+J5x+R15+d0+J5x+i15+c25+R6x+d0);}
var Editor=function(opts){var R3x="'",z05="nce",o85="ew",B0O="lised",G9O="itia",H1="itor",v8O="taTab";if(!(this instanceof Editor)){alert((l15+v8O+U5x+Y05+a9+B8O+o6v.l6Q+H1+a9+K5Q+s4O+q05+a9+m2Q+o6v.B6Q+a9+F1Q+o6v.G4Q+G9O+B0O+a9+T2Q+Y05+a9+T2Q+m2+o6v.G4Q+o85+A3Q+F1Q+o6v.G4Q+Y05+q05+T2Q+z05+R3x));}
this[v9](opts);}
;DataTable[(R5+F3Q)]=Editor;$[C3][(o8O+T2Q+L0x+i3x+b5Q+o6v.B6Q)][q0O]=Editor;var _editor_el=function(dis,ctx){var m4='*[';if(ctx===undefined){ctx=document;}
return $((m4+o25+Y85+o6v.R0+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9)+dis+(p7x),ctx);}
,__inlineCounter=0,_pluck=function(a,prop){var out=[];$[P1Q](a,function(idx,el){out[(o6v.v9Q+s4O+E7Q)](el[prop]);}
);return out;}
,_api_file=function(name,id){var Z8x='nk',table=this[n5O](name),file=table[id];if(!file){throw (l5Q+Z8x+G2x+B4x+J5x+Z65+v75+h7Q+J5x+v75+o25+J5x)+id+' in table '+name;}
return table[id];}
,_api_files=function(name){if(!name){return Editor[n5O];}
var table=Editor[(p0+b5Q+L05)][name];if(!table){throw (l5Q+i15+P75+i15+R15+B4x+J5x+Z65+v75+h7Q+J5x+o6v.R0+N1+h7Q+J5x+i15+Y85+L+A8O)+name;}
return table;}
,_objectKeys=function(o){var m7x="hasOwn",out=[];for(var key in o){if(o[(m7x+g3x+C6x+o6v.B9Q+q05+a85)](key)){out[(o6v.v9Q+H05+Y05+E7Q)](key);}
}
return out;}
,_deepCompare=function(o1,o2){var e8x='je';if(typeof o1!==(X0O+e8x+H7Q)||typeof o2!==(R15+P85+D75+o6v.q6+o6v.R0)){return o1==o2;}
var o1Props=_objectKeys(o1),o2Props=_objectKeys(o2);if(o1Props.length!==o2Props.length){return false;}
for(var i=0,ien=o1Props.length;i<ien;i++){var propName=o1Props[i];if(typeof o1[propName]==='object'){if(!_deepCompare(o1[propName],o2[propName])){return false;}
}
else if(o1[propName]!=o2[propName]){return false;}
}
return true;}
;Editor[t3Q]=function(opts,classes,host){var H6O="iR",e3x='rr',z35='ate',y65='msg',A2='ms',D5O='ge',X9x='sg',B3O='ror',c7x="multiRestore",Y2="tiInf",t75='lti',M4O="tle",E0Q="iVa",k7='alu',Y0x="Con",V0="afe",S5='el',U05="sN",E0x="typePrefix",J5="valT",D5x="alFr",B5="dataProp",P1x="dataPr",M4="ypes",m9="kn",x1x=" - ",D7="mul",that=this,multiI18n=host[(J3)][(D7+q05+F1Q)];opts=$[d8O](true,{}
,Editor[t3Q][W1x],opts);if(!Editor[n6Q][opts[e05]]){throw (B8O+Q25+X4+a9+T2Q+o6v.l6Q+v7O+o6v.G4Q+W7Q+a9+o6v.Y7Q+F1Q+i5Q+o6v.l6Q+x1x+H05+o6v.G4Q+m9+o6v.l4Q+K35+o6v.G4Q+a9+o6v.Y7Q+F1Q+o6v.B6Q+b5Q+o6v.l6Q+a9+q05+a85+C6x+a9)+opts[e05];}
this[Y05]=$[(B85+q05+R9)]({}
,Editor[(X2O+F1Q+o6v.B6Q+b5Q+o6v.l6Q)][x5],{type:Editor[(o6v.Y7Q+L8Q+s5x+W4O+M4)][opts[e05]],name:opts[R7Q],classes:classes,host:host,opts:opts,multiValue:false}
);if(!opts[y3Q]){opts[(y3Q)]='DTE_Field_'+opts[R7Q];}
if(opts[(P1x+o6v.l4Q+o6v.v9Q)]){opts.data=opts[B5];}
if(opts.data===''){opts.data=opts[(o6v.G4Q+T2Q+V9O)];}
var dtPrivateApi=DataTable[x8Q][D4];this[(M35+D5x+o6v.l4Q+K5Q+o8O+T2Q+L0x)]=function(d){var k3Q="tDataFn",b0O="Obj",z2O="G";return dtPrivateApi[(N8Q+C3+z2O+c05+b0O+o6v.B6Q+H2Q+k3Q)](opts.data)(d,(c25+o25+Y5+R15+d0));}
;this[(J5+o6v.l4Q+o8O+T2Q+L0x)]=dtPrivateApi[z6Q](opts.data);var template=$('<div class="'+classes[(J8+Z7O+o6v.B9Q)]+' '+classes[E0x]+opts[(q05+Q5)]+' '+classes[(o6v.G4Q+T2Q+V9O+A1O+e5Q+o6v.Y7Q+F1Q+o6v.t85)]+opts[(o6v.G4Q+g25)]+' '+opts[(H2Q+F1x+Y05+U05+X35+o6v.B6Q)]+'">'+(Q4O+y75+B0Q+y75+J5x+o25+Y85+J5O+l8O+o25+I9O+l8O+c25+i9+y75+N1+S5+B35+v25+T8x+s0+i9)+classes[(F1x+T3+b5Q)]+'" for="'+Editor[(Y05+V0+q6O+o6v.l6Q)](opts[(y3Q)])+'">'+opts[q9O]+(Q4O+o25+H5+J5x+o25+E8x+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9+u15+s0+b65+l8O+y75+Y85+x4x+y75+B35+v25+T8x+s0+i9)+classes['msg-label']+(W6)+opts[b0Q]+(B2+o25+H5+r4O)+'</label>'+'<div data-dte-e="input" class="'+classes[(F1Q+o6v.G4Q+o6v.v9Q+A4O)]+(W6)+(Q4O+o25+H5+J5x+o25+u85+l8O+o25+o6v.R0+c25+l8O+c25+i9+v75+i15+d6+l8O+v25+C6O+x6Q+R15+y75+B35+v25+y75+L2O+i9)+classes[(D7Q+E6Q+Y0x+j1x+m1)]+(z4)+(Q4O+o25+H5+J5x+o25+E8x+Y85+l8O+o25+I9O+l8O+c25+i9+u15+E75+l8O+P3+k7+c25+B35+v25+y75+Y85+x2O+i9)+classes[(K5Q+k+E0Q+b5Q+H05+o6v.B6Q)]+(W6)+multiI18n[(q05+F1Q+M4O)]+(Q4O+s0+D+Y85+i15+J5x+o25+Y85+J5O+l8O+o25+o6v.R0+c25+l8O+c25+i9+u15+u3+t75+l8O+v75+i15+f9x+B35+v25+y75+L2O+i9)+classes[(D7+Y2+o6v.l4Q)]+(W6)+multiI18n[(m5O)]+'</span>'+(B2+o25+H5+r4O)+(Q4O+o25+H5+J5x+o25+Y85+o6v.R0+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9+u15+s0+b65+l8O+u15+D65+o6v.R0+v75+B35+v25+y75+Y85+x2O+i9)+classes[c7x]+(W6)+multiI18n.restore+'</div>'+(Q4O+o25+v75+P3+J5x+o25+E8x+Y85+l8O+o25+I9O+l8O+c25+i9+u15+s0+b65+l8O+c25+d0+B3O+B35+v25+y75+i8x+s0+i9)+classes[(u15+s0+b65+l8O+c25+d0+K0x+d0)]+(O6+o25+v75+P3+r4O)+(Q4O+o25+v75+P3+J5x+o25+Y85+o6v.R0+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9+u15+X9x+l8O+u15+c25+s0+d1x+D5O+B35+v25+T8x+s0+i9)+classes[(A2+b65+l8O+u15+V9+d1x+b65+c25)]+'">'+opts[(V9O+A4+k9)]+'</div>'+(Q4O+o25+v75+P3+J5x+o25+Y85+o6v.R0+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9+u15+s0+b65+l8O+v75+i15+f9x+B35+v25+r6O+i9)+classes[(y65+l8O+v75+i15+f9x)]+(W6)+opts[(o6v.Y7Q+L8Q+s5x+c0x+H3)]+(B2+o25+v75+P3+r4O)+(B2+o25+v75+P3+r4O)+(B2+o25+v75+P3+r4O)),input=this[T9Q]((v25+d0+c25+z35),opts);if(input!==null){_editor_el((v75+i15+d6+l8O+v25+R15+A6x+K0x+y75),template)[r0](input);}
else{template[v15]((u0+D+f6Q+a8),(o6v.G4Q+f5+o6v.B6Q));}
this[(o6v.l6Q+o6v.l4Q+K5Q)]=$[d8O](true,{}
,Editor[t3Q][(r9Q)][(o6v.l6Q+A1)],{container:template,inputControl:_editor_el('input-control',template),label:_editor_el((f6Q+P85+S5),template),fieldInfo:_editor_el('msg-info',template),labelInfo:_editor_el((A2+b65+l8O+y75+Y85+x4x+y75),template),fieldError:_editor_el((A2+b65+l8O+c25+e3x+R15+d0),template),fieldMessage:_editor_el('msg-message',template),multi:_editor_el('multi-value',template),multiReturn:_editor_el((y65+l8O+u15+u3+t75),template),multiInfo:_editor_el('multi-info',template)}
);this[(o6v.l6Q+A1)][(A6Q+b5Q+q05+F1Q)][f5]((v25+h8+P75),function(){var G65='only',n0='read',U2x="tiEd";if(that[Y05][L2][(K5Q+H05+b5Q+U2x+F1Q+q05+T2Q+U65)]&&!template[O0Q](classes[(K85+T2Q+m2Q+b5Q+o6v.B6Q+o6v.l6Q)])&&opts[(U6Q+o6v.B6Q)]!==(n0+G65)){that[(J8Q+b5Q)]('');}
}
);this[(o6v.l6Q+o6v.l4Q+K5Q)][(K5Q+v1O+q05+H6O+c05+t4O+o6v.G4Q)][(o6v.l4Q+o6v.G4Q)]('click',function(){that[Y05][(D7+q05+E0Q+D7O)]=true;that[x85]();}
);$[(o6v.B6Q+s6x)](this[Y05][(q05+a85+C6x)],function(name,fn){var K6x='fun';if(typeof fn===(K6x+v25+o6v.R0+C75)&&that[name]===undefined){that[name]=function(){var R6O="ly",args=Array.prototype.slice.call(arguments);args[(x2Q+r3O+y2)](name);var ret=that[T9Q][(l85+o6v.v9Q+R6O)](that,args);return ret===undefined?that:ret;}
;}
}
);}
;Editor.Field.prototype={def:function(set){var k1Q="isFunction",X7='ef',t9='fault',opts=this[Y05][L2];if(set===undefined){var def=opts[(o25+c25+t9)]!==undefined?opts[(o25+X7+Y85+Z1x)]:opts[(V2O+o6v.Y7Q)];return $[k1Q](def)?def():def;}
opts[w4O]=set;return this;}
,disable:function(){var m0='ble';this[Q0][(H2Q+f5+q05+T2Q+F1Q+G35+o6v.B9Q)][(T2Q+a2O+p8O+O4+Y05)](this[Y05][k0][u4Q]);this[(N8Q+U6Q+o6v.B6Q+A6O)]((o25+K1O+m0));return this;}
,displayed:function(){var J9x="arents",container=this[(Q0)][W85];return container[(o6v.v9Q+J9x)]('body').length&&container[v15]((o25+v75+s0+q7Q+Y85+a8))!=(G2x+i15+c25)?true:false;}
,enable:function(){var k9Q='enabl';this[(Q0)][(H2Q+o6v.l4Q+k6+o6v.B6Q+o6v.B9Q)][(e5Q+K5Q+s9+o6v.B6Q+d75)](this[Y05][k0][(f2O+U5x+o6v.l6Q)]);this[T9Q]((k9Q+c25));return this;}
,enabled:function(){return this[(o6v.l6Q+A1)][(k7x+o6v.G4Q+L0x+F1Q+o6v.G4Q+o6v.B6Q+o6v.B9Q)][O0Q](this[Y05][(y6+L05)][u4Q])===false;}
,error:function(msg,fn){var Q05="fieldError",E3="lasses",classes=this[Y05][(H2Q+E3)];if(msg){this[(o6v.l6Q+o6v.l4Q+K5Q)][W85][(m5Q+o6v.l6Q+d75)](classes.error);}
else{this[Q0][W85][k0Q](classes.error);}
this[T9Q]('errorMessage',msg);return this[H5O](this[Q0][Q05],msg,fn);}
,fieldInfo:function(msg){var c85="fieldInfo",R3="sg";return this[(N8Q+K5Q+R3)](this[(Q5O+K5Q)][c85],msg);}
,isMultiValue:function(){return this[Y05][S7Q]&&this[Y05][(L9O+b1)].length!==1;}
,inError:function(){var a5O="sClas",X25="tainer";return this[(Q5O+K5Q)][(k7x+o6v.G4Q+X25)][(W9x+a5O+Y05)](this[Y05][(H2Q+b5Q+w65+D3+Y05)].error);}
,input:function(){var z1="ainer";return this[Y05][(e05)][(F1Q+B65+A4O)]?this[T9Q]('input'):$((v75+Y0+K9+s0+c25+Z9Q+K9+o6v.R0+c25+Y8+o6v.R0+Y85+q5+Y85),this[Q0][(f0x+z1)]);}
,focus:function(){var G8Q="peFn";if(this[Y05][(r4x+C6x)][F35]){this[(N8Q+r4x+G8Q)]((Z65+R15+v25+o15));}
else{$('input, select, textarea',this[(Q5O+K5Q)][W85])[(o6v.Y7Q+o6v.l4Q+v0O)]();}
return this;}
,get:function(){var J35="_typeF",V1O="iV";if(this[(F1Q+Y05+U7O+v1O+q05+V1O+T2Q+g2O+o6v.B6Q)]()){return undefined;}
var val=this[(J35+o6v.G4Q)]((b65+c25+o6v.R0));return val!==undefined?val:this[w4O]();}
,hide:function(animate){var K0O="eUp",el=this[(o6v.l6Q+o6v.l4Q+K5Q)][W85];if(animate===undefined){animate=true;}
if(this[Y05][r8Q][a15]()&&animate){el[(Y05+q9x+o6v.l6Q+K0O)]();}
else{el[v15]('display',(G2x+i15+c25));}
return this;}
,label:function(str){var label=this[Q0][(F1x+T3+b5Q)],labelInfo=this[Q0][b0Q][(o6v.l6Q+o6v.B6Q+L0x+H2Q+E7Q)]();if(str===undefined){return label[J5Q]();}
label[J5Q](str);label[(T2Q+o6v.v9Q+o6v.v9Q+X4Q+o6v.l6Q)](labelInfo);return this;}
,labelInfo:function(msg){var c6="lInfo";return this[H5O](this[(o6v.l6Q+o6v.l4Q+K5Q)][(b5Q+n1Q+o6v.B6Q+c6)],msg);}
,message:function(msg,fn){var n5Q="fieldMessage";return this[H5O](this[(o6v.l6Q+A1)][n5Q],msg,fn);}
,multiGet:function(id){var y6O="Valu",j8O="ultiIds",value,multiValues=this[Y05][W35],multiIds=this[Y05][(K5Q+j8O)];if(id===undefined){value={}
;for(var i=0;i<multiIds.length;i++){value[multiIds[i]]=this[E5Q]()?multiValues[multiIds[i]]:this[(J8Q+b5Q)]();}
}
else if(this[(F1Q+Y05+U7O+v1O+q05+F1Q+y6O+o6v.B6Q)]()){value=multiValues[id];}
else{value=this[(M35+T2Q+b5Q)]();}
return value;}
,multiSet:function(id,val){var multiValues=this[Y05][W35],multiIds=this[Y05][(A6Q+b5Q+u2x+q6O+z4O)];if(val===undefined){val=id;id=undefined;}
var set=function(idSrc,val){if($[(F1Q+o6v.G4Q+o3O+Q25+T2Q+a85)](multiIds)===-1){multiIds[C7O](idSrc);}
multiValues[idSrc]=val;}
;if($[E2O](val)&&id===undefined){$[P1Q](val,function(idSrc,innerVal){set(idSrc,innerVal);}
);}
else if(id===undefined){$[(z2Q+H2Q+E7Q)](multiIds,function(i,idSrc){set(idSrc,val);}
);}
else{set(id,val);}
this[Y05][S7Q]=true;this[x85]();return this;}
,name:function(){return this[Y05][L2][(L2Q+o6v.B6Q)];}
,node:function(){return this[(o6v.l6Q+A1)][W85][0];}
,set:function(val,multiCheck){var S7O="alu",U3O="_mu",U1O="entityDecode",decodeFn=function(d){var N6O='\'';var m2O="rep";return typeof d!==(l2O+d0+v75+i15+b65)?d:d[L6x](/&gt;/g,'>')[(e5Q+o6v.v9Q+F1x+v8x)](/&lt;/g,'<')[(m2O+d9Q+o6v.B6Q)](/&amp;/g,'&')[(m2O+d9Q+o6v.B6Q)](/&quot;/g,'"')[(m2O+b5Q+D5Q+o6v.B6Q)](/&#39;/g,(N6O))[L6x](/&#10;/g,'\n');}
;this[Y05][S7Q]=false;var decode=this[Y05][(o6v.l4Q+o6v.v9Q+o6v.r1x)][U1O];if(decode===undefined||decode===true){if($[(F0x+o6v.B9Q+F85)](val)){for(var i=0,ien=val.length;i<ien;i++){val[i]=decodeFn(val[i]);}
}
else{val=decodeFn(val);}
}
this[T9Q]((T4x+o6v.R0),val);if(multiCheck===undefined||multiCheck===true){this[(U3O+Z7x+M9O+S7O+c8O+o3x)]();}
return this;}
,show:function(animate){var E25='isplay',D0x="slideDown",el=this[(Q5O+K5Q)][W85];if(animate===undefined){animate=true;}
if(this[Y05][(r8Q)][(o6v.l6Q+a6x+F1x+a85)]()&&animate){el[D0x]();}
else{el[(v15)]((o25+E25),(P85+y75+R15+v25+P75));}
return this;}
,val:function(val){return val===undefined?this[(W7Q+o6v.B6Q+q05)]():this[q4Q](val);}
,dataSrc:function(){return this[Y05][(o6v.l4Q+r8O)].data;}
,destroy:function(){var b4O='oy',D05='dest',b85="peF";this[Q0][(k7x+k6+U9Q)][k8]();this[(N8Q+r4x+b85+o6v.G4Q)]((D05+d0+b4O));return this;}
,multiEditable:function(){return this[Y05][(L2)][u7O];}
,multiIds:function(){return this[Y05][J1];}
,multiInfoShown:function(show){this[Q0][(A6Q+v2O+F1Q+m8O)][(H2Q+Y05+Y05)]({display:show?'block':(i15+u2)}
);}
,multiReset:function(){this[Y05][(K5Q+v1O+q05+b1)]=[];this[Y05][(A6Q+v2O+F1Q+M9O+T2Q+b5Q+H05+L05)]={}
;}
,valFromData:null,valToData:null,_errorNode:function(){var g2x="ldE";return this[(Q5O+K5Q)][(p0+o6v.B6Q+g2x+o6v.B9Q+o6v.B9Q+o6v.l4Q+o6v.B9Q)];}
,_msg:function(el,msg,fn){var p9O="eU",j85="lide";if(msg===undefined){return el[J5Q]();}
if(typeof msg===(Z65+R65+v25+o6v.R0+C75)){var editor=this[Y05][(E7Q+o6v.l4Q+Y1)];msg=msg(editor,new DataTable[(V9Q)](editor[Y05][s25]));}
if(el.parent()[Y5Q](":visible")){el[J5Q](msg);if(msg){el[(Y05+j85+o8O+J9+o6v.G4Q)](fn);}
else{el[(Y05+b5Q+F1Q+o6v.l6Q+p9O+o6v.v9Q)](fn);}
}
else{el[J5Q](msg||'')[(H2Q+Y05+Y05)]('display',msg?(A0O+c0O+P75):(n3));if(fn){fn();}
}
return this;}
,_multiValueCheck:function(){var R6Q="_multiInfo",i05="oE",f4="ggl",s8O="noM",w75="tiI",p7O='ock',b8O="multiReturn",L3O="multi",T15="ontrol",m4Q="rol",O6O="putC",h7x="tiVa",last,ids=this[Y05][J1],values=this[Y05][W35],isMultiValue=this[Y05][(K5Q+H05+b5Q+u2x+M9O+T2Q+g2O+o6v.B6Q)],isMultiEditable=this[Y05][L2][u7O],val,different=false;if(ids){for(var i=0;i<ids.length;i++){val=values[ids[i]];if(i>0&&!_deepCompare(val,last)){different=true;break;}
last=val;}
}
if((different&&isMultiValue)||(!isMultiEditable&&this[(F1Q+W05+H05+b5Q+h7x+b5Q+y8O)]())){this[Q0][(D7Q+O6O+o6v.l4Q+o6v.O75+m4Q)][v15]({display:'none'}
);this[Q0][(K5Q+H05+b5Q+q05+F1Q)][v15]({display:(P85+g9Q+F8Q)}
);}
else{this[Q0][(F1Q+o6v.G4Q+l0O+A+T15)][v15]({display:'block'}
);this[Q0][L3O][(H2Q+S1)]({display:(G2x+i15+c25)}
);if(isMultiValue&&!different){this[q4Q](last,false);}
}
this[Q0][b8O][(H2Q+Y05+Y05)]({display:ids&&ids.length>1&&different&&!isMultiValue?(A0O+p7O):(i15+u2)}
);var i18n=this[Y05][r8Q][J3][L3O];this[(o6v.l6Q+o6v.l4Q+K5Q)][(K5Q+H05+b5Q+w75+o6v.G4Q+H3)][J5Q](isMultiEditable?i18n[(D7Q+H3)]:i18n[(s8O+H05+b5Q+u2x)]);this[(o6v.l6Q+o6v.l4Q+K5Q)][L3O][(q05+o6v.l4Q+f4+o6v.B6Q+p8O+b5Q+o9x)](this[Y05][k0][(K5Q+H05+v2O+F1Q+M1O+i05+o6v.l6Q+P5Q)],!isMultiEditable);this[Y05][r8Q][R6Q]();return true;}
,_typeFn:function(name){var q="ost",args=Array.prototype.slice.call(arguments);args[e7]();args[U5O](this[Y05][L2]);var fn=this[Y05][(q05+b6O+o6v.B6Q)][name];if(fn){return fn[(T2Q+o6v.v9Q+P5x+a85)](this[Y05][(E7Q+q)],args);}
}
}
;Editor[(G2O+o2O)][(K5Q+K2+V35)]={}
;Editor[(X2O+L8Q+s5x)][W1x]={"className":"","data":"","def":"","fieldInfo":"","id":"","label":"","labelInfo":"","name":null,"type":(y3x+o6v.t85+q05),"message":"","multiEditable":true}
;Editor[t3Q][(K5Q+h4O+P8O)][(q4Q+u2x+o6v.G4Q+W7Q+Y05)]={type:null,name:null,classes:null,opts:null,host:null}
;Editor[(t3Q)][(m8Q+g15)][(o6v.l6Q+o6v.l4Q+K5Q)]={container:null,label:null,labelInfo:null,fieldInfo:null,fieldError:null,fieldMessage:null}
;Editor[(m8Q+g15)]={}
;Editor[r9Q][(o6v.l6Q+F1Q+Y05+k25+o6v.l4Q+o6v.G4Q+j1x+o6v.l4Q+b5Q+b5Q+o6v.B6Q+o6v.B9Q)]={"init":function(dte){}
,"open":function(dte,append,fn){}
,"close":function(dte,fn){}
}
;Editor[r9Q][d7O]={"create":function(conf){}
,"get":function(conf){}
,"set":function(conf,val){}
,"enable":function(conf){}
,"disable":function(conf){}
}
;Editor[r9Q][x5]={"ajaxUrl":null,"ajax":null,"dataSource":null,"domTable":null,"opts":null,"displayController":null,"fields":{}
,"order":[],"id":-1,"displayed":false,"processing":false,"modifier":null,"action":null,"idSrc":null,"unique":0}
;Editor[(D15+b5Q+Y05)][H85]={"label":null,"fn":null,"className":null}
;Editor[(K5Q+o6v.l4Q+Y25+Y05)][S8]={onReturn:(u75+o6v.R0),onBlur:(i7x+c25),onBackground:(P85+y75+p15),onComplete:'close',onEsc:(P8Q+R15+s0+c25),onFieldError:(f85),submit:(h9+y75),focus:0,buttons:true,title:true,message:true,drawType:false}
;Editor[a15]={}
;(function(window,document,$,DataTable){var z15="ghtb",z25='Clo',o5O='D_L',I7='gro',a7O='htb',n7O='box_Co',O5O='ED_Li',v9x='nt_',W0O='_C',Y1O='ght',r5O='gh',E8='z',p4Q='W',u6O='x_',L7='Ligh',K0='Lightbo',r05="stop",m75="apper",H2O="_shown",M0x="ox",B6O="light",self;Editor[a15][(B6O+m2Q+M0x)]=$[(x8Q+o6v.B6Q+x05)](true,{}
,Editor[(K5Q+K2+V35)][(v7O+d7+F1x+a85+p8O+o6v.l4Q+o6v.G4Q+E2+P0O+U9Q)],{"init":function(dte){var M="_init";self[M]();return self;}
,"open":function(dte,append,callback){var q15="ppen",w4="detac",b6Q="sho";if(self[(N8Q+b6Q+K35+o6v.G4Q)]){if(callback){callback();}
return ;}
self[(V6x+q05+o6v.B6Q)]=dte;var content=self[m85][N3O];content[(j5x+J85+o6v.G4Q)]()[(w4+E7Q)]();content[(T2Q+q15+o6v.l6Q)](append)[(T2Q+p9x+o6v.B6Q+x05)](self[(N8Q+Q0)][(H2Q+w3O+Y05+o6v.B6Q)]);self[H2O]=true;self[(N8Q+b6Q+K35)](callback);}
,"close":function(dte,callback){var N3="wn";if(!self[H2O]){if(callback){callback();}
return ;}
self[(V6x+q05+o6v.B6Q)]=dte;self[O7](callback);self[(x0O+E7Q+o6v.l4Q+N3)]=false;}
,node:function(dte){return self[(V6x+o6v.l4Q+K5Q)][(J8+T2Q+o6v.v9Q+C6x+o6v.B9Q)][0];}
,"_init":function(){var b3Q='ci',d8Q="groun",k1O="rap",B9O="rea";if(self[(N8Q+B9O+o6v.l6Q+a85)]){return ;}
var dom=self[(N8Q+Q5O+K5Q)];dom[N3O]=$('div.DTED_Lightbox_Content',self[m85][(K35+o6v.B9Q+m75)]);dom[(K35+k1O+C6x+o6v.B9Q)][v15]((Q9O+Y5+a8),0);dom[(m2Q+D5Q+J1Q+d8Q+o6v.l6Q)][v15]((G7O+Y85+b3Q+m1Q),0);}
,"_show":function(callback){var C1O='_S',x7Q="kgrou",w5Q="not",L3x="lT",O5Q="lTop",m6x="scr",F2Q='tbox',n1='rap',R4O='ten',v1x='Con',K15="ckgr",o8x="grou",H4Q="fset",O8O="ontent",that=this,dom=self[(N8Q+Q0)];if(window[(o6v.l4Q+o6v.B9Q+F1Q+o6v.B6Q+o6v.G4Q+q05+d65+F1Q+o6v.l4Q+o6v.G4Q)]!==undefined){$('body')[(T2Q+a2O+p8O+O4+Y05)]('DTED_Lightbox_Mobile');}
dom[(H2Q+O8O)][(H2Q+Y05+Y05)]('height',(Y85+u3+o6v.R0+R15));dom[(J8+l85+o6v.v9Q+U9Q)][v15]({top:-self[(H2Q+G15)][(o6v.l4Q+o6v.Y7Q+H4Q+o3O+n85)]}
);$((H75+a8))[(T2Q+o6v.v9Q+C6x+o6v.G4Q+o6v.l6Q)](self[m85][Y75])[z6x](self[m85][q1O]);self[(A7x+o6v.B6Q+t2Q+E7Q+A+a0Q)]();dom[(r5Q+o6v.v9Q+o6v.v9Q+U9Q)][(r05)]()[O1x]({opacity:1,top:0}
,callback);dom[(m2Q+T2Q+H2Q+J1Q+o8x+o6v.G4Q+o6v.l6Q)][r05]()[(x35+F1Q+K5Q+d65+o6v.B6Q)]({opacity:1}
);setTimeout(function(){var q3x='ex',m4x='Foo';$((o25+v75+P3+R8O+v3Q+g85+g35+m4x+o6v.R0+c25+d0))[v15]((o6v.R0+q3x+o6v.R0+l8O+v75+H8Q+i15+o6v.R0),-1);}
,10);dom[(W9Q+o6v.B6Q)][(Z8+o6v.l6Q)]((N1Q+R8O+v3Q+g85+v3Q+g35+K0+Y8),function(e){self[(N8Q+f1x)][R9O]();}
);dom[(m2Q+T2Q+K15+o6v.l4Q+d7x)][Q0O]('click.DTED_Lightbox',function(e){self[c9Q][(o6+b2+L9+o6v.G4Q+o6v.l6Q)]();}
);$((o25+H5+R8O+v3Q+g85+v3Q+g35+L7+b75+u6O+v1x+R4O+o6v.R0+D4O+n1+I8Q+d0),dom[(K35+H4x+U9Q)])[(m2Q+r8)]('click.DTED_Lightbox',function(e){var S9="ackg",O7Q='x_Con',k0x="hasCla";if($(e[(q05+x25+a6O)])[(k0x+S1)]((v3Q+g85+v3Q+g35+r2Q+R8+l65+G8O+O7Q+o6v.R0+c25+i15+F5O+p4Q+h7+D+D+c25+d0))){self[(N8Q+o6v.l6Q+q05+o6v.B6Q)][(m2Q+S9+D1+x05)]();}
}
);$(window)[(m2Q+r8)]((d0+c25+s0+v75+E8+c25+R8O+v3Q+a9Q+i7Q+b65+c65+F2Q),function(){var A8Q="igh";self[(N8Q+e0O+A8Q+q05+p7Q+w5x)]();}
);self[(N8Q+m6x+m1+O5Q)]=$('body')[(Y05+H2Q+o6v.B9Q+o6v.l4Q+b5Q+L3x+o6v.l4Q+o6v.v9Q)]();if(window[(o6v.l4Q+o6v.B9Q+L8Q+o6v.G4Q+L0x+u2x+o6v.l4Q+o6v.G4Q)]!==undefined){var kids=$((H75+a8))[(T8+s5x+o6v.B9Q+o6v.B6Q+o6v.G4Q)]()[w5Q](dom[(o6+x7Q+x05)])[(o6v.G4Q+o6v.l4Q+q05)](dom[(J8+T2Q+F0)]);$('body')[z6x]((Q4O+o25+v75+P3+J5x+v25+y75+Y85+x2O+i9+v3Q+E1Q+o3Q+v3Q+g35+r2Q+v75+r5O+o6v.R0+s7+C1O+c65+R15+B3+i15+z4));$((p+R8O+v3Q+E1Q+p1x+i7Q+Y1O+P85+R15+Y8+C1O+U8O+i15))[z6x](kids);}
}
,"_heightCalc":function(){var K6Q='_Con',Y4O="addi",V4Q="wP",H="wi",dom=self[(V6x+o6v.l4Q+K5Q)],maxHeight=$(window).height()-(self[K2x][(H+x05+o6v.l4Q+V4Q+Y4O+H35)]*2)-$((p+R8O+v3Q+E1Q+o3Q+Z5Q+D5+Q9),dom[(K35+o6v.B9Q+l85+C6x+o6v.B9Q)])[I9Q]()-$('div.DTE_Footer',dom[(J8+m75)])[(L9+O8+Q75+F1Q+W7Q+E7Q+q05)]();$((o25+v75+P3+R8O+v3Q+g85+g35+u0Q+H7+K6Q+o6v.R0+c25+A6x),dom[(q1O)])[v15]('maxHeight',maxHeight);}
,"_hide":function(callback){var G1x='Lig',M75='ED_',k3="setAn",G6O="_scrollTop",F1O="scrollTop",g4='ile',x0x='DT',N8='Sho',t9Q='htbo',e6Q='_Lig',G1="ient",dom=self[(m85)];if(!callback){callback=function(){}
;}
if(window[(X4+G1+d65+n7Q+o6v.G4Q)]!==undefined){var show=$((T25+P3+R8O+v3Q+g85+v3Q+e6Q+t9Q+u6O+N8+B4x));show[m0x]()[w2O]((G8O+Y3));show[k8]();}
$('body')[(o6v.B9Q+r4Q+q6Q+p8O+F1x+S1)]((x0x+p1x+g35+r2Q+v75+b65+l65+G8O+u6O+V6Q+X0O+g4))[F1O](self[G6O]);dom[(K35+o6v.B9Q+T2Q+p9x+o6v.B6Q+o6v.B9Q)][r05]()[O1x]({opacity:0,top:self[K2x][(Z05+k3+F1Q)]}
,function(){var y4Q="etach";$(this)[(o6v.l6Q+y4Q)]();callback();}
);dom[Y75][r05]()[(x35+v7Q+T2Q+y3x)]({opacity:0}
,function(){$(this)[(o6v.l6Q+c05+s6x)]();}
);dom[R9O][T2O]((v25+h8+P75+R8O+v3Q+g85+v3Q+g35+K0+Y8));dom[(m2Q+T2Q+E2x+W7Q+h35+H05+x05)][T2O]('click.DTED_Lightbox');$('div.DTED_Lightbox_Content_Wrapper',dom[(J8+T2Q+o6v.v9Q+o6v.v9Q+o6v.B6Q+o6v.B9Q)])[(H05+o6v.G4Q+m2Q+r8)]((P8Q+S7+R8O+v3Q+E1Q+M75+G1x+c65+f4O+E5O));$(window)[T2O]((d0+c25+s0+v75+E8+c25+R8O+v3Q+C2O+V8x+r5O+o6v.R0+P85+E5O));}
,"_dte":null,"_ready":false,"_shown":false,"_dom":{"wrapper":$((Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9+v3Q+E1Q+o3Q+v3Q+J5x+v3Q+g85+c6x+r2Q+v75+Y1O+s7+g35+p4Q+d0+Y85+D+I8Q+d0+W6)+(Q4O+o25+H5+J5x+v25+y75+L2O+i9+v3Q+C2O+L7+o6v.R0+G8O+Y8+W0O+R15+Y4x+v75+i15+c25+d0+W6)+(Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9+v3Q+g85+c6x+r2Q+v75+r5O+o6v.R0+P85+R15+u6O+i0Q+R15+z9x+v9x+p4Q+d0+Y85+D+D+Q9+W6)+(Q4O+o25+v75+P3+J5x+v25+f6Q+x2O+i9+v3Q+E1Q+O5O+b65+c65+o6v.R0+n7O+A6x+r5+o6v.R0+W6)+(B2+o25+H5+r4O)+(B2+o25+H5+r4O)+(B2+o25+v75+P3+r4O)+'</div>'),"background":$((Q4O+o25+H5+J5x+v25+y75+L2O+i9+v3Q+g85+v3Q+g35+r2Q+R8+a7O+E5O+g35+u0Q+Y85+v25+P75+I7+u3+c9+e8Q+o25+v75+P3+I9+o25+v75+P3+r4O)),"close":$((Q4O+o25+H5+J5x+v25+r6O+i9+v3Q+E1Q+o3Q+o5O+R8+a7O+E5O+g35+z25+s0+c25+O6+o25+v75+P3+r4O)),"content":null}
}
);self=Editor[(K85+o6v.v9Q+N)][(b5Q+F1Q+z15+o6v.l4Q+o6v.t85)];self[(H2Q+o6v.l4Q+o6v.G4Q+o6v.Y7Q)]={"offsetAni":25,"windowPadding":25}
;}
(window,document,jQuery,jQuery[C3][o6v.Y4]));(function(window,document,$,DataTable){var Z0O="ope",s1O="vel",x15=';</',K8='imes',Q2x='">&',u4='Cl',A8='e_',r4='elo',M6x='TED_E',L6O='roun',z1O='elope_Ba',F5Q='ner',z8O='lope',S1x='_Env',k8O='pe_S',A4Q='ppe',Y0Q='Wra',b2O='D_En',P35="nf",C5x="style",O85='nve',y8="_do",y2Q="layCont",W2O="envelope",self;Editor[a15][W2O]=$[d8O](true,{}
,Editor[r9Q][(o6v.l6Q+a6x+y2Q+o6v.B9Q+w2x+o6v.B6Q+o6v.B9Q)],{"init":function(dte){self[c9Q]=dte;self[(n0x+P5Q)]();return self;}
,"open":function(dte,append,callback){var X3O="Child",x1Q="pendCh";self[(V6x+q05+o6v.B6Q)]=dte;$(self[m85][(N3O)])[m0x]()[(V2O+q05+T2Q+H2Q+E7Q)]();self[(y8+K5Q)][(H2Q+f5+q05+X4Q+q05)][(l85+x1Q+F1Q+s5x)](append);self[(m85)][(H2Q+o6v.l4Q+o6v.G4Q+q05+o6v.B6Q+o6v.O75)][(Z7O+o6v.G4Q+o6v.l6Q+X3O)](self[(V6x+o6v.l4Q+K5Q)][R9O]);self[(N8Q+u8+o6v.l4Q+K35)](callback);}
,"close":function(dte,callback){self[(V6x+q05+o6v.B6Q)]=dte;self[O7](callback);}
,node:function(dte){return self[m85][(J8+T2Q+o6v.v9Q+A9)][0];}
,"_init":function(){var b8='sible',u1Q="vi",p7="styl",l8="backg",x0="ground",Z4="_css",a1x="roun",V5="visbility",u0x="kgro",N8x="appendChild",t4x='iner',k0O='pe_',q8O="_ready";if(self[q8O]){return ;}
self[m85][N3O]=$((o25+v75+P3+R8O+v3Q+g85+c6x+o3Q+O85+y75+R15+k0O+i0Q+R15+Y4x+t4x),self[(N8Q+o6v.l6Q+A1)][(K35+o6v.B9Q+T2Q+o6v.v9Q+o6v.v9Q+U9Q)])[0];document[(z9O+a85)][(T2Q+o6v.v9Q+C6x+o6v.G4Q+o6v.l6Q+u5Q+W6Q+o6v.l6Q)](self[m85][Y75]);document[(m2Q+o6v.l4Q+o6v.l6Q+a85)][N8x](self[(N8Q+o6v.l6Q+o6v.l4Q+K5Q)][(K35+o6v.B9Q+T2Q+o6v.v9Q+C6x+o6v.B9Q)]);self[(N8Q+Q0)][(o6+u0x+m1O+o6v.l6Q)][C5x][V5]=(t05+o25+o25+c25+i15);self[(m85)][(m2Q+T2Q+E2x+W7Q+a1x+o6v.l6Q)][C5x][a15]=(x5x+F8Q);self[(Z4+i1x+J1Q+x0+G3Q+T2Q+H2Q+P5Q+a85)]=$(self[m85][(l8+o6v.B9Q+L9+x05)])[v15]((Q9O+v75+m1Q));self[(m85)][Y75][C5x][(o6v.l6Q+F1Q+d7+b5Q+z75)]='none';self[m85][Y75][(p7+o6v.B6Q)][(u1Q+Y05+m2Q+W6Q+P5Q+a85)]=(P3+v75+b8);}
,"_show":function(callback){var D3x='Envel',E3Q='velo',v3O='_E',L7Q="ckg",a0="ba",M9Q="wPa",R5Q="win",l2="fs",F9x="windowS",v2Q="ppe",S85='rma',e2Q="_cssBackgroundOpacity",z4x="opa",P7O="gro",o0x="gh",V2="setHei",e3="Lef",b3O="marg",V3O="px",T2x="ci",U2="idth",W8x="etW",I0="offs",B0="ightC",z4Q="ndA",t6="rapper",f0='aut',that=this,formHeight;if(!callback){callback=function(){}
;}
self[m85][N3O][(Y05+r4x+U5x)].height=(f0+R15);var style=self[m85][(K35+t6)][C5x];style[(o6v.l4Q+D2x+H2Q+F1Q+q05+a85)]=0;style[a15]='block';var targetRow=self[(N8Q+p0+z4Q+q05+w9+C5O+J9)](),height=self[(N8Q+E7Q+o6v.B6Q+B0+a0Q)](),width=targetRow[(I0+W8x+U2)];style[(v7O+Y05+P6Q+a85)]='none';style[(o6v.l4Q+D2x+T2x+r4x)]=1;self[m85][q1O][(Z9O+b5Q+o6v.B6Q)].width=width+(V3O);self[(V6x+o6v.l4Q+K5Q)][q1O][(Y05+q05+a85+b5Q+o6v.B6Q)][(b3O+D7Q+e3+q05)]=-(width/2)+(V3O);self._dom.wrapper.style.top=($(targetRow).offset().top+targetRow[(i6+o6v.Y7Q+V2+o0x+q05)])+(V3O);self._dom.content.style.top=((-1*height)-20)+(V3O);self[(N8Q+o6v.l6Q+A1)][(m2Q+D5Q+J1Q+P7O+H05+o6v.G4Q+o6v.l6Q)][(Y05+r4x+U5x)][(z4x+H2Q+F1Q+q05+a85)]=0;self[(y8+K5Q)][Y75][(Y05+q05+a85+U5x)][(v7O+Y05+o6v.v9Q+b5Q+T2Q+a85)]=(x5x+v25+P75);$(self[(y8+K5Q)][(m2Q+D5Q+b2+F65)])[(T2Q+n85+K5Q+T2Q+y3x)]({'opacity':self[e2Q]}
,(G2x+S85+y75));$(self[m85][(J8+T2Q+v2Q+o6v.B9Q)])[(o6v.Y7Q+m5Q+o6v.B6Q+c0x)]();if(self[(k7x+P35)][(F9x+H2Q+o6v.B9Q+w2x)]){$((l65+u15+y75+t8O+P85+H7))[O1x]({"scrollTop":$(targetRow).offset().top+targetRow[(i6+l2+c05+Q75+F1Q+o0x+q05)]-self[K2x][(R5Q+o6v.l6Q+o6v.l4Q+M9Q+o6v.l6Q+o6v.l6Q+F1Q+H35)]}
,function(){var p65="mate";$(self[m85][(f0x+X4Q+q05)])[(T2Q+o6v.G4Q+F1Q+p65)]({"top":0}
,600,callback);}
);}
else{$(self[(y8+K5Q)][N3O])[O1x]({"top":0}
,600,callback);}
$(self[(N8Q+o6v.l6Q+o6v.l4Q+K5Q)][R9O])[Q0O]((u1x+v25+P75+R8O+v3Q+E1Q+o3Q+b2O+P3+c25+g9Q+I8Q),function(e){self[(V6x+q05+o6v.B6Q)][R9O]();}
);$(self[m85][(a0+L7Q+h35+m1O+o6v.l6Q)])[(Z8+o6v.l6Q)]((B4Q+P75+R8O+v3Q+a9Q+v3O+i15+E3Q+D+c25),function(e){self[c9Q][Y75]();}
);$('div.DTED_Lightbox_Content_Wrapper',self[(m85)][(J8+k8Q+o6v.B6Q+o6v.B9Q)])[(m2Q+F1Q+o6v.G4Q+o6v.l6Q)]((N1Q+R8O+v3Q+E1Q+o3Q+v3Q+g35+D3x+R15+D+c25),function(e){var z1Q='pp',a65='Wr',l4O='Envelope_C';if($(e[(L0x+o6v.B9Q+W7Q+o6v.B6Q+q05)])[O0Q]((v3Q+E1Q+p1x+g35+l4O+R15+i15+o6v.R0+c25+i15+F5O+a65+Y85+z1Q+c25+d0))){self[(N8Q+o6v.l6Q+y3x)][Y75]();}
}
);$(window)[(Z8+o6v.l6Q)]('resize.DTED_Envelope',function(){var V0Q="eigh";self[(N8Q+E7Q+V0Q+A+T2Q+b5Q+H2Q)]();}
);}
,"_heightCalc":function(){var G6Q="terHe",P7='Body_',k6Q='ote',d05='E_F',C0='der',u3O="Padd",i9x="wind",T1Q="ei",S0="heightCalc",formHeight;formHeight=self[(H2Q+G15)][S0]?self[K2x][(E7Q+T1Q+W7Q+p1O+p7Q+w5x)](self[(V6x+A1)][q1O]):$(self[m85][N3O])[(H2Q+E7Q+W6Q+J85+o6v.G4Q)]().height();var maxHeight=$(window).height()-(self[K2x][(i9x+J9+u3O+F1Q+o6v.G4Q+W7Q)]*2)-$((o25+H5+R8O+v3Q+E1Q+o3Q+Z5Q+Y85+C0),self[(y8+K5Q)][(K35+o6v.B9Q+l85+o6v.v9Q+o6v.B6Q+o6v.B9Q)])[I9Q]()-$((o25+v75+P3+R8O+v3Q+E1Q+d05+R15+k6Q+d0),self[(V6x+o6v.l4Q+K5Q)][q1O])[I9Q]();$((p+R8O+v3Q+E1Q+o3Q+g35+P7+i0Q+R15+i15+I9O+i15+o6v.R0),self[(N8Q+Q5O+K5Q)][q1O])[(H2Q+S1)]('maxHeight',maxHeight);return $(self[c9Q][(o6v.l6Q+A1)][q1O])[(L9+G6Q+t2Q+p1O)]();}
,"_hide":function(callback){var J1O='size',F3x='ap',i8='Cont',K5x='Light',Q="unbi",F8O="los",c75="Heig";if(!callback){callback=function(){}
;}
$(self[(V6x+A1)][(f0x+Y6)])[(T2Q+o6v.G4Q+v7Q+T2Q+q05+o6v.B6Q)]({"top":-(self[m85][(f0x+o6v.B6Q+o6v.G4Q+q05)][(Z05+Y05+c05+c75+p1O)]+50)}
,600,function(){var p2O='mal',d5x='nor',U3Q="deO";$([self[(N8Q+o6v.l6Q+A1)][(K35+U7Q+p9x+o6v.B6Q+o6v.B9Q)],self[(V6x+A1)][Y75]])[(o6v.Y7Q+T2Q+U3Q+H05+q05)]((d5x+p2O),callback);}
);$(self[m85][(H2Q+F8O+o6v.B6Q)])[T2O]((P8Q+v75+F8Q+R8O+v3Q+E1Q+o3Q+v3Q+g35+r2Q+R8+c65+f4O+E5O));$(self[(N8Q+Q0)][Y75])[(Q+x05)]((P8Q+V3+P75+R8O+v3Q+E1Q+o3Q+c6x+K5x+P85+R15+Y8));$((o25+H5+R8O+v3Q+E1Q+o3Q+c6x+V8x+b65+c65+b75+Y8+g35+i8+c25+i15+o6v.R0+D4O+d0+F3x+D+Q9),self[m85][(r5Q+o6v.v9Q+o6v.v9Q+U9Q)])[(m1O+m2Q+r8)]((v25+h8+P75+R8O+v3Q+E1Q+o3Q+v3Q+g35+r2Q+R8+l65+G8O+Y8));$(window)[(m1O+m2Q+F1Q+x05)]((d0+c25+J1O+R8O+v3Q+E1Q+p1x+i7Q+b65+c65+o6v.R0+s7));}
,"_findAttachRow":function(){var a9x='head',l35="attac",dt=$(self[(V6x+y3x)][Y05][s25])[(o8O+h3x+W4O+T2Q+m2Q+b5Q+o6v.B6Q)]();if(self[(k7x+P35)][(l35+E7Q)]===(a9x)){return dt[s25]()[(E7Q+o6v.B6Q+m5Q+U9Q)]();}
else if(self[c9Q][Y05][b7O]==='create'){return dt[s25]()[(E7Q+o6v.B6Q+s8x)]();}
else{return dt[(o6v.B9Q+J9)](self[(N8Q+f1x)][Y05][(m8Q+v7O+o6v.Y7Q+L8Q+o6v.B9Q)])[t0O]();}
}
,"_dte":null,"_ready":false,"_cssBackgroundOpacity":1,"_dom":{"wrapper":$((Q4O+o25+v75+P3+J5x+v25+T8x+s0+i9+v3Q+a9Q+J5x+v3Q+C2O+o3Q+O85+g9Q+I8Q+g35+Y0Q+A4Q+d0+W6)+(Q4O+o25+H5+J5x+v25+y75+i8x+s0+i9+v3Q+g85+b2O+P3+c25+g9Q+k8O+g5Q+o25+R15+B3+O6+o25+H5+r4O)+(Q4O+o25+H5+J5x+v25+y75+i8x+s0+i9+v3Q+g85+v3Q+S1x+c25+z8O+g35+i0Q+R15+Y4x+v75+F5Q+O6+o25+v75+P3+r4O)+'</div>')[0],"background":$((Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9+v3Q+a9Q+g35+o3Q+i15+P3+z1O+F8Q+b65+L6O+o25+e8Q+o25+v75+P3+I9+o25+H5+r4O))[0],"close":$((Q4O+o25+H5+J5x+v25+r6O+i9+v3Q+M6x+i15+P3+r4+D+A8+u4+m3O+Q2x+o6v.R0+K8+x15+o25+v75+P3+r4O))[0],"content":null}
}
);self=Editor[(o6v.l6Q+Y5Q+P5x+T2Q+a85)][(o6v.B6Q+o6v.G4Q+s1O+Z0O)];self[K2x]={"windowPadding":50,"heightCalc":null,"attach":"row","windowScroll":true}
;}
(window,document,jQuery,jQuery[(C3)][(d1Q+Z8Q+n1Q+b5Q+o6v.B6Q)]));Editor.prototype.add=function(cfg,after){var q8x="inArra",e1x='tFie',a4x="ataSource",R2x="sts",B2Q="'. ",G8="` ",d6O=" `";if($[z9Q](cfg)){for(var i=0,iLen=cfg.length;i<iLen;i++){this[(T2Q+a2O)](cfg[i]);}
}
else{var name=cfg[(P9Q+V9O)];if(name===undefined){throw (y6x+h35+o6v.B9Q+a9+T2Q+O9O+o6v.G4Q+W7Q+a9+o6v.Y7Q+F1Q+o6v.B6Q+s5x+S6x+W4O+e0O+a9+o6v.Y7Q+F1Q+o2O+a9+o6v.B9Q+o6v.B6Q+q9Q+H05+s1Q+L05+a9+T2Q+d6O+o6v.G4Q+X35+o6v.B6Q+G8+o6v.l4Q+o6v.v9Q+u2x+f5);}
if(this[Y05][I4x][name]){throw "Error adding field '"+name+(B2Q+o3O+a9+o6v.Y7Q+L8Q+s5x+a9+T2Q+b5Q+e5Q+m5Q+a85+a9+o6v.B6Q+o6v.t85+F1Q+R2x+a9+K35+F1Q+q05+E7Q+a9+q05+r3O+Y05+a9+o6v.G4Q+X35+o6v.B6Q);}
this[(V6x+a4x)]((l8Q+e1x+a7Q),cfg);this[Y05][(p0+o6v.B6Q+P25)][name]=new Editor[(X2O+F1Q+i5Q+o6v.l6Q)](cfg,this[(b6x+T2Q+S1+L05)][(o6v.Y7Q+F1Q+i5Q+o6v.l6Q)],this);if(after===undefined){this[Y05][(p25+o6v.B6Q+o6v.B9Q)][(o6v.v9Q+s4O+E7Q)](name);}
else if(after===null){this[Y05][s8Q][U5O](name);}
else{var idx=$[(q8x+a85)](after,this[Y05][(p25+o6v.B6Q+o6v.B9Q)]);this[Y05][(p25+o6v.B6Q+o6v.B9Q)][(Y05+o6v.v9Q+q9x+v8x)](idx+1,0,name);}
}
this[j7](this[s8Q]());return this;}
;Editor.prototype.background=function(){var P65="submi",D35="onBackground",onBackground=this[Y05][W2Q][D35];if(typeof onBackground===(Z65+R65+v25+u3Q+C6O)){onBackground(this);}
else if(onBackground==='blur'){this[c35]();}
else if(onBackground==='close'){this[(H2Q+b5Q+u1)]();}
else if(onBackground===(r2O+P85+u15+Y5)){this[(P65+q05)]();}
return this;}
;Editor.prototype.blur=function(){var P0="_blur";this[P0]();return this;}
;Editor.prototype.bubble=function(cells,fieldNames,show,opts){var w05='ubb',D0="ude",W8="inc",W8O="bubblePosition",j6="dren",D2Q="pointer",o9Q='ica',m3x='ssin',o2Q='oce',l8x='Pr',h8Q="liner",G7x="conc",l9='iz',C8="eopen",M2O="tions",r3x="urc",u4O="So",g6x="data",A7O="Opt",that=this;if(this[(N8Q+u2x+X3Q)](function(){that[(b5+m2Q+H2+o6v.B6Q)](cells,fieldNames,opts);}
)){return this;}
if($[E2O](fieldNames)){opts=fieldNames;fieldNames=undefined;show=true;}
else if(typeof fieldNames==='boolean'){show=fieldNames;fieldNames=undefined;opts=undefined;}
if($[E2O](show)){opts=show;show=true;}
if(show===undefined){show=true;}
opts=$[(o6v.B6Q+o6v.t85+q05+o6v.B6Q+o6v.G4Q+o6v.l6Q)]({}
,this[Y05][(f5O+K5Q+A7O+n7Q+o6v.G4Q+Y05)][(m2Q+H05+f0Q+o6v.B6Q)],opts);var editFields=this[(N8Q+g6x+u4O+r3x+o6v.B6Q)]('individual',cells,fieldNames);this[(O6x+o6v.l6Q+P5Q)](cells,editFields,(z9));var namespace=this[(L7x+X4+K5Q+G3Q+M2O)](opts),ret=this[(m9x+o6v.B9Q+C8)]((P85+O9Q+A0O+c25));if(!ret){return this;}
$(window)[(f5)]((d0+V9+l9+c25+R8O)+namespace,function(){var y2x="osit",t5O="eP",d7Q="ubbl";that[(m2Q+d7Q+t5O+y2x+F1Q+o6v.l4Q+o6v.G4Q)]();}
);var nodes=[];this[Y05][H9x]=nodes[(G7x+d65)][Q2Q](nodes,_pluck(editFields,'attach'));var classes=this[(b6x+T2Q+Y05+Y05+L05)][(b5+f0Q+o6v.B6Q)],background=$('<div class="'+classes[(m2Q+W7Q)]+(e8Q+o25+v75+P3+I9+o25+H5+r4O)),container=$((Q4O+o25+v75+P3+J5x+v25+y75+L2O+i9)+classes[(t65+A9)]+(W6)+'<div class="'+classes[h8Q]+(W6)+(Q4O+o25+H5+J5x+v25+y75+Y85+x2O+i9)+classes[(q05+T2Q+m2Q+U5x)]+(W6)+(Q4O+o25+H5+J5x+v25+T8x+s0+i9)+classes[(H2Q+b5Q+o6v.l4Q+Y05+o6v.B6Q)]+(r9x)+(Q4O+o25+H5+J5x+v25+f6Q+x2O+i9+v3Q+g85+g35+l8x+o2Q+m3x+R1x+i15+o25+o9Q+o6v.R0+R15+d0+e8Q+s0+E6x+c7O+o25+H5+r4O)+(B2+o25+H5+r4O)+(B2+o25+v75+P3+r4O)+'<div class="'+classes[D2Q]+(r9x)+'</div>');if(show){container[(T2Q+p9x+R9+W4O+o6v.l4Q)]((G8O+o25+a8));background[w2O]((P85+R15+o25+a8));}
var liner=container[m0x]()[n9Q](0),table=liner[(H2Q+E7Q+F1Q+b5Q+j6)](),close=table[(j5x+j6)]();liner[(T2Q+p9x+o6v.B6Q+o6v.G4Q+o6v.l6Q)](this[(Q5O+K5Q)][u2Q]);table[(b9x+o6v.B6Q+C6x+o6v.G4Q+o6v.l6Q)](this[(o6v.l6Q+o6v.l4Q+K5Q)][(o6v.Y7Q+o6v.l4Q+v35)]);if(opts[T0Q]){liner[(o6v.v9Q+o6v.B9Q+D9Q+R9)](this[(o6v.l6Q+A1)][(H3+v35+q6O+o6v.G4Q+o6v.Y7Q+o6v.l4Q)]);}
if(opts[O7x]){liner[(b9x+o6v.B6Q+o6v.v9Q+o6v.B6Q+x05)](this[(Q5O+K5Q)][h75]);}
if(opts[(b5+q05+q05+o6v.l4Q+s75)]){table[z6x](this[Q0][(H85+Y05)]);}
var pair=$()[(Q7O)](container)[Q7O](background);this[g6O](function(submitComplete){var s5="ani";pair[(s5+K5Q+d2x)]({opacity:0}
,function(){var H7O="rDyn";pair[(V2O+w9)]();$(window)[(i6+o6v.Y7Q)]('resize.'+namespace);that[(N4Q+z2Q+H7O+T2Q+K5Q+a3Q+q6O+R85)]();}
);}
);background[(b6x+F1Q+H2Q+J1Q)](function(){that[c35]();}
);close[(H2Q+q9x+E2x)](function(){that[(r2x+w3O+Y05+o6v.B6Q)]();}
);this[W8O]();pair[(T2Q+o6v.G4Q+F1Q+M8O+o6v.B6Q)]({opacity:1}
);this[z6O](this[Y05][(W8+b5Q+D0+X2O+F1Q+i5Q+o6v.l6Q+Y05)],opts[F35]);this[(m9x+o6v.l4Q+Y1+o6v.l4Q+o6v.v9Q+o6v.B6Q+o6v.G4Q)]((P85+w05+h7Q));return this;}
;Editor.prototype.bubblePosition=function(){var z5x="veCla",E35="addC",K8x="bott",T4Q="bble",t8="uterW",u9O="tom",t9O="rig",P2O="bot",r65="right",Z7Q="offset",B2O='_L',M8Q='_Bub',H1O='ubble',w0O='_B',wrapper=$((o25+H5+R8O+v3Q+g85+w0O+H1O)),liner=$((o25+H5+R8O+v3Q+E1Q+o3Q+M8Q+P85+h7Q+B2O+z0Q+d0)),nodes=this[Y05][H9x],position={top:0,left:0,right:0,bottom:0}
;$[(o6v.B6Q+T2Q+H2Q+E7Q)](nodes,function(i,node){var Z0x="Hei",p0x="Wid",M7Q="ef",Q5Q="lef",pos=$(node)[Z7Q]();node=$(node)[a6O](0);position.top+=pos.top;position[(Q5Q+q05)]+=pos[(U5x+y2)];position[r65]+=pos[(b5Q+M7Q+q05)]+node[(Z05+q4Q+p0x+q05+E7Q)];position[(P2O+q7x+K5Q)]+=pos.top+node[(i6+o6v.Y7Q+q4Q+Z0x+T8O)];}
);position.top/=nodes.length;position[t5x]/=nodes.length;position[(t9O+E7Q+q05)]/=nodes.length;position[(P2O+u9O)]/=nodes.length;var top=position.top,left=(position[t5x]+position[r65])/2,width=liner[(o6v.l4Q+t8+F1Q+o6v.l6Q+q05+E7Q)](),visLeft=left-(width/2),visRight=visLeft+width,docWidth=$(window).width(),padding=15,classes=this[k0][(b5+T4Q)];wrapper[v15]({top:top,left:left}
);if(liner.length&&liner[(Z7Q)]().top<0){wrapper[(H2Q+Y05+Y05)]((N2Q+D),position[(K8x+A1)])[(E35+F1x+Y05+Y05)]((P85+c25+y75+R15+B3));}
else{wrapper[(C1Q+z5x+Y05+Y05)]('below');}
if(visRight+padding>docWidth){var diff=visRight-docWidth;liner[v15]('left',visLeft<padding?-(visLeft-padding):-(diff+padding));}
else{liner[v15]('left',visLeft<padding?-(visLeft-padding):0);}
return this;}
;Editor.prototype.buttons=function(buttons){var W0x='sic',that=this;if(buttons===(e3Q+Y85+W0x)){buttons=[{label:this[(J3)][this[Y05][(T2Q+G4x+n7Q+o6v.G4Q)]][(Y05+h3O+K5Q+F1Q+q05)],fn:function(){this[G3x]();}
}
];}
else if(!$[(F1Q+m7Q+a1O)](buttons)){buttons=[buttons];}
$(this[(Q5O+K5Q)][(m2Q+H05+a5x+o6v.l4Q+o6v.G4Q+Y05)]).empty();$[(o6v.B6Q+D5Q+E7Q)](buttons,function(i,btn){var H6x="Name",o7="className",S5Q='rin';if(typeof btn===(l2O+S5Q+b65)){btn={label:btn,fn:function(){this[(R3Q+K5Q+F1Q+q05)]();}
}
;}
$((Q4O+P85+B15+N2Q+i15+q1),{'class':that[(H2Q+W6x+o6v.B6Q+Y05)][z65][H85]+(btn[o7]?' '+btn[(H2Q+b5Q+T2Q+S1+H6x)]:'')}
)[J5Q](typeof btn[(b5Q+T2Q+T3+b5Q)]===(Z65+u3+i15+v25+k2x+i15)?btn[q9O](that):btn[(F1x+m2Q+i5Q)]||'')[x9x]('tabindex',btn[(L0+q6O+x05+o6v.B6Q+o6v.t85)]!==undefined?btn[(q05+T2Q+m2Q+q6O+r2+o6v.t85)]:0)[(f5)]((P75+E3x+u3+D),function(e){if(e[Q15]===13&&btn[C3]){btn[(C3)][(K7O)](that);}
}
)[(f5)]('keypress',function(e){var V="De";if(e[Q15]===13){e[(b9x+t35+o6v.O75+V+o75+H05+v2O)]();}
}
)[f5]('click',function(e){var O9="preven";e[(O9+M0+o6v.B6Q+o75+v1O+q05)]();if(btn[(C3)]){btn[(C3)][(r0x+P0O)](that);}
}
)[(T2Q+o6v.v9Q+o6v.v9Q+o6v.B6Q+o6v.G4Q+o6v.l6Q+W4O+o6v.l4Q)](that[(Q5O+K5Q)][(m2Q+A4O+P9O+Y05)]);}
);return this;}
;Editor.prototype.clear=function(fieldName){var E8O="clud",b5O="nA",that=this,fields=this[Y05][(o6v.Y7Q+L8Q+P25)];if(typeof fieldName===(s0+x6Q+F7+b65)){fields[fieldName][(o6v.l6Q+o6v.B6Q+Y05+E2+a85)]();delete  fields[fieldName];var orderIdx=$[(t4Q+a1O)](fieldName,this[Y05][(o6v.l4Q+o6v.B9Q+o6v.l6Q+o6v.B6Q+o6v.B9Q)]);this[Y05][s8Q][(d7+q9x+H2Q+o6v.B6Q)](orderIdx,1);var includeIdx=$[(F1Q+b5O+Q25+z75)](fieldName,this[Y05][(D7Q+E8O+o6v.B6Q+t7x+P25)]);if(includeIdx!==-1){this[Y05][M65][(Y05+P5x+N8O)](includeIdx,1);}
}
else{$[P1Q](this[I5](fieldName),function(i,name){var f7Q="lea";that[(H2Q+f7Q+o6v.B9Q)](name);}
);}
return this;}
;Editor.prototype.close=function(){this[(r2x+w3O+Y05+o6v.B6Q)](false);return this;}
;Editor.prototype.create=function(arg1,arg2,arg3,arg4){var O0O="eMa",y0Q="mbl",z1x='tC',O="modi",i4Q="rg",S3O="_cru",t8x="tFie",j15='umbe',that=this,fields=this[Y05][(o6v.Y7Q+L8Q+P25)],count=1;if(this[(N8Q+u2x+o6v.l6Q+a85)](function(){var Y9O="cre";that[(Y9O+T2Q+y3x)](arg1,arg2,arg3,arg4);}
)){return this;}
if(typeof arg1===(i15+j15+d0)){count=arg1;arg1=arg2;arg2=arg3;}
this[Y05][(G7Q+F1Q+P15+o6v.B6Q+P25)]={}
;for(var i=0;i<count;i++){this[Y05][(H25+t8x+s5x+Y05)][i]={fields:this[Y05][(o6v.Y7Q+L8Q+b5Q+o6v.l6Q+Y05)]}
;}
var argOpts=this[(S3O+o6v.l6Q+o3O+i4Q+Y05)](arg1,arg2,arg3,arg4);this[Y05][(K5Q+o6v.l4Q+V2O)]=(Z5O);this[Y05][(T2Q+H2Q+q05+n7Q+o6v.G4Q)]="create";this[Y05][(O+p0+o6v.B6Q+o6v.B9Q)]=null;this[Q0][z65][(Z9O+b5Q+o6v.B6Q)][(o6v.l6Q+F1Q+Y05+P5x+T2Q+a85)]='block';this[t0]();this[(V6x+a6x+b5Q+T2Q+a85+C5O+o6v.B6Q+X4+S75)](this[(o6v.Y7Q+F1Q+i5Q+o6v.l6Q+Y05)]());$[(o6v.B6Q+T2Q+Z2x)](fields,function(name,field){var U1Q="Res";field[(A6Q+Z7x+U1Q+c05)]();field[q4Q](field[(V2O+o6v.Y7Q)]());}
);this[(N8Q+o6v.B6Q+M35+X4Q+q05)]((F7+v75+z1x+d0+c25+Y85+o6v.R0+c25));this[(N8Q+w65+D3+y0Q+O0O+F1Q+o6v.G4Q)]();this[l](argOpts[L2]);argOpts[(R5O+a85+m2Q+B1O+s4)]();return this;}
;Editor.prototype.dependent=function(parent,url,opts){var B8x='POST';if($[(F0x+o6v.B9Q+F85)](parent)){for(var i=0,ien=parent.length;i<ien;i++){this[(o6v.l6Q+D9Q+X4Q+V2O+o6v.G4Q+q05)](parent[i],url,opts);}
return this;}
var that=this,field=this[(o6v.Y7Q+d6Q)](parent),ajaxOpts={type:(B8x),dataType:'json'}
;opts=$[d8O]({event:(v25+g5Q+i15+b65+c25),data:null,preUpdate:null,postUpdate:null}
,opts);var update=function(json){var w3Q="ostU",D2="Up",a6Q="preUpdate",w2="Upd";if(opts[(G4+w2+d65+o6v.B6Q)]){opts[a6Q](json);}
$[P1Q]({labels:(y75+B0Q+y75),options:(l75+o25+Y85+I9O),values:(n8+y75),messages:'message',errors:'error'}
,function(jsonProp,fieldFn){if(json[jsonProp]){$[P1Q](json[jsonProp],function(field,val){that[G3O](field)[fieldFn](val);}
);}
}
);$[P1Q]([(c65+v75+o25+c25),(s0+U8O),'enable','disable'],function(i,key){if(json[key]){that[key](json[key]);}
}
);if(opts[(o6v.v9Q+o6v.l4Q+Y05+q05+D2+o6v.l6Q+d65+o6v.B6Q)]){opts[(o6v.v9Q+w3Q+Y6x+T2Q+y3x)](json);}
}
;$(field[(j65+V2O)]())[f5](opts[(A35+X4Q+q05)],function(e){var w1="rge",u65="nod";if($(field[(u65+o6v.B6Q)]())[O1O](e[(L0x+w1+q05)]).length===0){return ;}
var data={}
;data[(h35+d2)]=that[Y05][A2Q]?_pluck(that[Y05][A2Q],(o25+Y85+J5O)):null;data[G5]=data[(o6v.B9Q+O5)]?data[(h35+d2)][0]:null;data[(M35+I05+y8O+Y05)]=that[(M35+T2Q+b5Q)]();if(opts.data){var ret=opts.data(data);if(ret){opts.data=ret;}
}
if(typeof url==='function'){var o=url(field[(J8Q+b5Q)](),data,update);if(o){update(o);}
}
else{if($[E2O](url)){$[(x8Q+o6v.B6Q+x05)](ajaxOpts,url);}
else{ajaxOpts[u7x]=url;}
$[(G05+T2Q+o6v.t85)]($[(o6v.B6Q+v6x+X4Q+o6v.l6Q)](ajaxOpts,{url:url,data:data,success:update}
));}
}
);return this;}
;Editor.prototype.destroy=function(){var x3O="clear";if(this[Y05][(K85+o6v.v9Q+b5Q+z75+o6v.B6Q+o6v.l6Q)]){this[R9O]();}
this[(x3O)]();var controller=this[Y05][G3];if(controller[o4]){controller[o4](this);}
$(document)[(Z05)]('.dte'+this[Y05][(m1O+F1Q+q9Q+H05+o6v.B6Q)]);this[(o6v.l6Q+o6v.l4Q+K5Q)]=null;this[Y05]=null;}
;Editor.prototype.disable=function(name){var b1Q="eldNa",fields=this[Y05][(W2+s5x+Y05)];$[(o6v.B6Q+s6x)](this[(L7x+F1Q+b1Q+u9x)](name),function(i,n){fields[n][(f2O+b5Q+o6v.B6Q)]();}
);return this;}
;Editor.prototype.display=function(show){var w7x="layed";if(show===undefined){return this[Y05][(v7O+Y05+o6v.v9Q+w7x)];}
return this[show?'open':'close']();}
;Editor.prototype.displayed=function(){return $[(K5Q+T2Q+o6v.v9Q)](this[Y05][(p0+o6v.B6Q+P25)],function(field,name){return field[j5]()?name:null;}
);}
;Editor.prototype.displayNode=function(){var e0x="roll";return this[Y05][(v7O+d7+b5Q+T2Q+C3Q+o6v.O75+e0x+o6v.B6Q+o6v.B9Q)][t0O](this);}
;Editor.prototype.edit=function(items,arg1,arg2,arg3,arg4){var J4x="yb",m0Q="_assembleMain",h2x="gs",G0Q="udAr",A7="idy",that=this;if(this[(N8Q+q05+A7)](function(){that[(o6v.B6Q+F25)](items,arg1,arg2,arg3,arg4);}
)){return this;}
var fields=this[Y05][(o6v.Y7Q+L8Q+b5Q+z4O)],argOpts=this[(N8Q+n1x+G0Q+h2x)](arg1,arg2,arg3,arg4);this[(N8Q+G7Q+P5Q)](items,this[k7Q]((E1x+C9Q+s0),items),(Z5O));this[m0Q]();this[l](argOpts[(o6v.l4Q+r8O)]);argOpts[(K5Q+T2Q+J4x+B1O+C6x+o6v.G4Q)]();return this;}
;Editor.prototype.enable=function(name){var D9x="dNa",fields=this[Y05][(o6v.Y7Q+L8Q+b5Q+o6v.l6Q+Y05)];$[(o6v.B6Q+T2Q+Z2x)](this[(N8Q+p0+o6v.B6Q+b5Q+D9x+V9O+Y05)](name),function(i,n){fields[n][(o6v.B6Q+o6v.G4Q+T2Q+m2Q+b5Q+o6v.B6Q)]();}
);return this;}
;Editor.prototype.error=function(name,msg){var d0x="_message";if(msg===undefined){this[d0x](this[(o6v.l6Q+A1)][u2Q],name);}
else{this[Y05][I4x][name].error(msg);}
return this;}
;Editor.prototype.field=function(name){return this[Y05][I4x][name];}
;Editor.prototype.fields=function(){return $[(E0O)](this[Y05][(o6v.Y7Q+b0+o6v.l6Q+Y05)],function(field,name){return name;}
);}
;Editor.prototype.file=_api_file;Editor.prototype.files=_api_files;Editor.prototype.get=function(name){var K8Q="rra",fields=this[Y05][(W2+b5Q+z4O)];if(!name){name=this[(p0+i5Q+z4O)]();}
if($[(F1Q+Y05+o3O+K8Q+a85)](name)){var out={}
;$[P1Q](name,function(i,n){out[n]=fields[n][a6O]();}
);return out;}
return fields[name][a6O]();}
;Editor.prototype.hide=function(names,animate){var a9O="ldN",fields=this[Y05][(B4O+o6v.l6Q+Y05)];$[P1Q](this[(N8Q+o6v.Y7Q+L8Q+a9O+T2Q+V9O+Y05)](names),function(i,n){fields[n][b15](animate);}
);return this;}
;Editor.prototype.inError=function(inNames){var F5="nErro",c6O="Erro";if($(this[Q0][(o6v.Y7Q+N75+c6O+o6v.B9Q)])[Y5Q]((M5O+P3+v75+e9x+P85+h7Q))){return true;}
var fields=this[Y05][I4x],names=this[I5](inNames);for(var i=0,ien=names.length;i<ien;i++){if(fields[names[i]][(F1Q+F5+o6v.B9Q)]()){return true;}
}
return false;}
;Editor.prototype.inline=function(cell,fieldName,opts){var t25="postopen",X7O="_fo",i5x="mE",v5Q="lin",s3O='icat',c0='Proc',B9x="contents",a2Q='inl',F2O="reo",M0Q="_edit",d5Q='li',that=this;if($[E2O](fieldName)){opts=fieldName;fieldName=undefined;}
opts=$[(o6v.B6Q+v6x+R9)]({}
,this[Y05][(o6v.Y7Q+X4+y9+s0x+o6v.G4Q+Y05)][(F1Q+J25+F1Q+o6v.G4Q+o6v.B6Q)],opts);var editFields=this[k7Q]('individual',cell,fieldName),node,field,countOuter=0,countInner,closed=false,classes=this[(b6x+T2Q+Y05+Y05+L05)][(F1Q+J25+X2)];$[(o6v.B6Q+T2Q+Z2x)](editFields,function(i,editField){var s7x="ayFie",h4Q='Canno';if(countOuter>0){throw (h4Q+o6v.R0+J5x+c25+T25+o6v.R0+J5x+u15+W0+J5x+o6v.R0+c65+i0x+J5x+R15+Q0x+J5x+d0+R15+B3+J5x+v75+i15+d5Q+i15+c25+J5x+Y85+o6v.R0+J5x+Y85+J5x+o6v.R0+v75+u15+c25);}
node=$(editField[(T2Q+q05+q05+s6x)][0]);countInner=0;$[(g5+E7Q)](editField[(o6v.l6Q+Y5Q+o6v.v9Q+b5Q+s7x+b5Q+o6v.l6Q+Y05)],function(j,f){var X7x='iel',u4x='han';if(countInner>0){throw (i0Q+i0x+i15+W1O+J5x+c25+G0+J5x+u15+R15+d0+c25+J5x+o6v.R0+u4x+J5x+R15+Q0x+J5x+Z65+X7x+o25+J5x+v75+j8x+v75+i15+c25+J5x+Y85+o6v.R0+J5x+Y85+J5x+o6v.R0+v75+u15+c25);}
field=f;countInner++;}
);countOuter++;}
);if($('div.DTE_Field',node).length){return this;}
if(this[(H1Q+o6v.l6Q+a85)](function(){var F7Q="inli";that[(F7Q+o6v.G4Q+o6v.B6Q)](cell,fieldName,opts);}
)){return this;}
this[M0Q](cell,editFields,(v75+j8x+F7+c25));var namespace=this[l](opts),ret=this[(N8Q+o6v.v9Q+F2O+o6v.v9Q+o6v.B6Q+o6v.G4Q)]((a2Q+z0Q));if(!ret){return this;}
var children=node[B9x]()[q2O]();node[z6x]($((Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9)+classes[(K35+H4x+o6v.B6Q+o6v.B9Q)]+(W6)+'<div class="'+classes[(b5Q+F1Q+o6v.G4Q+o6v.B6Q+o6v.B9Q)]+(W6)+(Q4O+o25+v75+P3+J5x+v25+r6O+i9+v3Q+g85+g35+c0+c25+s0+s0+v75+i15+R1x+i15+o25+s3O+R15+d0+e8Q+s0+D+i0x+I9+o25+v75+P3+r4O)+(B2+o25+v75+P3+r4O)+(Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9)+classes[e6]+'"/>'+(B2+o25+H5+r4O)));node[O1O]((o25+H5+R8O)+classes[(v5Q+U9Q)][L6x](/ /g,'.'))[z6x](field[(o6v.G4Q+h4O)]())[z6x](this[Q0][(H3+o6v.B9Q+i5x+T7O+o6v.B9Q)]);if(opts[(m2Q+H05+a5x+c4Q)]){node[(p0+o6v.G4Q+o6v.l6Q)]('div.'+classes[e6][L6x](/ /g,'.'))[z6x](this[(Q5O+K5Q)][e6]);}
this[g6O](function(submitComplete){var Z1Q="_clearDynamicInfo",i0="tac";closed=true;$(document)[(o6v.l4Q+u)]((u1x+v25+P75)+namespace);if(!submitComplete){node[(H2Q+o6v.l4Q+o6v.O75+Y6+Y05)]()[(o6v.l6Q+o6v.B6Q+i0+E7Q)]();node[(T2Q+p9x+X4Q+o6v.l6Q)](children);}
that[Z1Q]();}
);setTimeout(function(){if(closed){return ;}
$(document)[f5]((v25+d5Q+F8Q)+namespace,function(e){var U0x="inAr",back=$[(o6v.Y7Q+o6v.G4Q)][(Q7O+i1x+J1Q)]?'addBack':'andSelf';if(!field[T9Q]('owns',e[(v4x)])&&$[(U0x+o6v.B9Q+z75)](node[0],$(e[(q05+T2Q+o6v.B9Q+W7Q+o6v.B6Q+q05)])[(D2x+o6v.B9Q+X4Q+q05+Y05)]()[back]())===-1){that[(H2+H05+o6v.B9Q)]();}
}
);}
,0);this[(X7O+H2Q+s4O)]([field],opts[(H3+l4x+Y05)]);this[(N8Q+t25)]('inline');return this;}
;Editor.prototype.message=function(name,msg){var t6O="formInfo";if(msg===undefined){this[(N8Q+V9O+A4+W7Q+o6v.B6Q)](this[(o6v.l6Q+A1)][t6O],name);}
else{this[Y05][(o6v.Y7Q+F1Q+o2O+Y05)][name][T0Q](msg);}
return this;}
;Editor.prototype.mode=function(){var s3Q="act";return this[Y05][(s3Q+F1Q+f5)];}
;Editor.prototype.modifier=function(){return this[Y05][(K5Q+o6v.l4Q+v7O+W2+o6v.B9Q)];}
;Editor.prototype.multiGet=function(fieldNames){var p3O="iG",fields=this[Y05][I4x];if(fieldNames===undefined){fieldNames=this[(p0+o6v.B6Q+P25)]();}
if($[(F1Q+Y05+q4x+U7Q+a85)](fieldNames)){var out={}
;$[(o6v.B6Q+T2Q+Z2x)](fieldNames,function(i,name){var Z75="multiGet";out[name]=fields[name][Z75]();}
);return out;}
return fields[fieldNames][(A6Q+b5Q+q05+p3O+o6v.B6Q+q05)]();}
;Editor.prototype.multiSet=function(fieldNames,val){var Z35="ltiSet",fields=this[Y05][(p0+o6v.B6Q+s5x+Y05)];if($[E2O](fieldNames)&&val===undefined){$[P1Q](fieldNames,function(name,value){var q7O="iS";fields[name][(L9O+q7O+c05)](value);}
);}
else{fields[fieldNames][(A6Q+Z35)](val);}
return this;}
;Editor.prototype.node=function(name){var J2="isAr",fields=this[Y05][(o6v.Y7Q+F1Q+o6v.B6Q+P25)];if(!name){name=this[(X4+S75)]();}
return $[(J2+U7Q+a85)](name)?$[E0O](name,function(n){return fields[n][(o6v.G4Q+h4O)]();}
):fields[name][t0O]();}
;Editor.prototype.off=function(name,fn){$(this)[Z05](this[z0](name),fn);return this;}
;Editor.prototype.on=function(name,fn){$(this)[(f5)](this[z0](name),fn);return this;}
;Editor.prototype.one=function(name,fn){var F6x="Na";$(this)[(i75)](this[(D1x+o6v.B6Q+o6v.O75+F6x+V9O)](name),fn);return this;}
;Editor.prototype.open=function(){var U4="_postopen",C9O="itOp",R2O="open",Q3O="ayC",n25="eope",d5="_pr",A0Q="eRe",T6x="eorde",that=this;this[(N8Q+v7O+d7+b5Q+T2Q+a85+C5O+T6x+o6v.B9Q)]();this[(N8Q+H2Q+w3O+Y05+A0Q+W7Q)](function(submitComplete){that[Y05][G3][(H2Q+b5Q+u1)](that,function(){var M8="cI",a8x="clea";that[(N8Q+a8x+o6v.B9Q+o8O+a85+P9Q+C0Q+M8+R85)]();}
);}
);var ret=this[(d5+n25+o6v.G4Q)]('main');if(!ret){return this;}
this[Y05][(K85+o6v.v9Q+b5Q+Q3O+o6v.l4Q+o6v.G4Q+q05+o6v.B9Q+m1+b5Q+o6v.B6Q+o6v.B9Q)][R2O](this,this[(Q5O+K5Q)][(J8+k8Q+U9Q)]);this[z6O]($[(K5Q+l85)](this[Y05][s8Q],function(name){return that[Y05][(p0+o2O+Y05)][name];}
),this[Y05][(o6v.B6Q+o6v.l6Q+C9O+q05+Y05)][(H3+H2Q+s4O)]);this[U4]((u15+Y85+v75+i15));return this;}
;Editor.prototype.order=function(set){var T0="onal",t7Q="All",t="jo",w4x="sor",k2="sl";if(!set){return this[Y05][(p25+U9Q)];}
if(arguments.length&&!$[z9Q](set)){set=Array.prototype.slice.call(arguments);}
if(this[Y05][(X4+o6v.l6Q+o6v.B6Q+o6v.B9Q)][(k2+N8O)]()[(Y05+X4+q05)]()[G9Q]('-')!==set[(k2+F1Q+v8x)]()[(w4x+q05)]()[(t+F1Q+o6v.G4Q)]('-')){throw (t7Q+a9+o6v.Y7Q+d6Q+Y05+m05+T2Q+o6v.G4Q+o6v.l6Q+a9+o6v.G4Q+o6v.l4Q+a9+T2Q+O9O+u2x+T0+a9+o6v.Y7Q+c8x+m05+K5Q+H05+Y05+q05+a9+m2Q+o6v.B6Q+a9+o6v.v9Q+o6v.B9Q+s9+F1Q+V2O+o6v.l6Q+a9+o6v.Y7Q+X4+a9+o6v.l4Q+j5Q+U9Q+G6+Z6x);}
$[d8O](this[Y05][(o6v.l4Q+j5Q+U9Q)],set);this[j7]();return this;}
;Editor.prototype.remove=function(items,arg1,arg2,arg3,arg4){var f9O="butt",f5Q="eOp",P7x="leMai",x3Q="ssemb",T8Q='tiRem',h0O='tM',R4Q="actio",e9="itFiel",p2="odifie",K="rgs",C25="ru",that=this;if(this[(H1Q+X3Q)](function(){that[(e5Q+m8Q+M35+o6v.B6Q)](items,arg1,arg2,arg3,arg4);}
)){return this;}
if(items.length===undefined){items=[items];}
var argOpts=this[(N8Q+H2Q+C25+o6v.l6Q+o3O+K)](arg1,arg2,arg3,arg4),editFields=this[(N8Q+d1Q+i3Q+L9+K4)]((Z65+v75+c25+a7Q+s0),items);this[Y05][(T2Q+q7+o6v.l4Q+o6v.G4Q)]="remove";this[Y05][(K5Q+p2+o6v.B9Q)]=items;this[Y05][(G7Q+e9+z4O)]=editFields;this[(o6v.l6Q+A1)][(o6v.Y7Q+o6v.l4Q+v35)][(Y1+a85+U5x)][(v7O+Y05+P5x+T2Q+a85)]='none';this[(N8Q+R4Q+o6v.G4Q+C4Q+o9x)]();this[t0x]('initRemove',[_pluck(editFields,'node'),_pluck(editFields,'data'),items]);this[(N8Q+o6v.B6Q+e75)]((l8Q+h0O+u3+y75+T8Q+R15+X6),[editFields,items]);this[(j2x+x3Q+P7x+o6v.G4Q)]();this[(N8Q+o6v.Y7Q+X4+y9+s0x+s75)](argOpts[L2]);argOpts[(K5Q+T2Q+a85+m2Q+f5Q+X4Q)]();var opts=this[Y05][(o6v.B6Q+z0x+o6v.v9Q+o6v.r1x)];if(opts[F35]!==null){$((u8x),this[(Q0)][(f9O+c4Q)])[(o6v.B6Q+q9Q)](opts[(o6v.Y7Q+s7Q)])[(U2Q+s4O)]();}
return this;}
;Editor.prototype.set=function(set,val){var y1Q="nObje",b1O="isPl",fields=this[Y05][(o6v.Y7Q+c8x)];if(!$[(b1O+K9Q+y1Q+G4x)](set)){var o={}
;o[set]=val;set=o;}
$[(o6v.B6Q+T2Q+Z2x)](set,function(n,v){fields[n][(D3+q05)](v);}
);return this;}
;Editor.prototype.show=function(names,animate){var fields=this[Y05][I4x];$[(o6v.B6Q+D5Q+E7Q)](this[I5](names),function(i,n){fields[n][(Y05+E7Q+J9)](animate);}
);return this;}
;Editor.prototype.submit=function(successCallback,errorCallback,formatdata,hide){var that=this,fields=this[Y05][(p0+a0O)],errorFields=[],errorReady=0,sent=false;if(this[Y05][J2Q]||!this[Y05][(T2Q+q7+o6v.l4Q+o6v.G4Q)]){return this;}
this[h0Q](true);var send=function(){var Z4O="ubm";if(errorFields.length!==errorReady||sent){return ;}
sent=true;that[(N8Q+Y05+Z4O+P5Q)](successCallback,errorCallback,formatdata,hide);}
;this.error();$[(z2Q+H2Q+E7Q)](fields,function(name,field){var y5="nEr";if(field[(F1Q+y5+b7)]()){errorFields[C7O](name);}
}
);$[P1Q](errorFields,function(i,name){fields[name].error('',function(){errorReady++;send();}
);}
);send();return this;}
;Editor.prototype.template=function(set){var n3Q="empla";if(set===undefined){return this[Y05][(q05+n3Q+y3x)];}
this[Y05][(y3x+K5Q+o6v.v9Q+b5Q+d65+o6v.B6Q)]=$(set);return this;}
;Editor.prototype.title=function(title){var Q4Q="heade",header=$(this[(Q0)][(Q4Q+o6v.B9Q)])[(H2Q+E7Q+F1Q+b5Q+o6v.l6Q+o6v.B9Q+X4Q)]('div.'+this[k0][h75][(H2Q+o6v.l4Q+o6v.G4Q+q05+o6v.B6Q+o6v.O75)]);if(title===undefined){return header[(p1O+K5Q+b5Q)]();}
if(typeof title==='function'){title=title(this,new DataTable[(o3O+Y1x)](this[Y05][s25]));}
header[J5Q](title);return this;}
;Editor.prototype.val=function(field,value){var P2x="inObject";if(value!==undefined||$[(Y5Q+A1O+F1x+P2x)](field)){return this[(Y05+c05)](field,value);}
return this[a6O](field);}
;var apiRegister=DataTable[(V9Q)][E9Q];function __getInst(api){var Z3="oInit",V8="context",ctx=api[V8][0];return ctx[Z3][(o6v.B6Q+v7O+F3Q)]||ctx[(O6x+v7O+q7x+o6v.B9Q)];}
function __setBasic(inst,opts,type,plural){var h4='ove',g4Q='rem',w6="messag",v4Q='asic',k5="but",K7="utt";if(!opts){opts={}
;}
if(opts[(m2Q+K7+o6v.l4Q+s75)]===undefined){opts[(k5+q7x+s75)]=(e3Q+v4Q);}
if(opts[(q05+P5Q+b5Q+o6v.B6Q)]===undefined){opts[(e0+U5x)]=inst[J3][type][(O7x)];}
if(opts[(w6+o6v.B6Q)]===undefined){if(type===(g4Q+h4)){var confirm=inst[J3][type][r3];opts[T0Q]=plural!==1?confirm[N8Q][(o6v.B9Q+o6v.B6Q+o6v.v9Q+b5Q+D5Q+o6v.B6Q)](/%d/,plural):confirm['1'];}
else{opts[T0Q]='';}
}
return opts;}
apiRegister('editor()',function(){return __getInst(this);}
);apiRegister((d0+R15+B3+R8O+v25+d0+a7x+f7x),function(opts){var inst=__getInst(this);inst[(n1x+o6v.B6Q+T2Q+y3x)](__setBasic(inst,opts,'create'));return this;}
);apiRegister((d0+s5O+F8+c25+G0+f7x),function(opts){var inst=__getInst(this);inst[k3O](this[0][0],__setBasic(inst,opts,'edit'));return this;}
);apiRegister('rows().edit()',function(opts){var inst=__getInst(this);inst[k3O](this[0],__setBasic(inst,opts,(T6Q)));return this;}
);apiRegister((d0+s5O+F8+o25+L15+c25+f7x),function(opts){var inst=__getInst(this);inst[(o6v.B9Q+r4Q+q6Q)](this[0][0],__setBasic(inst,opts,'remove',1));return this;}
);apiRegister((c3x+s0+F8+o25+c25+y75+w15+f7x),function(opts){var inst=__getInst(this);inst[k8](this[0],__setBasic(inst,opts,'remove',this[0].length));return this;}
);apiRegister((v25+c25+b4Q+F8+c25+G0+f7x),function(type,opts){var S8Q="nO";if(!type){type=(F7+y75+z0Q);}
else if($[(P2+F1x+F1Q+S8Q+m2Q+q1Q+h2O)](type)){opts=type;type='inline';}
__getInst(this)[type](this[0][0],opts);return this;}
);apiRegister((K75+y05+F8+c25+o25+v75+o6v.R0+f7x),function(opts){var i6Q="bubble";__getInst(this)[i6Q](this[0],opts);return this;}
);apiRegister('file()',_api_file);apiRegister((E1x+y75+V9+f7x),_api_files);$(document)[(f5)]((A3O+R8O+o25+o6v.R0),function(e,ctx,json){var Z='dt',b0x="namespace";if(e[b0x]!==(Z)){return ;}
if(json&&json[(W5x+o6v.B6Q+Y05)]){$[P1Q](json[(o6v.Y7Q+N4O+Y05)],function(name,files){Editor[(o6v.Y7Q+W6Q+o6v.B6Q+Y05)][name]=files;}
);}
}
);Editor.error=function(msg,tn){var A9Q='atabl',l1='ttp',X6x='efer',d1='ease',v0x='rm';throw tn?msg+(J5x+K3Q+R15+d0+J5x+u15+W0+J5x+v75+i15+f9x+v0x+Y85+u3Q+R15+i15+K9+D+y75+d1+J5x+d0+X6x+J5x+o6v.R0+R15+J5x+c65+l1+s0+l9O+o25+E8x+A9Q+c25+s0+R8O+i15+c25+o6v.R0+d2O+o6v.R0+i15+d2O)+tn:msg;}
;Editor[(D2x+F1Q+Z25)]=function(data,props,fn){var E3O="bje",m3="Plai",i,ien,dataPoint;props=$[(B85+y3x+x05)]({label:(f6Q+P85+c25+y75),value:(n8+y75+u3+c25)}
,props);if($[z9Q](data)){for(i=0,ien=data.length;i<ien;i++){dataPoint=data[i];if($[(Y5Q+m3+o6v.G4Q+x1O+E3O+H2Q+q05)](dataPoint)){fn(dataPoint[props[f35]]===undefined?dataPoint[props[q9O]]:dataPoint[props[f35]],dataPoint[props[q9O]],i,dataPoint[(T2Q+q05+j1x)]);}
else{fn(dataPoint,dataPoint,i);}
}
}
else{i=0;$[(P1Q)](data,function(key,val){fn(val,key,i);i++;}
);}
}
;Editor[d3O]=function(id){return id[L6x](/\./g,'-');}
;Editor[(i7O+o6v.l6Q)]=function(editor,conf,files,progressCallback,completeCallback){var a05="UR",P5="sDa",A3x="adA",X5O="onlo",f0O=">",c9x="<",y8x="Re",S3x='ading',q2x='ccu',t3O='erve',reader=new FileReader(),counter=0,ids=[],generalError=(H9O+J5x+s0+t3O+d0+J5x+c25+d0+d0+e7O+J5x+R15+q2x+d0+d0+r6+J5x+B3+c65+v75+y75+c25+J5x+u3+q7Q+R15+S3x+J5x+o6v.R0+J4Q+J5x+Z65+b6+c25);editor.error(conf[(o6v.G4Q+g25)],'');progressCallback(conf,conf[(p0+U5x+y8x+m5Q+r7Q+v6x)]||(c9x+F1Q+f0O+H4O+o6v.v9Q+b5Q+f25+G6+a9+o6v.Y7Q+F1Q+b5Q+o6v.B6Q+R2Q+F1Q+f0O));reader[(X5O+T2Q+o6v.l6Q)]=function(e){var x8="oa",e5x='js',S4='post',I85="ja",u5='lug',M85='cif',M2Q='ing',a4="ajaxData",j8Q="axDa",Q8O='upl',A0='action',g65="appen",data=new FormData(),ajax;data[(g65+o6v.l6Q)]((A0),(Q8O+l0));data[(T2Q+p9x+o6v.B6Q+o6v.G4Q+o6v.l6Q)]((u3+q7Q+l0+K3Q+v75+c25+a7Q),conf[(L2Q+o6v.B6Q)]);data[(k8Q+o6v.B6Q+o6v.G4Q+o6v.l6Q)]('upload',files[counter]);if(conf[(T2Q+q1Q+j8Q+L0x)]){conf[a4](data);}
if(conf[(x6O)]){ajax=conf[(x6O)];}
else if($[E2O](editor[Y05][(T2Q+q1Q+T2Q+o6v.t85)])){ajax=editor[Y05][x6O][B5O]?editor[Y05][x6O][(a7+o6v.l4Q+m5Q)]:editor[Y05][x6O];}
else if(typeof editor[Y05][(T2Q+q1Q+q75)]===(l2O+d0+M2Q)){ajax=editor[Y05][x6O];}
if(!ajax){throw (X5Q+J5x+H9O+D75+Y85+Y8+J5x+R15+D+o6v.R0+v75+R15+i15+J5x+s0+I8Q+M85+v75+r6+J5x+Z65+e7O+J5x+u3+n4+Y85+o25+J5x+D+u5+l8O+v75+i15);}
if(typeof ajax===(s0+o6v.R0+x4+I0x)){ajax={url:ajax}
;}
var submit=false;editor[(o6v.l4Q+o6v.G4Q)]('preSubmit.DTE_Upload',function(){submit=true;return false;}
);if(typeof ajax.data==='function'){var d={}
,ret=ajax.data(d);if(ret!==undefined){d=ret;}
$[(g5+E7Q)](d,function(key,value){data[(l85+s4+o6v.l6Q)](key,value);}
);}
$[(T2Q+I85+o6v.t85)]($[(B85+q05+X4Q+o6v.l6Q)]({}
,ajax,{type:(S4),data:data,dataType:(e5x+C6O),contentType:false,processData:false,xhr:function(){var g8x="onloadend",S7x="onprogress",T7="xhr",f6="axS",xhr=$[(T2Q+q1Q+f6+c05+q05+F1Q+H35+Y05)][(T7)]();if(xhr[(H05+o6v.v9Q+b5Q+o6v.l4Q+T2Q+o6v.l6Q)]){xhr[(g5O+w3O+m5Q)][S7x]=function(e){var Q8Q="tot",z0O="mputa",P4="hC",f6x="gt";if(e[(b5Q+X4Q+f6x+P4+o6v.l4Q+z0O+m2Q+U5x)]){var percent=(e[(b5Q+x8+o6v.l6Q+G7Q)]/e[(Q8Q+T2Q+b5Q)]*100)[(q7x+G2O+o6v.t85+o6v.B6Q+o6v.l6Q)](0)+"%";progressCallback(conf,files.length===1?percent:counter+':'+files.length+' '+percent);}
}
;xhr[(H05+o6v.v9Q+s6+o6v.l6Q)][g8x]=function(e){progressCallback(conf);}
;}
return xhr;}
,success:function(json){var P6="RL",U3="ataU",T4O="stat",p6x="dErr",c7Q="ors",R1O='Succ',j4Q='X',l0x='uplo',i5='_Up';editor[(Z05)]((L5Q+c25+a1Q+O9Q+u15+v75+o6v.R0+R8O+v3Q+g85+i5+y75+h9x+o25));editor[(D1x+Y6)]((l0x+Y85+o25+j4Q+m25+R1O+c25+s0+s0),[conf[(o6v.G4Q+T2Q+K5Q+o6v.B6Q)],json]);if(json[(p0+o2O+y6x+o6v.B9Q+c7Q)]&&json[(p0+o6v.B6Q+b5Q+p6x+o6v.l4Q+Z25)].length){var errors=json[V8O];for(var i=0,ien=errors.length;i<ien;i++){editor.error(errors[i][(P9Q+V9O)],errors[i][(T4O+s4O)]);}
}
else if(json.error){editor.error(json.error);}
else if(!json[(H05+o6v.v9Q+b5Q+x8+o6v.l6Q)]||!json[(H05+o6v.v9Q+b5Q+o6v.l4Q+T2Q+o6v.l6Q)][(F1Q+o6v.l6Q)]){editor.error(conf[R7Q],generalError);}
else{if(json[(p0+U5x+Y05)]){$[P1Q](json[(o6v.Y7Q+F1Q+g1)],function(table,files){var M7x="iles";if(!Editor[n5O][table]){Editor[(o6v.Y7Q+M7x)][table]={}
;}
$[(B85+l3+o6v.l6Q)](Editor[(o6v.Y7Q+M7x)][table],files);}
);}
ids[C7O](json[(H05+o6v.v9Q+b5Q+x8+o6v.l6Q)][y3Q]);if(counter<files.length-1){counter++;reader[(o6v.B9Q+z2Q+o6v.l6Q+o3O+Y05+o8O+U3+P6)](files[counter]);}
else{completeCallback[(H2Q+T2Q+P0O)](editor,ids);if(submit){editor[G3x]();}
}
}
}
,error:function(xhr){editor[t0x]('uploadXhrError',[conf[R7Q],xhr]);editor.error(conf[(P9Q+K5Q+o6v.B6Q)],generalError);}
}
));}
;reader[(o6v.B9Q+o6v.B6Q+A3x+P5+L0x+a05+k7O)](files[0]);}
;Editor.prototype._constructor=function(init){var K9O="nit",v65="unique",k8x='proces',l1Q="cess",R25='y_conten',r3Q='ent',U9O='orm_c',x7O="formCo",m6O="even",f1='reat',r1="BUTTONS",Q3x='but',B25="hea",B8Q='inf',X75='m_',X8Q='_c',T2='orm',o0="conte",v0Q="oter",I7O="rappe",M3Q='oot',Y='_con',q2Q="ica",u6="roce",v0="niqu",l9Q="emp",A25="template",t2x="Aja",g2Q="acy",Z2Q="ormO",w9x="dataSources",j35="domTable",f9="domT";init=$[(o6v.B6Q+o6v.t85+q25)](true,{}
,Editor[(V2O+o6v.Y7Q+N65+s0Q)],init);this[Y05]=$[(o6v.B6Q+E1O+o6v.G4Q+o6v.l6Q)](true,{}
,Editor[(K5Q+o6v.l4Q+V2O+b5Q+Y05)][x5],{table:init[(f9+T2Q+U65)]||init[(L0x+m2Q+b5Q+o6v.B6Q)],dbTable:init[j3x]||null,ajaxUrl:init[(G05+q75+H4O+P05)],ajax:init[(T2Q+n8Q)],idSrc:init[(A5x)],dataSource:init[j35]||init[(q05+T2Q+m2Q+b5Q+o6v.B6Q)]?Editor[(o6v.l6Q+d65+i3Q+o6v.l4Q+H05+K4+Y05)][o6v.Y4]:Editor[w9x][J5Q],formOptions:init[(o6v.Y7Q+Z2Q+O9x+F1Q+o6v.l4Q+s75)],legacyAjax:init[(U5x+W7Q+g2Q+t2x+o6v.t85)],template:init[A25]?$(init[(q05+l9Q+F1x+q05+o6v.B6Q)])[(o6v.l6Q+c05+T2Q+Z2x)]():null}
);this[(H2Q+F1x+Y05+Y05+L05)]=$[d8O](true,{}
,Editor[k0]);this[(J3)]=init[J3];Editor[r9Q][(D3+a5x+D7Q+W7Q+Y05)][(H05+v0+o6v.B6Q)]++;var that=this,classes=this[(y6+L05)];this[(o6v.l6Q+A1)]={"wrapper":$('<div class="'+classes[(K35+U7Q+p9x+o6v.B6Q+o6v.B9Q)]+(W6)+(Q4O+o25+H5+J5x+o25+u85+l8O+o25+I9O+l8O+c25+i9+D+d0+c0O+V9+s0+F7+b65+B35+v25+y75+L2O+i9)+classes[(o6v.v9Q+u6+S1+G6)][(D7Q+o6v.l6Q+q2Q+q05+o6v.l4Q+o6v.B9Q)]+(e8Q+s0+D+i0x+I9+o25+v75+P3+r4O)+'<div data-dte-e="body" class="'+classes[(m2Q+o6v.l4Q+o6v.l6Q+a85)][q1O]+(W6)+(Q4O+o25+H5+J5x+o25+u85+l8O+o25+I9O+l8O+c25+i9+P85+R15+o25+a8+Y+I9O+A6x+B35+v25+r6O+i9)+classes[(z9O+a85)][(H2Q+N9Q+Y6)]+'"/>'+'</div>'+(Q4O+o25+H5+J5x+o25+Y85+o6v.R0+Y85+l8O+o25+o6v.R0+c25+l8O+c25+i9+Z65+M3Q+B35+v25+r6O+i9)+classes[(o6v.Y7Q+o6v.l4Q+o6v.l4Q+O8)][(K35+I7O+o6v.B9Q)]+(W6)+(Q4O+o25+H5+J5x+v25+r6O+i9)+classes[(H3+v0Q)][(o0+o6v.O75)]+(z4)+(B2+o25+v75+P3+r4O)+(B2+o25+v75+P3+r4O))[0],"form":$((Q4O+Z65+e7O+u15+J5x+o25+u85+l8O+o25+o6v.R0+c25+l8O+c25+i9+Z65+T2+B35+v25+y75+L2O+i9)+classes[z65][(L0x+W7Q)]+(W6)+(Q4O+o25+H5+J5x+o25+E8x+Y85+l8O+o25+I9O+l8O+c25+i9+Z65+R15+d0+u15+X8Q+R15+z9x+A6x+B35+v25+y75+L2O+i9)+classes[z65][N3O]+(z4)+'</form>')[0],"formError":$((Q4O+o25+v75+P3+J5x+o25+u85+l8O+o25+I9O+l8O+c25+i9+Z65+R15+d0+X75+Q9+d0+e7O+B35+v25+y75+Y85+x2O+i9)+classes[z65].error+(z4))[0],"formInfo":$((Q4O+o25+v75+P3+J5x+o25+Y85+J5O+l8O+o25+I9O+l8O+c25+i9+Z65+e7O+X75+B8Q+R15+B35+v25+y75+Y85+s0+s0+i9)+classes[(o6v.Y7Q+N75)][(m5O)]+'"/>')[0],"header":$((Q4O+o25+H5+J5x+o25+u85+l8O+o25+I9O+l8O+c25+i9+c65+c2+o25+B35+v25+y75+Y85+x2O+i9)+classes[(B25+o6v.l6Q+o6v.B6Q+o6v.B9Q)][(t65+A9)]+(e8Q+o25+H5+J5x+v25+r6O+i9)+classes[(E7Q+o6v.B6Q+s8x)][N3O]+'"/></div>')[0],"buttons":$((Q4O+o25+v75+P3+J5x+o25+Y85+J5O+l8O+o25+o6v.R0+c25+l8O+c25+i9+Z65+e7O+u15+g35+Q3x+o6v.R0+C6O+s0+B35+v25+r6O+i9)+classes[z65][(e6)]+(z4))[0]}
;if($[(C3)][(f8O+q05+T2Q+O2Q+U65)][t15]){var ttButtons=$[C3][o6v.Y4][t15][r1],i18n=this[J3];$[(o6v.B6Q+s6x)]([(v25+f1+c25),(T6Q),(d0+c25+o8+P3+c25)],function(i,val){var z5O="tonTex",Z7='r_';ttButtons[(c25+o25+v75+N2Q+Z7)+val][(Y05+R3O+H05+q05+z5O+q05)]=i18n[val][(m2Q+A4O+P9O)];}
);}
$[(z2Q+Z2x)](init[(m6O+o6v.r1x)],function(evt,fn){that[(f5)](evt,function(){var args=Array.prototype.slice.call(arguments);args[(e7)]();fn[(Q2Q)](that,args);}
);}
);var dom=this[(Q0)],wrapper=dom[q1O];dom[(x7O+o6v.G4Q+q05+o6v.B6Q+o6v.G4Q+q05)]=_editor_el((Z65+U9O+R15+i15+o6v.R0+r3Q),dom[z65])[0];dom[s3]=_editor_el((Z65+R15+W1O),wrapper)[0];dom[(Q7+X3Q)]=_editor_el((G8O+o25+a8),wrapper)[0];dom[u7]=_editor_el((H75+R25+o6v.R0),wrapper)[0];dom[(o6v.v9Q+h35+l1Q+G6)]=_editor_el((k8x+e9x+I0x),wrapper)[0];if(init[(B4O+z4O)]){this[(Q7O)](init[(o6v.Y7Q+b0+z4O)]);}
$(document)[(f5)]((v75+i15+v75+o6v.R0+R8O+o25+o6v.R0+R8O+o25+o6v.R0+c25)+this[Y05][v65],function(e,settings,json){if(that[Y05][(q05+T2Q+m2Q+b5Q+o6v.B6Q)]&&settings[(o6v.G4Q+W4O+n1Q+U5x)]===$(that[Y05][s25])[(a6O)](0)){settings[(N8Q+G7Q+P5Q+o6v.l4Q+o6v.B9Q)]=that;}
}
)[(f5)]((Y8+m25+R8O+o25+o6v.R0+R8O+o25+o6v.R0+c25)+this[Y05][v65],function(e,settings,json){var f1Q="_optionsUpdate";if(json&&that[Y05][s25]&&settings[(o6v.G4Q+O2Q+U65)]===$(that[Y05][(q05+T2Q+U65)])[(W7Q+o6v.B6Q+q05)](0)){that[f1Q](json);}
}
);this[Y05][G3]=Editor[(o6v.l6Q+F1Q+Y05+P5x+T2Q+a85)][init[(o6v.l6Q+a6x+b5Q+T2Q+a85)]][(F1Q+K9O)](this);this[(N8Q+o6v.B6Q+M35+o6v.B6Q+o6v.G4Q+q05)]('initComplete',[]);}
;Editor.prototype._actionClass=function(){var Y3O="ddCla",P0Q="creat",classesActions=this[(H2Q+F1x+S1+o6v.B6Q+Y05)][(D5Q+q05+F1Q+o6v.l4Q+s75)],action=this[Y05][(T2Q+Q2+o6v.G4Q)],wrapper=$(this[(o6v.l6Q+A1)][q1O]);wrapper[k0Q]([classesActions[(P0Q+o6v.B6Q)],classesActions[k3O],classesActions[(e5Q+K5Q+s9+o6v.B6Q)]][G9Q](' '));if(action==="create"){wrapper[(m5Q+f3x+W6x)](classesActions[(H2Q+o6v.B9Q+o6v.B6Q+T2Q+y3x)]);}
else if(action===(o6v.B6Q+o6v.l6Q+P5Q)){wrapper[(T2Q+o6v.l6Q+o6v.l6Q+p8O+F1x+Y05+Y05)](classesActions[k3O]);}
else if(action===(o6v.B9Q+A5Q+o6v.l4Q+M35+o6v.B6Q)){wrapper[(T2Q+Y3O+Y05+Y05)](classesActions[(e5Q+P6O+o6v.B6Q)]);}
}
;Editor.prototype._ajax=function(data,success,error,submitParams){var w6Q="teBod",S2="dele",J0O='DELET',B5Q="sF",q5O="Fu",e9O="ete",j9x="compl",I75="nshift",t7="complete",U7="mple",n2='tring',H3O="repl",y3O="split",b1x="axU",p6="Ur",p9Q="isFun",Y4Q='dSr',Q9x="axUrl",t8Q='son',I7Q='ST',that=this,action=this[Y05][b7O],thrown,opts={type:(P7Q+u7Q+I7Q),dataType:(D75+t8Q),data:null,error:[function(xhr,text,err){thrown=err;}
],success:[],complete:[function(xhr,text){var O25="status";var P8="responseText";var g8O="rseJ";var q35="SON";var w7O="eJ";var k05="pons";var n6O="res";var K8O="seJ";var W6O="respon";var g3Q="nseT";var n4x="po";var json=null;if(xhr[(Y1+T2Q+q05+s4O)]===204||xhr[(e5Q+Y05+n4x+g3Q+o6v.B6Q+v6x)]==='null'){json={}
;}
else{try{json=xhr[(W6O+K8O+G4O+x1O+M1O)]?xhr[(n6O+k05+w7O+q35)]:$[(D2x+g8O+G4O+x1O+M1O)](xhr[P8]);}
catch(e){}
}
if($[E2O](json)||$[z9Q](json)){success(json,xhr[O25]>=400,xhr);}
else{error(xhr,text,thrown);}
}
]}
,a,ajaxSrc=this[Y05][x6O]||this[Y05][(T2Q+q1Q+Q9x)],id=action===(c25+o25+Y5)||action==='remove'?_pluck(this[Y05][(G7Q+F1Q+P15+o6v.B6Q+P25)],(v75+Y4Q+v25)):null;if($[(F1Q+m7Q+a1O)](id)){id=id[(q1Q+o6v.l4Q+F1Q+o6v.G4Q)](',');}
if($[E2O](ajaxSrc)&&ajaxSrc[action]){ajaxSrc=ajaxSrc[action];}
if($[(p9Q+H2Q+q05+d9O)](ajaxSrc)){var uri=null,method=null;if(this[Y05][(G05+q75+p6+b5Q)]){var url=this[Y05][(T2Q+q1Q+b1x+o6v.B9Q+b5Q)];if(url[(H2Q+e5Q+T2Q+y3x)]){uri=url[action];}
if(uri[Z9x](' ')!==-1){a=uri[y3O](' ');method=a[0];uri=a[1];}
uri=uri[(H3O+m2x)](/_id_/,id);}
ajaxSrc(method,uri,data,success,error);return ;}
else if(typeof ajaxSrc===(s0+n2)){if(ajaxSrc[(F1Q+o6v.G4Q+o6v.l6Q+o6v.B6Q+o6v.t85+x1O+o6v.Y7Q)](' ')!==-1){a=ajaxSrc[y3O](' ');opts[e05]=a[0];opts[(H05+P05)]=a[1];}
else{opts[(H05+P05)]=ajaxSrc;}
}
else{var optsCopy=$[d8O]({}
,ajaxSrc||{}
);if(optsCopy[(k7x+U7+q05+o6v.B6Q)]){opts[t7][(H05+I75)](optsCopy[(j9x+e9O)]);delete  optsCopy[(k7x+K5Q+o6v.v9Q+N7O)];}
if(optsCopy.error){opts.error[(x2Q+E7Q+c8Q+q05)](optsCopy.error);delete  optsCopy.error;}
opts=$[d8O]({}
,opts,optsCopy);}
opts[(t4O+b5Q)]=opts[(H05+P05)][(e5Q+o6v.v9Q+d9Q+o6v.B6Q)](/_id_/,id);if(opts.data){var newData=$[(F1Q+Y05+q5O+o6v.G4Q+H2Q+q05+n7Q+o6v.G4Q)](opts.data)?opts.data(data):opts.data;data=$[(F1Q+B5Q+H05+o6v.G4Q+G4x+d9O)](opts.data)&&newData?newData:$[(o6v.B6Q+v6x+o6v.B6Q+x05)](true,data,newData);}
opts.data=data;if(opts[(q05+b6O+o6v.B6Q)]===(J0O+o3Q)&&(opts[(S2+w6Q+a85)]===undefined||opts[(Y25+e9O+o4O+o6v.l6Q+a85)]===true)){var params=$[(o6v.v9Q+x25+X35)](opts.data);opts[(H05+o6v.B9Q+b5Q)]+=opts[u7x][(r8+o6v.B6Q+o6v.t85+e5O)]('?')===-1?'?'+params:'&'+params;delete  opts.data;}
$[(T2Q+n8Q)](opts);}
;Editor.prototype._assembleMain=function(){var n9O="ormE",dom=this[Q0];$(dom[(K35+U7Q+F0)])[r0](dom[h75]);$(dom[s3])[z6x](dom[(o6v.Y7Q+n9O+T7O+o6v.B9Q)])[(l85+o6v.v9Q+o6v.B6Q+o6v.G4Q+o6v.l6Q)](dom[(m2Q+A4O+q7x+s75)]);$(dom[u7])[(T2Q+p9x+o6v.B6Q+o6v.G4Q+o6v.l6Q)](dom[(o6v.Y7Q+o6v.l4Q+v35+m8O)])[z6x](dom[z65]);}
;Editor.prototype._blur=function(){var L65='uncti',i4x='preB',G85="lur",opts=this[Y05][W2Q],onBlur=opts[(f5+R3O+G85)];if(this[t0x]((i4x+y75+p15))===false){return ;}
if(typeof onBlur===(Z65+L65+R15+i15)){onBlur(this);}
else if(onBlur==='submit'){this[G3x]();}
else if(onBlur===(i7x+c25)){this[(r2x+b5Q+u1)]();}
}
;Editor.prototype._clearDynamicInfo=function(){if(!this[Y05]){return ;}
var errorClass=this[(b6x+T2Q+Y05+Y05+o6v.B6Q+Y05)][(o6v.Y7Q+F1Q+i5Q+o6v.l6Q)].error,fields=this[Y05][(o6v.Y7Q+F1Q+o2O+Y05)];$('div.'+errorClass,this[Q0][(r5Q+p9x+U9Q)])[k0Q](errorClass);$[P1Q](fields,function(name,field){field.error('')[T0Q]('');}
);this.error('')[(K5Q+L05+Y05+H0x)]('');}
;Editor.prototype._close=function(submitComplete){var K1='dito',T75="oseIcb",J6x="seCb";if(this[t0x]('preClose')===false){return ;}
if(this[Y05][d4x]){this[Y05][(H2Q+b5Q+o6v.l4Q+J6x)](submitComplete);this[Y05][(b6x+u1+p8O+m2Q)]=null;}
if(this[Y05][W7]){this[Y05][(b6x+T75)]();this[Y05][W7]=null;}
$((o5))[(o6v.l4Q+u)]((Z65+R15+v25+u3+s0+R8O+c25+K1+d0+l8O+Z65+R15+v25+u3+s0));this[Y05][j5]=false;this[t0x]('close');}
;Editor.prototype._closeReg=function(fn){this[Y05][d4x]=fn;}
;Editor.prototype._crudArgs=function(arg1,arg2,arg3,arg4){var o4x="mai",E65="rmOp",U9x='boole',that=this,title,buttons,show,opts;if($[(P2+b5Q+T2Q+D7Q+x1O+m2Q+S65+H2Q+q05)](arg1)){opts=arg1;}
else if(typeof arg1===(U9x+Y85+i15)){show=arg1;opts=arg2;}
else{title=arg1;buttons=arg2;show=arg3;opts=arg4;}
if(show===undefined){show=true;}
if(title){that[(e0+U5x)](title);}
if(buttons){that[e6](buttons);}
return {opts:$[(B85+l3+o6v.l6Q)]({}
,this[Y05][(H3+E65+q05+F1Q+o6v.l4Q+s75)][(o4x+o6v.G4Q)],opts),maybeOpen:function(){if(show){that[(o6v.l4Q+C6x+o6v.G4Q)]();}
}
}
;}
;Editor.prototype._dataSource=function(name){var t1="taS",args=Array.prototype.slice.call(arguments);args[e7]();var fn=this[Y05][(o6v.l6Q+T2Q+t1+L9+o6v.B9Q+H2Q+o6v.B6Q)][name];if(fn){return fn[Q2Q](this,args);}
}
;Editor.prototype._displayReorder=function(includeFields){var x4O='Order',C65="deFi",W5="ncl",S9x="empl",N1x="mC",that=this,formContent=$(this[(Q0)][(f5O+N1x+o6v.l4Q+o6v.G4Q+y3x+o6v.O75)]),fields=this[Y05][I4x],order=this[Y05][s8Q],template=this[Y05][(q05+S9x+T2Q+q05+o6v.B6Q)],mode=this[Y05][(K5Q+o6v.l4Q+o6v.l6Q+o6v.B6Q)]||'main';if(includeFields){this[Y05][(F1Q+W5+H05+C65+o6v.B6Q+b5Q+o6v.l6Q+Y05)]=includeFields;}
else{includeFields=this[Y05][M65];}
formContent[m0x]()[q2O]();$[(o6v.B6Q+T2Q+Z2x)](order,function(i,fieldOrName){var f8="InA",T05="ak",J75="we",name=fieldOrName instanceof Editor[t3Q]?fieldOrName[R7Q]():fieldOrName;if(that[(N8Q+J75+T05+f8+o6v.B9Q+o6v.B9Q+T2Q+a85)](name,includeFields)!==-1){if(template&&mode===(R75+v75+i15)){template[(p0+o6v.G4Q+o6v.l6Q)]((c25+T25+o6v.R0+e7O+l8O+Z65+v75+c25+y75+o25+y9Q+i15+Y85+u15+c25+i9)+name+(p7x))[(T2Q+o6v.Y7Q+O8)](fields[name][t0O]());template[O1O]('[data-editor-template="'+name+'"]')[(l85+o6v.v9Q+o6v.B6Q+x05)](fields[name][(j65+o6v.l6Q+o6v.B6Q)]());}
else{formContent[z6x](fields[name][(j65+o6v.l6Q+o6v.B6Q)]());}
}
}
);if(template&&mode==='main'){template[w2O](formContent);}
this[(D1x+o6v.B6Q+o6v.O75)]((u0+q7Q+I6x+x4O),[this[Y05][j5],this[Y05][(T2Q+Q2+o6v.G4Q)],formContent]);}
;Editor.prototype._edit=function(items,editFields,type){var F4O='Ed',B7O='initM',R7x='init',O3="toStr",u9="slice",that=this,fields=this[Y05][(o6v.Y7Q+L8Q+b5Q+o6v.l6Q+Y05)],usedFields=[],includeInOrder,editData={}
;this[Y05][A2Q]=editFields;this[Y05][(o6v.B6Q+o6v.l6Q+P5Q+o8O+d65+T2Q)]=editData;this[Y05][(K5Q+o6v.l4Q+o6v.l6Q+c8Q+F1Q+U9Q)]=items;this[Y05][(D5Q+q05+F1Q+o6v.l4Q+o6v.G4Q)]=(o6v.B6Q+o6v.l6Q+P5Q);this[Q0][z65][(Y05+q05+a85+U5x)][a15]=(P85+g9Q+v25+P75);this[Y05][(m8Q+V2O)]=type;this[t0]();$[(z2Q+H2Q+E7Q)](fields,function(name,field){var n2O="iRe";field[(A6Q+b5Q+q05+n2O+D3+q05)]();includeInOrder=true;editData[name]={}
;$[P1Q](editFields,function(idSrc,edit){var M0O="Data";if(edit[(o6v.Y7Q+F1Q+o2O+Y05)][name]){var val=field[(J8Q+b5Q+X2O+o6v.B9Q+o6v.l4Q+K5Q+M0O)](edit.data);editData[name][idSrc]=val;field[(K5Q+H05+b5Q+u2x+V6O+q05)](idSrc,val!==undefined?val:field[w4O]());if(edit[(K85+o6v.v9Q+F1x+a85+t7x+b5Q+z4O)]&&!edit[D0Q][name]){includeInOrder=false;}
}
}
);if(field[J1]().length!==0&&includeInOrder){usedFields[(C15+E7Q)](name);}
}
);var currOrder=this[(o6v.l4Q+j5Q+o6v.B6Q+o6v.B9Q)]()[(u9)]();for(var i=currOrder.length-1;i>=0;i--){if($[y7Q](currOrder[i][(O3+F1Q+o6v.G4Q+W7Q)](),usedFields)===-1){currOrder[(Y05+o6v.v9Q+b5Q+N8O)](i,1);}
}
this[j7](currOrder);this[(N8Q+A35+X4Q+q05)]((R7x+L1x),[_pluck(editFields,'node')[0],_pluck(editFields,'data')[0],items,type]);this[t0x]((B7O+Z1x+v75+F4O+Y5),[editFields,items,type]);}
;Editor.prototype._event=function(trigger,args){var X6O="resul",q0x="gg",q1x="Eve";if(!args){args=[];}
if($[z9Q](trigger)){for(var i=0,ien=trigger.length;i<ien;i++){this[(N8Q+t35+o6v.G4Q+q05)](trigger[i],args);}
}
else{var e=$[(q1x+o6v.G4Q+q05)](trigger);$(this)[(K3+q0x+o6v.B6Q+o6v.B9Q+I8)](e,args);return e[(X6O+q05)];}
}
;Editor.prototype._eventName=function(input){var w8Q="rin",f7="Case",j25="oL",l7O="pli",name,names=input[(Y05+l7O+q05)](' ');for(var i=0,ien=names.length;i<ien;i++){name=names[i];var onStyle=name[E2Q](/^on([A-Z])/);if(onStyle){name=onStyle[1][(q05+j25+J9+U9Q+f7)]()+name[(Y05+h3O+Y05+q05+w8Q+W7Q)](3);}
names[i]=name;}
return names[(q1Q+o6v.l4Q+F1Q+o6v.G4Q)](' ');}
;Editor.prototype._fieldFromNode=function(node){var foundField=null;$[P1Q](this[Y05][(G3O+Y05)],function(name,field){if($(field[t0O]())[O1O](node).length){foundField=field;}
}
);return foundField;}
;Editor.prototype._fieldNames=function(fieldNames){if(fieldNames===undefined){return this[(o6v.Y7Q+F1Q+i5Q+o6v.l6Q+Y05)]();}
else if(!$[(F0x+o6v.B9Q+o6v.B9Q+T2Q+a85)](fieldNames)){return [fieldNames];}
return fieldNames;}
;Editor.prototype._focus=function(fieldsIn,focus){var y1x='jq',D7x='nu',that=this,field,fields=$[(K5Q+T2Q+o6v.v9Q)](fieldsIn,function(fieldOrName){return typeof fieldOrName==='string'?that[Y05][(p0+o6v.B6Q+b5Q+z4O)][fieldOrName]:fieldOrName;}
);if(typeof focus===(D7x+u15+x4x+d0)){field=fields[focus];}
else if(focus){if(focus[Z9x]((y1x+M5O))===0){field=$((o25+H5+R8O+v3Q+E1Q+o3Q+J5x)+focus[(e5Q+o6v.v9Q+b5Q+m2x)](/^jq:/,''));}
else{field=this[Y05][(B4O+o6v.l6Q+Y05)][focus];}
}
this[Y05][U5Q]=field;if(field){field[(o6v.Y7Q+s7Q)]();}
}
;Editor.prototype._formOptions=function(opts){var C8x="eIc",x75="utto",C9x="tOpt",S4x='blu',l6x="rOn",z7="Backg",U6='non',f2x="etur",M5="onReturn",N2O="etu",V2Q="nR",s65="mitO",a5Q="onBlur",J7x="submitOnBlur",l5="mplet",c8="OnCo",v05="Co",q4O='In',that=this,inlineCount=__inlineCounter++,namespace=(R8O+o25+I9O+q4O+y75+v75+Q0x)+inlineCount;if(opts[(W9Q+o6v.B6Q+x1O+o6v.G4Q+v05+K5Q+y2O+q05+o6v.B6Q)]!==undefined){opts[(f5+p8O+o6v.l4Q+w2Q+b5Q+c05+o6v.B6Q)]=opts[(b6x+o6v.l4Q+D3+c8+l5+o6v.B6Q)]?(p5x):(G2x+Q0x);}
if(opts[J7x]!==undefined){opts[a5Q]=opts[J7x]?'submit':(j9O+T4x);}
if(opts[(Y05+H05+m2Q+s65+V2Q+N2O+o6v.B9Q+o6v.G4Q)]!==undefined){opts[M5]=opts[(Y05+h3O+K5Q+F1Q+a6+V2Q+f2x+o6v.G4Q)]?(T5Q+h0+o6v.R0):(U6+c25);}
if(opts[(H2+t4O+x1O+o6v.G4Q+z7+o6v.B9Q+F65)]!==undefined){opts[(o6v.l4Q+o6v.G4Q+R3O+T2Q+E2x+W7Q+o6v.B9Q+o6v.l4Q+d7x)]=opts[(H2+H05+l6x+i1x+z5+o6v.B9Q+F65)]?(S4x+d0):(i15+C6O+c25);}
this[Y05][(o6v.B6Q+o6v.l6Q+F1Q+C9x+Y05)]=opts;this[Y05][N0O]=inlineCount;if(typeof opts[(u2x+q05+U5x)]==='string'||typeof opts[(u2x+t6x+o6v.B6Q)]===(Z65+R65+v25+u3Q+R15+i15)){this[(q05+F1Q+q05+b5Q+o6v.B6Q)](opts[(q05+P5Q+U5x)]);opts[O7x]=true;}
if(typeof opts[(V9O+Y05+Y05+T2Q+k9)]==='string'||typeof opts[(V9O+A4+W7Q+o6v.B6Q)]===(Z65+R65+H7Q+C75)){this[(u9x+Y05+T2Q+k9)](opts[(K5Q+M3x+T2Q+k9)]);opts[T0Q]=true;}
if(typeof opts[(m2Q+H05+a5x+f5+Y05)]!=='boolean'){this[(b5+q05+q05+c4Q)](opts[(m2Q+x75+s75)]);opts[(b5+l3x+Y05)]=true;}
$(document)[(o6v.l4Q+o6v.G4Q)]((P75+E3x+o25+s5O+i15)+namespace,function(e){var r25="key",o0Q="eyCod",q6x='ns',S15='m_Bu',w9O='_Fo',Q4="nEs",u3x="onEsc",Y7x="Es",X0Q="Esc",U25="efault",w6x="preventDefault",w7="mit",J65="turnSub",m7="nRe",B1Q="nSub",X2x="romN",e6x="yed",q85="spla",A5="yC",h5Q="veElem",el=$(document[(T2Q+G4x+F1Q+h5Q+Y6)]);if(e[(v5+A5+o6v.l4Q+o6v.l6Q+o6v.B6Q)]===13&&that[Y05][(v7O+q85+e6x)]){var field=that[(N8Q+p0+o2O+X2O+X2x+o6v.l4Q+o6v.l6Q+o6v.B6Q)](el);if(field&&typeof field[(H2Q+T2Q+o6v.G4Q+C5O+c05+H05+o6v.B9Q+B1Q+C0Q+q05)]==='function'&&field[(H2Q+T2Q+m7+J65+w7)](el)){if(opts[M5]===(r2O+P85+u15+Y5)){e[w6x]();that[(Y05+H05+m2Q+C0Q+q05)]();}
else if(typeof opts[M5]===(Z65+R65+H7Q+C75)){e[w6x]();opts[M5](that);}
}
}
else if(e[Q15]===27){e[(G4+q6Q+o6v.O75+o8O+U25)]();if(typeof opts[(o6v.l4Q+o6v.G4Q+X0Q)]===(g3O+i15+d6x)){opts[(f5+Y7x+H2Q)](that);}
else if(opts[u3x]===(S4x+d0)){that[c35]();}
else if(opts[(o6v.l4Q+o6v.G4Q+B8O+Y05+H2Q)]===(v25+y75+m3O)){that[(H2Q+w3O+D3)]();}
else if(opts[(o6v.l4Q+Q4+H2Q)]===(T5Q+u15+Y5)){that[(i1+m2Q+K5Q+F1Q+q05)]();}
}
else if(el[n6x]((R8O+v3Q+g85+w9O+d0+S15+o6v.R0+o6v.R0+R15+q6x)).length){if(e[(J1Q+o0Q+o6v.B6Q)]===37){el[(o6v.v9Q+o6v.B9Q+o6v.B6Q+M35)]('button')[(U2Q+H05+Y05)]();}
else if(e[(r25+v05+o6v.l6Q+o6v.B6Q)]===39){el[(o6v.G4Q+o6v.B6Q+v6x)]((P85+B15+W75))[(O5x+Y05)]();}
}
}
);this[Y05][(b6x+o6v.l4Q+Y05+C8x+m2Q)]=function(){$(document)[(o6v.l4Q+o6v.Y7Q+o6v.Y7Q)]('keydown'+namespace);}
;return namespace;}
;Editor.prototype._legacyAjax=function(direction,action,data){var Q7Q="cyA";if(!this[Y05][(b5Q+o6v.B6Q+W7Q+T2Q+Q7Q+n8Q)]||!data){return ;}
if(direction===(s0+r5+o25)){if(action===(v25+q5+E8x+c25)||action===(r6+Y5)){var id;$[(o6v.B6Q+T2Q+H2Q+E7Q)](data.data,function(rowId,values){var V1Q='jax',n4Q='acy',z2x='ted',y85='por',g7='ting';if(id!==undefined){throw (L1x+R15+d0+A8O+V6Q+E75+l8O+d0+R15+B3+J5x+c25+T25+g7+J5x+v75+s0+J5x+i15+R15+o6v.R0+J5x+s0+u3+D+y85+z2x+J5x+P85+a8+J5x+o6v.R0+J4Q+J5x+y75+c25+b65+n4Q+J5x+H9O+V1Q+J5x+o25+Y85+J5O+J5x+Z65+e7O+R75+o6v.R0);}
id=rowId;}
);data.data=data.data[id];if(action===(c25+o25+v75+o6v.R0)){data[(y3Q)]=id;}
}
else{data[(y3Q)]=$[(R5O+o6v.v9Q)](data.data,function(values,id){return id;}
);delete  data.data;}
}
else{if(!data.data&&data[(o6v.B9Q+o6v.l4Q+K35)]){data.data=[data[G5]];}
else if(!data.data){data.data=[];}
}
}
;Editor.prototype._optionsUpdate=function(json){var that=this;if(json[k9x]){$[(P1Q)](this[Y05][(B4O+z4O)],function(name,field){var l3Q="pti",C6Q="update";if(json[(o6v.l4Q+z+o6v.G4Q+Y05)][name]!==undefined){var fieldInst=that[(W2+b5Q+o6v.l6Q)](name);if(fieldInst&&fieldInst[(H05+Y6x+T2Q+y3x)]){fieldInst[C6Q](json[(o6v.l4Q+l3Q+o6v.l4Q+s75)][name]);}
}
}
);}
}
;Editor.prototype._message=function(el,msg){var k9O="deI",x8x="sto",L75='isp',C2x="fadeOut",q0Q="top";if(typeof msg===(Z65+R65+d6x)){msg=msg(this,new DataTable[(o3O+Y1x)](this[Y05][(L0+b5Q+o6v.B6Q)]));}
el=$(el);if(!msg&&this[Y05][j5]){el[(Y05+q0Q)]()[C2x](function(){el[(p8x+b5Q)]('');}
);}
else if(!msg){el[J5Q]('')[v15]((o25+L75+y75+I6x),'none');}
else if(this[Y05][(v7O+d7+b5Q+z75+G7Q)]){el[(x8x+o6v.v9Q)]()[(J5Q)](msg)[(o75+k9O+o6v.G4Q)]();}
else{el[(p8x+b5Q)](msg)[v15]((o25+L75+f6Q+a8),'block');}
}
;Editor.prototype._multiInfo=function(){var H6Q="multiInfoShown",l4="Va",fields=this[Y05][(o6v.Y7Q+F1Q+a0O)],include=this[Y05][M65],show=true,state;if(!include){return ;}
for(var i=0,ien=include.length;i<ien;i++){var field=fields[include[i]],multiEditable=field[u7O]();if(field[E5Q]()&&multiEditable&&show){state=true;show=false;}
else if(field[(F1Q+W05+k+F1Q+l4+b5Q+H05+o6v.B6Q)]()&&!multiEditable){state=true;}
else{state=false;}
fields[include[i]][H6Q](state);}
}
;Editor.prototype._postopen=function(type){var i2Q="iIn",O2="_mul",y5x='bub',J4='ai',k4='na',y7x='ern',B2x='bmi',i5O="captureFocus",that=this,focusCapture=this[Y05][G3][i5O];if(focusCapture===undefined){focusCapture=true;}
$(this[(Q0)][z65])[(i6+o6v.Y7Q)]((r2O+B2x+o6v.R0+R8O+c25+o25+v75+N2Q+d0+l8O+v75+A6x+y7x+h9))[f5]((T5Q+u15+Y5+R8O+c25+o25+v75+N2Q+d0+l8O+v75+A6x+Q9+k4+y75),function(e){var F3O="efaul",S4O="ntD",O7O="rev";e[(o6v.v9Q+O7O+o6v.B6Q+S4O+F3O+q05)]();}
);if(focusCapture&&(type===(u15+J4+i15)||type===(y5x+A0O+c25))){$('body')[(f5)]('focus.editor-focus',function(){var T0x="etFoc",Q8x="veE",s6O="veEle";if($(document[(T2Q+G4x+F1Q+s6O+K5Q+X4Q+q05)])[n6x]((R8O+v3Q+g85)).length===0&&$(document[(T2Q+G4x+F1Q+Q8x+b5Q+o6v.B6Q+K5Q+X4Q+q05)])[n6x]((R8O+v3Q+E1Q+p1x)).length===0){if(that[Y05][(Y05+T0x+H05+Y05)]){that[Y05][U5Q][(o6v.Y7Q+o6v.l4Q+l4x+Y05)]();}
}
}
);}
this[(O2+q05+i2Q+H3)]();this[t0x]('open',[type,this[Y05][(D5Q+q05+F1Q+o6v.l4Q+o6v.G4Q)]]);return true;}
;Editor.prototype._preopen=function(type){var q8Q="seIc",L0Q="mod",Q1Q='lOpe',c1Q='can',M8x="icI",Z5="Dy",W9="cle",G5x='eOp';if(this[(O6x+M35+Y6)]((L5Q+G5x+r5),[type,this[Y05][b7O]])===false){this[(N8Q+W9+T2Q+o6v.B9Q+Z5+o6v.G4Q+X35+M8x+R85)]();this[(D1x+o6v.B6Q+o6v.G4Q+q05)]((c1Q+v25+c25+Q1Q+i15),[type,this[Y05][b7O]]);if((this[Y05][D15]===(v75+j8x+F7+c25)||this[Y05][(L0Q+o6v.B6Q)]===(z9))&&this[Y05][W7]){this[Y05][W7]();}
this[Y05][(H2Q+b5Q+o6v.l4Q+q8Q+m2Q)]=null;return false;}
this[Y05][j5]=type;return true;}
;Editor.prototype._processing=function(processing){var e65="toggleClass",G9="ive",J6="clas",procClass=this[(J6+Y05+L05)][J2Q][(D5Q+q05+G9)];$(['div.DTE',this[(o6v.l6Q+A1)][q1O]])[e65](procClass,processing);this[Y05][J2Q]=processing;this[(O6x+M35+Y6)]('processing',[processing]);}
;Editor.prototype._submit=function(successCallback,errorCallback,formatdata,hide){var N9="Table",y5O="_submit",O05="ajaxUrl",d2Q="yAjax",e0Q="egac",g0Q='tCo',t6Q="all",g9='nc',v8Q="nCo",x5O="onComplete",A8x='anged',y1='Ch',h7O='If',v1Q="dbT",c5="editData",that=this,i,iLen,eventRet,errorNodes,changed=false,allData={}
,changedData={}
,setBuilder=DataTable[x8Q][(o6v.l4Q+o3O+o6v.v9Q+F1Q)][z6Q],dataSource=this[Y05][(f8O+q05+i3Q+U8Q+H2Q+o6v.B6Q)],fields=this[Y05][I4x],action=this[Y05][b7O],editCount=this[Y05][(G7Q+F1Q+A+o6v.l4Q+H05+o6v.O75)],modifier=this[Y05][r35],editFields=this[Y05][(o6v.B6Q+o6v.l6Q+F1Q+q05+X2O+L8Q+b5Q+z4O)],editData=this[Y05][c5],opts=this[Y05][(o6v.B6Q+z0x+r8O)],changedSubmit=opts[(i1+m2Q+K5Q+F1Q+q05)],submitParams={"action":this[Y05][(D5Q+q05+F1Q+f5)],"data":{}
}
,submitParamsLocal;if(this[Y05][j3x]){submitParams[s25]=this[Y05][(v1Q+n1Q+U5x)];}
if(action===(H2Q+o6v.B9Q+o6v.B6Q+d2x)||action==="edit"){$[(P1Q)](editFields,function(idSrc,edit){var allRowData={}
,changedRowData={}
;$[(P1Q)](fields,function(name,field){var x='edi',W5Q='oun',S9O="epla",I1="xOf",s2O="Array",K5="iGe";if(edit[(o6v.Y7Q+F1Q+a0O)][name]){var value=field[(K5Q+H05+v2O+K5+q05)](idSrc),builder=setBuilder(name),manyBuilder=$[(F1Q+Y05+s2O)](value)&&name[(F1Q+r2+I1)]('[]')!==-1?setBuilder(name[(o6v.B9Q+S9O+H2Q+o6v.B6Q)](/\[.*$/,'')+(l8O+u15+i0x+a8+l8O+v25+W5Q+o6v.R0)):null;builder(allRowData,value);if(manyBuilder){manyBuilder(allRowData,value.length);}
if(action===(x+o6v.R0)&&(!editData[name]||!_deepCompare(value,editData[name][idSrc]))){builder(changedRowData,value);changed=true;if(manyBuilder){manyBuilder(changedRowData,value.length);}
}
}
}
);if(!$[R1Q](allRowData)){allData[idSrc]=allRowData;}
if(!$[R1Q](changedRowData)){changedData[idSrc]=changedRowData;}
}
);if(action==='create'||changedSubmit===(Y85+y75+y75)||(changedSubmit===(Y85+y75+y75+h7O+y1+A8x)&&changed)){submitParams.data=allData;}
else if(changedSubmit===(v25+g5Q+i15+b65+r6)&&changed){submitParams.data=changedData;}
else{this[Y05][b7O]=null;if(opts[x5O]==='close'&&(hide===undefined||hide)){this[(N8Q+H2Q+w3O+Y05+o6v.B6Q)](false);}
else if(typeof opts[(o6v.l4Q+v8Q+w2Q+U5x+q05+o6v.B6Q)]===(g3O+g9+u3Q+R15+i15)){opts[(f5+p8O+A1+P5x+o6v.B6Q+q05+o6v.B6Q)](this);}
if(successCallback){successCallback[(H2Q+t6Q)](this);}
this[h0Q](false);this[(N8Q+A35+o6v.B6Q+o6v.G4Q+q05)]((T5Q+u15+v75+g0Q+u15+q7Q+c25+I9O));return ;}
}
else if(action===(o6v.B9Q+o6v.B6Q+K5Q+o6v.l4Q+q6Q)){$[P1Q](editFields,function(idSrc,edit){submitParams.data[idSrc]=edit.data;}
);}
this[(N8Q+b5Q+e0Q+d2Q)]('send',action,submitParams);submitParamsLocal=$[(x8Q+o6v.B6Q+o6v.G4Q+o6v.l6Q)](true,{}
,submitParams);if(formatdata){formatdata(submitParams);}
if(this[(N8Q+o6v.B6Q+e75)]((I8x+a1Q+O9Q+h0+o6v.R0),[submitParams,action])===false){this[h0Q](false);return ;}
var submitWire=this[Y05][(T2Q+n8Q)]||this[Y05][O05]?this[(N8Q+x6O)]:this[(y5O+N9)];submitWire[(r0x+b5Q+b5Q)](this,submitParams,function(json,notGood,xhr){var C3x="cc",M6="bm",s85="_su";that[(s85+M6+F1Q+J7+H05+C3x+M3x)](json,notGood,submitParams,submitParamsLocal,action,editCount,hide,successCallback,errorCallback,xhr);}
,function(xhr,err,thrown){that[(x0O+h3O+K5Q+P5Q+B8O+o6v.B9Q+o6v.B9Q+X4)](xhr,err,thrown,errorCallback,submitParams,action);}
,submitParams);}
;Editor.prototype._submitTable=function(data,success,error,submitParams){var P1O="aF",W4="Dat",P3O="jec",T3Q="ectDa",F6O="etObj",that=this,action=data[(T2Q+H2Q+q05+d9O)],out={data:[]}
,idGet=DataTable[x8Q][(o6v.l4Q+F5x+F1Q)][(N8Q+v3+F6O+T3Q+q05+T2Q+X2O+o6v.G4Q)](this[Y05][(F1Q+C1x+o6v.B9Q+H2Q)]),idSet=DataTable[x8Q][D4][(N8Q+o6v.Y7Q+K2Q+o6v.B6Q+a6+m2Q+P3O+q05+W4+P1O+o6v.G4Q)](this[Y05][(y3Q+G4O+o6v.B9Q+H2Q)]);if(action!=='remove'){var originalData=this[(V6x+T2Q+L0x+G4O+U8Q+v8x)]((E1x+c25+y75+k15),this[r35]());$[(o6v.B6Q+T2Q+Z2x)](data.data,function(key,vals){var toSave;if(action===(r6+Y5)){var rowData=originalData[key].data;toSave=$[(B85+l3+o6v.l6Q)](true,{}
,rowData,vals);}
else{toSave=$[(o6v.B6Q+v6x+R9)](true,{}
,vals);}
if(action===(Z3x)&&idGet(toSave)===undefined){idSet(toSave,+new Date()+''+key);}
else{idSet(toSave,key);}
out.data[(C7O)](toSave);}
);}
success(out);}
;Editor.prototype._submitSuccess=function(json,notGood,submitParams,submitParamsLocal,action,editCount,hide,successCallback,errorCallback,xhr){var C7x='Com',r5x='cess',f05='tSuc',q3O='bm',X4O="nC",w8="_clos",C2="onComple",i4O="aSource",Y7="_dat",Z1='mov',Z9='stRe',H8O="taSo",K4O='emov',C85='reR',Q85="aSo",i8O='preEd',V7Q='reate',D25='pos',w4Q="eate",o8Q="cal",f8x='ful',g0O='succ',I9x='Un',L0O="dEr",x4Q="eldE",c6Q="_legacyAjax",Y9="tOpts",that=this,setData,fields=this[Y05][I4x],opts=this[Y05][(G7Q+F1Q+Y9)],modifier=this[Y05][(m8Q+o6v.l6Q+F1Q+o6v.Y7Q+L8Q+o6v.B9Q)];this[c6Q]('receive',action,json);this[(N8Q+t35+o6v.G4Q+q05)]('postSubmit',[json,submitParams,action,xhr]);if(!json.error){json.error="";}
if(!json[(p0+x4Q+o6v.B9Q+o6v.B9Q+o6v.l4Q+Z25)]){json[V8O]=[];}
if(notGood||json.error||json[V8O].length){this.error(json.error);$[P1Q](json[(B4O+L0O+b7+Y05)],function(i,err){var X9O="onFi",N05="nte",L1Q='cu',o9O="ieldE",n7x="tatu",field=fields[err[R7Q]];field.error(err[(Y05+n7x+Y05)]||(B8O+o6v.B9Q+b7));if(i===0){if(opts[(o6v.l4Q+o6v.G4Q+X2O+o9O+o6v.B9Q+o6v.B9Q+X4)]===(Z65+R15+L1Q+s0)){$(that[Q0][(z9O+C3Q+N05+o6v.O75)],that[Y05][q1O])[O1x]({"scrollTop":$(field[t0O]()).position().top}
,500);field[F35]();}
else if(typeof opts[(X9O+o6v.B6Q+s5x+y6x+h35+o6v.B9Q)]==='function'){opts[(o6v.l4Q+o6v.G4Q+X2O+F1Q+o6v.B6Q+b5Q+o6v.l6Q+y6x+h35+o6v.B9Q)](that,err);}
}
}
);this[(N8Q+o6v.B6Q+e75)]((T5Q+h0+o6v.R0+I9x+g0O+c25+s0+s0+f8x),[json]);if(errorCallback){errorCallback[(o8Q+b5Q)](that,json);}
}
else{var store={}
;if(json.data&&(action===(H2Q+o6v.B9Q+o6v.B6Q+T2Q+q05+o6v.B6Q)||action==="edit")){this[k7Q]((D+d0+c25+D),action,modifier,submitParamsLocal,json,store);for(var i=0;i<json.data.length;i++){setData=json.data[i];this[(N8Q+A35+o6v.B6Q+o6v.G4Q+q05)]('setData',[json,setData,action]);if(action===(n1x+w4Q)){this[(N8Q+o6v.B6Q+e75)]('preCreate',[json,setData]);this[k7Q]((v25+q5+Y85+I9O),fields,setData,store);this[t0x](['create',(D25+o6v.R0+i0Q+V7Q)],[json,setData]);}
else if(action===(o6v.B6Q+F25)){this[(D1x+X4Q+q05)]((i8O+v75+o6v.R0),[json,setData]);this[(N8Q+o6v.l6Q+d65+i3Q+U8Q+H2Q+o6v.B6Q)]('edit',modifier,fields,setData,store);this[t0x]([(r6+Y5),'postEdit'],[json,setData]);}
}
this[(V6x+d65+Q85+H05+K4)]('commit',action,modifier,json.data,store);}
else if(action==="remove"){this[k7Q]((I8x+D),action,modifier,submitParamsLocal,json,store);this[(N8Q+o6v.B6Q+M35+o6v.B6Q+o6v.O75)]((D+C85+K4O+c25),[json]);this[(N8Q+o6v.l6Q+T2Q+H8O+t4O+H2Q+o6v.B6Q)]((d0+K4O+c25),modifier,fields,store);this[t0x](['remove',(D+R15+Z9+Z1+c25)],[json]);this[(Y7+i4O)]((v25+M6O+h0+o6v.R0),action,modifier,json.data,store);}
if(editCount===this[Y05][N0O]){this[Y05][b7O]=null;if(opts[(C2+q05+o6v.B6Q)]===(P8Q+m3O)&&(hide===undefined||hide)){this[(w8+o6v.B6Q)](json.data?true:false);}
else if(typeof opts[(o6v.l4Q+o6v.G4Q+p8O+A1+o6v.v9Q+N7O)]==='function'){opts[(o6v.l4Q+X4O+o6v.l4Q+K5Q+y2O+y3x)](this);}
}
if(successCallback){successCallback[(H2Q+T2Q+b5Q+b5Q)](that,json);}
this[(N8Q+o6v.B6Q+M35+Y6)]((s0+u3+q3O+v75+f05+r5x),[json,setData]);}
this[(m9x+h35+H2Q+o6v.B6Q+S1+F1Q+H35)](false);this[(O6x+M35+o6v.B6Q+o6v.G4Q+q05)]((r2O+P85+u15+Y5+C7x+D+y75+c25+o6v.R0+c25),[json,setData]);}
;Editor.prototype._submitError=function(xhr,err,thrown,errorCallback,submitParams,action){var L4Q="system",l9x="event";this[(N8Q+l9x)]('postSubmit',[null,submitParams,action,xhr]);this.error(this[J3].error[L4Q]);this[h0Q](false);if(errorCallback){errorCallback[(H2Q+I05+b5Q)](this,xhr,err,thrown);}
this[(O6x+e75)](['submitError',(u75+o6v.R0+i0Q+R15+u15+D+h7Q+I9O)],[xhr,err,thrown,submitParams]);}
;Editor.prototype._tidy=function(fn){var Q1O='los',n0O="bServerSide",that=this,dt=this[Y05][(q05+v5x+o6v.B6Q)]?new $[(C3)][(f8O+L0x+W4O+T2Q+m2Q+U5x)][V9Q](this[Y05][(q05+n1Q+U5x)]):null,ssp=false;if(dt){ssp=dt[(Y05+c05+q05+G6+Y05)]()[0][n05][n0O];}
if(this[Y05][J2Q]){this[i75]('submitComplete',function(){if(ssp){dt[(o6v.l4Q+G35)]((o25+d0+Y85+B3),fn);}
else{setTimeout(function(){fn();}
,10);}
}
);return true;}
else if(this[(o6v.l6Q+Y5Q+o6v.v9Q+N)]()==='inline'||this[a15]()==='bubble'){this[i75]((v25+Q1O+c25),function(){if(!that[Y05][J2Q]){setTimeout(function(){fn();}
,10);}
else{that[(f5+o6v.B6Q)]('submitComplete',function(e,json){if(ssp&&json){dt[(i75)]('draw',fn);}
else{setTimeout(function(){fn();}
,10);}
}
);}
}
)[(H2+t4O)]();return true;}
return false;}
;Editor.prototype._weakInArray=function(name,arr){for(var i=0,ien=arr.length;i<ien;i++){if(name==arr[i]){return i;}
}
return -1;}
;Editor[(Y1Q+q05+Y05)]={"table":null,"ajaxUrl":null,"fields":[],"display":(m6+l65+P85+E5O),"ajax":null,"idSrc":(v3Q+E1Q+g35+S1Q+U9+o25),"events":{}
,"i18n":{"create":{"button":(M1O+o6v.B6Q+K35),"title":"Create new entry","submit":(p8O+e5Q+d2x)}
,"edit":{"button":"Edit","title":(N5x+a9+o6v.B6Q+o6v.O75+o6v.B9Q+a85),"submit":"Update"}
,"remove":{"button":"Delete","title":"Delete","submit":"Delete","confirm":{"_":(o3O+e5Q+a9+a85+L9+a9+Y05+H05+o6v.B9Q+o6v.B6Q+a9+a85+o6v.l4Q+H05+a9+K35+F1Q+Y05+E7Q+a9+q05+o6v.l4Q+a9+o6v.l6Q+o6v.B6Q+U5x+y3x+H8+o6v.l6Q+a9+o6v.B9Q+O5+C0O),"1":(o3O+e5Q+a9+a85+L9+a9+Y05+H05+o6v.B9Q+o6v.B6Q+a9+a85+L9+a9+K35+Y5Q+E7Q+a9+q05+o6v.l4Q+a9+o6v.l6Q+J2O+y3x+a9+b7x+a9+o6v.B9Q+J9+C0O)}
}
,"error":{"system":(o3O+a9+Y05+m7O+X3+a9+o6v.B6Q+Q35+a9+E7Q+T2Q+Y05+a9+o6v.l4Q+H2Q+H2Q+t4O+o6v.B9Q+o6v.B6Q+o6v.l6Q+G5O+T2Q+a9+q05+T2Q+o6v.B9Q+a6O+b4x+N8Q+B0x+d9x+E7Q+c3Q+J4O+o6v.l6Q+d65+T2Q+q05+T2Q+H2+L05+Z6x+o6v.G4Q+c05+x6x+q05+o6v.G4Q+x6x+b7x+K7x+t0Q+U7O+o6v.l4Q+o6v.B9Q+o6v.B6Q+a9+F1Q+o6v.G4Q+f5O+f75+f5+R2Q+T2Q+j7Q)}
,multi:{title:(U7O+v1O+q05+F1Q+P5x+o6v.B6Q+a9+M35+T2Q+g2O+L05),info:(r1Q+o6v.B6Q+a9+Y05+o6v.B6Q+U5x+H2Q+y3x+o6v.l6Q+a9+F1Q+q05+A5Q+Y05+a9+H2Q+f5+h2Q+a9+o6v.l6Q+j9+Y6+a9+M35+I05+H05+L05+a9+o6v.Y7Q+o6v.l4Q+o6v.B9Q+a9+q05+h15+a9+F1Q+s4Q+S6x+W4O+o6v.l4Q+a9+o6v.B6Q+v7O+q05+a9+T2Q+o6v.G4Q+o6v.l6Q+a9+Y05+c05+a9+T2Q+b5Q+b5Q+a9+F1Q+y3x+Z6Q+a9+o6v.Y7Q+X4+a9+q05+E7Q+Y5Q+a9+F1Q+B65+H05+q05+a9+q05+o6v.l4Q+a9+q05+e0O+a9+Y05+T2Q+K5Q+o6v.B6Q+a9+M35+I05+y8O+m05+H2Q+b5Q+a3Q+J1Q+a9+o6v.l4Q+o6v.B9Q+a9+q05+T2Q+o6v.v9Q+a9+E7Q+o6v.B6Q+o6v.B9Q+o6v.B6Q+m05+o6v.l4Q+q05+e0O+V65+F1Q+D3+a9+q05+E7Q+S25+a9+K35+W6Q+b5Q+a9+o6v.B9Q+o6v.B6Q+L0x+D7Q+a9+q05+e0O+F1Q+o6v.B9Q+a9+F1Q+o6v.G4Q+o6v.l6Q+F1Q+i8Q+l3O+b5Q+a9+M35+I05+H05+o6v.B6Q+Y05+Z6x),restore:(m5x+a9+H2Q+E7Q+T2Q+o6v.G4Q+W7Q+o6v.B6Q+Y05),noMulti:(W4O+E7Q+Y5Q+a9+F1Q+o6v.G4Q+l0O+q05+a9+H2Q+x35+a9+m2Q+o6v.B6Q+a9+o6v.B6Q+v7+o6v.l6Q+a9+F1Q+x05+F1Q+M35+j2+b5Q+a85+m05+m2Q+A4O+a9+o6v.G4Q+o6v.l4Q+q05+a9+o6v.v9Q+V4+a9+o6v.l4Q+o6v.Y7Q+a9+T2Q+a9+W7Q+D1+o6v.v9Q+Z6x)}
,"datetime":{previous:(b4+v75+R15+o15),next:'Next',months:['January',(K3Q+c25+P85+d0+t1Q+a8),'March',(F2+v75+y75),(r0O+a8),(A85+i15+c25),(A85+d25),(H9O+T85+u3+s0+o6v.R0),'September',(u7Q+H7Q+R15+P85+Q9),(X5Q+f9Q+c25+d0),(v3Q+c25+r9O+k65)],weekdays:[(a1Q+u3+i15),'Mon',(C0x+c25),(X9Q+o25),'Thu','Fri',(a1Q+Y85+o6v.R0)],amPm:['am',(D+u15)],unknown:'-'}
}
,formOptions:{bubble:$[d8O]({}
,Editor[r9Q][(o6v.Y7Q+o6v.l4Q+v35+G3Q+q05+n7Q+o6v.G4Q+Y05)],{title:false,message:false,buttons:(g35+P85+E8Q+v25),submit:(U0Q+N3x+c25+o25)}
),inline:$[(d8O)]({}
,Editor[r9Q][(H3+o6v.B9Q+y9+q05+n7Q+o6v.G4Q+Y05)],{buttons:false,submit:'changed'}
),main:$[d8O]({}
,Editor[(m8Q+g15)][(o6v.Y7Q+o6v.l4Q+f5x+o6v.v9Q+q05+f1O)])}
,legacyAjax:false}
;(function(){var k6x="tm",f4Q='ditor',A2O="cancelled",Y5O="rowIds",q3="any",g4O="dr",c0Q="_fnGetObjectDataFn",z85="Source",__dataSources=Editor[(o6v.l6Q+T2Q+q05+T2Q+z85+Y05)]={}
,__dtIsSsp=function(dt,editor){var a1="drawType";var j4O="rver";var s9Q="bSe";return dt[x5]()[0][n05][(s9Q+j4O+G4O+f15)]&&editor[Y05][(o6v.B6Q+F25+G3Q+o6v.r1x)][a1]!==(i15+u2);}
,__dtApi=function(table){return $(table)[(o8O+d65+T2Q+O2Q+m2Q+U5x)]();}
,__dtHighlight=function(node){node=$(node);setTimeout(function(){var E4Q='igh';node[x7x]((t05+b65+c65+y75+E4Q+o6v.R0));setTimeout(function(){var U85='high';var T35='hl';var v7x='Hi';node[(Q7O+p8O+b5Q+w65+Y05)]((G2x+v7x+b65+T35+v75+b65+c65+o6v.R0))[(e5Q+K5Q+s9+c8O+F1x+Y05+Y05)]((U85+m6+c65+o6v.R0));setTimeout(function(){var i4="eCl";node[(e5Q+m8Q+M35+i4+w65+Y05)]('noHighlight');}
,550);}
,500);}
,20);}
,__dtRowSelector=function(out,dt,identifier,fields,idFn){dt[(o6v.B9Q+o6v.l4Q+d2)](identifier)[(r8+B6x+Y05)]()[P1Q](function(idx){var row=dt[(o6v.B9Q+o6v.l4Q+K35)](idx);var data=row.data();var idSrc=idFn(data);if(idSrc===undefined){Editor.error('Unable to find row identifier',14);}
out[idSrc]={idSrc:idSrc,data:data,node:row[t0O](),fields:fields,type:'row'}
;}
);}
,__dtColumnSelector=function(out,dt,identifier,fields,idFn){var i1O="ells";dt[(H2Q+i1O)](null,identifier)[x1]()[P1Q](function(idx){__dtCellSelector(out,dt,idx,fields,idFn);}
);}
,__dtCellSelector=function(out,dt,identifier,allFields,idFn,forceFields){var j6O="lls";dt[(v8x+j6O)](identifier)[x1]()[(z2Q+Z2x)](function(idx){var C4="yF";var Z15="odeN";var R7O='jec';var N5O="column";var cell=dt[(H2Q+i5Q+b5Q)](idx);var row=dt[(o6v.B9Q+J9)](idx[(G5)]);var data=row.data();var idSrc=idFn(data);var fields=forceFields||__dtFieldsFromIdx(dt,allFields,idx[N5O]);var isNode=(typeof identifier===(R15+P85+R7O+o6v.R0)&&identifier[(o6v.G4Q+Z15+g25)])||identifier instanceof $;__dtRowSelector(out,dt,idx[(o6v.B9Q+o6v.l4Q+K35)],allFields,idFn);out[idSrc][(T2Q+q05+q05+D5Q+E7Q)]=isNode?[$(identifier)[(k9+q05)](0)]:[cell[(o6v.G4Q+K2+o6v.B6Q)]()];out[idSrc][(o6v.l6Q+F1Q+Y05+o6v.v9Q+b5Q+T2Q+C4+c8x)]=fields;}
);}
,__dtFieldsFromIdx=function(dt,fields,idx){var q0='ame';var Z8O='pec';var t7O='ermin';var G0O='atica';var d15='nab';var p2Q="mData";var Q7x="editField";var U35="ao";var field;var col=dt[x5]()[0][(U35+p8O+m1+o6v.o1O+o6v.G4Q+Y05)][idx];var dataSrc=col[Q7x]!==undefined?col[(G7Q+F1Q+q05+t7x+s5x)]:col[p2Q];var resolvedFields={}
;var run=function(field,dataSrc){if(field[R7Q]()===dataSrc){resolvedFields[field[(o6v.G4Q+T2Q+K5Q+o6v.B6Q)]()]=field;}
}
;$[(o6v.B6Q+D5Q+E7Q)](fields,function(name,fieldInst){if($[z9Q](dataSrc)){for(var i=0;i<dataSrc.length;i++){run(fieldInst,dataSrc[i]);}
}
else{run(fieldInst,dataSrc);}
}
);if($[R1Q](resolvedFields)){Editor.error((l5Q+d15+y75+c25+J5x+o6v.R0+R15+J5x+Y85+u3+o6v.R0+R15+u15+G0O+y75+d25+J5x+o25+c25+o6v.R0+t7O+c25+J5x+Z65+v75+C9Q+J5x+Z65+d0+R15+u15+J5x+s0+h1O+d0+r9O+b8Q+P7Q+y75+c2+T4x+J5x+s0+Z8O+v75+Z65+a8+J5x+o6v.R0+J4Q+J5x+Z65+v75+c25+y75+o25+J5x+i15+q0+R8O),11);}
return resolvedFields;}
,__dtjqId=function(id){var N9x='\\$';return typeof id===(s0+o6v.R0+x4+i15+b65)?'#'+id[(o6v.B9Q+D9Q+F1x+H2Q+o6v.B6Q)](/(:|\.|\[|\]|,)/g,(N9x+w6O)):'#'+id;}
;__dataSources[(f8O+L0x+W4O+T2Q+U65)]={individual:function(identifier,fieldNames){var idFn=DataTable[x8Q][(o6v.l4Q+F5x+F1Q)][c0Q](this[Y05][A5x]),dt=__dtApi(this[Y05][s25]),fields=this[Y05][(W2+b5Q+z4O)],out={}
,forceFields,responsiveNode;if(fieldNames){if(!$[z9Q](fieldNames)){fieldNames=[fieldNames];}
forceFields={}
;$[(o6v.B6Q+D5Q+E7Q)](fieldNames,function(i,name){forceFields[name]=fields[name];}
);}
__dtCellSelector(out,dt,identifier,fields,idFn,forceFields);return out;}
,fields:function(identifier){var X1O="ell",u0O="umn",p4O="lum",a3="cells",V4O="columns",p6Q="dSr",c1O="aFn",u25="GetO",idFn=DataTable[(o6v.B6Q+v6x)][D4][(N8Q+o6v.Y7Q+o6v.G4Q+u25+m2Q+q1Q+o6v.B6Q+H2Q+q05+o8O+T2Q+q05+c1O)](this[Y05][(F1Q+p6Q+H2Q)]),dt=__dtApi(this[Y05][s25]),fields=this[Y05][(o6v.Y7Q+d6Q+Y05)],out={}
;if($[E2O](identifier)&&(identifier[(h35+K35+Y05)]!==undefined||identifier[(V4O)]!==undefined||identifier[a3]!==undefined)){if(identifier[(h35+K35+Y05)]!==undefined){__dtRowSelector(out,dt,identifier[(o6v.B9Q+O5)],fields,idFn);}
if(identifier[(H2Q+o6v.l4Q+p4O+s75)]!==undefined){__dtColumnSelector(out,dt,identifier[(k7x+b5Q+u0O+Y05)],fields,idFn);}
if(identifier[a3]!==undefined){__dtCellSelector(out,dt,identifier[(H2Q+X1O+Y05)],fields,idFn);}
}
else{__dtRowSelector(out,dt,identifier,fields,idFn);}
return out;}
,create:function(fields,data){var dt=__dtApi(this[Y05][(q05+T2Q+m2Q+b5Q+o6v.B6Q)]);if(!__dtIsSsp(dt,this)){var row=dt[(h35+K35)][(Q7O)](data);__dtHighlight(row[t0O]());}
}
,edit:function(identifier,fields,data,store){var t1x="splic",A7Q="wI",n75="ectDat",W3="awTy",dt=__dtApi(this[Y05][(q05+T2Q+U65)]);if(!__dtIsSsp(dt,this)||this[Y05][(o6v.B6Q+z0x+o6v.v9Q+q05+Y05)][(g4O+W3+o6v.v9Q+o6v.B6Q)]===(i15+C6O+c25)){var idFn=DataTable[(B85+q05)][D4][(N8Q+v3+c05+x1O+m2Q+q1Q+n75+T2Q+X2O+o6v.G4Q)](this[Y05][A5x]),rowId=idFn(data),row;try{row=dt[G5](__dtjqId(rowId));}
catch(e){row=dt;}
if(!row[q3]()){row=dt[(o6v.B9Q+J9)](function(rowIdx,rowData,rowNode){return rowId==idFn(rowData);}
);}
if(row[(q3)]()){row.data(data);var idx=$[(D7Q+q4x+o6v.B9Q+T2Q+a85)](rowId,store[(o6v.B9Q+o6v.l4Q+A7Q+z4O)]);store[Y5O][(t1x+o6v.B6Q)](idx,1);}
else{row=dt[(o6v.B9Q+o6v.l4Q+K35)][(m5Q+o6v.l6Q)](data);}
__dtHighlight(row[t0O]());}
}
,remove:function(identifier,fields,store){var D4x="every",B75="tDat",H3x="bjec",u2O="nGetO",X65="rows",dt=__dtApi(this[Y05][(q05+T2Q+m2Q+U5x)]),cancelled=store[A2O];if(cancelled.length===0){dt[X65](identifier)[(o6v.B9Q+A5Q+s9+o6v.B6Q)]();}
else{var idFn=DataTable[(x8Q)][(D4)][(L7x+u2O+H3x+B75+T2Q+A6O)](this[Y05][(y3Q+G4O+o6v.B9Q+H2Q)]),indexes=[];dt[(h35+d2)](identifier)[D4x](function(){var id=idFn(this.data());if($[y7Q](id,cancelled)===-1){indexes[C7O](this[(D7Q+o6v.l6Q+B85)]());}
}
);dt[(o6v.B9Q+O5)](indexes)[k8]();}
}
,prep:function(action,identifier,submit,json,store){var K65="lled",f2Q="can";if(action===(T6Q)){var cancelled=json[(f2Q+v8x+b5Q+M1Q)]||[];store[Y5O]=$[E0O](submit.data,function(val,key){return !$[R1Q](submit.data[key])&&$[(t4Q+o6v.B9Q+o6v.B9Q+T2Q+a85)](key,cancelled)===-1?key:undefined;}
);}
else if(action===(d0+c25+u15+R15+P3+c25)){store[(H2Q+T2Q+o6v.G4Q+H2Q+o6v.B6Q+K65)]=json[A2O]||[];}
}
,commit:function(action,identifier,data,store){var F05="wT",A2x="itO",dt=__dtApi(this[Y05][s25]);if(action===(c25+o25+v75+o6v.R0)&&store[Y5O].length){var ids=store[(h35+K35+q6O+z4O)],idFn=DataTable[(x8Q)][(u9Q+Y1x)][c0Q](this[Y05][A5x]),row;for(var i=0,ien=ids.length;i<ien;i++){row=dt[(h35+K35)](__dtjqId(ids[i]));if(!row[(x35+a85)]()){row=dt[G5](function(rowIdx,rowData,rowNode){return ids[i]==idFn(rowData);}
);}
if(row[(q3)]()){row[k8]();}
}
}
var drawType=this[Y05][(G7Q+A2x+O9x+Y05)][(o6v.l6Q+U7Q+F05+b6O+o6v.B6Q)];if(drawType!==(i15+u2)){dt[(g4O+T2Q+K35)](drawType);}
}
}
;function __html_get(identifier,dataSrc){var el=__html_el(identifier,dataSrc);return el[(o6v.Y7Q+F1Q+b5Q+y3x+o6v.B9Q)]('[data-editor-value]').length?el[(T2Q+a5x+o6v.B9Q)]('data-editor-value'):el[J5Q]();}
function __html_set(identifier,fields,data){$[(g5+E7Q)](fields,function(name,field){var j05=']',Z6="filter",b9O="Sr",j1O="Fr",val=field[(L85+j1O+A1+o8O+T2Q+L0x)](data);if(val!==undefined){var el=__html_el(identifier,field[(o6v.l6Q+h3x+b9O+H2Q)]());if(el[Z6]((y9Q+o25+E8x+Y85+l8O+c25+o25+Q6x+l8O+P3+Y85+y75+u3+c25+j05)).length){el[(d65+q05+o6v.B9Q)]((L5x+Y85+l8O+c25+f4Q+l8O+P3+h9+u3+c25),val);}
else{el[(g5+E7Q)](function(){var P0x="firstChild",j75="des";while(this[(T8+s5x+M1O+o6v.l4Q+j75)].length){this[(e5Q+K5Q+o6v.l4Q+M35+o6v.B6Q+u5Q+F1Q+s5x)](this[P0x]);}
}
)[(p8x+b5Q)](val);}
}
}
);}
function __html_els(identifier,names){var out=$();for(var i=0,ien=names.length;i<ien;i++){out=out[(T2Q+o6v.l6Q+o6v.l6Q)](__html_el(identifier,names[i]));}
return out;}
function __html_el(identifier,name){var K6O='keyl',context=identifier===(K6O+V9+s0)?document:$((y9Q+o25+Y85+J5O+l8O+c25+f4Q+l8O+v75+o25+i9)+identifier+(p7x));return $((y9Q+o25+u85+l8O+c25+T25+o6v.R0+R15+d0+l8O+Z65+v75+C9Q+i9)+name+(p7x),context);}
__dataSources[(E7Q+k6x+b5Q)]={initField:function(cfg){var label=$('[data-editor-label="'+(cfg.data||cfg[(R7Q)])+'"]');if(!cfg[q9O]&&label.length){cfg[(F1x+m2Q+i5Q)]=label[(p1O+K5Q+b5Q)]();}
}
,individual:function(identifier,fieldNames){var K5O='urce',J3O='ield',b25='ati',a8O='addBa',A0x="dB",k75="Nam",attachEl;if(identifier instanceof $||identifier[(t0O+k75+o6v.B6Q)]){attachEl=identifier;if(!fieldNames){fieldNames=[$(identifier)[(x9x)]((o25+Y85+J5O+l8O+c25+o25+Y5+R15+d0+l8O+Z65+v75+c25+a7Q))];}
var back=$[C3][(m5Q+A0x+T2Q+E2x)]?(a8O+F8Q):'andSelf';identifier=$(identifier)[n6x]('[data-editor-id]')[back]().data('editor-id');}
if(!identifier){identifier='keyless';}
if(fieldNames&&!$[z9Q](fieldNames)){fieldNames=[fieldNames];}
if(!fieldNames||fieldNames.length===0){throw (i0Q+i0x+i15+W1O+J5x+Y85+u3+o6v.R0+R15+u15+b25+v25+Y85+y75+y75+a8+J5x+o25+w15+d0+u15+v75+Q0x+J5x+Z65+J3O+J5x+i15+g0x+c25+J5x+Z65+d0+M6O+J5x+o25+Y85+J5O+J5x+s0+R15+K5O);}
var out=__dataSources[(E7Q+V1)][I4x][(r0x+P0O)](this,identifier),fields=this[Y05][I4x],forceFields={}
;$[(o6v.B6Q+T2Q+Z2x)](fieldNames,function(i,name){forceFields[name]=fields[name];}
);$[P1Q](out,function(id,set){var m8="toArray";set[(q05+Q5)]=(v25+c25+b4Q);set[(T2Q+q05+q05+D5Q+E7Q)]=attachEl?$(attachEl):__html_els(identifier,fieldNames)[m8]();set[I4x]=fields;set[D0Q]=forceFields;}
);return out;}
,fields:function(identifier){var X='key',out={}
,data={}
,fields=this[Y05][(o6v.Y7Q+F1Q+o6v.B6Q+b5Q+o6v.l6Q+Y05)];if(!identifier){identifier=(X+y75+c25+s0+s0);}
$[(g5+E7Q)](fields,function(name,field){var W4Q="valToData",val=__html_get(identifier,field[(d1Q+T2Q+G4O+o6v.B9Q+H2Q)]());field[W4Q](data,val===null?undefined:val);}
);out[identifier]={idSrc:identifier,data:data,node:document,fields:fields,type:'row'}
;return out;}
,create:function(fields,data){if(data){var idFn=DataTable[x8Q][(u9Q+o6v.v9Q+F1Q)][c0Q](this[Y05][(y3Q+G4O+o6v.B9Q+H2Q)]),id=idFn(data);if($('[data-editor-id="'+id+(p7x)).length){__html_set(id,fields,data);}
}
}
,edit:function(identifier,fields,data){var y5Q="taF",G6x="etOb",idFn=DataTable[(o6v.B6Q+v6x)][D4][(N8Q+v3+G6x+S65+H2Q+q05+l15+y5Q+o6v.G4Q)](this[Y05][(F1Q+C1x+o6v.B9Q+H2Q)]),id=idFn(data)||'keyless';__html_set(id,fields,data);}
,remove:function(identifier,fields){$('[data-editor-id="'+identifier+(p7x))[k8]();}
}
;}
());Editor[k0]={"wrapper":"DTE","processing":{"indicator":"DTE_Processing_Indicator","active":(o6v.v9Q+o6v.B9Q+o6v.l4Q+v8x+Y05+s8+o6v.G4Q+W7Q)}
,"header":{"wrapper":(o8O+W4O+D1O+W7O+o6v.B9Q),"content":(o8O+W4O+B8O+N8Q+Q75+T2Q+V2O+G8x+o6v.G4Q+y3x+o6v.G4Q+q05)}
,"body":{"wrapper":(V5Q+o4O+o6v.l6Q+a85),"content":"DTE_Body_Content"}
,"footer":{"wrapper":(V05+N8Q+F9Q+O8),"content":"DTE_Footer_Content"}
,"form":{"wrapper":(o8O+W4O+B8O+T6+o6v.l4Q+o6v.B9Q+K5Q),"content":(V05+A6+p5O+p8O+f5+q05+X4Q+q05),"tag":"","info":"DTE_Form_Info","error":"DTE_Form_Error","buttons":(s35+N4+V7O+o6v.B9Q+z5Q+q05+c4Q),"button":(m2Q+q05+o6v.G4Q)}
,"field":{"wrapper":"DTE_Field","typePrefix":(o8O+W4O+B8O+N8Q+c2Q+o6v.l6Q+o9+b6O+S2Q),"namePrefix":(V05+T6+F1Q+i5Q+o6v.l6Q+t5+T2Q+K5Q+S2Q),"label":(o8O+W4O+B8O+N8Q+k7O+T2Q+m2Q+i5Q),"input":"DTE_Field_Input","inputControl":"DTE_Field_InputControl","error":(o8O+D6O+b0+o6v.l6Q+p9+q05+p1Q+X4),"msg-label":"DTE_Label_Info","msg-error":(V05+N8Q+X2O+F1Q+i5Q+c3O+y6x+b7),"msg-message":(o8O+W4O+B8O+Z1O+b5Q+c3O+U7O+L05+P2Q),"msg-info":(o8O+p6O+N8Q+t7x+b5Q+c3O+q6O+o6v.G4Q+H3),"multiValue":(K5Q+H05+Z7x+I2x+M35+T2Q+D7O),"multiInfo":(K5Q+H05+v2O+F1Q+I2x+F1Q+o6v.G4Q+o6v.Y7Q+o6v.l4Q),"multiRestore":"multi-restore","multiNoEdit":"multi-noEdit","disabled":"disabled"}
,"actions":{"create":(s35+N4+o3O+H2Q+u2x+o6v.l4Q+o6v.G4Q+N8Q+u35+z2Q+y3x),"edit":"DTE_Action_Edit","remove":"DTE_Action_Remove"}
,"inline":{"wrapper":(o8O+W4O+B8O+a9+o8O+Y65+q6O+o6v.G4Q+b5Q+X2),"liner":"DTE_Inline_Field","buttons":(V05+N8Q+c0x+b5Q+D7Q+o6v.B6Q+z8+A4O+q05+o6v.l4Q+o6v.G4Q+Y05)}
,"bubble":{"wrapper":"DTE DTE_Bubble","liner":(o8O+I3Q+H05+m2Q+H2+o6v.B6Q+p0Q+o6v.G4Q+o6v.B6Q+o6v.B9Q),"table":"DTE_Bubble_Table","close":"icon close","pointer":"DTE_Bubble_Triangle","bg":(s35+B8O+N8Q+R0Q+f0Q+i25+z5+o6v.B9Q+o6v.l4Q+H05+o6v.G4Q+o6v.l6Q)}
}
;(function(){var Q9Q="removeSingle",L5="ngle",w1O="Si",o6x='ngle',w1Q='dSi',E05="xten",D8x="editSingle",x9="ditS",m5='em',M25="formTitle",t9x="bmit",y7O="firm",b3x="8n",n8x="i1",P5O="editor_remove",N6="bel",C7="formButtons",U1x="fnGetSelectedIndexes",z7Q="select_single",y25="editor_edit",d0Q="editor",F2x="editor_create",i6x="UTTONS";if(DataTable[t15]){var ttButtons=DataTable[t15][(R3O+i6x)],ttButtonBase={sButtonText:null,editor:null,formTitle:null}
;ttButtons[F2x]=$[(o6v.B6Q+v6x+o6v.B6Q+x05)](true,ttButtons[(y3x+v6x)],ttButtonBase,{formButtons:[{label:null,fn:function(e){this[(G3x)]();}
}
],fnClick:function(button,config){var editor=config[d0Q],i18nCreate=editor[(F1Q+R4+o6v.G4Q)][b9Q],buttons=config[(f5O+K5Q+R3O+A4O+q05+o6v.l4Q+s75)];if(!buttons[0][(b5Q+T2Q+m2Q+i5Q)]){buttons[0][(F1x+m2Q+i5Q)]=i18nCreate[G3x];}
editor[(H2Q+o6v.B9Q+z2Q+q05+o6v.B6Q)]({title:i18nCreate[(O7x)],buttons:buttons}
);}
}
);ttButtons[y25]=$[d8O](true,ttButtons[z7Q],ttButtonBase,{formButtons:[{label:null,fn:function(e){this[G3x]();}
}
],fnClick:function(button,config){var selected=this[U1x]();if(selected.length!==1){return ;}
var editor=config[d0Q],i18nEdit=editor[(J3)][(G7Q+P5Q)],buttons=config[C7];if(!buttons[0][q9O]){buttons[0][(b5Q+T2Q+N6)]=i18nEdit[G3x];}
editor[(G7Q+F1Q+q05)](selected[0],{title:i18nEdit[O7x],buttons:buttons}
);}
}
);ttButtons[P5O]=$[d8O](true,ttButtons[a2],ttButtonBase,{question:null,formButtons:[{label:null,fn:function(e){var that=this;this[G3x](function(json){var g3="fnSelectNone",V6="GetI",Q65="ools",tt=$[C3][o6v.Y4][(O2Q+H2+o6v.B6Q+W4O+Q65)][(C3+V6+s75+q05+T2Q+o6v.G4Q+v8x)]($(that[Y05][s25])[(o8O+T2Q+q05+T2Q+W4O+n1Q+U5x)]()[(L0x+m2Q+U5x)]()[(o6v.G4Q+o6v.l4Q+V2O)]());tt[g3]();}
);}
}
],fnClick:function(button,config){var a3O="titl",w7Q="con",D3Q='tri',V5O="nfi",L2x="But",rows=this[U1x]();if(rows.length===0){return ;}
var editor=config[(o6v.B6Q+o6v.l6Q+P5Q+X4)],i18nRemove=editor[(n8x+b3x)][k8],buttons=config[(o6v.Y7Q+o6v.l4Q+o6v.B9Q+K5Q+L2x+q05+o6v.l4Q+o6v.G4Q+Y05)],question=typeof i18nRemove[(k7x+V5O+o6v.B9Q+K5Q)]===(s0+D3Q+i15+b65)?i18nRemove[(w7Q+o6v.Y7Q+s1Q+K5Q)]:i18nRemove[r3][rows.length]?i18nRemove[(H2Q+f5+y7O)][rows.length]:i18nRemove[(K2x+s1Q+K5Q)][N8Q];if(!buttons[0][(b5Q+T2Q+m2Q+o6v.B6Q+b5Q)]){buttons[0][(b5Q+T2Q+N6)]=i18nRemove[(i1+t9x)];}
editor[(o6v.B9Q+r4Q+M35+o6v.B6Q)](rows,{message:question[L6x](/%d/g,rows.length),title:i18nRemove[(a3O+o6v.B6Q)],buttons:buttons}
);}
}
);}
var _buttons=DataTable[x8Q][e6];$[(o6v.B6Q+o6v.t85+q25)](_buttons,{create:{text:function(dt,node,config){var F9O="utton";return dt[J3]('buttons.create',config[(G7Q+F1Q+q7x+o6v.B9Q)][(F1Q+o2x)][(n1x+o6v.B6Q+d65+o6v.B6Q)][(m2Q+F9O)]);}
,className:'buttons-create',editor:null,formButtons:{label:function(editor){return editor[(F1Q+o2x)][b9Q][G3x];}
,fn:function(e){this[(R3Q+C0Q+q05)]();}
}
,formMessage:null,formTitle:null,action:function(e,dt,node,config){var D8="Messa",editor=config[(k3O+X4)],buttons=config[(z65+R0Q+q05+q7x+s75)];editor[b9Q]({buttons:config[(H3+o6v.B9Q+K5Q+R0Q+q05+q05+f5+Y05)],message:config[(z65+D8+k9)],title:config[M25]||editor[J3][(H2Q+e5Q+d65+o6v.B6Q)][(q05+F1Q+t6x+o6v.B6Q)]}
);}
}
,edit:{extend:'selected',text:function(dt,node,config){return dt[(F1Q+b7x+b3x)]((h6O+o6v.R0+o6v.R0+p4x+R8O+c25+o25+Y5),config[(G7Q+P5Q+o6v.l4Q+o6v.B9Q)][(F1Q+o2x)][(o6v.B6Q+F25)][H85]);}
,className:(h6O+b7Q+p4x+l8O+c25+G0),editor:null,formButtons:{label:function(editor){return editor[(F1Q+o2x)][(G7Q+F1Q+q05)][G3x];}
,fn:function(e){this[(i1+t9x)]();}
}
,formMessage:null,formTitle:null,action:function(e,dt,node,config){var V85="rmMes",C3O="cell",a8Q="colu",editor=config[d0Q],rows=dt[(o6v.B9Q+J9+Y05)]({selected:true}
)[x1](),columns=dt[(a8Q+K5Q+o6v.G4Q+Y05)]({selected:true}
)[(r8+B6x+Y05)](),cells=dt[(C3O+Y05)]({selected:true}
)[x1](),items=columns.length||cells.length?{rows:rows,columns:columns,cells:cells}
:rows;editor[(o6v.B6Q+F25)](items,{message:config[(o6v.Y7Q+o6v.l4Q+V85+Y05+H0x)],buttons:config[C7],title:config[M25]||editor[(n8x+F4x+o6v.G4Q)][(H25+q05)][(q05+F1Q+t6x+o6v.B6Q)]}
);}
}
,remove:{extend:'selected',text:function(dt,node,config){return dt[(n8x+b3x)]('buttons.remove',config[(o6v.B6Q+F25+o6v.l4Q+o6v.B9Q)][J3][(e5Q+P6O+o6v.B6Q)][(m2Q+A4O+q7x+o6v.G4Q)]);}
,className:(P85+B15+o6v.R0+R15+i15+s0+l8O+d0+m5+L5O+c25),editor:null,formButtons:{label:function(editor){return editor[(F1Q+b7x+F4x+o6v.G4Q)][k8][(Y05+H05+t9x)];}
,fn:function(e){this[G3x]();}
}
,formMessage:function(editor,dt){var o3="onfir",rows=dt[(G5+Y05)]({selected:true}
)[x1](),i18n=editor[(F1Q+b7x+b3x)][k8],question=typeof i18n[r3]==='string'?i18n[(H2Q+f5+p0+v35)]:i18n[(H2Q+f5+y7O)][rows.length]?i18n[(H2Q+o3+K5Q)][rows.length]:i18n[r3][N8Q];return question[L6x](/%d/g,rows.length);}
,formTitle:null,action:function(e,dt,node,config){var h3="mMes",I4O="ormB",editor=config[d0Q];editor[(C1Q+q6Q)](dt[(o6v.B9Q+o6v.l4Q+d2)]({selected:true}
)[x1](),{buttons:config[(o6v.Y7Q+I4O+H05+l3x+Y05)],message:config[(o6v.Y7Q+X4+h3+Y05+H0x)],title:config[(z65+W4O+F1Q+t6x+o6v.B6Q)]||editor[(n8x+F4x+o6v.G4Q)][(o6v.B9Q+o6v.B6Q+K5Q+s9+o6v.B6Q)][O7x]}
);}
}
}
);_buttons[(o6v.B6Q+x9+F1Q+o6v.G4Q+W7Q+b5Q+o6v.B6Q)]=$[d8O]({}
,_buttons[k3O]);_buttons[D8x][(o6v.B6Q+E05+o6v.l6Q)]=(T4x+k5x+o6v.R0+c25+w1Q+o6x);_buttons[(C1Q+M35+o6v.B6Q+w1O+L5)]=$[(o6v.B6Q+E1O+x05)]({}
,_buttons[k8]);_buttons[Q9Q][d8O]='selectedSingle';}
());Editor[n6Q]={}
;Editor[(o8O+c2O+V9O)]=function(input,opts){var Q0Q="calendar",z7O="_instance",x2='rror',K4Q='econ',f8Q='bel',E4O="previous",n65="sed",m65="YYY",Z5x="nly",W2x="tj",y7=": ",d9='YY';this[H2Q]=$[(o6v.B6Q+o6v.t85+q05+R9)](true,{}
,Editor[(y4x+W4O+F1Q+V9O)][(w4O+T2Q+H05+s0Q)],opts);var classPrefix=this[H2Q][F7O],i18n=this[H2Q][J3];if(!window[(m8Q+V9O+o6v.O75)]&&this[H2Q][h65]!==(d9+d9+l8O+V6Q+V6Q+l8O+v3Q+v3Q)){throw (B8O+o6v.l6Q+F1Q+q05+o6v.l4Q+o6v.B9Q+a9+o6v.l6Q+d65+o6v.B6Q+u2x+K5Q+o6v.B6Q+y7+i9O+P5Q+E7Q+k2Q+a9+K5Q+o6v.l4Q+V9O+o6v.G4Q+W2x+Y05+a9+o6v.l4Q+Z5x+a9+q05+e0O+a9+o6v.Y7Q+o6v.l4Q+v35+T2Q+q05+m2+F0Q+m65+I2x+U7O+U7O+I2x+o8O+o8O+A3Q+H2Q+T2Q+o6v.G4Q+a9+m2Q+o6v.B6Q+a9+H05+n65);}
var timeBlock=function(type){var N15='nD',C05="previou";return '<div class="'+classPrefix+(l8O+o6v.R0+v75+u15+c25+x5x+v25+P75+W6)+(Q4O+o25+H5+J5x+v25+y75+Y85+s0+s0+i9)+classPrefix+(l8O+v75+v25+C6O+s0O+W6)+'<button>'+i18n[(C05+Y05)]+(B2+P85+u3+E4x+r4O)+'</div>'+'<div class="'+classPrefix+(l8O+y75+Y85+P85+c25+y75+W6)+(Q4O+s0+L3Q+i15+q1)+(Q4O+s0+c25+y75+c25+H7Q+J5x+v25+f6Q+s0+s0+i9)+classPrefix+'-'+type+(z4)+(B2+o25+H5+r4O)+(Q4O+o25+H5+J5x+v25+y75+Y85+x2O+i9)+classPrefix+(l8O+v75+n2Q+N15+R15+B3+i15+W6)+(Q4O+P85+u3+E4x+r4O)+i18n[(G35+o6v.t85+q05)]+'</button>'+(B2+o25+H5+r4O)+(B2+o25+H5+r4O);}
,gap=function(){return '<span>:</span>';}
,structure=$((Q4O+o25+v75+P3+J5x+v25+y75+i8x+s0+i9)+classPrefix+'">'+(Q4O+o25+v75+P3+J5x+v25+r6O+i9)+classPrefix+(l8O+o25+Y85+I9O+W6)+(Q4O+o25+H5+J5x+v25+y75+i8x+s0+i9)+classPrefix+'-title">'+'<div class="'+classPrefix+'-iconLeft">'+'<button>'+i18n[E4O]+(B2+P85+B15+W75+r4O)+(B2+o25+v75+P3+r4O)+'<div class="'+classPrefix+'-iconRight">'+(Q4O+P85+u3+b7Q+C6O+r4O)+i18n[(G35+o6v.t85+q05)]+(B2+P85+B15+o6v.R0+R15+i15+r4O)+(B2+o25+v75+P3+r4O)+'<div class="'+classPrefix+(l8O+y75+B0Q+y75+W6)+(Q4O+s0+D+Y85+i15+q1)+'<select class="'+classPrefix+'-month"/>'+(B2+o25+v75+P3+r4O)+'<div class="'+classPrefix+(l8O+y75+Y85+f8Q+W6)+'<span/>'+(Q4O+s0+c25+k5x+o6v.R0+J5x+v25+y75+i8x+s0+i9)+classPrefix+'-year"/>'+'</div>'+'</div>'+(Q4O+o25+v75+P3+J5x+v25+T8x+s0+i9)+classPrefix+'-calendar"/>'+(B2+o25+v75+P3+r4O)+(Q4O+o25+H5+J5x+v25+y75+L2O+i9)+classPrefix+'-time">'+timeBlock((c65+R15+p15+s0))+gap()+timeBlock('minutes')+gap()+timeBlock((s0+K4Q+o25+s0))+timeBlock('ampm')+'</div>'+'<div class="'+classPrefix+(l8O+c25+d0+d0+e7O+z4)+(B2+o25+H5+r4O));this[(o6v.l6Q+A1)]={container:structure,date:structure[O1O]('.'+classPrefix+'-date'),title:structure[(O1O)]('.'+classPrefix+(l8O+o6v.R0+v75+o6v.R0+h7Q)),calendar:structure[(p0+x05)]('.'+classPrefix+'-calendar'),time:structure[(o6v.Y7Q+F1Q+x05)]('.'+classPrefix+'-time'),error:structure[(f4x+o6v.l6Q)]('.'+classPrefix+(l8O+c25+x2)),input:$(input)}
;this[Y05]={d:null,display:null,namespace:'editor-dateime-'+(Editor[(l15+y3x+W4O+F1Q+V9O)][z7O]++),parts:{date:this[H2Q][(H3+v35+T2Q+q05)][(K5Q+T2Q+q05+H2Q+E7Q)](/[YMD]|L(?!T)|l/)!==null,time:this[H2Q][h65][(R5O+R0x+E7Q)](/[Hhm]|LT|LTS/)!==null,seconds:this[H2Q][h65][Z9x]('s')!==-1,hours12:this[H2Q][(o6v.Y7Q+X4+K5Q+d65)][(E2Q)](/[haA]/)!==null}
}
;this[(Q5O+K5Q)][(H2Q+o6v.l4Q+o6v.G4Q+L0x+D7Q+o6v.B6Q+o6v.B9Q)][(l85+j0)](this[Q0][(r8x)])[(l85+o6v.v9Q+X4Q+o6v.l6Q)](this[Q0][(g1Q)])[(z6x)](this[(Q0)].error);this[Q0][(o6v.l6Q+T2Q+y3x)][z6x](this[Q0][O7x])[(T2Q+o6v.v9Q+C6x+x05)](this[Q0][Q0Q]);this[v9]();}
;$[(o6v.B6Q+o6v.t85+y3x+o6v.G4Q+o6v.l6Q)](Editor.DateTime.prototype,{destroy:function(){var U6x="_hid";this[(U6x+o6v.B6Q)]();this[Q0][(H2Q+N9Q+K1Q+o6v.B6Q+o6v.B9Q)][(Z05)]().empty();this[Q0][R][(Z05)]('.editor-datetime');}
,errorMsg:function(msg){var error=this[(o6v.l6Q+A1)].error;if(msg){error[(E7Q+V1)](msg);}
else{error.empty();}
}
,hide:function(){this[(N8Q+E7Q+f15)]();}
,max:function(date){var I3O="Calan";this[H2Q][K0Q]=date;this[(h25+q05+F1Q+c4Q+d8x+b5Q+o6v.B6Q)]();this[(N8Q+D3+q05+I3O+V2O+o6v.B9Q)]();}
,min:function(date){var r6x="nsTitle",m4O="nD";this[H2Q][(K5Q+F1Q+m4O+d2x)]=date;this[(N8Q+o6v.l4Q+z+r6x)]();this[(N8Q+Y05+o6v.B6Q+q05+p8O+T2Q+b5Q+x35+V2O+o6v.B9Q)]();}
,owns:function(node){var a2x="lte";return $(node)[(D2x+o6v.B9Q+o6v.B6Q+o6v.G4Q+o6v.r1x)]()[(o6v.Y7Q+F1Q+a2x+o6v.B9Q)](this[Q0][W85]).length>0;}
,val:function(set,write){var N35="ande",f7O="UTCD",g75="oS",x3x="disp",U0O="toDate",b5x="isV",l7Q="utc",Y2O="oment",o5x="moment";if(set===undefined){return this[Y05][o6v.l6Q];}
if(set instanceof Date){this[Y05][o6v.l6Q]=this[C35](set);}
else if(set===null||set===''){this[Y05][o6v.l6Q]=null;}
else if(typeof set==='string'){if(window[o5x]){var m=window[(K5Q+Y2O)][l7Q](set,this[H2Q][h65],this[H2Q][L1],this[H2Q][(m8Q+K5Q+Y6+G4O+K3+H2Q+q05)]);this[Y05][o6v.l6Q]=m[(b5x+T2Q+b5Q+F1Q+o6v.l6Q)]()?m[U0O]():null;}
else{var match=set[(R5O+q05+Z2x)](/(\d{4})\-(\d{2})\-(\d{2})/);this[Y05][o6v.l6Q]=match?new Date(Date[(H4O+J8O)](match[1],match[2]-1,match[3])):null;}
}
if(write||write===undefined){if(this[Y05][o6v.l6Q]){this[L25]();}
else{this[(o6v.l6Q+A1)][R][(M35+I05)](set);}
}
if(!this[Y05][o6v.l6Q]){this[Y05][o6v.l6Q]=this[C35](new Date());}
this[Y05][(x3x+F1x+a85)]=new Date(this[Y05][o6v.l6Q][(q05+g75+q05+o6v.B9Q+G6)]());this[Y05][(v7O+Y05+o6v.v9Q+b5Q+z75)][(Y05+o6v.B6Q+q05+f7O+T2Q+q05+o6v.B6Q)](1);this[A1x]();this[(x0O+o6v.B6Q+q05+p8O+T2Q+b5Q+N35+o6v.B9Q)]();this[(N8Q+q4Q+W4O+F1Q+K5Q+o6v.B6Q)]();}
,_constructor:function(){var R8x="parts",h5x="_setCalander",E5='ito',W65='yu',o6O='ke',W3x='atet',W1Q='focu',Z3O="mP",R4x="_o",Y15="secondsIncrement",g8="minutesIncrement",G25="sT",E4="_opti",I6="s12",e15="part",M1='ours',V15="_optionsTime",y1O='ebl',E6='im',H0O='ime',B9='et',N0x="ildren",H65="urs12",e8O="ren",g6="hild",S2O="remov",p85="seco",n9="tim",x5Q="nge",h6x="nCha",R9x="Pre",that=this,classPrefix=this[H2Q][(H2Q+F1x+Y05+Y05+R9x+o6v.Y7Q+S9Q)],container=this[(o6v.l6Q+o6v.l4Q+K5Q)][(H2Q+f5+h2Q+U9Q)],i18n=this[H2Q][J3],onChange=this[H2Q][(o6v.l4Q+h6x+x5Q)];if(!this[Y05][(o6v.v9Q+x25+o6v.r1x)][(d1Q+o6v.B6Q)]){this[(o6v.l6Q+A1)][(d1Q+o6v.B6Q)][v15]('display',(G2x+i15+c25));}
if(!this[Y05][(o6v.v9Q+x25+q05+Y05)][(n9+o6v.B6Q)]){this[Q0][(n9+o6v.B6Q)][v15]('display','none');}
if(!this[Y05][(o6v.v9Q+T2Q+o6v.B9Q+o6v.r1x)][(p85+x05+Y05)]){this[(Q5O+K5Q)][g1Q][(H2Q+E7Q+F1Q+s5x+e5Q+o6v.G4Q)]('div.editor-datetime-timeblock')[n9Q](2)[(S2O+o6v.B6Q)]();this[Q0][(u2x+K5Q+o6v.B6Q)][(H2Q+g6+e8O)]('span')[n9Q](1)[(o6v.B9Q+r4Q+M35+o6v.B6Q)]();}
if(!this[Y05][(D2x+o6v.B9Q+o6v.r1x)][(E7Q+o6v.l4Q+H65)]){this[Q0][g1Q][(Z2x+N0x)]((T25+P3+R8O+c25+o25+v75+N2Q+d0+l8O+o25+Y85+o6v.R0+B9+H0O+l8O+o6v.R0+E6+y1O+R15+F8Q))[(b5Q+T2Q+Y05+q05)]()[k8]();}
this[(N8Q+o6v.l4Q+O9x+F1Q+f5+Y05+d8x+b5Q+o6v.B6Q)]();this[V15]((c65+M1),this[Y05][(e15+Y05)][(Y6O+H05+o6v.B9Q+I6)]?12:24,1);this[(E4+f5+G25+F1Q+K5Q+o6v.B6Q)]((u15+v75+i15+u3+I9O+s0),60,this[H2Q][g8]);this[V15]((s0+o6v.q6+R15+c9+s0),60,this[H2Q][Y15]);this[(R4x+O9x+F1Q+f5+Y05)]('ampm',[(Y85+u15),'pm'],i18n[(T2Q+Z3O+K5Q)]);this[Q0][R][(f5)]((W1Q+s0+R8O+c25+T25+o6v.R0+R15+d0+l8O+o25+E8x+c25+o6v.R0+v75+L+J5x+v25+y75+V3+P75+R8O+c25+o25+Y5+R15+d0+l8O+o25+W3x+v75+L),function(){var n1O="_show",j2Q='abl';if(that[(Q0)][(k7x+o6v.O75+K1Q+o6v.B6Q+o6v.B9Q)][(Y5Q)](':visible')||that[Q0][R][Y5Q]((M5O+o25+v75+s0+j2Q+c25+o25))){return ;}
that[(M35+I05)](that[Q0][R][L85](),false);that[n1O]();}
)[f5]((o6O+W65+D+R8O+c25+o25+E5+d0+l8O+o25+E8x+B9+v75+u15+c25),function(){var G0x='sib';if(that[(o6v.l6Q+A1)][(H2Q+o6v.l4Q+o6v.G4Q+L0x+X2+o6v.B9Q)][Y5Q]((M5O+P3+v75+G0x+h7Q))){that[(M35+T2Q+b5Q)](that[(Q5O+K5Q)][(F1Q+o6v.G4Q+l0O+q05)][(M35+I05)](),false);}
}
);this[Q0][(H2Q+o6v.l4Q+o6v.O75+K9Q+o6v.G4Q+o6v.B6Q+o6v.B9Q)][(o6v.l4Q+o6v.G4Q)]('change','select',function(){var o7Q="sit",Q1="_po",G7="wri",d3x="etS",e7x="_setTime",V3x="tUTCMin",e6O='nut',O1="tTim",l0Q="urs",n5="TCHo",m35="CHo",F1="tU",S3='mpm',A9O="s1",W4x="hou",P8x="Cla",L7O="ander",v6Q="setT",W9O="sCla",Z2O="Month",J0Q='th',select=$(this),val=select[L85]();if(select[O0Q](classPrefix+(l8O+u15+R15+i15+J0Q))){that[(r2x+o6v.l4Q+o6v.B9Q+e5Q+H2Q+q05+Z2O)](that[Y05][a15],val);that[A1x]();that[h5x]();}
else if(select[(E7Q+T2Q+W9O+S1)](classPrefix+'-year')){that[Y05][a15][(D3+q05+b35+j7O+b5Q+b5Q+F0Q+o6v.B6Q+T2Q+o6v.B9Q)](val);that[(N8Q+v6Q+P5Q+b5Q+o6v.B6Q)]();that[(x0O+o6v.B6Q+A+T2Q+b5Q+L7O)]();}
else if(select[O0Q](classPrefix+(l8O+c65+Y9Q+s0))||select[(E7Q+w65+P8x+Y05+Y05)](classPrefix+'-ampm')){if(that[Y05][R8x][(W4x+o6v.B9Q+A9O+K7x)]){var hours=$(that[(Q0)][W85])[(o6v.Y7Q+F1Q+x05)]('.'+classPrefix+(l8O+c65+R15+u3+d0+s0))[L85]()*1,pm=$(that[Q0][(k7x+k6+o6v.B6Q+o6v.B9Q)])[(o6v.Y7Q+F1Q+x05)]('.'+classPrefix+(l8O+Y85+S3))[(M35+I05)]()===(D+u15);that[Y05][o6v.l6Q][(Y05+o6v.B6Q+F1+W4O+m35+H05+Z25)](hours===12&&!pm?0:pm&&hours!==12?hours+12:hours);}
else{that[Y05][o6v.l6Q][(D3+q05+H4O+n5+l0Q)](val);}
that[(x0O+o6v.B6Q+O1+o6v.B6Q)]();that[L25](true);onChange();}
else if(select[(W9x+Y05+p8O+F1x+S1)](classPrefix+(l8O+u15+v75+e6O+c25+s0))){that[Y05][o6v.l6Q][(D3+V3x+H05+q05+o6v.B6Q+Y05)](val);that[e7x]();that[L25](true);onChange();}
else if(select[O0Q](classPrefix+(l8O+s0+o6v.q6+R15+c9+s0))){that[Y05][o6v.l6Q][(Y05+d3x+m6Q+o6v.l4Q+o6v.G4Q+o6v.l6Q+Y05)](val);that[e7x]();that[(N8Q+G7+y3x+x1O+H05+q05+o6v.v9Q+H05+q05)](true);onChange();}
that[Q0][(F1Q+B65+H05+q05)][(o6v.Y7Q+o6v.l4Q+l4x+Y05)]();that[(Q1+o7Q+n7Q+o6v.G4Q)]();}
)[(f5)]((B4Q+P75),function(e){var Q6O="_se",B7x="tp",O8Q="Ou",S6Q="rit",w8O="_w",J0x="setUTCFullYear",H6="Ut",n15="change",T0O='Do',s2x="edInde",l7="elect",F="selectedIndex",j3Q="edI",I4='sele',I3="play",U1="ctMont",c7="_cor",I3x='nRi',D1Q="sC",V9x="setCa",c4O="tUTCM",r1O='eft',x6='con',N6x="asCla",W5O="gat",N2x="toLowerCase",O1Q="nodeName",S6="arge",nodeName=e[(q05+S6+q05)][O1Q][N2x]();if(nodeName==='select'){return ;}
e[(Y05+q05+C5+g3x+D2x+W5O+F1Q+o6v.l4Q+o6v.G4Q)]();if(nodeName===(P85+B15+o6v.R0+C6O)){var button=$(e[v4x]),parent=button.parent(),select;if(parent[O0Q]((T25+s0+X85+o25))){return ;}
if(parent[(E7Q+N6x+S1)](classPrefix+(l8O+v75+x6+r2Q+r1O))){that[Y05][(K85+o6v.v9Q+F1x+a85)][B3Q](that[Y05][a15][(k9+c4O+N9Q+E7Q)]()-1);that[A1x]();that[(N8Q+V9x+F1x+r2+o6v.B9Q)]();that[(Q5O+K5Q)][R][(o6v.Y7Q+o6v.l4Q+v0O)]();}
else if(parent[(E7Q+T2Q+D1Q+F1x+Y05+Y05)](classPrefix+(l8O+v75+n2Q+I3x+b65+c65+o6v.R0))){that[(c7+o6v.B9Q+o6v.B6Q+U1+E7Q)](that[Y05][(o6v.l6Q+Y5Q+I3)],that[Y05][(v7O+Y05+P5x+z75)][t1O]()+1);that[A1x]();that[h5x]();that[(o6v.l6Q+A1)][(D7Q+E6Q)][(H3+l4x+Y05)]();}
else if(parent[O0Q](classPrefix+(l8O+v75+x6+s0O))){select=parent.parent()[O1O]((I4+v25+o6v.R0))[0];select[(N7Q+h2O+j3Q+x05+B85)]=select[F]!==select[k9x].length-1?select[(Y05+l7+s2x+o6v.t85)]+1:0;$(select)[(H2Q+W9x+H35+o6v.B6Q)]();}
else if(parent[O0Q](classPrefix+(l8O+v75+n2Q+i15+T0O+B4x))){select=parent.parent()[(O1O)]((s0+c25+Z9Q))[0];select[F]=select[F]===0?select[(o6v.l4Q+o6v.v9Q+q05+d9O+Y05)].length-1:select[F]-1;$(select)[n15]();}
else{if(!that[Y05][o6v.l6Q]){that[Y05][o6v.l6Q]=that[(N8Q+o6v.l6Q+T2Q+q05+e4O+o6v.l4Q+H6+H2Q)](new Date());}
that[Y05][o6v.l6Q][(D3+q05+H4O+J8O+y4x)](1);that[Y05][o6v.l6Q][J0x](button.data((a8+c2+d0)));that[Y05][o6v.l6Q][B3Q](button.data('month'));that[Y05][o6v.l6Q][L8O](button.data('day'));that[(w8O+S6Q+o6v.B6Q+O8Q+B7x+A4O)](true);if(!that[Y05][R8x][g1Q]){setTimeout(function(){that[(A7x+y3Q+o6v.B6Q)]();}
,10);}
else{that[(Q6O+q05+p7Q+b5Q+T2Q+x05+U9Q)]();}
onChange();}
}
else{that[(o6v.l6Q+A1)][(F1Q+B65+A4O)][(H3+H2Q+H05+Y05)]();}
}
);}
,_compareDates:function(a,b){var X9="eTo",x9O="St",U75="oU";return this[(N8Q+d1Q+e4O+U75+R0x+x9O+o6v.B9Q+F1Q+o6v.G4Q+W7Q)](a)===this[(V6x+T2Q+q05+X9+H4O+R0x+x9O+o6v.B9Q+F1Q+o6v.G4Q+W7Q)](b);}
,_correctMonth:function(date,month){var i0O="onth",v4O="UTCM",T4="ull",s2Q="etUTC",P9x="_daysInMonth",days=this[P9x](date[(W7Q+s2Q+X2O+T4+o65+T2Q+o6v.B9Q)](),month),correctDays=date[(W7Q+F3+p8O+o8O+T2Q+y3x)]()>days;date[(Y05+c05+v4O+i0O)](month);if(correctDays){date[L8O](days);date[B3Q](month);}
}
,_daysInMonth:function(year,month){var isLeap=((year%4)===0&&((year%100)!==0||(year%400)===0)),months=[31,(isLeap?29:28),31,30,31,30,31,31,30,31,30,31];return months[month];}
,_dateToUtc:function(s){var J="getSeconds",D0O="inu",V75="getHo",X15="getDate",e2="getMonth";return new Date(Date[X3x](s[y0x](),s[e2](),s[X15](),s[(V75+t4O+Y05)](),s[(W7Q+c05+U7O+D0O+y3x+Y05)](),s[J]()));}
,_dateToUtcString:function(d){var F4="getUTCD",J6Q="UTCFul";return d[(W7Q+o6v.B6Q+q05+J6Q+b5Q+o65+x25)]()+'-'+this[J0](d[t1O]()+1)+'-'+this[J0](d[(F4+d2x)]());}
,_hide:function(){var O2O='ol',W25='scr',i7='ody_C',namespace=this[Y05][(L2Q+L05+o6v.v9Q+D5Q+o6v.B6Q)];this[Q0][(H2Q+f5+h2Q+U9Q)][q2O]();$(window)[(o6v.l4Q+o6v.Y7Q+o6v.Y7Q)]('.'+namespace);$(document)[(Z05)]('keydown.'+namespace);$((o25+H5+R8O+v3Q+E1Q+o3Q+g35+u0Q+i7+R15+i15+o6v.R0+c25+i15+o6v.R0))[Z05]((W25+O2O+y75+R8O)+namespace);$((o5))[Z05]((P8Q+v75+F8Q+R8O)+namespace);}
,_hours24To12:function(val){return val===0?12:val>12?val-12:val;}
,_htmlDay:function(day){var W0Q="month",J3x="year",E9O='ear',e85='yp',n7="oi",S4Q="day",X1Q="selected",e25="Pr";if(day.empty){return '<td class="empty"></td>';}
var classes=[(o25+I6x)],classPrefix=this[H2Q][(b6x+w65+Y05+e25+o6v.B6Q+o6v.Y7Q+S9Q)];if(day[u4Q]){classes[(o6v.v9Q+s4O+E7Q)]((o25+K1O+A0O+r6));}
if(day[(q05+o6v.l4Q+o6v.l6Q+z75)]){classes[(l0O+Y05+E7Q)]((o6v.R0+R15+o25+I6x));}
if(day[X1Q]){classes[C7O]('selected');}
return (Q4O+o6v.R0+o25+J5x+o25+u85+l8O+o25+I6x+i9)+day[(S4Q)]+'" class="'+classes[(q1Q+n7+o6v.G4Q)](' ')+(W6)+'<button class="'+classPrefix+(l8O+P85+u3+o6v.R0+o6v.R0+R15+i15+J5x)+classPrefix+(l8O+o25+I6x+B35+o6v.R0+e85+c25+i9+P85+u3+o6v.R0+N2Q+i15+B35)+(o25+Y85+J5O+l8O+a8+E9O+i9)+day[J3x]+'" data-month="'+day[W0Q]+(B35+o25+E8x+Y85+l8O+o25+I6x+i9)+day[S4Q]+'">'+day[S4Q]+(B2+P85+u3+E4x+r4O)+(B2+o6v.R0+o25+r4O);}
,_htmlMonth:function(year,month){var o7x="_htmlMonthHead",C7Q="mber",c3="Wee",z3="_ht",M4x="ber",j3O="Nu",U4x="_htmlDay",o5Q='unction',O4x="tUTCD",Z3Q="Arra",e1O="bleDa",c4="_compareDates",z8x="Dates",i9Q="are",d4="Sec",v6O="H",f2="tSeco",E1="setUTCMinutes",Y3Q="Hou",j6Q="setU",x65="minDate",o0O="tDa",k6O="firs",O4Q="firstDay",h5O="getUTCDay",p5Q="aysInM",now=this[C35](new Date()),days=this[(N8Q+o6v.l6Q+p5Q+f5+q05+E7Q)](year,month),before=new Date(Date[(H4O+J8O)](year,month,1))[h5O](),data=[],row=[];if(this[H2Q][O4Q]>0){before-=this[H2Q][(k6O+o0O+a85)];if(before<0){before+=7;}
}
var cells=days+before,after=cells;while(after>7){after-=7;}
cells+=7-after;var minDate=this[H2Q][x65],maxDate=this[H2Q][(K0Q)];if(minDate){minDate[(j6Q+J8O+Y3Q+o6v.B9Q+Y05)](0);minDate[E1](0);minDate[(Y05+o6v.B6Q+f2+y0O)](0);}
if(maxDate){maxDate[(Y05+c05+H4O+J8O+v6O+L9+o6v.B9Q+Y05)](23);maxDate[(Y05+c05+X3x+c1+o6v.G4Q+A4O+L05)](59);maxDate[(Y05+c05+d4+f5+o6v.l6Q+Y05)](59);}
for(var i=0,r=0;i<cells;i++){var day=new Date(Date[(b35+p8O)](year,month,1+(i-before))),selected=this[Y05][o6v.l6Q]?this[(r2x+o6v.l4Q+w2Q+i9Q+z8x)](day,this[Y05][o6v.l6Q]):false,today=this[c4](day,now),empty=i<before||i>=(days+before),disabled=(minDate&&day<minDate)||(maxDate&&day>maxDate),disableDays=this[H2Q][(o6v.l6Q+F1Q+Y05+T2Q+e1O+a85+Y05)];if($[(Y5Q+q4x+F85)](disableDays)&&$[(D7Q+Z3Q+a85)](day[(W7Q+o6v.B6Q+O4x+T2Q+a85)](),disableDays)!==-1){disabled=true;}
else if(typeof disableDays===(Z65+o5Q)&&disableDays(day)===true){disabled=true;}
var dayConfig={day:1+(i-before),month:month,year:year,selected:selected,today:today,disabled:disabled,empty:empty}
;row[(C7O)](this[U4x](dayConfig));if(++r===7){if(this[H2Q][(u8+o6v.l4Q+K35+i9O+o6v.B6Q+o6v.B6Q+J1Q+j3O+K5Q+M4x)]){row[U5O](this[(z3+K5Q+b5Q+c3+J1Q+e5O+F0Q+H0)](i-before,month,year));}
data[(l0O+u8)]('<tr>'+row[(q1Q+o6v.l4Q+F1Q+o6v.G4Q)]('')+(B2+o6v.R0+d0+r4O));row=[];r=0;}
}
var className=this[H2Q][F7O]+'-table';if(this[H2Q][(u8+o6v.l4Q+K35+c3+J1Q+j3O+C7Q)]){className+=' weekNumber';}
return (Q4O+o6v.R0+Y85+A0O+c25+J5x+v25+y75+Y85+x2O+i9)+className+'">'+'<thead>'+this[o7x]()+'</thead>'+'<tbody>'+data[(o35+o6v.G4Q)]('')+'</tbody>'+(B2+o6v.R0+N1+h7Q+r4O);}
,_htmlMonthHead:function(){var L4O="mb",T7Q="ee",A75="owW",w5="Day",a=[],firstDay=this[H2Q][(o6v.Y7Q+F1Q+o6v.B9Q+Y05+q05+w5)],i18n=this[H2Q][(F1Q+R4+o6v.G4Q)],dayName=function(day){var U5="week";day+=firstDay;while(day>=7){day-=7;}
return i18n[(U5+f8O+a85+Y05)][day];}
;if(this[H2Q][(Y05+E7Q+A75+T7Q+J1Q+M1O+H05+L4O+U9Q)]){a[C7O]((Q4O+o6v.R0+c65+c7O+o6v.R0+c65+r4O));}
for(var i=0;i<7;i++){a[(o6v.v9Q+H05+u8)]((Q4O+o6v.R0+c65+r4O)+dayName(i)+'</th>');}
return a[G9Q]('');}
,_htmlWeekOfYear:function(d,m,y){var v3x='eek',q5Q="refix",k4Q="ssP",w5O="getDay",date=new Date(y,m,d,0,0,0,0);date[(q4Q+o8O+d65+o6v.B6Q)](date[(k9+M0+d2x)]()+4-(date[w5O]()||7));var oneJan=new Date(y,0,1),weekNum=Math[(H2Q+o6v.B6Q+F1Q+b5Q)]((((date-oneJan)/86400000)+1)/7);return (Q4O+o6v.R0+o25+J5x+v25+f6Q+x2O+i9)+this[H2Q][(H2Q+b5Q+T2Q+k4Q+q5Q)]+(l8O+B3+v3x+W6)+weekNum+'</td>';}
,_options:function(selector,values,labels){var b9='ptio',e3O="fix",R35="sP";if(!labels){labels=values;}
var select=this[(o6v.l6Q+A1)][W85][(p0+o6v.G4Q+o6v.l6Q)]('select.'+this[H2Q][(H2Q+b5Q+T2Q+Y05+R35+e5Q+e3O)]+'-'+selector);select.empty();for(var i=0,ien=values.length;i<ien;i++){select[(l85+j0)]((Q4O+R15+D+u3Q+R15+i15+J5x+P3+Y85+y75+u3+c25+i9)+values[i]+(W6)+labels[i]+(B2+R15+b9+i15+r4O));}
}
,_optionSet:function(selector,val){var n4O="unknown",D8O='sp',select=this[(o6v.l6Q+A1)][(H2Q+f5+q05+T2Q+F1Q+o6v.G4Q+o6v.B6Q+o6v.B9Q)][(p0+x05)]('select.'+this[H2Q][F7O]+'-'+selector),span=select.parent()[m0x]((D8O+Y85+i15));select[(M35+T2Q+b5Q)](val);var selected=select[O1O]('option:selected');span[(p1O+h3Q)](selected.length!==0?selected[(q05+o6v.B6Q+v6x)]():this[H2Q][J3][n4O]);}
,_optionsTime:function(select,count,inc){var j1='selec',K3x="ssPr",classPrefix=this[H2Q][(b6x+T2Q+K3x+o6v.B6Q+o6v.Y7Q+S9Q)],sel=this[(Q0)][W85][(o6v.Y7Q+F1Q+o6v.G4Q+o6v.l6Q)]((j1+o6v.R0+R8O)+classPrefix+'-'+select),start=0,end=count,render=count===12?function(i){return i;}
:this[(m9x+T2Q+o6v.l6Q)];if(count===12){start=1;end=13;}
for(var i=start;i<end;i+=inc){sel[(T2Q+o6v.v9Q+C6x+o6v.G4Q+o6v.l6Q)]('<option value="'+i+'">'+render(i)+'</option>');}
}
,_optionsTitle:function(year,month){var S0O="_r",P4x='year',K4x="_options",J8x="th",I2Q="mon",V3Q='onth',y9x="ye",L6Q="ullY",d3="tF",classPrefix=this[H2Q][F7O],i18n=this[H2Q][(J3)],min=this[H2Q][(K5Q+F1Q+o6v.G4Q+y4x)],max=this[H2Q][(z3x+o8O+T2Q+y3x)],minYear=min?min[y0x]():null,maxYear=max?max[y0x]():null,i=minYear!==null?minYear:new Date()[(k9+d3+L6Q+H0)]()-this[H2Q][(a85+z2Q+o6v.B9Q+C5O+x35+k9)],j=maxYear!==null?maxYear:new Date()[(W7Q+o6v.B6Q+d3+v1O+b5Q+o65+T2Q+o6v.B9Q)]()+this[H2Q][(y9x+T2Q+o6v.B9Q+C5O+T2Q+H35+o6v.B6Q)];this[(N8Q+O8x+F1Q+f5+Y05)]((u15+V3Q),this[(N8Q+o6v.B9Q+T2Q+o6v.G4Q+W7Q+o6v.B6Q)](0,11),i18n[(I2Q+J8x+Y05)]);this[K4x]((P4x),this[(S0O+x35+W7Q+o6v.B6Q)](i,j));}
,_pad:function(i){return i<10?'0'+i:i;}
,_position:function(){var J9Q="To",g0="sc",Y5x="dT",D2O="erHe",Y8Q="offse",offset=this[Q0][R][(Y8Q+q05)](),container=this[(Q0)][W85],inputHeight=this[(Q5O+K5Q)][R][(k2Q+D2O+F1Q+T8O)]();container[(v15)]({top:offset.top+inputHeight,left:offset[t5x]}
)[(l85+o6v.v9Q+X4Q+Y5x+o6v.l4Q)]('body');var calHeight=container[I9Q](),scrollTop=$((o5))[(g0+o6v.B9Q+w2x+J9Q+o6v.v9Q)]();if(offset.top+inputHeight+calHeight-scrollTop>$(window).height()){var newTop=offset.top-calHeight;container[v15]((N2Q+D),newTop<0?0:newTop);}
}
,_range:function(start,end){var a=[];for(var i=start;i<=end;i++){a[(o6v.v9Q+H05+Y05+E7Q)](i);}
return a;}
,_setCalander:function(){var H4="lM",p35="ndar";if(this[Y05][a15]){this[(o6v.l6Q+o6v.l4Q+K5Q)][(H2Q+I05+o6v.B6Q+p35)].empty()[(Z7O+o6v.G4Q+o6v.l6Q)](this[(N8Q+p1O+K5Q+H4+o6v.l4Q+x7)](this[Y05][(o6v.l6Q+C6+a85)][o7O](),this[Y05][(o6v.l6Q+a6x+b5Q+z75)][t1O]()));}
}
,_setTitle:function(){var F8x='ar',H5Q='ye',L4="Mo";this[d35]('month',this[Y05][a15][(W7Q+o6v.B6Q+q05+H4O+W4O+p8O+L4+x7)]());this[(h25+q05+d9O+G4O+c05)]((H5Q+F8x),this[Y05][a15][o7O]());}
,_setTime:function(){var d0O="nut",I0Q='tes',k3x='rs',C8O='hou',h9Q="_hours24To12",b3="par",q4="getUTCHours",d=this[Y05][o6v.l6Q],hours=d?d[q4]():0;if(this[Y05][(b3+q05+Y05)][(Y6O+t4O+Y05+b7x+K7x)]){this[d35]((c65+Y9Q+s0),this[h9Q](hours));this[d35]((g0x+D+u15),hours<12?'am':(B7Q));}
else{this[d35]((C8O+k3x),hours);}
this[d35]((u15+F7+u3+I0Q),d?d[(W7Q+c05+H4O+W4O+p8O+c1+d0O+L05)]():0);this[(N8Q+o6v.l4Q+O9x+n7Q+K2Q+c05)]((s0+c25+v25+R15+i15+k15),d?d[(k9+q05+V6O+H2Q+o6v.l4Q+y0O)]():0);}
,_show:function(){var z7x='croll',V4x='ont',f3O='TE_B',M3='ze',m0O="_position",that=this,namespace=this[Y05][(o6v.G4Q+X35+L05+D2x+v8x)];this[m0O]();$(window)[f5]('scroll.'+namespace+(J5x+d0+V9+v75+M3+R8O)+namespace,function(){that[m0O]();}
);$((o25+v75+P3+R8O+v3Q+f3O+R15+o25+a8+g35+i0Q+V4x+r5+o6v.R0))[(f5)]((s0+z7x+R8O)+namespace,function(){var O0x="tion",I65="posi";that[(N8Q+I65+O0x)]();}
);$(document)[(o6v.l4Q+o6v.G4Q)]('keydown.'+namespace,function(e){var N7="yCod",Q8="Cod";if(e[(J1Q+o6v.B6Q+a85+Q8+o6v.B6Q)]===9||e[(v5+N7+o6v.B6Q)]===27||e[Q15]===13){that[(N8Q+b15)]();}
}
);setTimeout(function(){$((G8O+o25+a8))[(o6v.l4Q+o6v.G4Q)]((P8Q+S7+R8O)+namespace,function(e){var I35="hid",I25="aine",parents=$(e[(v4x)])[n6x]();if(!parents[(W5x+q05+U9Q)](that[(Q5O+K5Q)][(H2Q+f5+q05+I25+o6v.B9Q)]).length&&e[v4x]!==that[Q0][R][0]){that[(N8Q+I35+o6v.B6Q)]();}
}
);}
,10);}
,_writeOutput:function(focus){var u5O="CM",U8x="lY",h1Q="forma",y4="momentStrict",l2Q="mom",date=this[Y05][o6v.l6Q],out=window[(K5Q+o6v.l4Q+V9O+o6v.G4Q+q05)]?window[(l2Q+X4Q+q05)][(A4O+H2Q)](date,undefined,this[H2Q][L1],this[H2Q][y4])[(h1Q+q05)](this[H2Q][h65]):date[(W7Q+F3+j7O+b5Q+U8x+o6v.B6Q+T2Q+o6v.B9Q)]()+'-'+this[(N8Q+o6v.v9Q+T2Q+o6v.l6Q)](date[(k9+q05+b35+u5O+f5+q05+E7Q)]()+1)+'-'+this[J0](date[(a6O+X3x+o8O+d2x)]());this[(Q0)][(R)][L85](out);if(focus){this[Q0][R][F35]();}
}
}
);Editor[X0][(n0x+Y1+V7+o6v.B6Q)]=0;Editor[(o8O+T2Q+y3x+x2x)][W1x]={classPrefix:'editor-datetime',disableDays:null,firstDay:1,format:(w9Q+w9Q+w9Q+w9Q+l8O+V6Q+V6Q+l8O+v3Q+v3Q),i18n:Editor[(V2O+o6v.Y7Q+N65+b5Q+o6v.r1x)][(F1Q+o2x)][(o6v.l6Q+T2Q+y3x+q05+F1Q+V9O)],maxDate:null,minDate:null,minutesIncrement:1,momentStrict:true,momentLocale:(r5),onChange:function(){}
,secondsIncrement:1,showWeekNumber:false,yearRange:10}
;(function(){var Y8O="dMany",K3O="_v",j5O="plo",R1="_pic",M2x="_picker",u05="ime",I15="cke",T3O="datepicker",C4O="ker",n8O='inp',A65='inpu',D4Q='pu',i6O="eI",O3x="radio",l6="ddOpt",D8Q='disabled',x0Q=' />',z8Q="eck",G75="separator",h4x="ipOpts",s6Q="multiple",S5O="ttr",T9O="pairs",j8="_editor_val",R7="textarea",j6x="password",a4O="afeId",T1x="_i",i2x="text",A5O='text',s3x="_val",E85="dden",d85="prop",L8='sab',N4x="inp",o1Q="inpu",N5Q="_inp",l25="Ty",S35='ue',w8x='pen',M05="rop",I4Q="ag",j9Q="_enabled",k1="_input",fieldTypes=Editor[n6Q];function _buttonText(conf,text){var y8Q="...",R6="hoo",q65="uplo";if(text===null||text===undefined){text=conf[(q65+T2Q+o6v.l6Q+W4O+o6v.B6Q+v6x)]||(p8O+R6+D3+a9+o6v.Y7Q+W6Q+o6v.B6Q+y8Q);}
conf[(N8Q+F1Q+B65+A4O)][O1O]('div.upload button')[(E7Q+q05+h3Q)](text);}
function _commonUpload(editor,conf,dropCallback){var M2='arV',T9='oD',u1O='os',d1O='E_',T9x='over',E9='dra',M9="Drag",L6="Dr",B6="tex",U7x="dragDrop",n3O="FileReader",T5='r_up',btnClass=editor[(H2Q+F1x+Y05+D3+Y05)][(f5O+K5Q)][(H85)],container=$((Q4O+o25+H5+J5x+v25+T8x+s0+i9+c25+T25+N2Q+T5+y75+h9x+o25+W6)+'<div class="eu_table">'+'<div class="row">'+'<div class="cell upload">'+'<button class="'+btnClass+(r9x)+'<input type="file"/>'+(B2+o25+H5+r4O)+'<div class="cell clearValue">'+(Q4O+P85+u3+o6v.R0+o6v.R0+C6O+J5x+v25+y75+Y85+x2O+i9)+btnClass+'" />'+'</div>'+(B2+o25+H5+r4O)+(Q4O+o25+v75+P3+J5x+v25+y75+i8x+s0+i9+d0+s5O+J5x+s0+c25+v25+C6O+o25+W6)+'<div class="cell">'+(Q4O+o25+H5+J5x+v25+y75+Y85+s0+s0+i9+o25+d0+G7O+e8Q+s0+L3Q+i15+I9+o25+H5+r4O)+'</div>'+(Q4O+o25+v75+P3+J5x+v25+y75+Y85+s0+s0+i9+v25+c25+y75+y75+W6)+(Q4O+o25+H5+J5x+v25+T8x+s0+i9+d0+c25+H8Q+r6Q+z4)+(B2+o25+H5+r4O)+(B2+o25+v75+P3+r4O)+'</div>'+(B2+o25+v75+P3+r4O));conf[k1]=container;conf[j9Q]=true;_buttonText(conf);if(window[n3O]&&conf[U7x]!==false){container[(p0+o6v.G4Q+o6v.l6Q)]((o25+H5+R8O+o25+d0+G7O+J5x+s0+D+i0x))[(B6+q05)](conf[(o6v.l6Q+o6v.B9Q+I4Q+L6+C5+r7Q+o6v.t85+q05)]||(M9+a9+T2Q+x05+a9+o6v.l6Q+M05+a9+T2Q+a9+o6v.Y7Q+N4O+a9+E7Q+o6v.B6Q+e5Q+a9+q05+o6v.l4Q+a9+H05+P5x+f25));var dragDrop=container[O1O]((o25+v75+P3+R8O+o25+d0+R15+D));dragDrop[(f5)]((o25+K0x+D),function(e){var S="ans",W1="taT",R0O="originalEvent";if(conf[(N8Q+X4Q+v5x+G7Q)]){Editor[(H05+o6v.v9Q+s6+o6v.l6Q)](editor,conf,e[R0O][(f8O+W1+o6v.B9Q+S+o6v.Y7Q+U9Q)][n5O],_buttonText,dropCallback);dragDrop[k0Q]((L5O+c25+d0));}
return false;}
)[(f5)]('dragleave dragexit',function(e){if(conf[(N8Q+o6v.B6Q+o6v.G4Q+T2Q+H2+G7Q)]){dragDrop[(o6v.B9Q+o6v.B6Q+K5Q+o6v.l4Q+M35+c8O+b5Q+T2Q+S1)]('over');}
return false;}
)[(o6v.l4Q+o6v.G4Q)]((E9+b65+T9x),function(e){if(conf[(N8Q+o6v.B6Q+P9Q+U65+o6v.l6Q)]){dragDrop[(Q7O+C4Q+T2Q+S1)]('over');}
return false;}
);editor[(f5)]((R15+w8x),function(){var t2='agov';$((G8O+Y3))[(o6v.l4Q+o6v.G4Q)]((o25+d0+t2+c25+d0+R8O+v3Q+g85+g35+l5Q+q7Q+R15+Y85+o25+J5x+o25+K0x+D+R8O+v3Q+E1Q+d1O+l5Q+q7Q+R15+Y85+o25),function(e){return false;}
);}
)[(f5)]((v25+y75+u1O+c25),function(){var B3x='TE_U';$('body')[(Z05)]((o25+h7+b65+R15+X6+d0+R8O+v3Q+B3x+D+y75+R15+Y85+o25+J5x+o25+d0+R15+D+R8O+v3Q+E1Q+d1O+l5Q+n4+D5));}
);}
else{container[(T2Q+o6v.l6Q+f3x+b5Q+T2Q+S1)]((i15+T9+d0+R15+D));container[z6x](container[(f4x+o6v.l6Q)]('div.rendered'));}
container[(O1O)]((p+R8O+v25+y75+c25+M2+h9+S35+J5x+P85+u3+o6v.R0+N2Q+i15))[(o6v.l4Q+o6v.G4Q)]((P8Q+S7),function(){var j0x="pes";Editor[(o6v.Y7Q+F1Q+i5Q+o6v.l6Q+l25+j0x)][(g5O+b5Q+o6v.l4Q+T2Q+o6v.l6Q)][(Y05+c05)][(H2Q+I05+b5Q)](editor,conf,'');}
);container[(o6v.Y7Q+F1Q+o6v.G4Q+o6v.l6Q)]('input[type=file]')[(o6v.l4Q+o6v.G4Q)]('change',function(){Editor[B5O](editor,conf,this[(o6v.Y7Q+W6Q+o6v.B6Q+Y05)],_buttonText,function(ids){dropCallback[(r0x+P0O)](editor,ids);container[O1O]('input[type=file]')[L85]('');}
);}
);return container;}
function _triggerChange(input){setTimeout(function(){input[(q05+o6v.B9Q+F1Q+W7Q+W7Q+o6v.B6Q+o6v.B9Q)]('change',{editor:true,editorSet:true}
);}
,0);}
var baseFieldType=$[(o6v.B6Q+v6x+X4Q+o6v.l6Q)](true,{}
,Editor[(m8Q+o6v.l6Q+V35)][d7O],{get:function(conf){return conf[(n0x+l0O+q05)][(M35+I05)]();}
,set:function(conf,val){conf[(N5Q+H05+q05)][(L85)](val);_triggerChange(conf[(N8Q+o1Q+q05)]);}
,enable:function(conf){conf[(N8Q+N4x+A4O)][(o6v.v9Q+o6v.B9Q+C5)]((T25+L8+y75+c25+o25),false);}
,disable:function(conf){conf[k1][d85]('disabled',true);}
,canReturnSubmit:function(conf,node){return true;}
}
);fieldTypes[(r3O+E85)]={create:function(conf){conf[s3x]=conf[f35];return null;}
,get:function(conf){return conf[s3x];}
,set:function(conf,val){conf[s3x]=val;}
}
;fieldTypes[(e5Q+m5Q+o6v.l4Q+J25+a85)]=$[d8O](true,{}
,baseFieldType,{create:function(conf){var V0x='ado';conf[k1]=$('<input/>')[(d65+q05+o6v.B9Q)]($[d8O]({id:Editor[d3O](conf[(y3Q)]),type:(A5O),readonly:(d0+c25+V0x+i15+d25)}
,conf[x9x]||{}
));return conf[k1][0];}
}
);fieldTypes[(i2x)]=$[(o6v.B6Q+E1O+o6v.G4Q+o6v.l6Q)](true,{}
,baseFieldType,{create:function(conf){conf[(T1x+B65+H05+q05)]=$('<input/>')[(T2Q+q05+q05+o6v.B9Q)]($[d8O]({id:Editor[(Y05+a4O)](conf[(F1Q+o6v.l6Q)]),type:'text'}
,conf[(d65+q05+o6v.B9Q)]||{}
));return conf[k1][0];}
}
);fieldTypes[j6x]=$[(o6v.B6Q+o6v.t85+y3x+x05)](true,{}
,baseFieldType,{create:function(conf){var Q6Q='ssw';conf[k1]=$('<input/>')[x9x]($[d8O]({id:Editor[d3O](conf[(y3Q)]),type:(D+Y85+Q6Q+e7O+o25)}
,conf[(T2Q+q05+j1x)]||{}
));return conf[(N8Q+F1Q+o6v.G4Q+o6v.v9Q+H05+q05)][0];}
}
);fieldTypes[R7]=$[d8O](true,{}
,baseFieldType,{create:function(conf){conf[k1]=$('<textarea/>')[(d65+q05+o6v.B9Q)]($[(B85+q25)]({id:Editor[(Y05+a4O)](conf[y3Q])}
,conf[(d65+q05+o6v.B9Q)]||{}
));return conf[k1][0];}
,canReturnSubmit:function(conf,node){return false;}
}
);fieldTypes[a2]=$[(x8Q+o6v.B6Q+x05)](true,{}
,baseFieldType,{_addOptions:function(conf,opts,append){var J7O="sPair",F15="opti",W7x="disa",c5O="sabl",J9O="placeholderDisabled",g05="placeholderValue",elOpts=conf[k1][0][k9x],countOffset=0;if(!append){elOpts.length=0;if(conf[(o6v.v9Q+F1x+v8x+E7Q+m1+V2O+o6v.B9Q)]!==undefined){var placeholderValue=conf[g05]!==undefined?conf[g05]:'';countOffset+=1;elOpts[0]=new Option(conf[(o6v.v9Q+b5Q+m2x+E7Q+m1+o6v.l6Q+U9Q)],placeholderValue);var disabled=conf[J9O]!==undefined?conf[(P6Q+v8x+E7Q+m1+V2O+o6v.B9Q+o8O+F1Q+c5O+G7Q)]:true;elOpts[0][(r3O+o6v.l6Q+o6v.l6Q+o6v.B6Q+o6v.G4Q)]=disabled;elOpts[0][(W7x+H2+G7Q)]=disabled;elOpts[0][j8]=placeholderValue;}
}
else{countOffset=elOpts.length;}
if(opts){Editor[T9O](opts,conf[(F15+o6v.l4Q+o6v.G4Q+J7O)],function(val,label,i,attr){var p3Q="att",J6O="tor_",option=new Option(label,val);option[(N8Q+H25+J6O+M35+I05)]=val;if(attr){$(option)[(p3Q+o6v.B9Q)](attr);}
elOpts[i+countOffset]=option;}
);}
}
,create:function(conf){var c15='ange';conf[k1]=$((Q4O+s0+c25+y75+o6v.q6+o6v.R0+q1))[(T2Q+S5O)]($[d8O]({id:Editor[d3O](conf[(F1Q+o6v.l6Q)]),multiple:conf[s6Q]===true}
,conf[x9x]||{}
))[(f5)]((U0Q+c15+R8O+o25+I9O),function(e,d){var X05="_la";if(!d||!d[(o6v.B6Q+o6v.l6Q+P5Q+o6v.l4Q+o6v.B9Q)]){conf[(X05+Y05+J7+o6v.B6Q+q05)]=fieldTypes[(Y05+i5Q+o6v.B6Q+G4x)][(a6O)](conf);}
}
);fieldTypes[(a2)][(N8Q+T2Q+a2O+x1O+O9x+F1Q+f5+Y05)](conf,conf[(O8x+n7Q+s75)]||conf[h4x]);return conf[k1][0];}
,update:function(conf,options,append){var t4="_lastSet",s15="sele";fieldTypes[(s15+H2Q+q05)][(N8Q+T2Q+a2O+x1O+O9x+F1Q+c4Q)](conf,options,append);var lastSet=conf[t4];if(lastSet!==undefined){fieldTypes[(N7Q+h2O)][(Y05+c05)](conf,lastSet,true);}
_triggerChange(conf[(N5Q+H05+q05)]);}
,get:function(conf){var f3Q="epa",I0O='cte',b05='optio',val=conf[k1][O1O]((b05+i15+M5O+s0+c25+y75+c25+I0O+o25))[E0O](function(){return this[j8];}
)[(q05+u9Q+a1O)]();if(conf[s6Q]){return conf[(Y05+f3Q+U7Q+q05+X4)]?val[(o35+o6v.G4Q)](conf[G75]):val;}
return val.length?val[0]:null;}
,set:function(conf,val,localUpdate){var N2="hol",m9Q="plac",F9="ted",i3O="_inpu",H9Q="lit",h8x="epara",a3x="iple",I5x="_l";if(!localUpdate){conf[(I5x+w65+J7+o6v.B6Q+q05)]=val;}
if(conf[(L9O+a3x)]&&conf[(Y05+h8x+q05+o6v.l4Q+o6v.B9Q)]&&!$[z9Q](val)){val=typeof val===(s0+o6v.R0+x4+I0x)?val[(Y05+o6v.v9Q+H9Q)](conf[G75]):[];}
else if(!$[(F1Q+Y05+o3O+Q25+T2Q+a85)](val)){val=[val];}
var i,len=val.length,found,allFound=false,options=conf[(i3O+q05)][O1O]((G7O+k2x+i15));conf[(N8Q+N4x+A4O)][(f4x+o6v.l6Q)]('option')[(o6v.B6Q+s6x)](function(){var S1O="ito";found=false;for(i=0;i<len;i++){if(this[(O6x+o6v.l6Q+S1O+o6v.B9Q+N8Q+M35+T2Q+b5Q)]==val[i]){found=true;allFound=true;break;}
}
this[(Y05+o6v.B6Q+b5Q+m6Q+F9)]=found;}
);if(conf[(m9Q+o6v.B6Q+N2+V2O+o6v.B9Q)]&&!allFound&&!conf[s6Q]&&options.length){options[0][(D3+b5Q+o6v.B6Q+H2Q+F9)]=true;}
if(!localUpdate){_triggerChange(conf[(N8Q+F1Q+s4Q)]);}
return allFound;}
,destroy:function(conf){conf[(N8Q+N4x+H05+q05)][(o6v.l4Q+o6v.Y7Q+o6v.Y7Q)]((A9x+R8O+o25+I9O));}
}
);fieldTypes[(H2Q+E7Q+z8Q+m2Q+o6v.l4Q+o6v.t85)]=$[(o6v.B6Q+E1O+o6v.G4Q+o6v.l6Q)](true,{}
,baseFieldType,{_addOptions:function(conf,opts,append){var l5O="onsPa",o1x="irs",val,label,jqInput=conf[k1],offset=0;if(!append){jqInput.empty();}
else{offset=$('input',jqInput).length;}
if(opts){Editor[(o6v.v9Q+T2Q+o1x)](opts,conf[(o6v.l4Q+O9x+F1Q+l5O+F1Q+o6v.B9Q)],function(val,label,i,attr){var z3O="safeI";jqInput[(T2Q+o6v.v9Q+o6v.v9Q+o6v.B6Q+o6v.G4Q+o6v.l6Q)]((Q4O+o25+v75+P3+r4O)+(Q4O+v75+i15+D+u3+o6v.R0+J5x+v75+o25+i9)+Editor[d3O](conf[(y3Q)])+'_'+(i+offset)+'" type="checkbox" />'+'<label for="'+Editor[(z3O+o6v.l6Q)](conf[y3Q])+'_'+(i+offset)+'">'+label+(B2+y75+N1+c25+y75+r4O)+(B2+o25+H5+r4O));$((F7+D+B15+M5O+y75+i8x+o6v.R0),jqInput)[x9x]((P3+Y85+y75+S35),val)[0][j8]=val;if(attr){$('input:last',jqInput)[x9x](attr);}
}
);}
}
,create:function(conf){var K05="_addOptions";conf[k1]=$((Q4O+o25+v75+P3+x0Q));fieldTypes[(Z2x+m6Q+J1Q+m2Q+o6v.l4Q+o6v.t85)][K05](conf,conf[(O8x+n7Q+o6v.G4Q+Y05)]||conf[h4x]);return conf[k1][0];}
,get:function(conf){var I5Q="ara",I1Q="sep",n6="cted",a35="nse",V8Q="unselectedValue",y4O='cked',out=[],selected=conf[(k1)][(o6v.Y7Q+F1Q+x05)]((F7+D+u3+o6v.R0+M5O+v25+J4Q+y4O));if(selected.length){selected[(o6v.B6Q+s6x)](function(){out[(o6v.v9Q+s4O+E7Q)](this[j8]);}
);}
else if(conf[V8Q]!==undefined){out[(C15+E7Q)](conf[(H05+a35+U5x+n6+M9O+T2Q+D7O)]);}
return conf[G75]===undefined||conf[(I1Q+I5Q+F3Q)]===null?out:out[(q1Q+o6v.l4Q+D7Q)](conf[G75]);}
,set:function(conf,val){var y9O="sArr",D6x="spl",n2x='ring',jqInputs=conf[(T1x+o6v.G4Q+o6v.v9Q+A4O)][(p0+o6v.G4Q+o6v.l6Q)]((G));if(!$[(F0x+o6v.B9Q+o6v.B9Q+T2Q+a85)](val)&&typeof val===(l2O+n2x)){val=val[(D6x+F1Q+q05)](conf[(D3+D2x+U7Q+q05+X4)]||'|');}
else if(!$[(F1Q+y9O+z75)](val)){val=[val];}
var i,len=val.length,found;jqInputs[(z2Q+H2Q+E7Q)](function(){var M15="checked",k4O="or_";found=false;for(i=0;i<len;i++){if(this[(N8Q+G7Q+P5Q+k4O+M35+T2Q+b5Q)]==val[i]){found=true;break;}
}
this[M15]=found;}
);_triggerChange(jqInputs);}
,enable:function(conf){conf[(N8Q+D7Q+l0O+q05)][O1O]((v75+i15+d6))[(b9x+C5)]((T25+d1x+P85+y75+c25+o25),false);}
,disable:function(conf){conf[(n0x+l0O+q05)][O1O]((v75+i15+d6))[d85]((D8Q),true);}
,update:function(conf,options,append){var v1="kbo",checkbox=fieldTypes[(H2Q+E7Q+m6Q+v1+o6v.t85)],currVal=checkbox[a6O](conf);checkbox[(j2x+l6+n7Q+s75)](conf,options,append);checkbox[(Y05+o6v.B6Q+q05)](conf,currVal);}
}
);fieldTypes[O3x]=$[d8O](true,{}
,baseFieldType,{_addOptions:function(conf,opts,append){var P4Q="air",V2x='np',val,label,jqInput=conf[k1],offset=0;if(!append){jqInput.empty();}
else{offset=$((v75+V2x+B15),jqInput).length;}
if(opts){Editor[T9O](opts,conf[(o6v.l4Q+o6v.v9Q+q05+F1Q+o6v.l4Q+o6v.G4Q+Y05+A1O+P4Q)],function(val,label,i,attr){var M7O='ast',H5x="r_v",r9='dio',M4Q="af";jqInput[(T2Q+o6v.v9Q+o6v.v9Q+R9)]('<div>'+'<input id="'+Editor[(Y05+M4Q+i6O+o6v.l6Q)](conf[(y3Q)])+'_'+(i+offset)+(B35+o6v.R0+a8+I8Q+i9+d0+Y85+r9+B35+i15+Y85+u15+c25+i9)+conf[R7Q]+'" />'+(Q4O+y75+Y85+x4x+y75+J5x+Z65+R15+d0+i9)+Editor[d3O](conf[y3Q])+'_'+(i+offset)+'">'+label+(B2+y75+Y85+x4x+y75+r4O)+'</div>');$((v75+i15+D4Q+o6v.R0+M5O+y75+Y85+s0+o6v.R0),jqInput)[(d65+j1x)]((P3+Y85+y75+u3+c25),val)[0][(N8Q+G7Q+F1Q+q05+o6v.l4Q+H5x+T2Q+b5Q)]=val;if(attr){$((G+M5O+y75+M7O),jqInput)[x9x](attr);}
}
);}
}
,create:function(conf){var G1Q="ip",g6Q="rad";conf[(N8Q+F1Q+o6v.G4Q+l0O+q05)]=$((Q4O+o25+v75+P3+x0Q));fieldTypes[(g6Q+n7Q)][(N8Q+m5Q+o6v.l6Q+x1O+o6v.v9Q+q05+F1Q+c4Q)](conf,conf[k9x]||conf[(G1Q+G3Q+q05+Y05)]);this[f5]((R15+w8x),function(){conf[(k1)][(o6v.Y7Q+r8)]((A65+o6v.R0))[P1Q](function(){var y35="reCh";if(this[(N8Q+o6v.v9Q+y35+o6v.B6Q+E2x+o6v.B6Q+o6v.l6Q)]){this[(Z2x+z8Q+o6v.B6Q+o6v.l6Q)]=true;}
}
);}
);return conf[k1][0];}
,get:function(conf){var el=conf[(N8Q+F1Q+s4Q)][O1O]((A65+o6v.R0+M5O+v25+J4Q+F8Q+c25+o25));return el.length?el[0][j8]:undefined;}
,set:function(conf,val){var a25='ecked',that=this;conf[(k1)][O1O]((v75+i15+D4Q+o6v.R0))[(o6v.B6Q+D5Q+E7Q)](function(){var F6Q="hecked",n9x="_preChecked",U0="che",O0="_pre";this[(O0+u5Q+o6v.B6Q+H2Q+J1Q+G7Q)]=false;if(this[j8]==val){this[(U0+H2Q+J1Q+o6v.B6Q+o6v.l6Q)]=true;this[n9x]=true;}
else{this[(H2Q+F6Q)]=false;this[n9x]=false;}
}
);_triggerChange(conf[k1][(p0+x05)]((n8O+u3+o6v.R0+M5O+v25+c65+a25)));}
,enable:function(conf){conf[k1][(O1O)]((v75+Y0))[d85]('disabled',false);}
,disable:function(conf){conf[k1][O1O]((n8O+u3+o6v.R0))[(b9x+o6v.l4Q+o6v.v9Q)]((o25+v75+s0+X85+o25),true);}
,update:function(conf,options,append){var v85='value',X6Q='alue',radio=fieldTypes[(O3x)],currVal=radio[a6O](conf);radio[(j2x+l6+F1Q+o6v.l4Q+s75)](conf,options,append);var inputs=conf[(N8Q+F1Q+o6v.G4Q+o6v.v9Q+A4O)][O1O]('input');radio[(Y05+c05)](conf,inputs[(W5x+y3x+o6v.B9Q)]((y9Q+P3+X6Q+i9)+currVal+'"]').length?currVal:inputs[n9Q](0)[(T2Q+S5O)]((v85)));}
}
);fieldTypes[r8x]=$[(o6v.B6Q+v6x+o6v.B6Q+o6v.G4Q+o6v.l6Q)](true,{}
,baseFieldType,{create:function(conf){var D6Q="C_",p1="dateFormat",g8Q='xt';conf[k1]=$('<input />')[(T2Q+S5O)]($[(o6v.B6Q+v6x+X4Q+o6v.l6Q)]({id:Editor[d3O](conf[(y3Q)]),type:(o6v.R0+c25+g8Q)}
,conf[(d65+j1x)]));if($[(f8O+q05+o6v.B6Q+Y1x+H2Q+C4O)]){conf[k1][x7x]('jqueryui');if(!conf[p1]){conf[p1]=$[T3O][(C5O+X2O+D6Q+K7x+F4x+K7x+K7x)];}
setTimeout(function(){var B1='is';$(conf[(N8Q+o1Q+q05)])[(o6v.l6Q+T2Q+y3x+Y1x+I15+o6v.B9Q)]($[(o6v.B6Q+v6x+o6v.B6Q+o6v.G4Q+o6v.l6Q)]({showOn:(Q7+q05+E7Q),dateFormat:conf[(f8O+y3x+X2O+X4+M8O)],buttonImage:conf[(r8x+q6O+K5Q+I4Q+o6v.B6Q)],buttonImageOnly:true,onSelect:function(){conf[k1][(O5x+Y05)]()[(H2Q+b5Q+F1Q+E2x)]();}
}
,conf[(o6v.l4Q+r8O)]));$((A4x+u3+v75+l8O+o25+Y85+o6v.R0+c25+D+v75+F8Q+Q9+l8O+o25+v75+P3))[(H2Q+S1)]((o25+B1+D+y75+Y85+a8),'none');}
,10);}
else{conf[(N8Q+F1Q+B65+A4O)][x9x]('type',(L5x+c25));}
return conf[(T1x+o6v.G4Q+l0O+q05)][0];}
,set:function(conf,val){var n0Q="setDa",E6O="ick",F4Q='epi',g7x='Da',E7="sClass",I7x="atepic";if($[(o6v.l6Q+I7x+J1Q+o6v.B6Q+o6v.B9Q)]&&conf[(n0x+o6v.v9Q+A4O)][(E7Q+T2Q+E7)]((g5Q+s0+g7x+o6v.R0+F4Q+F8Q+c25+d0))){conf[k1][(o6v.l6Q+T2Q+y3x+o6v.v9Q+E6O+U9Q)]((n0Q+q05+o6v.B6Q),val)[(H2Q+W9x+H35+o6v.B6Q)]();}
else{$(conf[(T1x+o6v.G4Q+l0O+q05)])[L85](val);}
}
,enable:function(conf){var i35="tepic",v8="epicker";$[(f8O+q05+v8)]?conf[(T1x+o6v.G4Q+o6v.v9Q+H05+q05)][(o6v.l6Q+T2Q+i35+J1Q+o6v.B6Q+o6v.B9Q)]((o6v.B6Q+o6v.G4Q+T2Q+H2+o6v.B6Q)):$(conf[(N5Q+A4O)])[(d85)]((Q1x+o25),false);}
,disable:function(conf){var Z4x='led',p8="tep";$[T3O]?conf[(n0x+E6Q)][(f8O+p8+F1Q+I15+o6v.B9Q)]((o6v.l6Q+Y5Q+T2Q+U65)):$(conf[(T1x+o6v.G4Q+E6Q)])[d85]((o25+v75+L8+Z4x),true);}
,owns:function(conf,node){var U2O="aren";return $(node)[(o6v.v9Q+x25+Y6+Y05)]('div.ui-datepicker').length||$(node)[(o6v.v9Q+U2O+o6v.r1x)]('div.ui-datepicker-header').length?true:false;}
}
);fieldTypes[(f8O+q05+c05+u05)]=$[(o6v.B6Q+v6x+o6v.B6Q+o6v.G4Q+o6v.l6Q)](true,{}
,baseFieldType,{create:function(conf){var i2="tet",p05="_pi";conf[k1]=$((Q4O+v75+Y0+x0Q))[x9x]($[(o6v.B6Q+o6v.t85+l3+o6v.l6Q)](true,{id:Editor[(Y05+T2Q+o6v.Y7Q+i6O+o6v.l6Q)](conf[(y3Q)]),type:'text'}
,conf[x9x]));conf[(p05+H2Q+v5+o6v.B9Q)]=new Editor[(o8O+d2x+W4O+v7Q+o6v.B6Q)](conf[(T1x+o6v.G4Q+E6Q)],$[(B85+q05+o6v.B6Q+o6v.G4Q+o6v.l6Q)]({format:conf[(o6v.Y7Q+N75+d65)],i18n:this[J3][(o6v.l6Q+T2Q+i2+F1Q+V9O)],onChange:function(){_triggerChange(conf[(T1x+o6v.G4Q+E6Q)]);}
}
,conf[(C5+o6v.r1x)]));conf[(N4Q+u1+X2O+o6v.G4Q)]=function(){conf[M2x][(E7Q+f15)]();}
;this[f5]((j9O+s0+c25),conf[(r2x+w3O+Y05+o6v.B6Q+X2O+o6v.G4Q)]);return conf[(T1x+o6v.G4Q+o6v.v9Q+H05+q05)][0];}
,set:function(conf,val){var v2x="icker";conf[(m9x+v2x)][L85](val);_triggerChange(conf[(N8Q+o1Q+q05)]);}
,owns:function(conf,node){return conf[(R1+C4O)][(J9+s75)](node);}
,errorMessage:function(conf,msg){var P3x="errorMsg";conf[M2x][P3x](msg);}
,destroy:function(conf){this[Z05]('close',conf[(r2x+b5Q+o6v.l4Q+D3+A6O)]);conf[(R1+C4O)][o4]();}
,minDate:function(conf,min){var X8="min";conf[M2x][X8](min);}
,maxDate:function(conf,max){conf[(N8Q+Y1x+E2x+U9Q)][z3x](max);}
}
);fieldTypes[(H05+j5O+m5Q)]=$[(o6v.B6Q+o6v.t85+q05+R9)](true,{}
,baseFieldType,{create:function(conf){var editor=this,container=_commonUpload(editor,conf,function(val){Editor[(o6v.Y7Q+L8Q+b5Q+J7Q+C6x+Y05)][B5O][q4Q][(H2Q+I05+b5Q)](editor,conf,val[0]);}
);return container;}
,get:function(conf){return conf[s3x];}
,set:function(conf,val){var B7="and",v5O="rH",w0x='noCle',Q4x="earT",X1x="clearText",h6Q='N',w0Q="Fil",k2O="splay";conf[(K3O+I05)]=val;var container=conf[k1];if(conf[(K85+P6Q+a85)]){var rendered=container[(f4x+o6v.l6Q)]('div.rendered');if(conf[s3x]){rendered[(E7Q+V1)](conf[(o6v.l6Q+F1Q+k2O)](conf[s3x]));}
else{rendered.empty()[z6x]((Q4O+s0+E6x+r4O)+(conf[(j65+w0Q+o6v.B6Q+r7Q+o6v.t85+q05)]||(h6Q+R15+J5x+Z65+b6+c25))+'</span>');}
}
var button=container[(o6v.Y7Q+F1Q+x05)]('div.clearValue button');if(val&&conf[X1x]){button[(E7Q+q05+K5Q+b5Q)](conf[(b6x+Q4x+o6v.B6Q+v6x)]);container[k0Q]('noClear');}
else{container[(m5Q+f3x+b5Q+T2Q+Y05+Y05)]((w0x+Y85+d0));}
conf[(T1x+B65+A4O)][(o6v.Y7Q+F1Q+o6v.G4Q+o6v.l6Q)]('input')[(j1x+t2Q+W7Q+o6v.B6Q+v5O+B7+b5Q+o6v.B6Q+o6v.B9Q)]((l75+y75+R15+Y85+o25+R8O+c25+o25+v75+N2Q+d0),[conf[(N8Q+M35+T2Q+b5Q)]]);}
,enable:function(conf){conf[(N5Q+A4O)][O1O]((A65+o6v.R0))[(b9x+o6v.l4Q+o6v.v9Q)]((u0+N1+y75+r6),false);conf[j9Q]=true;}
,disable:function(conf){conf[(N8Q+N4x+H05+q05)][(f4x+o6v.l6Q)]('input')[(o6v.v9Q+o6v.B9Q+C5)]('disabled',true);conf[(O6x+P9Q+m2Q+U5x+o6v.l6Q)]=false;}
,canReturnSubmit:function(conf,node){return false;}
}
);fieldTypes[(a7+o6v.l4Q+T2Q+Y8O)]=$[d8O](true,{}
,baseFieldType,{create:function(conf){var p0O="_va",editor=this,container=_commonUpload(editor,conf,function(val){var U="ny";var I2="Ma";var N7x="concat";conf[(K3O+I05)]=conf[(K3O+T2Q+b5Q)][N7x](val);Editor[n6Q][(H05+o6v.v9Q+b5Q+f25+I2+U)][(D3+q05)][K7O](editor,conf,conf[(p0O+b5Q)]);}
);container[(T2Q+o6v.l6Q+f3x+O4+Y05)]((u15+D65+o6v.R0+v75))[f5]((u1x+v25+P75),(h6O+o6v.R0+W75+R8O+d0+c25+o8+X6),function(e){var X5="uploadMany",c9O="splice",D9O="stopPropagation";e[D9O]();var idx=$(this).data('idx');conf[(p0O+b5Q)][c9O](idx,1);Editor[(W2+b5Q+o6v.l6Q+l25+o6v.v9Q+o6v.B6Q+Y05)][X5][q4Q][K7O](editor,conf,conf[s3x]);}
);return container;}
,get:function(conf){return conf[s3x];}
,set:function(conf,val){var P1="rigger",h9O='npu',h05='iles',w85="noFileText",E7x="endTo",k35='lu',v6='ave',n35='oll';if(!val){val=[];}
if(!$[(F0x+o6v.B9Q+o6v.B9Q+T2Q+a85)](val)){throw (l5Q+q7Q+l0+J5x+v25+n35+o6v.q6+o6v.R0+v75+p4x+J5x+u15+u3+l2O+J5x+c65+v6+J5x+Y85+i15+J5x+Y85+d0+d0+Y85+a8+J5x+Y85+s0+J5x+Y85+J5x+P3+Y85+k35+c25);}
conf[(N8Q+L85)]=val;var that=this,container=conf[k1];if(conf[(o6v.l6Q+C6+a85)]){var rendered=container[O1O]((o25+H5+R8O+d0+r5+o25+Q9+c25+o25)).empty();if(val.length){var list=$((Q4O+u3+y75+q1))[(T2Q+o6v.v9Q+o6v.v9Q+E7x)](rendered);$[P1Q](val,function(i,file){var E0='dx',E5x='move',N5='tto',v9O=' <';list[(k8Q+X4Q+o6v.l6Q)]((Q4O+y75+v75+r4O)+conf[a15](file,i)+(v9O+P85+u3+N5+i15+J5x+v25+y75+Y85+x2O+i9)+that[k0][z65][(m2Q+A4O+q7x+o6v.G4Q)]+(J5x+d0+c25+E5x+B35+o25+u85+l8O+v75+E0+i9)+i+'">&times;</button>'+'</li>');}
);}
else{rendered[(T2Q+o6v.v9Q+j0)]('<span>'+(conf[w85]||(X5Q+J5x+Z65+h05))+'</span>');}
}
conf[k1][(o6v.Y7Q+r8)]((v75+h9O+o6v.R0))[(q05+P1+I8)]('upload.editor',[conf[s3x]]);}
,enable:function(conf){var L4x='sabled';conf[(T1x+B65+H05+q05)][(p0+o6v.G4Q+o6v.l6Q)]((F7+d6))[(o6v.v9Q+M05)]((T25+L4x),false);conf[(N8Q+o6v.B6Q+o6v.G4Q+v5x+o6v.B6Q+o6v.l6Q)]=true;}
,disable:function(conf){conf[k1][O1O]((A65+o6v.R0))[(d85)]('disabled',true);conf[(N8Q+o6v.B6Q+o6v.G4Q+T2Q+m2Q+M1Q)]=false;}
,canReturnSubmit:function(conf,node){return false;}
}
);}
());if(DataTable[x8Q][(G7Q+P5Q+K6+s5x+Y05)]){$[(o6v.B6Q+E1O+o6v.G4Q+o6v.l6Q)](Editor[(p0+o6v.B6Q+b5Q+J7Q+o6v.v9Q+o6v.B6Q+Y05)],DataTable[x8Q][(o6v.B6Q+o6v.l6Q+I2O+L8Q+s5x+Y05)]);}
DataTable[x8Q][(o6v.B6Q+v7O+F3Q+t7x+s5x+Y05)]=Editor[(p0+l1x+C6x+Y05)];Editor[(o6v.Y7Q+F1Q+g1)]={}
;Editor.prototype.CLASS=(B8O+L9Q);Editor[(q6Q+o6v.B9Q+Y05+n7Q+o6v.G4Q)]=(b7x+Z6x+V5x+Z6x+H1x);return Editor;}
));

/*! Buttons for DataTables 1.4.2
 * ©2016-2017 SpryMedia Ltd - datatables.net/license
 */

(function( factory ){
	if ( typeof define === 'function' && define.amd ) {
		// AMD
		define( ['jquery', 'datatables.net'], function ( $ ) {
			return factory( $, window, document );
		} );
	}
	else if ( typeof exports === 'object' ) {
		// CommonJS
		module.exports = function (root, $) {
			if ( ! root ) {
				root = window;
			}

			if ( ! $ || ! $.fn.dataTable ) {
				$ = require('datatables.net')(root, $).$;
			}

			return factory( $, root, root.document );
		};
	}
	else {
		// Browser
		factory( jQuery, window, document );
	}
}(function( $, window, document, undefined ) {
'use strict';
var DataTable = $.fn.dataTable;


// Used for namespacing events added to the document by each instance, so they
// can be removed on destroy
var _instCounter = 0;

// Button namespacing counter for namespacing events on individual buttons
var _buttonCounter = 0;

var _dtButtons = DataTable.ext.buttons;

/**
 * [Buttons description]
 * @param {[type]}
 * @param {[type]}
 */
var Buttons = function( dt, config )
{
	// If there is no config set it to an empty object
	if ( typeof( config ) === 'undefined' ) {
		config = {};	
	}
	
	// Allow a boolean true for defaults
	if ( config === true ) {
		config = {};
	}

	// For easy configuration of buttons an array can be given
	if ( $.isArray( config ) ) {
		config = { buttons: config };
	}

	this.c = $.extend( true, {}, Buttons.defaults, config );

	// Don't want a deep copy for the buttons
	if ( config.buttons ) {
		this.c.buttons = config.buttons;
	}

	this.s = {
		dt: new DataTable.Api( dt ),
		buttons: [],
		listenKeys: '',
		namespace: 'dtb'+(_instCounter++)
	};

	this.dom = {
		container: $('<'+this.c.dom.container.tag+'/>')
			.addClass( this.c.dom.container.className )
	};

	this._constructor();
};


$.extend( Buttons.prototype, {
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Public methods
	 */

	/**
	 * Get the action of a button
	 * @param  {int|string} Button index
	 * @return {function}
	 *//**
	 * Set the action of a button
	 * @param  {node} node Button element
	 * @param  {function} action Function to set
	 * @return {Buttons} Self for chaining
	 */
	action: function ( node, action )
	{
		var button = this._nodeToButton( node );

		if ( action === undefined ) {
			return button.conf.action;
		}

		button.conf.action = action;

		return this;
	},

	/**
	 * Add an active class to the button to make to look active or get current
	 * active state.
	 * @param  {node} node Button element
	 * @param  {boolean} [flag] Enable / disable flag
	 * @return {Buttons} Self for chaining or boolean for getter
	 */
	active: function ( node, flag ) {
		var button = this._nodeToButton( node );
		var klass = this.c.dom.button.active;
		var jqNode = $(button.node);

		if ( flag === undefined ) {
			return jqNode.hasClass( klass );
		}

		jqNode.toggleClass( klass, flag === undefined ? true : flag );

		return this;
	},

	/**
	 * Add a new button
	 * @param {object} config Button configuration object, base string name or function
	 * @param {int|string} [idx] Button index for where to insert the button
	 * @return {Buttons} Self for chaining
	 */
	add: function ( config, idx )
	{
		var buttons = this.s.buttons;

		if ( typeof idx === 'string' ) {
			var split = idx.split('-');
			var base = this.s;

			for ( var i=0, ien=split.length-1 ; i<ien ; i++ ) {
				base = base.buttons[ split[i]*1 ];
			}

			buttons = base.buttons;
			idx = split[ split.length-1 ]*1;
		}

		this._expandButton( buttons, config, false, idx );
		this._draw();

		return this;
	},

	/**
	 * Get the container node for the buttons
	 * @return {jQuery} Buttons node
	 */
	container: function ()
	{
		return this.dom.container;
	},

	/**
	 * Disable a button
	 * @param  {node} node Button node
	 * @return {Buttons} Self for chaining
	 */
	disable: function ( node ) {
		var button = this._nodeToButton( node );

		$(button.node).addClass( this.c.dom.button.disabled );

		return this;
	},

	/**
	 * Destroy the instance, cleaning up event handlers and removing DOM
	 * elements
	 * @return {Buttons} Self for chaining
	 */
	destroy: function ()
	{
		// Key event listener
		$('body').off( 'keyup.'+this.s.namespace );

		// Individual button destroy (so they can remove their own events if
		// needed). Take a copy as the array is modified by `remove`
		var buttons = this.s.buttons.slice();
		var i, ien;
		
		for ( i=0, ien=buttons.length ; i<ien ; i++ ) {
			this.remove( buttons[i].node );
		}

		// Container
		this.dom.container.remove();

		// Remove from the settings object collection
		var buttonInsts = this.s.dt.settings()[0];

		for ( i=0, ien=buttonInsts.length ; i<ien ; i++ ) {
			if ( buttonInsts.inst === this ) {
				buttonInsts.splice( i, 1 );
				break;
			}
		}

		return this;
	},

	/**
	 * Enable / disable a button
	 * @param  {node} node Button node
	 * @param  {boolean} [flag=true] Enable / disable flag
	 * @return {Buttons} Self for chaining
	 */
	enable: function ( node, flag )
	{
		if ( flag === false ) {
			return this.disable( node );
		}

		var button = this._nodeToButton( node );
		$(button.node).removeClass( this.c.dom.button.disabled );

		return this;
	},

	/**
	 * Get the instance name for the button set selector
	 * @return {string} Instance name
	 */
	name: function ()
	{
		return this.c.name;
	},

	/**
	 * Get a button's node
	 * @param  {node} node Button node
	 * @return {jQuery} Button element
	 */
	node: function ( node )
	{
		var button = this._nodeToButton( node );
		return $(button.node);
	},

	/**
	 * Set / get a processing class on the selected button
	 * @param  {boolean} flag true to add, false to remove, undefined to get
	 * @return {boolean|Buttons} Getter value or this if a setter.
	 */
	processing: function ( node, flag )
	{
		var button = this._nodeToButton( node );

		if ( flag === undefined ) {
			return $(button.node).hasClass( 'processing' );
		}

		$(button.node).toggleClass( 'processing', flag );

		return this;
	},

	/**
	 * Remove a button.
	 * @param  {node} node Button node
	 * @return {Buttons} Self for chaining
	 */
	remove: function ( node )
	{
		var button = this._nodeToButton( node );
		var host = this._nodeToHost( node );
		var dt = this.s.dt;

		// Remove any child buttons first
		if ( button.buttons.length ) {
			for ( var i=button.buttons.length-1 ; i>=0 ; i-- ) {
				this.remove( button.buttons[i].node );
			}
		}

		// Allow the button to remove event handlers, etc
		if ( button.conf.destroy ) {
			button.conf.destroy.call( dt.button(node), dt, $(node), button.conf );
		}

		this._removeKey( button.conf );

		$(button.node).remove();

		var idx = $.inArray( button, host );
		host.splice( idx, 1 );

		return this;
	},

	/**
	 * Get the text for a button
	 * @param  {int|string} node Button index
	 * @return {string} Button text
	 *//**
	 * Set the text for a button
	 * @param  {int|string|function} node Button index
	 * @param  {string} label Text
	 * @return {Buttons} Self for chaining
	 */
	text: function ( node, label )
	{
		var button = this._nodeToButton( node );
		var buttonLiner = this.c.dom.collection.buttonLiner;
		var linerTag = button.inCollection && buttonLiner && buttonLiner.tag ?
			buttonLiner.tag :
			this.c.dom.buttonLiner.tag;
		var dt = this.s.dt;
		var jqNode = $(button.node);
		var text = function ( opt ) {
			return typeof opt === 'function' ?
				opt( dt, jqNode, button.conf ) :
				opt;
		};

		if ( label === undefined ) {
			return text( button.conf.text );
		}

		button.conf.text = label;

		if ( linerTag ) {
			jqNode.children( linerTag ).html( text(label) );
		}
		else {
			jqNode.html( text(label) );
		}

		return this;
	},


	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Constructor
	 */

	/**
	 * Buttons constructor
	 * @private
	 */
	_constructor: function ()
	{
		var that = this;
		var dt = this.s.dt;
		var dtSettings = dt.settings()[0];
		var buttons =  this.c.buttons;

		if ( ! dtSettings._buttons ) {
			dtSettings._buttons = [];
		}

		dtSettings._buttons.push( {
			inst: this,
			name: this.c.name
		} );

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			this.add( buttons[i] );
		}

		dt.on( 'destroy', function () {
			that.destroy();
		} );

		// Global key event binding to listen for button keys
		$('body').on( 'keyup.'+this.s.namespace, function ( e ) {
			if ( ! document.activeElement || document.activeElement === document.body ) {
				// SUse a string of characters for fast lookup of if we need to
				// handle this
				var character = String.fromCharCode(e.keyCode).toLowerCase();

				if ( that.s.listenKeys.toLowerCase().indexOf( character ) !== -1 ) {
					that._keypress( character, e );
				}
			}
		} );
	},


	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Private methods
	 */

	/**
	 * Add a new button to the key press listener
	 * @param {object} conf Resolved button configuration object
	 * @private
	 */
	_addKey: function ( conf )
	{
		if ( conf.key ) {
			this.s.listenKeys += $.isPlainObject( conf.key ) ?
				conf.key.key :
				conf.key;
		}
	},

	/**
	 * Insert the buttons into the container. Call without parameters!
	 * @param  {node} [container] Recursive only - Insert point
	 * @param  {array} [buttons] Recursive only - Buttons array
	 * @private
	 */
	_draw: function ( container, buttons )
	{
		if ( ! container ) {
			container = this.dom.container;
			buttons = this.s.buttons;
		}

		container.children().detach();

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			container.append( buttons[i].inserter );
			container.append( ' ' );

			if ( buttons[i].buttons && buttons[i].buttons.length ) {
				this._draw( buttons[i].collection, buttons[i].buttons );
			}
		}
	},

	/**
	 * Create buttons from an array of buttons
	 * @param  {array} attachTo Buttons array to attach to
	 * @param  {object} button Button definition
	 * @param  {boolean} inCollection true if the button is in a collection
	 * @private
	 */
	_expandButton: function ( attachTo, button, inCollection, attachPoint )
	{
		var dt = this.s.dt;
		var buttonCounter = 0;
		var buttons = ! $.isArray( button ) ?
			[ button ] :
			button;

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			var conf = this._resolveExtends( buttons[i] );

			if ( ! conf ) {
				continue;
			}

			// If the configuration is an array, then expand the buttons at this
			// point
			if ( $.isArray( conf ) ) {
				this._expandButton( attachTo, conf, inCollection, attachPoint );
				continue;
			}

			var built = this._buildButton( conf, inCollection );
			if ( ! built ) {
				continue;
			}

			if ( attachPoint !== undefined ) {
				attachTo.splice( attachPoint, 0, built );
				attachPoint++;
			}
			else {
				attachTo.push( built );
			}

			if ( built.conf.buttons ) {
				var collectionDom = this.c.dom.collection;
				built.collection = $('<'+collectionDom.tag+'/>')
					.addClass( collectionDom.className )
					.attr( 'role', 'menu') ;
				built.conf._collection = built.collection;

				this._expandButton( built.buttons, built.conf.buttons, true, attachPoint );
			}

			// init call is made here, rather than buildButton as it needs to
			// be selectable, and for that it needs to be in the buttons array
			if ( conf.init ) {
				conf.init.call( dt.button( built.node ), dt, $(built.node), conf );
			}

			buttonCounter++;
		}
	},

	/**
	 * Create an individual button
	 * @param  {object} config            Resolved button configuration
	 * @param  {boolean} inCollection `true` if a collection button
	 * @return {jQuery} Created button node (jQuery)
	 * @private
	 */
	_buildButton: function ( config, inCollection )
	{
		var buttonDom = this.c.dom.button;
		var linerDom = this.c.dom.buttonLiner;
		var collectionDom = this.c.dom.collection;
		var dt = this.s.dt;
		var text = function ( opt ) {
			return typeof opt === 'function' ?
				opt( dt, button, config ) :
				opt;
		};

		if ( inCollection && collectionDom.button ) {
			buttonDom = collectionDom.button;
		}

		if ( inCollection && collectionDom.buttonLiner ) {
			linerDom = collectionDom.buttonLiner;
		}

		// Make sure that the button is available based on whatever requirements
		// it has. For example, Flash buttons require Flash
		if ( config.available && ! config.available( dt, config ) ) {
			return false;
		}

		var action = function ( e, dt, button, config ) {
			config.action.call( dt.button( button ), e, dt, button, config );

			$(dt.table().node()).triggerHandler( 'buttons-action.dt', [
				dt.button( button ), dt, button, config 
			] );
		};

		var button = $('<'+buttonDom.tag+'/>')
			.addClass( buttonDom.className )
			.attr( 'tabindex', this.s.dt.settings()[0].iTabIndex )
			.attr( 'aria-controls', this.s.dt.table().node().id )
			.on( 'click.dtb', function (e) {
				e.preventDefault();

				if ( ! button.hasClass( buttonDom.disabled ) && config.action ) {
					action( e, dt, button, config );
				}

				button.blur();
			} )
			.on( 'keyup.dtb', function (e) {
				if ( e.keyCode === 13 ) {
					if ( ! button.hasClass( buttonDom.disabled ) && config.action ) {
						action( e, dt, button, config );
					}
				}
			} );

		// Make `a` tags act like a link
		if ( buttonDom.tag.toLowerCase() === 'a' ) {
			button.attr( 'href', '#' );
		}

		if ( linerDom.tag ) {
			var liner = $('<'+linerDom.tag+'/>')
				.html( text( config.text ) )
				.addClass( linerDom.className );

			if ( linerDom.tag.toLowerCase() === 'a' ) {
				liner.attr( 'href', '#' );
			}

			button.append( liner );
		}
		else {
			button.html( text( config.text ) );
		}

		if ( config.enabled === false ) {
			button.addClass( buttonDom.disabled );
		}

		if ( config.className ) {
			button.addClass( config.className );
		}

		if ( config.titleAttr ) {
			button.attr( 'title', text( config.titleAttr ) );
		}

		if ( ! config.namespace ) {
			config.namespace = '.dt-button-'+(_buttonCounter++);
		}

		var buttonContainer = this.c.dom.buttonContainer;
		var inserter;
		if ( buttonContainer && buttonContainer.tag ) {
			inserter = $('<'+buttonContainer.tag+'/>')
				.addClass( buttonContainer.className )
				.append( button );
		}
		else {
			inserter = button;
		}

		this._addKey( config );

		return {
			conf:         config,
			node:         button.get(0),
			inserter:     inserter,
			buttons:      [],
			inCollection: inCollection,
			collection:   null
		};
	},

	/**
	 * Get the button object from a node (recursive)
	 * @param  {node} node Button node
	 * @param  {array} [buttons] Button array, uses base if not defined
	 * @return {object} Button object
	 * @private
	 */
	_nodeToButton: function ( node, buttons )
	{
		if ( ! buttons ) {
			buttons = this.s.buttons;
		}

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			if ( buttons[i].node === node ) {
				return buttons[i];
			}

			if ( buttons[i].buttons.length ) {
				var ret = this._nodeToButton( node, buttons[i].buttons );

				if ( ret ) {
					return ret;
				}
			}
		}
	},

	/**
	 * Get container array for a button from a button node (recursive)
	 * @param  {node} node Button node
	 * @param  {array} [buttons] Button array, uses base if not defined
	 * @return {array} Button's host array
	 * @private
	 */
	_nodeToHost: function ( node, buttons )
	{
		if ( ! buttons ) {
			buttons = this.s.buttons;
		}

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			if ( buttons[i].node === node ) {
				return buttons;
			}

			if ( buttons[i].buttons.length ) {
				var ret = this._nodeToHost( node, buttons[i].buttons );

				if ( ret ) {
					return ret;
				}
			}
		}
	},

	/**
	 * Handle a key press - determine if any button's key configured matches
	 * what was typed and trigger the action if so.
	 * @param  {string} character The character pressed
	 * @param  {object} e Key event that triggered this call
	 * @private
	 */
	_keypress: function ( character, e )
	{
		var run = function ( conf, node ) {
			if ( ! conf.key ) {
				return;
			}

			if ( conf.key === character ) {
				$(node).click();
			}
			else if ( $.isPlainObject( conf.key ) ) {
				if ( conf.key.key !== character ) {
					return;
				}

				if ( conf.key.shiftKey && ! e.shiftKey ) {
					return;
				}

				if ( conf.key.altKey && ! e.altKey ) {
					return;
				}

				if ( conf.key.ctrlKey && ! e.ctrlKey ) {
					return;
				}

				if ( conf.key.metaKey && ! e.metaKey ) {
					return;
				}

				// Made it this far - it is good
				$(node).click();
			}
		};

		var recurse = function ( a ) {
			for ( var i=0, ien=a.length ; i<ien ; i++ ) {
				run( a[i].conf, a[i].node );

				if ( a[i].buttons.length ) {
					recurse( a[i].buttons );
				}
			}
		};

		recurse( this.s.buttons );
	},

	/**
	 * Remove a key from the key listener for this instance (to be used when a
	 * button is removed)
	 * @param  {object} conf Button configuration
	 * @private
	 */
	_removeKey: function ( conf )
	{
		if ( conf.key ) {
			var character = $.isPlainObject( conf.key ) ?
				conf.key.key :
				conf.key;

			// Remove only one character, as multiple buttons could have the
			// same listening key
			var a = this.s.listenKeys.split('');
			var idx = $.inArray( character, a );
			a.splice( idx, 1 );
			this.s.listenKeys = a.join('');
		}
	},

	/**
	 * Resolve a button configuration
	 * @param  {string|function|object} conf Button config to resolve
	 * @return {object} Button configuration
	 * @private
	 */
	_resolveExtends: function ( conf )
	{
		var dt = this.s.dt;
		var i, ien;
		var toConfObject = function ( base ) {
			var loop = 0;

			// Loop until we have resolved to a button configuration, or an
			// array of button configurations (which will be iterated
			// separately)
			while ( ! $.isPlainObject(base) && ! $.isArray(base) ) {
				if ( base === undefined ) {
					return;
				}

				if ( typeof base === 'function' ) {
					base = base( dt, conf );

					if ( ! base ) {
						return false;
					}
				}
				else if ( typeof base === 'string' ) {
					if ( ! _dtButtons[ base ] ) {
						throw 'Unknown button type: '+base;
					}

					base = _dtButtons[ base ];
				}

				loop++;
				if ( loop > 30 ) {
					// Protect against misconfiguration killing the browser
					throw 'Buttons: Too many iterations';
				}
			}

			return $.isArray( base ) ?
				base :
				$.extend( {}, base );
		};

		conf = toConfObject( conf );

		while ( conf && conf.extend ) {
			// Use `toConfObject` in case the button definition being extended
			// is itself a string or a function
			if ( ! _dtButtons[ conf.extend ] ) {
				throw 'Cannot extend unknown button type: '+conf.extend;
			}

			var objArray = toConfObject( _dtButtons[ conf.extend ] );
			if ( $.isArray( objArray ) ) {
				return objArray;
			}
			else if ( ! objArray ) {
				// This is a little brutal as it might be possible to have a
				// valid button without the extend, but if there is no extend
				// then the host button would be acting in an undefined state
				return false;
			}

			// Stash the current class name
			var originalClassName = objArray.className;

			conf = $.extend( {}, objArray, conf );

			// The extend will have overwritten the original class name if the
			// `conf` object also assigned a class, but we want to concatenate
			// them so they are list that is combined from all extended buttons
			if ( originalClassName && conf.className !== originalClassName ) {
				conf.className = originalClassName+' '+conf.className;
			}

			// Buttons to be added to a collection  -gives the ability to define
			// if buttons should be added to the start or end of a collection
			var postfixButtons = conf.postfixButtons;
			if ( postfixButtons ) {
				if ( ! conf.buttons ) {
					conf.buttons = [];
				}

				for ( i=0, ien=postfixButtons.length ; i<ien ; i++ ) {
					conf.buttons.push( postfixButtons[i] );
				}

				conf.postfixButtons = null;
			}

			var prefixButtons = conf.prefixButtons;
			if ( prefixButtons ) {
				if ( ! conf.buttons ) {
					conf.buttons = [];
				}

				for ( i=0, ien=prefixButtons.length ; i<ien ; i++ ) {
					conf.buttons.splice( i, 0, prefixButtons[i] );
				}

				conf.prefixButtons = null;
			}

			// Although we want the `conf` object to overwrite almost all of
			// the properties of the object being extended, the `extend`
			// property should come from the object being extended
			conf.extend = objArray.extend;
		}

		return conf;
	}
} );



/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Statics
 */

/**
 * Show / hide a background layer behind a collection
 * @param  {boolean} Flag to indicate if the background should be shown or
 *   hidden 
 * @param  {string} Class to assign to the background
 * @static
 */
Buttons.background = function ( show, className, fade ) {
	if ( fade === undefined ) {
		fade = 400;
	}

	if ( show ) {
		$('<div/>')
			.addClass( className )
			.css( 'display', 'none' )
			.appendTo( 'body' )
			.fadeIn( fade );
	}
	else {
		$('body > div.'+className)
			.fadeOut( fade, function () {
				$(this)
					.removeClass( className )
					.remove();
			} );
	}
};

/**
 * Instance selector - select Buttons instances based on an instance selector
 * value from the buttons assigned to a DataTable. This is only useful if
 * multiple instances are attached to a DataTable.
 * @param  {string|int|array} Instance selector - see `instance-selector`
 *   documentation on the DataTables site
 * @param  {array} Button instance array that was attached to the DataTables
 *   settings object
 * @return {array} Buttons instances
 * @static
 */
Buttons.instanceSelector = function ( group, buttons )
{
	if ( ! group ) {
		return $.map( buttons, function ( v ) {
			return v.inst;
		} );
	}

	var ret = [];
	var names = $.map( buttons, function ( v ) {
		return v.name;
	} );

	// Flatten the group selector into an array of single options
	var process = function ( input ) {
		if ( $.isArray( input ) ) {
			for ( var i=0, ien=input.length ; i<ien ; i++ ) {
				process( input[i] );
			}
			return;
		}

		if ( typeof input === 'string' ) {
			if ( input.indexOf( ',' ) !== -1 ) {
				// String selector, list of names
				process( input.split(',') );
			}
			else {
				// String selector individual name
				var idx = $.inArray( $.trim(input), names );

				if ( idx !== -1 ) {
					ret.push( buttons[ idx ].inst );
				}
			}
		}
		else if ( typeof input === 'number' ) {
			// Index selector
			ret.push( buttons[ input ].inst );
		}
	};
	
	process( group );

	return ret;
};

/**
 * Button selector - select one or more buttons from a selector input so some
 * operation can be performed on them.
 * @param  {array} Button instances array that the selector should operate on
 * @param  {string|int|node|jQuery|array} Button selector - see
 *   `button-selector` documentation on the DataTables site
 * @return {array} Array of objects containing `inst` and `idx` properties of
 *   the selected buttons so you know which instance each button belongs to.
 * @static
 */
Buttons.buttonSelector = function ( insts, selector )
{
	var ret = [];
	var nodeBuilder = function ( a, buttons, baseIdx ) {
		var button;
		var idx;

		for ( var i=0, ien=buttons.length ; i<ien ; i++ ) {
			button = buttons[i];

			if ( button ) {
				idx = baseIdx !== undefined ?
					baseIdx+i :
					i+'';

				a.push( {
					node: button.node,
					name: button.conf.name,
					idx:  idx
				} );

				if ( button.buttons ) {
					nodeBuilder( a, button.buttons, idx+'-' );
				}
			}
		}
	};

	var run = function ( selector, inst ) {
		var i, ien;
		var buttons = [];
		nodeBuilder( buttons, inst.s.buttons );

		var nodes = $.map( buttons, function (v) {
			return v.node;
		} );

		if ( $.isArray( selector ) || selector instanceof $ ) {
			for ( i=0, ien=selector.length ; i<ien ; i++ ) {
				run( selector[i], inst );
			}
			return;
		}

		if ( selector === null || selector === undefined || selector === '*' ) {
			// Select all
			for ( i=0, ien=buttons.length ; i<ien ; i++ ) {
				ret.push( {
					inst: inst,
					node: buttons[i].node
				} );
			}
		}
		else if ( typeof selector === 'number' ) {
			// Main button index selector
			ret.push( {
				inst: inst,
				node: inst.s.buttons[ selector ].node
			} );
		}
		else if ( typeof selector === 'string' ) {
			if ( selector.indexOf( ',' ) !== -1 ) {
				// Split
				var a = selector.split(',');

				for ( i=0, ien=a.length ; i<ien ; i++ ) {
					run( $.trim(a[i]), inst );
				}
			}
			else if ( selector.match( /^\d+(\-\d+)*$/ ) ) {
				// Sub-button index selector
				var indexes = $.map( buttons, function (v) {
					return v.idx;
				} );

				ret.push( {
					inst: inst,
					node: buttons[ $.inArray( selector, indexes ) ].node
				} );
			}
			else if ( selector.indexOf( ':name' ) !== -1 ) {
				// Button name selector
				var name = selector.replace( ':name', '' );

				for ( i=0, ien=buttons.length ; i<ien ; i++ ) {
					if ( buttons[i].name === name ) {
						ret.push( {
							inst: inst,
							node: buttons[i].node
						} );
					}
				}
			}
			else {
				// jQuery selector on the nodes
				$( nodes ).filter( selector ).each( function () {
					ret.push( {
						inst: inst,
						node: this
					} );
				} );
			}
		}
		else if ( typeof selector === 'object' && selector.nodeName ) {
			// Node selector
			var idx = $.inArray( selector, nodes );

			if ( idx !== -1 ) {
				ret.push( {
					inst: inst,
					node: nodes[ idx ]
				} );
			}
		}
	};


	for ( var i=0, ien=insts.length ; i<ien ; i++ ) {
		var inst = insts[i];

		run( selector, inst );
	}

	return ret;
};


/**
 * Buttons defaults. For full documentation, please refer to the docs/option
 * directory or the DataTables site.
 * @type {Object}
 * @static
 */
Buttons.defaults = {
	buttons: [ 'copy', 'excel', 'csv', 'pdf', 'print' ],
	name: 'main',
	tabIndex: 0,
	dom: {
		container: {
			tag: 'div',
			className: 'dt-buttons'
		},
		collection: {
			tag: 'div',
			className: 'dt-button-collection'
		},
		button: {
			tag: 'a',
			className: 'dt-button',
			active: 'active',
			disabled: 'disabled'
		},
		buttonLiner: {
			tag: 'span',
			className: ''
		}
	}
};

/**
 * Version information
 * @type {string}
 * @static
 */
Buttons.version = '1.4.2';


$.extend( _dtButtons, {
	collection: {
		text: function ( dt ) {
			return dt.i18n( 'buttons.collection', 'Collection' );
		},
		className: 'buttons-collection',
		action: function ( e, dt, button, config ) {
			var host = button;
			var hostOffset = host.offset();
			var tableContainer = $( dt.table().container() );
			var multiLevel = false;

			// Remove any old collection
			if ( $('div.dt-button-background').length ) {
				multiLevel = $('.dt-button-collection').offset();
				$('body').trigger( 'click.dtb-collection' );
			}

			config._collection
				.addClass( config.collectionLayout )
				.css( 'display', 'none' )
				.appendTo( 'body' )
				.fadeIn( config.fade );

			var position = config._collection.css( 'position' );

			if ( multiLevel && position === 'absolute' ) {
				config._collection.css( {
					top: multiLevel.top,
					left: multiLevel.left
				} );
			}
			else if ( position === 'absolute' ) {
				config._collection.css( {
					top: hostOffset.top + host.outerHeight(),
					left: hostOffset.left
				} );

				// calculate overflow when positioned beneath
				var tableBottom = tableContainer.offset().top + tableContainer.height();
				var listBottom = hostOffset.top + host.outerHeight() + config._collection.outerHeight();
				var bottomOverflow = listBottom - tableBottom;
				
				// calculate overflow when positioned above
				var listTop = hostOffset.top - config._collection.outerHeight();
				var tableTop = tableContainer.offset().top;
				var topOverflow = tableTop - listTop;
				
				// if bottom overflow is larger, move to the top because it fits better
				if (bottomOverflow > topOverflow) {
					config._collection.css( 'top', hostOffset.top - config._collection.outerHeight() - 5);
				}

				var listRight = hostOffset.left + config._collection.outerWidth();
				var tableRight = tableContainer.offset().left + tableContainer.width();
				if ( listRight > tableRight ) {
					config._collection.css( 'left', hostOffset.left - ( listRight - tableRight ) );
				}
			}
			else {
				// Fix position - centre on screen
				var top = config._collection.height() / 2;
				if ( top > $(window).height() / 2 ) {
					top = $(window).height() / 2;
				}

				config._collection.css( 'marginTop', top*-1 );
			}

			if ( config.background ) {
				Buttons.background( true, config.backgroundClassName, config.fade );
			}

			// Need to break the 'thread' for the collection button being
			// activated by a click - it would also trigger this event
			setTimeout( function () {
				// This is bonkers, but if we don't have a click listener on the
				// background element, iOS Safari will ignore the body click
				// listener below. An empty function here is all that is
				// required to make it work...
				$('div.dt-button-background').on( 'click.dtb-collection', function () {} );

				$('body').on( 'click.dtb-collection', function (e) {
					// andSelf is deprecated in jQ1.8, but we want 1.7 compat
					var back = $.fn.addBack ? 'addBack' : 'andSelf';

					if ( ! $(e.target).parents()[back]().filter( config._collection ).length ) {
						config._collection
							.fadeOut( config.fade, function () {
								config._collection.detach();
							} );

						$('div.dt-button-background').off( 'click.dtb-collection' );
						Buttons.background( false, config.backgroundClassName, config.fade );

						$('body').off( 'click.dtb-collection' );
						dt.off( 'buttons-action.b-internal' );
					}
				} );
			}, 10 );

			if ( config.autoClose ) {
				dt.on( 'buttons-action.b-internal', function () {
					$('div.dt-button-background').click();
				} );
			}
		},
		background: true,
		collectionLayout: '',
		backgroundClassName: 'dt-button-background',
		autoClose: false,
		fade: 400
	},
	copy: function ( dt, conf ) {
		if ( _dtButtons.copyHtml5 ) {
			return 'copyHtml5';
		}
		if ( _dtButtons.copyFlash && _dtButtons.copyFlash.available( dt, conf ) ) {
			return 'copyFlash';
		}
	},
	csv: function ( dt, conf ) {
		// Common option that will use the HTML5 or Flash export buttons
		if ( _dtButtons.csvHtml5 && _dtButtons.csvHtml5.available( dt, conf ) ) {
			return 'csvHtml5';
		}
		if ( _dtButtons.csvFlash && _dtButtons.csvFlash.available( dt, conf ) ) {
			return 'csvFlash';
		}
	},
	excel: function ( dt, conf ) {
		// Common option that will use the HTML5 or Flash export buttons
		if ( _dtButtons.excelHtml5 && _dtButtons.excelHtml5.available( dt, conf ) ) {
			return 'excelHtml5';
		}
		if ( _dtButtons.excelFlash && _dtButtons.excelFlash.available( dt, conf ) ) {
			return 'excelFlash';
		}
	},
	pdf: function ( dt, conf ) {
		// Common option that will use the HTML5 or Flash export buttons
		if ( _dtButtons.pdfHtml5 && _dtButtons.pdfHtml5.available( dt, conf ) ) {
			return 'pdfHtml5';
		}
		if ( _dtButtons.pdfFlash && _dtButtons.pdfFlash.available( dt, conf ) ) {
			return 'pdfFlash';
		}
	},
	pageLength: function ( dt ) {
		var lengthMenu = dt.settings()[0].aLengthMenu;
		var vals = $.isArray( lengthMenu[0] ) ? lengthMenu[0] : lengthMenu;
		var lang = $.isArray( lengthMenu[0] ) ? lengthMenu[1] : lengthMenu;
		var text = function ( dt ) {
			return dt.i18n( 'buttons.pageLength', {
				"-1": 'Show all rows',
				_:    'Show %d rows'
			}, dt.page.len() );
		};

		return {
			extend: 'collection',
			text: text,
			className: 'buttons-page-length',
			autoClose: true,
			buttons: $.map( vals, function ( val, i ) {
				return {
					text: lang[i],
					className: 'button-page-length',
					action: function ( e, dt ) {
						dt.page.len( val ).draw();
					},
					init: function ( dt, node, conf ) {
						var that = this;
						var fn = function () {
							that.active( dt.page.len() === val );
						};

						dt.on( 'length.dt'+conf.namespace, fn );
						fn();
					},
					destroy: function ( dt, node, conf ) {
						dt.off( 'length.dt'+conf.namespace );
					}
				};
			} ),
			init: function ( dt, node, conf ) {
				var that = this;
				dt.on( 'length.dt'+conf.namespace, function () {
					that.text( text( dt ) );
				} );
			},
			destroy: function ( dt, node, conf ) {
				dt.off( 'length.dt'+conf.namespace );
			}
		};
	}
} );


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * DataTables API
 *
 * For complete documentation, please refer to the docs/api directory or the
 * DataTables site
 */

// Buttons group and individual button selector
DataTable.Api.register( 'buttons()', function ( group, selector ) {
	// Argument shifting
	if ( selector === undefined ) {
		selector = group;
		group = undefined;
	}

	this.selector.buttonGroup = group;

	var res = this.iterator( true, 'table', function ( ctx ) {
		if ( ctx._buttons ) {
			return Buttons.buttonSelector(
				Buttons.instanceSelector( group, ctx._buttons ),
				selector
			);
		}
	}, true );

	res._groupSelector = group;
	return res;
} );

// Individual button selector
DataTable.Api.register( 'button()', function ( group, selector ) {
	// just run buttons() and truncate
	var buttons = this.buttons( group, selector );

	if ( buttons.length > 1 ) {
		buttons.splice( 1, buttons.length );
	}

	return buttons;
} );

// Active buttons
DataTable.Api.registerPlural( 'buttons().active()', 'button().active()', function ( flag ) {
	if ( flag === undefined ) {
		return this.map( function ( set ) {
			return set.inst.active( set.node );
		} );
	}

	return this.each( function ( set ) {
		set.inst.active( set.node, flag );
	} );
} );

// Get / set button action
DataTable.Api.registerPlural( 'buttons().action()', 'button().action()', function ( action ) {
	if ( action === undefined ) {
		return this.map( function ( set ) {
			return set.inst.action( set.node );
		} );
	}

	return this.each( function ( set ) {
		set.inst.action( set.node, action );
	} );
} );

// Enable / disable buttons
DataTable.Api.register( ['buttons().enable()', 'button().enable()'], function ( flag ) {
	return this.each( function ( set ) {
		set.inst.enable( set.node, flag );
	} );
} );

// Disable buttons
DataTable.Api.register( ['buttons().disable()', 'button().disable()'], function () {
	return this.each( function ( set ) {
		set.inst.disable( set.node );
	} );
} );

// Get button nodes
DataTable.Api.registerPlural( 'buttons().nodes()', 'button().node()', function () {
	var jq = $();

	// jQuery will automatically reduce duplicates to a single entry
	$( this.each( function ( set ) {
		jq = jq.add( set.inst.node( set.node ) );
	} ) );

	return jq;
} );

// Get / set button processing state
DataTable.Api.registerPlural( 'buttons().processing()', 'button().processing()', function ( flag ) {
	if ( flag === undefined ) {
		return this.map( function ( set ) {
			return set.inst.processing( set.node );
		} );
	}

	return this.each( function ( set ) {
		set.inst.processing( set.node, flag );
	} );
} );

// Get / set button text (i.e. the button labels)
DataTable.Api.registerPlural( 'buttons().text()', 'button().text()', function ( label ) {
	if ( label === undefined ) {
		return this.map( function ( set ) {
			return set.inst.text( set.node );
		} );
	}

	return this.each( function ( set ) {
		set.inst.text( set.node, label );
	} );
} );

// Trigger a button's action
DataTable.Api.registerPlural( 'buttons().trigger()', 'button().trigger()', function () {
	return this.each( function ( set ) {
		set.inst.node( set.node ).trigger( 'click' );
	} );
} );

// Get the container elements
DataTable.Api.registerPlural( 'buttons().containers()', 'buttons().container()', function () {
	var jq = $();
	var groupSelector = this._groupSelector;

	// We need to use the group selector directly, since if there are no buttons
	// the result set will be empty
	this.iterator( true, 'table', function ( ctx ) {
		if ( ctx._buttons ) {
			var insts = Buttons.instanceSelector( groupSelector, ctx._buttons );

			for ( var i=0, ien=insts.length ; i<ien ; i++ ) {
				jq = jq.add( insts[i].container() );
			}
		}
	} );

	return jq;
} );

// Add a new button
DataTable.Api.register( 'button().add()', function ( idx, conf ) {
	var ctx = this.context;

	// Don't use `this` as it could be empty - select the instances directly
	if ( ctx.length ) {
		var inst = Buttons.instanceSelector( this._groupSelector, ctx[0]._buttons );

		if ( inst.length ) {
			inst[0].add( conf, idx );
		}
	}

	return this.button( this._groupSelector, idx );
} );

// Destroy the button sets selected
DataTable.Api.register( 'buttons().destroy()', function () {
	this.pluck( 'inst' ).unique().each( function ( inst ) {
		inst.destroy();
	} );

	return this;
} );

// Remove a button
DataTable.Api.registerPlural( 'buttons().remove()', 'buttons().remove()', function () {
	this.each( function ( set ) {
		set.inst.remove( set.node );
	} );

	return this;
} );

// Information box that can be used by buttons
var _infoTimer;
DataTable.Api.register( 'buttons.info()', function ( title, message, time ) {
	var that = this;

	if ( title === false ) {
		$('#datatables_buttons_info').fadeOut( function () {
			$(this).remove();
		} );
		clearTimeout( _infoTimer );
		_infoTimer = null;

		return this;
	}

	if ( _infoTimer ) {
		clearTimeout( _infoTimer );
	}

	if ( $('#datatables_buttons_info').length ) {
		$('#datatables_buttons_info').remove();
	}

	title = title ? '<h2>'+title+'</h2>' : '';

	$('<div id="datatables_buttons_info" class="dt-button-info"/>')
		.html( title )
		.append( $('<div/>')[ typeof message === 'string' ? 'html' : 'append' ]( message ) )
		.css( 'display', 'none' )
		.appendTo( 'body' )
		.fadeIn();

	if ( time !== undefined && time !== 0 ) {
		_infoTimer = setTimeout( function () {
			that.buttons.info( false );
		}, time );
	}

	return this;
} );

// Get data from the table for export - this is common to a number of plug-in
// buttons so it is included in the Buttons core library
DataTable.Api.register( 'buttons.exportData()', function ( options ) {
	if ( this.context.length ) {
		return _exportData( new DataTable.Api( this.context[0] ), options );
	}
} );

// Get information about the export that is common to many of the export data
// types (DRY)
DataTable.Api.register( 'buttons.exportInfo()', function ( conf ) {
	if ( ! conf ) {
		conf = {};
	}

	return {
		filename: _filename( conf ),
		title: _title( conf ),
		messageTop: _message(this, conf.messageTop || conf.message, 'top'),
		messageBottom: _message(this, conf.messageBottom, 'bottom')
	};
} );



/**
 * Get the file name for an exported file.
 *
 * @param {object}	config Button configuration
 * @param {boolean} incExtension Include the file name extension
 */
var _filename = function ( config )
{
	// Backwards compatibility
	var filename = config.filename === '*' && config.title !== '*' && config.title !== undefined ?
		config.title :
		config.filename;

	if ( typeof filename === 'function' ) {
		filename = filename();
	}

	if ( filename === undefined || filename === null ) {
		return null;
	}

	if ( filename.indexOf( '*' ) !== -1 ) {
		filename = $.trim( filename.replace( '*', $('title').text() ) );
	}

	// Strip characters which the OS will object to
	filename = filename.replace(/[^a-zA-Z0-9_\u00A1-\uFFFF\.,\-_ !\(\)]/g, "");

	var extension = _stringOrFunction( config.extension );
	if ( ! extension ) {
		extension = '';
	}

	return filename + extension;
};

/**
 * Simply utility method to allow parameters to be given as a function
 *
 * @param {undefined|string|function} option Option
 * @return {null|string} Resolved value
 */
var _stringOrFunction = function ( option )
{
	if ( option === null || option === undefined ) {
		return null;
	}
	else if ( typeof option === 'function' ) {
		return option();
	}
	return option;
};

/**
 * Get the title for an exported file.
 *
 * @param {object} config	Button configuration
 */
var _title = function ( config )
{
	var title = _stringOrFunction( config.title );

	return title === null ?
		null : title.indexOf( '*' ) !== -1 ?
			title.replace( '*', $('title').text() || 'Exported data' ) :
			title;
};

var _message = function ( dt, option, position )
{
	var message = _stringOrFunction( option );
	if ( message === null ) {
		return null;
	}

	var caption = $('caption', dt.table().container()).eq(0);
	if ( message === '*' ) {
		var side = caption.css( 'caption-side' );
		if ( side !== position ) {
			return null;
		}

		return caption.length ?
			caption.text() :
			'';
	}

	return message;
};







var _exportTextarea = $('<textarea/>')[0];
var _exportData = function ( dt, inOpts )
{
	var config = $.extend( true, {}, {
		rows:           null,
		columns:        '',
		modifier:       {
			search: 'applied',
			order:  'applied'
		},
		orthogonal:     'display',
		stripHtml:      true,
		stripNewlines:  true,
		decodeEntities: true,
		trim:           true,
		format:         {
			header: function ( d ) {
				return strip( d );
			},
			footer: function ( d ) {
				return strip( d );
			},
			body: function ( d ) {
				return strip( d );
			}
		}
	}, inOpts );

	var strip = function ( str ) {
		if ( typeof str !== 'string' ) {
			return str;
		}

		// Always remove script tags
		str = str.replace( /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '' );

		if ( config.stripHtml ) {
			str = str.replace( /<[^>]*>/g, '' );
		}

		if ( config.trim ) {
			str = str.replace( /^\s+|\s+$/g, '' );
		}

		if ( config.stripNewlines ) {
			str = str.replace( /\n/g, ' ' );
		}

		if ( config.decodeEntities ) {
			_exportTextarea.innerHTML = str;
			str = _exportTextarea.value;
		}

		return str;
	};


	var header = dt.columns( config.columns ).indexes().map( function (idx) {
		var el = dt.column( idx ).header();
		return config.format.header( el.innerHTML, idx, el );
	} ).toArray();

	var footer = dt.table().footer() ?
		dt.columns( config.columns ).indexes().map( function (idx) {
			var el = dt.column( idx ).footer();
			return config.format.footer( el ? el.innerHTML : '', idx, el );
		} ).toArray() :
		null;

	var rowIndexes = dt.rows( config.rows, config.modifier ).indexes().toArray();
	var selectedCells = dt.cells( rowIndexes, config.columns );
	var cells = selectedCells
		.render( config.orthogonal )
		.toArray();
	var cellNodes = selectedCells
		.nodes()
		.toArray();

	var columns = header.length;
	var rows = columns > 0 ? cells.length / columns : 0;
	var body = new Array( rows );
	var cellCounter = 0;

	for ( var i=0, ien=rows ; i<ien ; i++ ) {
		var row = new Array( columns );

		for ( var j=0 ; j<columns ; j++ ) {
			row[j] = config.format.body( cells[ cellCounter ], i, j, cellNodes[ cellCounter ] );
			cellCounter++;
		}

		body[i] = row;
	}

	return {
		header: header,
		footer: footer,
		body:   body
	};
};


/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * DataTables interface
 */

// Attach to DataTables objects for global access
$.fn.dataTable.Buttons = Buttons;
$.fn.DataTable.Buttons = Buttons;



// DataTables creation - check if the buttons have been defined for this table,
// they will have been if the `B` option was used in `dom`, otherwise we should
// create the buttons instance here so they can be inserted into the document
// using the API. Listen for `init` for compatibility with pre 1.10.10, but to
// be removed in future.
$(document).on( 'init.dt plugin-init.dt', function (e, settings) {
	if ( e.namespace !== 'dt' ) {
		return;
	}

	var opts = settings.oInit.buttons || DataTable.defaults.buttons;

	if ( opts && ! settings._buttons ) {
		new Buttons( settings, opts ).container();
	}
} );

// DataTables `dom` feature option
DataTable.ext.feature.push( {
	fnInit: function( settings ) {
		var api = new DataTable.Api( settings );
		var opts = api.init().buttons || DataTable.defaults.buttons;

		return new Buttons( api, opts ).container();
	},
	cFeature: "B"
} );


return Buttons;
}));


/*!
 * Print button for Buttons and DataTables.
 * 2016 SpryMedia Ltd - datatables.net/license
 */

(function( factory ){
	if ( typeof define === 'function' && define.amd ) {
		// AMD
		define( ['jquery', 'datatables.net', 'datatables.net-buttons'], function ( $ ) {
			return factory( $, window, document );
		} );
	}
	else if ( typeof exports === 'object' ) {
		// CommonJS
		module.exports = function (root, $) {
			if ( ! root ) {
				root = window;
			}

			if ( ! $ || ! $.fn.dataTable ) {
				$ = require('datatables.net')(root, $).$;
			}

			if ( ! $.fn.dataTable.Buttons ) {
				require('datatables.net-buttons')(root, $);
			}

			return factory( $, root, root.document );
		};
	}
	else {
		// Browser
		factory( jQuery, window, document );
	}
}(function( $, window, document, undefined ) {
'use strict';
var DataTable = $.fn.dataTable;


var _link = document.createElement( 'a' );

/**
 * Clone link and style tags, taking into account the need to change the source
 * path.
 *
 * @param  {node}     el Element to convert
 */
var _styleToAbs = function( el ) {
	var url;
	var clone = $(el).clone()[0];
	var linkHost;

	if ( clone.nodeName.toLowerCase() === 'link' ) {
		clone.href = _relToAbs( clone.href );
	}

	return clone.outerHTML;
};

/**
 * Convert a URL from a relative to an absolute address so it will work
 * correctly in the popup window which has no base URL.
 *
 * @param  {string} href URL
 */
var _relToAbs = function( href ) {
	// Assign to a link on the original page so the browser will do all the
	// hard work of figuring out where the file actually is
	_link.href = href;
	var linkHost = _link.host;

	// IE doesn't have a trailing slash on the host
	// Chrome has it on the pathname
	if ( linkHost.indexOf('/') === -1 && _link.pathname.indexOf('/') !== 0) {
		linkHost += '/';
	}

	return _link.protocol+"//"+linkHost+_link.pathname+_link.search;
};


DataTable.ext.buttons.print = {
	className: 'buttons-print',

	text: function ( dt ) {
		return dt.i18n( 'buttons.print', 'Print' );
	},

	action: function ( e, dt, button, config ) {
		var data = dt.buttons.exportData(
			$.extend( {decodeEntities: false}, config.exportOptions ) // XSS protection
		);
		var exportInfo = dt.buttons.exportInfo( config );

		var addRow = function ( d, tag ) {
			var str = '<tr>';

			for ( var i=0, ien=d.length ; i<ien ; i++ ) {
				str += '<'+tag+'>'+d[i]+'</'+tag+'>';
			}

			return str + '</tr>';
		};

		// Construct a table for printing
		var html = '<table class="'+dt.table().node().className+'">';

		if ( config.header ) {
			html += '<thead>'+ addRow( data.header, 'th' ) +'</thead>';
		}

		html += '<tbody>';
		for ( var i=0, ien=data.body.length ; i<ien ; i++ ) {
			html += addRow( data.body[i], 'td' );
		}
		html += '</tbody>';

		if ( config.footer && data.footer ) {
			html += '<tfoot>'+ addRow( data.footer, 'th' ) +'</tfoot>';
		}
		html += '</table>';

		// Open a new window for the printable table
		var win = window.open( '', '' );
		win.document.close();

		// Inject the title and also a copy of the style and link tags from this
		// document so the table can retain its base styling. Note that we have
		// to use string manipulation as IE won't allow elements to be created
		// in the host document and then appended to the new window.
		var head = '<title>'+exportInfo.title+'</title>';
		$('style, link').each( function () {
			head += _styleToAbs( this );
		} );

		try {
			win.document.head.innerHTML = head; // Work around for Edge
		}
		catch (e) {
			$(win.document.head).html( head ); // Old IE
		}

		// Inject the table and other surrounding information
		win.document.body.innerHTML =
			'<h1>'+exportInfo.title+'</h1>'+
			'<div>'+(exportInfo.messageTop || '')+'</div>'+
			html+
			'<div>'+(exportInfo.messageBottom || '')+'</div>';

		$(win.document.body).addClass('dt-print-view');

		$('img', win.document.body).each( function ( i, img ) {
			img.setAttribute( 'src', _relToAbs( img.getAttribute('src') ) );
		} );

		if ( config.customize ) {
			config.customize( win );
		}

		// Allow stylesheets time to load
		setTimeout( function () {
			if ( config.autoPrint ) {
				win.print(); // blocking - so close will not
				win.close(); // execute until this is done
			}
		}, 1000 );
	},

	title: '*',

	messageTop: '*',

	messageBottom: '*',

	exportOptions: {},

	header: true,

	footer: false,

	autoPrint: true,

	customize: null
};


return DataTable.Buttons;
}));


/*! Responsive 2.2.0
 * 2014-2017 SpryMedia Ltd - datatables.net/license
 */

/**
 * @summary     Responsive
 * @description Responsive tables plug-in for DataTables
 * @version     2.2.0
 * @file        dataTables.responsive.js
 * @author      SpryMedia Ltd (www.sprymedia.co.uk)
 * @contact     www.sprymedia.co.uk/contact
 * @copyright   Copyright 2014-2017 SpryMedia Ltd.
 *
 * This source file is free software, available under the following license:
 *   MIT license - http://datatables.net/license/mit
 *
 * This source file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE. See the license files for details.
 *
 * For details please refer to: http://www.datatables.net
 */
(function( factory ){
	if ( typeof define === 'function' && define.amd ) {
		// AMD
		define( ['jquery', 'datatables.net'], function ( $ ) {
			return factory( $, window, document );
		} );
	}
	else if ( typeof exports === 'object' ) {
		// CommonJS
		module.exports = function (root, $) {
			if ( ! root ) {
				root = window;
			}

			if ( ! $ || ! $.fn.dataTable ) {
				$ = require('datatables.net')(root, $).$;
			}

			return factory( $, root, root.document );
		};
	}
	else {
		// Browser
		factory( jQuery, window, document );
	}
}(function( $, window, document, undefined ) {
'use strict';
var DataTable = $.fn.dataTable;


/**
 * Responsive is a plug-in for the DataTables library that makes use of
 * DataTables' ability to change the visibility of columns, changing the
 * visibility of columns so the displayed columns fit into the table container.
 * The end result is that complex tables will be dynamically adjusted to fit
 * into the viewport, be it on a desktop, tablet or mobile browser.
 *
 * Responsive for DataTables has two modes of operation, which can used
 * individually or combined:
 *
 * * Class name based control - columns assigned class names that match the
 *   breakpoint logic can be shown / hidden as required for each breakpoint.
 * * Automatic control - columns are automatically hidden when there is no
 *   room left to display them. Columns removed from the right.
 *
 * In additional to column visibility control, Responsive also has built into
 * options to use DataTables' child row display to show / hide the information
 * from the table that has been hidden. There are also two modes of operation
 * for this child row display:
 *
 * * Inline - when the control element that the user can use to show / hide
 *   child rows is displayed inside the first column of the table.
 * * Column - where a whole column is dedicated to be the show / hide control.
 *
 * Initialisation of Responsive is performed by:
 *
 * * Adding the class `responsive` or `dt-responsive` to the table. In this case
 *   Responsive will automatically be initialised with the default configuration
 *   options when the DataTable is created.
 * * Using the `responsive` option in the DataTables configuration options. This
 *   can also be used to specify the configuration options, or simply set to
 *   `true` to use the defaults.
 *
 *  @class
 *  @param {object} settings DataTables settings object for the host table
 *  @param {object} [opts] Configuration options
 *  @requires jQuery 1.7+
 *  @requires DataTables 1.10.3+
 *
 *  @example
 *      $('#example').DataTable( {
 *        responsive: true
 *      } );
 *    } );
 */
var Responsive = function ( settings, opts ) {
	// Sanity check that we are using DataTables 1.10 or newer
	if ( ! DataTable.versionCheck || ! DataTable.versionCheck( '1.10.3' ) ) {
		throw 'DataTables Responsive requires DataTables 1.10.3 or newer';
	}

	this.s = {
		dt: new DataTable.Api( settings ),
		columns: [],
		current: []
	};

	// Check if responsive has already been initialised on this table
	if ( this.s.dt.settings()[0].responsive ) {
		return;
	}

	// details is an object, but for simplicity the user can give it as a string
	// or a boolean
	if ( opts && typeof opts.details === 'string' ) {
		opts.details = { type: opts.details };
	}
	else if ( opts && opts.details === false ) {
		opts.details = { type: false };
	}
	else if ( opts && opts.details === true ) {
		opts.details = { type: 'inline' };
	}

	this.c = $.extend( true, {}, Responsive.defaults, DataTable.defaults.responsive, opts );
	settings.responsive = this;
	this._constructor();
};

$.extend( Responsive.prototype, {
	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Constructor
	 */

	/**
	 * Initialise the Responsive instance
	 *
	 * @private
	 */
	_constructor: function ()
	{
		var that = this;
		var dt = this.s.dt;
		var dtPrivateSettings = dt.settings()[0];
		var oldWindowWidth = $(window).width();

		dt.settings()[0]._responsive = this;

		// Use DataTables' throttle function to avoid processor thrashing on
		// resize
		$(window).on( 'resize.dtr orientationchange.dtr', DataTable.util.throttle( function () {
			// iOS has a bug whereby resize can fire when only scrolling
			// See: http://stackoverflow.com/questions/8898412
			var width = $(window).width();

			if ( width !== oldWindowWidth ) {
				that._resize();
				oldWindowWidth = width;
			}
		} ) );

		// DataTables doesn't currently trigger an event when a row is added, so
		// we need to hook into its private API to enforce the hidden rows when
		// new data is added
		dtPrivateSettings.oApi._fnCallbackReg( dtPrivateSettings, 'aoRowCreatedCallback', function (tr, data, idx) {
			if ( $.inArray( false, that.s.current ) !== -1 ) {
				$('>td, >th', tr).each( function ( i ) {
					var idx = dt.column.index( 'toData', i );

					if ( that.s.current[idx] === false ) {
						$(this).css('display', 'none');
					}
				} );
			}
		} );

		// Destroy event handler
		dt.on( 'destroy.dtr', function () {
			dt.off( '.dtr' );
			$( dt.table().body() ).off( '.dtr' );
			$(window).off( 'resize.dtr orientationchange.dtr' );

			// Restore the columns that we've hidden
			$.each( that.s.current, function ( i, val ) {
				if ( val === false ) {
					that._setColumnVis( i, true );
				}
			} );
		} );

		// Reorder the breakpoints array here in case they have been added out
		// of order
		this.c.breakpoints.sort( function (a, b) {
			return a.width < b.width ? 1 :
				a.width > b.width ? -1 : 0;
		} );

		this._classLogic();
		this._resizeAuto();

		// Details handler
		var details = this.c.details;

		if ( details.type !== false ) {
			that._detailsInit();

			// DataTables will trigger this event on every column it shows and
			// hides individually
			dt.on( 'column-visibility.dtr', function (e, ctx, col, vis) {
				that._classLogic();
				that._resizeAuto();
				that._resize();
			} );

			// Redraw the details box on each draw which will happen if the data
			// has changed. This is used until DataTables implements a native
			// `updated` event for rows
			dt.on( 'draw.dtr', function () {
				that._redrawChildren();
			} );

			$(dt.table().node()).addClass( 'dtr-'+details.type );
		}

		dt.on( 'column-reorder.dtr', function (e, settings, details) {
			that._classLogic();
			that._resizeAuto();
			that._resize();
		} );

		// Change in column sizes means we need to calc
		dt.on( 'column-sizing.dtr', function () {
			that._resizeAuto();
			that._resize();
		});

		// On Ajax reload we want to reopen any child rows which are displayed
		// by responsive
		dt.on( 'preXhr.dtr', function () {
			var rowIds = [];
			dt.rows().every( function () {
				if ( this.child.isShown() ) {
					rowIds.push( this.id(true) );
				}
			} );

			dt.one( 'draw.dtr', function () {
				dt.rows( rowIds ).every( function () {
					that._detailsDisplay( this, false );
				} );
			} );
		});

		dt.on( 'init.dtr', function (e, settings, details) {
			that._resizeAuto();
			that._resize();

			// If columns were hidden, then DataTables needs to adjust the
			// column sizing
			if ( $.inArray( false, that.s.current ) ) {
				dt.columns.adjust();
			}
		} );

		// First pass - draw the table for the current viewport size
		this._resize();
	},


	/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
	 * Private methods
	 */

	/**
	 * Calculate the visibility for the columns in a table for a given
	 * breakpoint. The result is pre-determined based on the class logic if
	 * class names are used to control all columns, but the width of the table
	 * is also used if there are columns which are to be automatically shown
	 * and hidden.
	 *
	 * @param  {string} breakpoint Breakpoint name to use for the calculation
	 * @return {array} Array of boolean values initiating the visibility of each
	 *   column.
	 *  @private
	 */
	_columnsVisiblity: function ( breakpoint )
	{
		var dt = this.s.dt;
		var columns = this.s.columns;
		var i, ien;

		// Create an array that defines the column ordering based first on the
		// column's priority, and secondly the column index. This allows the
		// columns to be removed from the right if the priority matches
		var order = columns
			.map( function ( col, idx ) {
				return {
					columnIdx: idx,
					priority: col.priority
				};
			} )
			.sort( function ( a, b ) {
				if ( a.priority !== b.priority ) {
					return a.priority - b.priority;
				}
				return a.columnIdx - b.columnIdx;
			} );

		// Class logic - determine which columns are in this breakpoint based
		// on the classes. If no class control (i.e. `auto`) then `-` is used
		// to indicate this to the rest of the function
		var display = $.map( columns, function ( col ) {
			return col.auto && col.minWidth === null ?
				false :
				col.auto === true ?
					'-' :
					$.inArray( breakpoint, col.includeIn ) !== -1;
		} );

		// Auto column control - first pass: how much width is taken by the
		// ones that must be included from the non-auto columns
		var requiredWidth = 0;
		for ( i=0, ien=display.length ; i<ien ; i++ ) {
			if ( display[i] === true ) {
				requiredWidth += columns[i].minWidth;
			}
		}

		// Second pass, use up any remaining width for other columns. For
		// scrolling tables we need to subtract the width of the scrollbar. It
		// may not be requires which makes this sub-optimal, but it would
		// require another full redraw to make complete use of those extra few
		// pixels
		var scrolling = dt.settings()[0].oScroll;
		var bar = scrolling.sY || scrolling.sX ? scrolling.iBarWidth : 0;
		var widthAvailable = dt.table().container().offsetWidth - bar;
		var usedWidth = widthAvailable - requiredWidth;

		// Control column needs to always be included. This makes it sub-
		// optimal in terms of using the available with, but to stop layout
		// thrashing or overflow. Also we need to account for the control column
		// width first so we know how much width is available for the other
		// columns, since the control column might not be the first one shown
		for ( i=0, ien=display.length ; i<ien ; i++ ) {
			if ( columns[i].control ) {
				usedWidth -= columns[i].minWidth;
			}
		}

		// Allow columns to be shown (counting by priority and then right to
		// left) until we run out of room
		var empty = false;
		for ( i=0, ien=order.length ; i<ien ; i++ ) {
			var colIdx = order[i].columnIdx;

			if ( display[colIdx] === '-' && ! columns[colIdx].control && columns[colIdx].minWidth ) {
				// Once we've found a column that won't fit we don't let any
				// others display either, or columns might disappear in the
				// middle of the table
				if ( empty || usedWidth - columns[colIdx].minWidth < 0 ) {
					empty = true;
					display[colIdx] = false;
				}
				else {
					display[colIdx] = true;
				}

				usedWidth -= columns[colIdx].minWidth;
			}
		}

		// Determine if the 'control' column should be shown (if there is one).
		// This is the case when there is a hidden column (that is not the
		// control column). The two loops look inefficient here, but they are
		// trivial and will fly through. We need to know the outcome from the
		// first , before the action in the second can be taken
		var showControl = false;

		for ( i=0, ien=columns.length ; i<ien ; i++ ) {
			if ( ! columns[i].control && ! columns[i].never && ! display[i] ) {
				showControl = true;
				break;
			}
		}

		for ( i=0, ien=columns.length ; i<ien ; i++ ) {
			if ( columns[i].control ) {
				display[i] = showControl;
			}
		}

		// Finally we need to make sure that there is at least one column that
		// is visible
		if ( $.inArray( true, display ) === -1 ) {
			display[0] = true;
		}

		return display;
	},


	/**
	 * Create the internal `columns` array with information about the columns
	 * for the table. This includes determining which breakpoints the column
	 * will appear in, based upon class names in the column, which makes up the
	 * vast majority of this method.
	 *
	 * @private
	 */
	_classLogic: function ()
	{
		var that = this;
		var calc = {};
		var breakpoints = this.c.breakpoints;
		var dt = this.s.dt;
		var columns = dt.columns().eq(0).map( function (i) {
			var column = this.column(i);
			var className = column.header().className;
			var priority = dt.settings()[0].aoColumns[i].responsivePriority;

			if ( priority === undefined ) {
				var dataPriority = $(column.header()).data('priority');

				priority = dataPriority !== undefined ?
					dataPriority * 1 :
					10000;
			}

			return {
				className: className,
				includeIn: [],
				auto:      false,
				control:   false,
				never:     className.match(/\bnever\b/) ? true : false,
				priority:  priority
			};
		} );

		// Simply add a breakpoint to `includeIn` array, ensuring that there are
		// no duplicates
		var add = function ( colIdx, name ) {
			var includeIn = columns[ colIdx ].includeIn;

			if ( $.inArray( name, includeIn ) === -1 ) {
				includeIn.push( name );
			}
		};

		var column = function ( colIdx, name, operator, matched ) {
			var size, i, ien;

			if ( ! operator ) {
				columns[ colIdx ].includeIn.push( name );
			}
			else if ( operator === 'max-' ) {
				// Add this breakpoint and all smaller
				size = that._find( name ).width;

				for ( i=0, ien=breakpoints.length ; i<ien ; i++ ) {
					if ( breakpoints[i].width <= size ) {
						add( colIdx, breakpoints[i].name );
					}
				}
			}
			else if ( operator === 'min-' ) {
				// Add this breakpoint and all larger
				size = that._find( name ).width;

				for ( i=0, ien=breakpoints.length ; i<ien ; i++ ) {
					if ( breakpoints[i].width >= size ) {
						add( colIdx, breakpoints[i].name );
					}
				}
			}
			else if ( operator === 'not-' ) {
				// Add all but this breakpoint
				for ( i=0, ien=breakpoints.length ; i<ien ; i++ ) {
					if ( breakpoints[i].name.indexOf( matched ) === -1 ) {
						add( colIdx, breakpoints[i].name );
					}
				}
			}
		};

		// Loop over each column and determine if it has a responsive control
		// class
		columns.each( function ( col, i ) {
			var classNames = col.className.split(' ');
			var hasClass = false;

			// Split the class name up so multiple rules can be applied if needed
			for ( var k=0, ken=classNames.length ; k<ken ; k++ ) {
				var className = $.trim( classNames[k] );

				if ( className === 'all' ) {
					// Include in all
					hasClass = true;
					col.includeIn = $.map( breakpoints, function (a) {
						return a.name;
					} );
					return;
				}
				else if ( className === 'none' || col.never ) {
					// Include in none (default) and no auto
					hasClass = true;
					return;
				}
				else if ( className === 'control' ) {
					// Special column that is only visible, when one of the other
					// columns is hidden. This is used for the details control
					hasClass = true;
					col.control = true;
					return;
				}

				$.each( breakpoints, function ( j, breakpoint ) {
					// Does this column have a class that matches this breakpoint?
					var brokenPoint = breakpoint.name.split('-');
					var re = new RegExp( '(min\\-|max\\-|not\\-)?('+brokenPoint[0]+')(\\-[_a-zA-Z0-9])?' );
					var match = className.match( re );

					if ( match ) {
						hasClass = true;

						if ( match[2] === brokenPoint[0] && match[3] === '-'+brokenPoint[1] ) {
							// Class name matches breakpoint name fully
							column( i, breakpoint.name, match[1], match[2]+match[3] );
						}
						else if ( match[2] === brokenPoint[0] && ! match[3] ) {
							// Class name matched primary breakpoint name with no qualifier
							column( i, breakpoint.name, match[1], match[2] );
						}
					}
				} );
			}

			// If there was no control class, then automatic sizing is used
			if ( ! hasClass ) {
				col.auto = true;
			}
		} );

		this.s.columns = columns;
	},


	/**
	 * Show the details for the child row
	 *
	 * @param  {DataTables.Api} row    API instance for the row
	 * @param  {boolean}        update Update flag
	 * @private
	 */
	_detailsDisplay: function ( row, update )
	{
		var that = this;
		var dt = this.s.dt;
		var details = this.c.details;

		if ( details && details.type !== false ) {
			var res = details.display( row, update, function () {
				return details.renderer(
					dt, row[0], that._detailsObj(row[0])
				);
			} );

			if ( res === true || res === false ) {
				$(dt.table().node()).triggerHandler( 'responsive-display.dt', [dt, row, res, update] );
			}
		}
	},


	/**
	 * Initialisation for the details handler
	 *
	 * @private
	 */
	_detailsInit: function ()
	{
		var that    = this;
		var dt      = this.s.dt;
		var details = this.c.details;

		// The inline type always uses the first child as the target
		if ( details.type === 'inline' ) {
			details.target = 'td:first-child, th:first-child';
		}

		// Keyboard accessibility
		dt.on( 'draw.dtr', function () {
			that._tabIndexes();
		} );
		that._tabIndexes(); // Initial draw has already happened

		$( dt.table().body() ).on( 'keyup.dtr', 'td, th', function (e) {
			if ( e.keyCode === 13 && $(this).data('dtr-keyboard') ) {
				$(this).click();
			}
		} );

		// type.target can be a string jQuery selector or a column index
		var target   = details.target;
		var selector = typeof target === 'string' ? target : 'td, th';

		// Click handler to show / hide the details rows when they are available
		$( dt.table().body() )
			.on( 'click.dtr mousedown.dtr mouseup.dtr', selector, function (e) {
				// If the table is not collapsed (i.e. there is no hidden columns)
				// then take no action
				if ( ! $(dt.table().node()).hasClass('collapsed' ) ) {
					return;
				}

				// Check that the row is actually a DataTable's controlled node
				if ( $.inArray( $(this).closest('tr').get(0), dt.rows().nodes().toArray() ) === -1 ) {
					return;
				}

				// For column index, we determine if we should act or not in the
				// handler - otherwise it is already okay
				if ( typeof target === 'number' ) {
					var targetIdx = target < 0 ?
						dt.columns().eq(0).length + target :
						target;

					if ( dt.cell( this ).index().column !== targetIdx ) {
						return;
					}
				}

				// $().closest() includes itself in its check
				var row = dt.row( $(this).closest('tr') );

				// Check event type to do an action
				if ( e.type === 'click' ) {
					// The renderer is given as a function so the caller can execute it
					// only when they need (i.e. if hiding there is no point is running
					// the renderer)
					that._detailsDisplay( row, false );
				}
				else if ( e.type === 'mousedown' ) {
					// For mouse users, prevent the focus ring from showing
					$(this).css('outline', 'none');
				}
				else if ( e.type === 'mouseup' ) {
					// And then re-allow at the end of the click
					$(this).blur().css('outline', '');
				}
			} );
	},


	/**
	 * Get the details to pass to a renderer for a row
	 * @param  {int} rowIdx Row index
	 * @private
	 */
	_detailsObj: function ( rowIdx )
	{
		var that = this;
		var dt = this.s.dt;

		return $.map( this.s.columns, function( col, i ) {
			// Never and control columns should not be passed to the renderer
			if ( col.never || col.control ) {
				return;
			}

			return {
				title:       dt.settings()[0].aoColumns[ i ].sTitle,
				data:        dt.cell( rowIdx, i ).render( that.c.orthogonal ),
				hidden:      dt.column( i ).visible() && !that.s.current[ i ],
				columnIndex: i,
				rowIndex:    rowIdx
			};
		} );
	},


	/**
	 * Find a breakpoint object from a name
	 *
	 * @param  {string} name Breakpoint name to find
	 * @return {object}      Breakpoint description object
	 * @private
	 */
	_find: function ( name )
	{
		var breakpoints = this.c.breakpoints;

		for ( var i=0, ien=breakpoints.length ; i<ien ; i++ ) {
			if ( breakpoints[i].name === name ) {
				return breakpoints[i];
			}
		}
	},


	/**
	 * Re-create the contents of the child rows as the display has changed in
	 * some way.
	 *
	 * @private
	 */
	_redrawChildren: function ()
	{
		var that = this;
		var dt = this.s.dt;

		dt.rows( {page: 'current'} ).iterator( 'row', function ( settings, idx ) {
			var row = dt.row( idx );

			that._detailsDisplay( dt.row( idx ), true );
		} );
	},


	/**
	 * Alter the table display for a resized viewport. This involves first
	 * determining what breakpoint the window currently is in, getting the
	 * column visibilities to apply and then setting them.
	 *
	 * @private
	 */
	_resize: function ()
	{
		var that = this;
		var dt = this.s.dt;
		var width = $(window).width();
		var breakpoints = this.c.breakpoints;
		var breakpoint = breakpoints[0].name;
		var columns = this.s.columns;
		var i, ien;
		var oldVis = this.s.current.slice();

		// Determine what breakpoint we are currently at
		for ( i=breakpoints.length-1 ; i>=0 ; i-- ) {
			if ( width <= breakpoints[i].width ) {
				breakpoint = breakpoints[i].name;
				break;
			}
		}
		
		// Show the columns for that break point
		var columnsVis = this._columnsVisiblity( breakpoint );
		this.s.current = columnsVis;

		// Set the class before the column visibility is changed so event
		// listeners know what the state is. Need to determine if there are
		// any columns that are not visible but can be shown
		var collapsedClass = false;
		for ( i=0, ien=columns.length ; i<ien ; i++ ) {
			if ( columnsVis[i] === false && ! columns[i].never && ! columns[i].control ) {
				collapsedClass = true;
				break;
			}
		}

		$( dt.table().node() ).toggleClass( 'collapsed', collapsedClass );

		var changed = false;

		dt.columns().eq(0).each( function ( colIdx, i ) {
			if ( columnsVis[i] !== oldVis[i] ) {
				changed = true;
				that._setColumnVis( colIdx, columnsVis[i] );
			}
		} );

		if ( changed ) {
			this._redrawChildren();

			// Inform listeners of the change
			$(dt.table().node()).trigger( 'responsive-resize.dt', [dt, this.s.current] );

			// If no records, update the "No records" display element
			if ( dt.page.info().recordsDisplay === 0 ) {
				dt.draw();
			}
		}
	},


	/**
	 * Determine the width of each column in the table so the auto column hiding
	 * has that information to work with. This method is never going to be 100%
	 * perfect since column widths can change slightly per page, but without
	 * seriously compromising performance this is quite effective.
	 *
	 * @private
	 */
	_resizeAuto: function ()
	{
		var dt = this.s.dt;
		var columns = this.s.columns;

		// Are we allowed to do auto sizing?
		if ( ! this.c.auto ) {
			return;
		}

		// Are there any columns that actually need auto-sizing, or do they all
		// have classes defined
		if ( $.inArray( true, $.map( columns, function (c) { return c.auto; } ) ) === -1 ) {
			return;
		}

		// Need to restore all children. They will be reinstated by a re-render
		if ( ! $.isEmptyObject( _childNodeStore ) ) {
			$.each( _childNodeStore, function ( key ) {
				var idx = key.split('-');

				_childNodesRestore( dt, idx[0]*1, idx[1]*1 );
			} );
		}

		// Clone the table with the current data in it
		var tableWidth   = dt.table().node().offsetWidth;
		var columnWidths = dt.columns;
		var clonedTable  = dt.table().node().cloneNode( false );
		var clonedHeader = $( dt.table().header().cloneNode( false ) ).appendTo( clonedTable );
		var clonedBody   = $( dt.table().body() ).clone( false, false ).empty().appendTo( clonedTable ); // use jQuery because of IE8

		// Header
		var headerCells = dt.columns()
			.header()
			.filter( function (idx) {
				return dt.column(idx).visible();
			} )
			.to$()
			.clone( false )
			.css( 'display', 'table-cell' );

		// Body rows - we don't need to take account of DataTables' column
		// visibility since we implement our own here (hence the `display` set)
		$(clonedBody)
			.append( $(dt.rows( { page: 'current' } ).nodes()).clone( false ) )
			.find( 'th, td' ).css( 'display', '' );

		// Footer
		var footer = dt.table().footer();
		if ( footer ) {
			var clonedFooter = $( footer.cloneNode( false ) ).appendTo( clonedTable );
			var footerCells = dt.columns()
				.footer()
				.filter( function (idx) {
					return dt.column(idx).visible();
				} )
				.to$()
				.clone( false )
				.css( 'display', 'table-cell' );

			$('<tr/>')
				.append( footerCells )
				.appendTo( clonedFooter );
		}

		$('<tr/>')
			.append( headerCells )
			.appendTo( clonedHeader );

		// In the inline case extra padding is applied to the first column to
		// give space for the show / hide icon. We need to use this in the
		// calculation
		if ( this.c.details.type === 'inline' ) {
			$(clonedTable).addClass( 'dtr-inline collapsed' );
		}
		
		// It is unsafe to insert elements with the same name into the DOM
		// multiple times. For example, cloning and inserting a checked radio
		// clears the chcecked state of the original radio.
		$( clonedTable ).find( '[name]' ).removeAttr( 'name' );
		
		var inserted = $('<div/>')
			.css( {
				width: 1,
				height: 1,
				overflow: 'hidden',
				clear: 'both'
			} )
			.append( clonedTable );

		inserted.insertBefore( dt.table().node() );

		// The cloned header now contains the smallest that each column can be
		headerCells.each( function (i) {
			var idx = dt.column.index( 'fromVisible', i );
			columns[ idx ].minWidth =  this.offsetWidth || 0;
		} );

		inserted.remove();
	},

	/**
	 * Set a column's visibility.
	 *
	 * We don't use DataTables' column visibility controls in order to ensure
	 * that column visibility can Responsive can no-exist. Since only IE8+ is
	 * supported (and all evergreen browsers of course) the control of the
	 * display attribute works well.
	 *
	 * @param {integer} col      Column index
	 * @param {boolean} showHide Show or hide (true or false)
	 * @private
	 */
	_setColumnVis: function ( col, showHide )
	{
		var dt = this.s.dt;
		var display = showHide ? '' : 'none'; // empty string will remove the attr

		$( dt.column( col ).header() ).css( 'display', display );
		$( dt.column( col ).footer() ).css( 'display', display );
		dt.column( col ).nodes().to$().css( 'display', display );

		// If the are child nodes stored, we might need to reinsert them
		if ( ! $.isEmptyObject( _childNodeStore ) ) {
			dt.cells( null, col ).indexes().each( function (idx) {
				_childNodesRestore( dt, idx.row, idx.column );
			} );
		}
	},


	/**
	 * Update the cell tab indexes for keyboard accessibility. This is called on
	 * every table draw - that is potentially inefficient, but also the least
	 * complex option given that column visibility can change on the fly. Its a
	 * shame user-focus was removed from CSS 3 UI, as it would have solved this
	 * issue with a single CSS statement.
	 *
	 * @private
	 */
	_tabIndexes: function ()
	{
		var dt = this.s.dt;
		var cells = dt.cells( { page: 'current' } ).nodes().to$();
		var ctx = dt.settings()[0];
		var target = this.c.details.target;

		cells.filter( '[data-dtr-keyboard]' ).removeData( '[data-dtr-keyboard]' );

		var selector = typeof target === 'number' ?
			':eq('+target+')' :
			target;

		// This is a bit of a hack - we need to limit the selected nodes to just
		// those of this table
		if ( selector === 'td:first-child, th:first-child' ) {
			selector = '>td:first-child, >th:first-child';
		}

		$( selector, dt.rows( { page: 'current' } ).nodes() )
			.attr( 'tabIndex', ctx.iTabIndex )
			.data( 'dtr-keyboard', 1 );
	}
} );


/**
 * List of default breakpoints. Each item in the array is an object with two
 * properties:
 *
 * * `name` - the breakpoint name.
 * * `width` - the breakpoint width
 *
 * @name Responsive.breakpoints
 * @static
 */
Responsive.breakpoints = [
	{ name: 'desktop',  width: Infinity },
	{ name: 'tablet-l', width: 1024 },
	{ name: 'tablet-p', width: 768 },
	{ name: 'mobile-l', width: 480 },
	{ name: 'mobile-p', width: 320 }
];


/**
 * Display methods - functions which define how the hidden data should be shown
 * in the table.
 *
 * @namespace
 * @name Responsive.defaults
 * @static
 */
Responsive.display = {
	childRow: function ( row, update, render ) {
		if ( update ) {
			if ( $(row.node()).hasClass('parent') ) {
				row.child( render(), 'child' ).show();

				return true;
			}
		}
		else {
			if ( ! row.child.isShown()  ) {
				row.child( render(), 'child' ).show();
				$( row.node() ).addClass( 'parent' );

				return true;
			}
			else {
				row.child( false );
				$( row.node() ).removeClass( 'parent' );

				return false;
			}
		}
	},

	childRowImmediate: function ( row, update, render ) {
		if ( (! update && row.child.isShown()) || ! row.responsive.hasHidden() ) {
			// User interaction and the row is show, or nothing to show
			row.child( false );
			$( row.node() ).removeClass( 'parent' );

			return false;
		}
		else {
			// Display
			row.child( render(), 'child' ).show();
			$( row.node() ).addClass( 'parent' );

			return true;
		}
	},

	// This is a wrapper so the modal options for Bootstrap and jQuery UI can
	// have options passed into them. This specific one doesn't need to be a
	// function but it is for consistency in the `modal` name
	modal: function ( options ) {
		return function ( row, update, render ) {
			if ( ! update ) {
				// Show a modal
				var close = function () {
					modal.remove(); // will tidy events for us
					$(document).off( 'keypress.dtr' );
				};

				var modal = $('<div class="dtr-modal"/>')
					.append( $('<div class="dtr-modal-display"/>')
						.append( $('<div class="dtr-modal-content"/>')
							.append( render() )
						)
						.append( $('<div class="dtr-modal-close">&times;</div>' )
							.click( function () {
								close();
							} )
						)
					)
					.append( $('<div class="dtr-modal-background"/>')
						.click( function () {
							close();
						} )
					)
					.appendTo( 'body' );

				$(document).on( 'keyup.dtr', function (e) {
					if ( e.keyCode === 27 ) {
						e.stopPropagation();

						close();
					}
				} );
			}
			else {
				$('div.dtr-modal-content')
					.empty()
					.append( render() );
			}

			if ( options && options.header ) {
				$('div.dtr-modal-content').prepend(
					'<h2>'+options.header( row )+'</h2>'
				);
			}
		};
	}
};


var _childNodeStore = {};

function _childNodes( dt, row, col ) {
	var name = row+'-'+col;

	if ( _childNodeStore[ name ] ) {
		return _childNodeStore[ name ];
	}

	// https://jsperf.com/childnodes-array-slice-vs-loop
	var nodes = [];
	var children = dt.cell( row, col ).node().childNodes;
	for ( var i=0, ien=children.length ; i<ien ; i++ ) {
		nodes.push( children[i] );
	}

	_childNodeStore[ name ] = nodes;

	return nodes;
}

function _childNodesRestore( dt, row, col ) {
	var name = row+'-'+col;

	if ( ! _childNodeStore[ name ] ) {
		return;
	}

	var node = dt.cell( row, col ).node();
	var store = _childNodeStore[ name ];
	var parent = store[0].parentNode;
	var parentChildren = parent.childNodes;
	var a = [];

	for ( var i=0, ien=parentChildren.length ; i<ien ; i++ ) {
		a.push( parentChildren[i] );
	}

	for ( var j=0, jen=a.length ; j<jen ; j++ ) {
		node.appendChild( a[j] );
	}

	_childNodeStore[ name ] = undefined;
}


/**
 * Display methods - functions which define how the hidden data should be shown
 * in the table.
 *
 * @namespace
 * @name Responsive.defaults
 * @static
 */
Responsive.renderer = {
	listHiddenNodes: function () {
		return function ( api, rowIdx, columns ) {
			var ul = $('<ul data-dtr-index="'+rowIdx+'" class="dtr-details"/>');
			var found = false;

			var data = $.each( columns, function ( i, col ) {
				if ( col.hidden ) {
					$(
						'<li data-dtr-index="'+col.columnIndex+'" data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
							'<span class="dtr-title">'+
								col.title+
							'</span> '+
						'</li>'
					)
						.append( $('<span class="dtr-data"/>').append( _childNodes( api, col.rowIndex, col.columnIndex ) ) )// api.cell( col.rowIndex, col.columnIndex ).node().childNodes ) )
						.appendTo( ul );

					found = true;
				}
			} );

			return found ?
				ul :
				false;
		};
	},

	listHidden: function () {
		return function ( api, rowIdx, columns ) {
			var data = $.map( columns, function ( col ) {
				return col.hidden ?
					'<li data-dtr-index="'+col.columnIndex+'" data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
						'<span class="dtr-title">'+
							col.title+
						'</span> '+
						'<span class="dtr-data">'+
							col.data+
						'</span>'+
					'</li>' :
					'';
			} ).join('');

			return data ?
				$('<ul data-dtr-index="'+rowIdx+'" class="dtr-details"/>').append( data ) :
				false;
		}
	},

	tableAll: function ( options ) {
		options = $.extend( {
			tableClass: ''
		}, options );

		return function ( api, rowIdx, columns ) {
			var data = $.map( columns, function ( col ) {
				return '<tr data-dt-row="'+col.rowIndex+'" data-dt-column="'+col.columnIndex+'">'+
						'<td>'+col.title+':'+'</td> '+
						'<td>'+col.data+'</td>'+
					'</tr>';
			} ).join('');

			return $('<table class="'+options.tableClass+' dtr-details" width="100%"/>').append( data );
		}
	}
};

/**
 * Responsive default settings for initialisation
 *
 * @namespace
 * @name Responsive.defaults
 * @static
 */
Responsive.defaults = {
	/**
	 * List of breakpoints for the instance. Note that this means that each
	 * instance can have its own breakpoints. Additionally, the breakpoints
	 * cannot be changed once an instance has been creased.
	 *
	 * @type {Array}
	 * @default Takes the value of `Responsive.breakpoints`
	 */
	breakpoints: Responsive.breakpoints,

	/**
	 * Enable / disable auto hiding calculations. It can help to increase
	 * performance slightly if you disable this option, but all columns would
	 * need to have breakpoint classes assigned to them
	 *
	 * @type {Boolean}
	 * @default  `true`
	 */
	auto: true,

	/**
	 * Details control. If given as a string value, the `type` property of the
	 * default object is set to that value, and the defaults used for the rest
	 * of the object - this is for ease of implementation.
	 *
	 * The object consists of the following properties:
	 *
	 * * `display` - A function that is used to show and hide the hidden details
	 * * `renderer` - function that is called for display of the child row data.
	 *   The default function will show the data from the hidden columns
	 * * `target` - Used as the selector for what objects to attach the child
	 *   open / close to
	 * * `type` - `false` to disable the details display, `inline` or `column`
	 *   for the two control types
	 *
	 * @type {Object|string}
	 */
	details: {
		display: Responsive.display.childRow,

		renderer: Responsive.renderer.listHidden(),

		target: 0,

		type: 'inline'
	},

	/**
	 * Orthogonal data request option. This is used to define the data type
	 * requested when Responsive gets the data to show in the child row.
	 *
	 * @type {String}
	 */
	orthogonal: 'display'
};


/*
 * API
 */
var Api = $.fn.dataTable.Api;

// Doesn't do anything - work around for a bug in DT... Not documented
Api.register( 'responsive()', function () {
	return this;
} );

Api.register( 'responsive.index()', function ( li ) {
	li = $(li);

	return {
		column: li.data('dtr-index'),
		row:    li.parent().data('dtr-index')
	};
} );

Api.register( 'responsive.rebuild()', function () {
	return this.iterator( 'table', function ( ctx ) {
		if ( ctx._responsive ) {
			ctx._responsive._classLogic();
		}
	} );
} );

Api.register( 'responsive.recalc()', function () {
	return this.iterator( 'table', function ( ctx ) {
		if ( ctx._responsive ) {
			ctx._responsive._resizeAuto();
			ctx._responsive._resize();
		}
	} );
} );

Api.register( 'responsive.hasHidden()', function () {
	var ctx = this.context[0];

	return ctx._responsive ?
		$.inArray( false, ctx._responsive.s.current ) !== -1 :
		false;
} );


/**
 * Version information
 *
 * @name Responsive.version
 * @static
 */
Responsive.version = '2.2.0';


$.fn.dataTable.Responsive = Responsive;
$.fn.DataTable.Responsive = Responsive;

// Attach a listener to the document which listens for DataTables initialisation
// events so we can automatically initialise
$(document).on( 'preInit.dt.dtr', function (e, settings, json) {
	if ( e.namespace !== 'dt' ) {
		return;
	}

	if ( $(settings.nTable).hasClass( 'responsive' ) ||
		 $(settings.nTable).hasClass( 'dt-responsive' ) ||
		 settings.oInit.responsive ||
		 DataTable.defaults.responsive
	) {
		var init = settings.oInit.responsive;

		if ( init !== false ) {
			new Responsive( settings, $.isPlainObject( init ) ? init : {}  );
		}
	}
} );


return Responsive;
}));


